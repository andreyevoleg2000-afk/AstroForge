# Orbital Lab integration

The main-screen **3D визуализатор** entry opens `OrbitalLabActivity`, which renders
`app/src/main/assets/orbital_lab/index.html` in an Android `WebView`.

All HTML, CSS, JavaScript application modules, and image textures from the supplied
Orbital Lab archive are packaged in the app. The WebView serves them from the local
`https://appassets.androidplatform.net/assets/orbital_lab/` origin so JavaScript ES
modules and relative asset paths work without `file://` access. The WebView is
hardware-accelerated, full-screen, and handles Android Back inside the Activity.

The supplied Orbital Lab 1.4.1 page imports Three.js 0.180.0 from jsDelivr using its
original import map. That third-party library was not included in the supplied game
archive and could not be fetched in this build environment. The page therefore still
needs an internet connection for the Three.js engine (and its optional Google Fonts).
A visible retry notice is shown if the module script fails to load. No external browser
activity is launched.


## Importing into AIDE Plus

Open/import the Android project directory `AstroForge-8-styled-roche-limit` (the
directory containing `settings.gradle`). Do not open `app/src/main/assets/orbital_lab`
as a project: it is only a folder of web assets and has no Gradle module. Android
packages everything under `app/src/main/assets` into the APK automatically.

The archive intentionally excludes `app/build` and other generated build caches.
AIDE/Gradle must regenerate those files for the current device and build environment.
