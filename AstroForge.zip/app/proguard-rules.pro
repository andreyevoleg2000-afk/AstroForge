# AstroForge ProGuard rules
-keepattributes *Annotation*
-keep class com.astroforge.** { *; }
