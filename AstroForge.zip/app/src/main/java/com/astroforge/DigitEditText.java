package com.astroforge;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.widget.EditText;

/** EditText where typed digits are automatically switched to Quintessential. */
final class DigitEditText extends EditText {

    private boolean applyingDigitSpans;

    DigitEditText(Context context) {
        super(context);
        installWatcher();
    }

    DigitEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        installWatcher();
    }

    DigitEditText(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        installWatcher();
    }

    private void installWatcher() {
        addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Nothing to do.
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Spans are applied in afterTextChanged so the editable is complete.
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (applyingDigitSpans) {
                    return;
                }

                applyingDigitSpans = true;
                DigitFont.applyToSpannable(getContext(), s);
                applyingDigitSpans = false;
            }
        });
    }

    @Override
    public void setText(CharSequence text, BufferType type) {
        super.setText(DigitFont.apply(getContext(), text), type);
    }

}
