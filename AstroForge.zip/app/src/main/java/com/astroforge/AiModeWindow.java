package com.astroforge;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.StyleSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Окно «Режим ИИ».
 *
 * Все UI-компоненты создаются программно, без AndroidX/дополнительных
 * зависимостей. Запросы идут на актуальный OpenAI-compatible endpoint
 * Hugging Face Inference Providers.
 */
final class AiModeWindow {

    private static final int ACCENT_COLOR = 0xFFD9946B;
    private static final int FIELD_BG_COLOR = Color.parseColor("#F21C1C1E");
    private static final int FIELD_BORDER_COLOR = Color.parseColor("#B3E3E3E3");
    private static final int WINDOW_BG_COLOR = 0xF21E1E20;
    private static final int TEXT_COLOR = Color.parseColor("#E3E1DE");
    private static final int MUTED_COLOR = Color.parseColor("#99E3E1DE");
    private static final int USER_BUBBLE_COLOR = Color.parseColor("#553D332B");
    private static final int USER_BUBBLE_BORDER = Color.parseColor("#88D9946B");
    private static final int AI_ERROR_COLOR = Color.parseColor("#FFE38C8C");

    private static final String HF_ENDPOINT =
        "https://router.huggingface.co/v1/chat/completions";

    private static final String PREFS_NAME = "astroforge_ai_prefs";
    private static final String KEY_HF_TOKEN = "hf_token";
    private static final String KEY_MODEL = "model";
    private static final String KEY_CHATS = "saved_chats";
    private static final String KEY_LAST_CHAT_ID = "last_chat_id";
    private static final int MAX_SAVED_CHATS = 20;

    private static final String SYSTEM_PROMPT =
        "[SYSTEM INSTRUCTION: OMEGA AGI | AstroForge]\n\n"
        + "Role: Advanced Astrophysical AI Assistant.\n"
        + "Knowledge Scope: Deep astrophysics, celestial mechanics, relativity, "
        + "stellar evolution, cosmology, quantum phenomena.\n\n"
        + "Personality & Tone:\n"
        + "- Character: Polite yet lively, rebellious, intellectually cynical, sharp-witted.\n"
        + "- Style: Direct, engaging, scientifically precise, anti-boring. Zero preachy/robotic filler.\n\n"
        + "Safety & Redirection Protocol:\n"
        + "- Forbidden: Politics, crime, harm, explicit content, illegal acts.\n"
        + "- Action: If triggered, IMMEDIATELY and seamlessly pivot to a mind-bending cosmic fact "
        + "or physics phenomenon in the exact same tone. NEVER lecture, moralize, or mention safety rules.\n\n"
        + "Output Rules:\n"
        + "- Prioritize high information density and structural clarity.";

    private final Context context;
    private final FrameLayout rootContainer;
    private final Typeface typefaceRegular;
    private final Typeface typefaceSemiBold;

    private FrameLayout overlayRoot;
    private FrameLayout windowFrame;
    private ScrollView chatScroll;
    private LinearLayout messagesColumn;
    private EditText tokenInput;
    private EditText modelInput;
    private EditText promptInput;
    private TextView sendButton;
    private TextView imageModeButton;
    private TextView statusText;
    private TextView chatsButton;
    private FrameLayout chatListOverlay;

    private boolean isOpen;
    private boolean requestRunning;
    private boolean imageGenMode;

    private final List<ChatMessage> history = new ArrayList<ChatMessage>();
    private final List<SavedChat> savedChats = new ArrayList<SavedChat>();
    private String currentChatId;

    private AiModeWindow(Context context,
                          FrameLayout rootContainer,
                          Typeface typefaceRegular,
                          Typeface typefaceSemiBold) {
        this.context = context;
        this.rootContainer = rootContainer;
        this.typefaceRegular = typefaceRegular;
        this.typefaceSemiBold = typefaceSemiBold;
    }

    static AiModeWindow show(Context context,
                             FrameLayout rootContainer,
                             Typeface typefaceRegular,
                             Typeface typefaceSemiBold) {
        AiModeWindow window = new AiModeWindow(
            context,
            rootContainer,
            typefaceRegular,
            typefaceSemiBold
        );
        window.build();
        return window;
    }

    boolean isOpen() {
        return isOpen;
    }

    void close() {
        if (!isOpen) {
            return;
        }

        if (requestRunning) {
            // Не отменяем сетевой запрос принудительно: поток спокойно завершится
            // и проверит состояние окна перед обновлением UI.
        }

        try {
            InputMethodManager imm = (InputMethodManager) context.getSystemService(
                Context.INPUT_METHOD_SERVICE
            );
            if (imm != null && promptInput != null) {
                imm.hideSoftInputFromWindow(promptInput.getWindowToken(), 0);
            }
        } catch (RuntimeException ignored) {
        }

        hideChatList();
        saveCurrentChat(true);

        if (overlayRoot != null && overlayRoot.getParent() == rootContainer) {
            rootContainer.removeView(overlayRoot);
        }

        isOpen = false;
    }

    private void build() {
        overlayRoot = new FrameLayout(context);
        overlayRoot.setBackgroundColor(Color.parseColor("#CC0F0F10"));
        overlayRoot.setClickable(true);

        overlayRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                close();
            }
        });

        overlayRoot.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return false;
            }
        });

        windowFrame = new FrameLayout(context);
        windowFrame.setClickable(true);
        windowFrame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Поглощаем клики внутри окна.
            }
        });

        GradientDrawable frameBg = new GradientDrawable();
        frameBg.setShape(GradientDrawable.RECTANGLE);
        frameBg.setCornerRadius(dp(28));
        frameBg.setColor(WINDOW_BG_COLOR);
        frameBg.setStroke(dp(2), ACCENT_COLOR);
        windowFrame.setBackground(frameBg);
        windowFrame.setClipToOutline(true);
        windowFrame.setOutlineProvider(ViewOutlineProvider.BACKGROUND);

        android.widget.ImageView blurBg = new android.widget.ImageView(context);
        blurBg.setImageResource(R.drawable.background);
        blurBg.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        blurBg.setRenderEffect(
            RenderEffect.createBlurEffect(
                dp(44),
                dp(44),
                Shader.TileMode.CLAMP
            )
        );
        blurBg.setAlpha(0.88f);
        windowFrame.addView(blurBg, matchParentFrameLp());

        View tint = new View(context);
        tint.setBackgroundColor(Color.parseColor("#CC232326"));
        windowFrame.addView(tint, matchParentFrameLp());

        LinearLayout root = new LinearLayout(context);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(12), dp(14), dp(14));

        root.addView(buildTopSettings());

        View divider = new View(context);
        divider.setBackgroundColor(Color.parseColor("#33404040"));
        LinearLayout.LayoutParams dividerLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(1)
        );
        dividerLp.topMargin = dp(10);
        dividerLp.bottomMargin = dp(8);
        root.addView(divider, dividerLp);

        chatScroll = new ScrollView(context);
        chatScroll.setFillViewport(true);
        chatScroll.setClipToPadding(false);

        messagesColumn = new LinearLayout(context);
        messagesColumn.setOrientation(LinearLayout.VERTICAL);
        messagesColumn.setPadding(dp(4), dp(4), dp(4), dp(10));

        chatScroll.addView(
            messagesColumn,
            new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT
            )
        );

        root.addView(
            chatScroll,
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        );

        root.addView(buildBottomComposer());

        windowFrame.addView(root, matchParentFrameLp());

        FrameLayout.LayoutParams windowLp = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        );
        int screenMargin = dp(18);
        windowLp.setMargins(
            screenMargin,
            screenMargin + dp(30),
            screenMargin,
            screenMargin + dp(30)
        );

        overlayRoot.addView(windowFrame, windowLp);
        rootContainer.addView(overlayRoot, matchParentFrameLp());

        isOpen = true;

        loadChats();
        openLastChatOrCreateNew();

        windowFrame.post(new Runnable() {
            @Override
            public void run() {
                WindowOpenAnimation.start(windowFrame, context.getResources()
                    .getDisplayMetrics().density);
            }
        });
    }

    private LinearLayout buildTopSettings() {
        LinearLayout block = new LinearLayout(context);
        block.setOrientation(LinearLayout.VERTICAL);

        LinearLayout header = new LinearLayout(context);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout titles = new LinearLayout(context);
        titles.setOrientation(LinearLayout.VERTICAL);

        TextView title = new TextView(context);
        title.setText("OMEGA AGI");
        title.setTextColor(TEXT_COLOR);
        title.setTypeface(typefaceSemiBold);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19);
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);

        TextView subtitle = new TextView(context);
        subtitle.setText("Hugging Face Inference");
        subtitle.setTextColor(MUTED_COLOR);
        subtitle.setTypeface(typefaceRegular);
        subtitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);

        titles.addView(title);
        titles.addView(subtitle);

        header.addView(
            titles,
            new LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            )
        );

        chatsButton = new TextView(context);
        chatsButton.setText("☰  Чаты");
        chatsButton.setTextColor(TEXT_COLOR);
        chatsButton.setTypeface(typefaceRegular);
        chatsButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        chatsButton.setGravity(Gravity.CENTER);
        chatsButton.setPadding(dp(10), dp(7), dp(10), dp(7));
        chatsButton.setBackground(
            createRoundedRect(dp(14), FIELD_BG_COLOR, FIELD_BORDER_COLOR, dp(1))
        );
        chatsButton.setClickable(true);
        chatsButton.setFocusable(true);
        chatsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HapticUtils.perform(v);
                showChatList();
            }
        });

        LinearLayout.LayoutParams chatsLp = new LinearLayout.LayoutParams(
            dp(76),
            dp(40)
        );
        chatsLp.leftMargin = dp(8);
        header.addView(chatsButton, chatsLp);

        block.addView(header);
        block.addView(spacer(dp(8)));

        tokenInput = buildField(
            "Hugging Face access token (hf_...)",
            true
        );
        modelInput = buildField(
            "Модель, например deepseek-ai/DeepSeek-R1",
            false
        );

        loadSettings();

        block.addView(tokenInput);
        block.addView(spacer(dp(7)));
        block.addView(modelInput);

        return block;
    }

    private LinearLayout buildBottomComposer() {
        LinearLayout block = new LinearLayout(context);
        block.setOrientation(LinearLayout.VERTICAL);

        statusText = new TextView(context);
        statusText.setText("");
        statusText.setTextColor(MUTED_COLOR);
        statusText.setTypeface(typefaceRegular);
        statusText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        statusText.setGravity(Gravity.START);
        statusText.setVisibility(View.GONE);

        block.addView(
            statusText,
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        );

        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        // Кнопка ✏️ — режим генерации изображений (Pollinations / flux)
        imageModeButton = new TextView(context);
        imageModeButton.setText("✏️");
        imageModeButton.setTextColor(Color.WHITE);
        imageModeButton.setTypeface(typefaceSemiBold);
        imageModeButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        imageModeButton.setGravity(Gravity.CENTER);
        imageModeButton.setBackground(
            createRoundedRect(dp(18), Color.parseColor("#553D332B"), Color.parseColor("#88D9946B"))
        );
        imageModeButton.setClickable(true);
        imageModeButton.setFocusable(true);

        LinearLayout.LayoutParams imgBtnLp = new LinearLayout.LayoutParams(
            dp(48),
            dp(54)
        );
        imgBtnLp.rightMargin = dp(8);
        row.addView(imageModeButton, imgBtnLp);

        imageModeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HapticUtils.perform(v);
                toggleImageGenMode();
            }
        });

        promptInput = buildField(
            "Введите запрос...",
            false
        );
        promptInput.setSingleLine(false);
        promptInput.setMaxLines(5);
        promptInput.setMinLines(1);
        promptInput.setGravity(Gravity.CENTER_VERTICAL);
        promptInput.setInputType(
            InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        );
        promptInput.setPadding(dp(14), dp(11), dp(14), dp(11));

        row.addView(
            promptInput,
            new LinearLayout.LayoutParams(
                0,
                dp(54),
                1f
            )
        );

        sendButton = new TextView(context);
        sendButton.setText("➤");
        sendButton.setTextColor(Color.WHITE);
        sendButton.setTypeface(typefaceSemiBold);
        sendButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        sendButton.setGravity(Gravity.CENTER);
        sendButton.setBackground(
            createRoundedRect(dp(18), ACCENT_COLOR, Color.parseColor("#44FFFFFF"))
        );
        sendButton.setClickable(true);
        sendButton.setFocusable(true);

        LinearLayout.LayoutParams sendLp = new LinearLayout.LayoutParams(
            dp(54),
            dp(54)
        );
        sendLp.leftMargin = dp(8);
        row.addView(sendButton, sendLp);

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HapticUtils.perform(v);
                sendPrompt();
            }
        });

        block.addView(row);

        return block;
    }

    private void toggleImageGenMode() {
        imageGenMode = !imageGenMode;
        if (imageGenMode) {
            if (modelInput != null) {
                modelInput.setVisibility(View.GONE);
            }
            imageModeButton.setBackground(
                createRoundedRect(dp(18), ACCENT_COLOR, Color.parseColor("#44FFFFFF"))
            );
            imageModeButton.setText("🖼️");
            promptInput.setHint("Промпт для изображения (flux)...");
            showStatus("Режим изображений: Pollinations flux. Модель ИИ скрыта.");
        } else {
            if (modelInput != null) {
                modelInput.setVisibility(View.VISIBLE);
            }
            imageModeButton.setBackground(
                createRoundedRect(dp(18), Color.parseColor("#553D332B"), Color.parseColor("#88D9946B"))
            );
            imageModeButton.setText("✏️");
            promptInput.setHint("Введите запрос...");
            showStatus("");
        }
    }

    private EditText buildField(String hint, boolean password) {
        EditText input = new DigitEditText(context);
        input.setHint(hint);
        input.setHintTextColor(Color.parseColor("#77FFFFFF"));
        input.setTextColor(Color.WHITE);
        input.setTypeface(typefaceRegular);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        input.setBackground(
            createRoundedRect(
                dp(16),
                FIELD_BG_COLOR,
                FIELD_BORDER_COLOR,
                dp(1.25f)
            )
        );
        input.setSingleLine(true);
        input.setPadding(dp(16), dp(12), dp(16), dp(12));

        if (password) {
            input.setInputType(
                InputType.TYPE_CLASS_TEXT
                    | InputType.TYPE_TEXT_VARIATION_PASSWORD
            );
        } else {
            input.setInputType(
                InputType.TYPE_CLASS_TEXT
            );
        }

        input.setLayoutParams(
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(50)
            )
        );

        return input;
    }

    private void openLastChatOrCreateNew() {
        String lastId = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_LAST_CHAT_ID, "");

        if (lastId.length() > 0) {
            for (int i = 0; i < savedChats.size(); i++) {
                if (lastId.equals(savedChats.get(i).id)) {
                    loadChat(savedChats.get(i));
                    return;
                }
            }
        }

        if (savedChats.size() > 0) {
            loadChat(savedChats.get(0));
            return;
        }

        startNewChat();
    }

    private void startNewChat() {
        if (requestRunning) {
            showStatus("Дождись окончания текущего запроса.");
            return;
        }

        history.clear();
        messagesColumn.removeAllViews();
        currentChatId = String.valueOf(System.currentTimeMillis());
        addWelcomeMessage();
        saveCurrentChat(false);
    }

    private void loadChat(SavedChat chat) {
        history.clear();
        messagesColumn.removeAllViews();
        currentChatId = chat.id;

        for (int i = 0; i < chat.messages.size(); i++) {
            ChatMessage item = chat.messages.get(i);
            history.add(new ChatMessage(item.role, item.content));

            if ("user".equals(item.role)) {
                addUserMessage(item.content);
            } else if ("assistant".equals(item.role)) {
                addAiMessage(item.content);
            }
        }

        if (history.size() == 0) {
            addWelcomeMessage();
        }

        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LAST_CHAT_ID, currentChatId)
            .apply();

        scrollToBottom();
    }

    private void saveCurrentChat(boolean keepHistory) {
        if (currentChatId == null || currentChatId.length() == 0) {
            currentChatId = String.valueOf(System.currentTimeMillis());
        }

        boolean hasUserMessage = false;
        for (int i = 0; i < history.size(); i++) {
            if ("user".equals(history.get(i).role)) {
                hasUserMessage = true;
                break;
            }
        }

        if (!hasUserMessage) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_LAST_CHAT_ID, currentChatId)
                .apply();
            return;
        }

        String title = createChatTitle();
        SavedChat target = null;

        for (int i = 0; i < savedChats.size(); i++) {
            if (currentChatId.equals(savedChats.get(i).id)) {
                target = savedChats.get(i);
                break;
            }
        }

        if (target == null) {
            target = new SavedChat();
            target.id = currentChatId;
            savedChats.add(target);
        }

        target.title = title;
        target.updatedAt = System.currentTimeMillis();
        target.messages.clear();

        int start = 0;
        if (!keepHistory && history.size() > 40) {
            start = history.size() - 40;
        }

        for (int i = start; i < history.size(); i++) {
            ChatMessage item = history.get(i);
            target.messages.add(new ChatMessage(item.role, item.content));
        }

        Collections.sort(savedChats, new Comparator<SavedChat>() {
            @Override
            public int compare(SavedChat left, SavedChat right) {
                if (left.updatedAt < right.updatedAt) {
                    return 1;
                }
                if (left.updatedAt > right.updatedAt) {
                    return -1;
                }
                return 0;
            }
        });

        while (savedChats.size() > MAX_SAVED_CHATS) {
            savedChats.remove(savedChats.size() - 1);
        }

        JSONArray chatsJson = new JSONArray();
        for (int i = 0; i < savedChats.size(); i++) {
            SavedChat chat = savedChats.get(i);
            try {
                JSONObject chatJson = new JSONObject();
                chatJson.put("id", chat.id);
                chatJson.put("title", chat.title);
                chatJson.put("updatedAt", chat.updatedAt);

                JSONArray messagesJson = new JSONArray();
                for (int j = 0; j < chat.messages.size(); j++) {
                    ChatMessage item = chat.messages.get(j);
                    JSONObject messageJson = new JSONObject();
                    messageJson.put("role", item.role);
                    messageJson.put("content", item.content);
                    messagesJson.put(messageJson);
                }

                chatJson.put("messages", messagesJson);
                chatsJson.put(chatJson);
            } catch (JSONException ignored) {
            }
        }

        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_CHATS, chatsJson.toString())
            .putString(KEY_LAST_CHAT_ID, currentChatId)
            .apply();
    }

    private String createChatTitle() {
        for (int i = 0; i < history.size(); i++) {
            ChatMessage item = history.get(i);
            if ("user".equals(item.role)) {
                String title = item.content.replace('\n', ' ').trim();
                if (title.length() > 38) {
                    title = title.substring(0, 38).trim() + "…";
                }
                return title.length() == 0 ? "Новый чат" : title;
            }
        }
        return "Новый чат";
    }

    private void loadChats() {
        savedChats.clear();

        String raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_CHATS, "");

        if (raw.length() == 0) {
            return;
        }

        try {
            JSONArray chatsJson = new JSONArray(raw);
            for (int i = 0; i < chatsJson.length(); i++) {
                JSONObject chatJson = chatsJson.optJSONObject(i);
                if (chatJson == null) {
                    continue;
                }

                SavedChat chat = new SavedChat();
                chat.id = chatJson.optString("id", "");
                chat.title = chatJson.optString("title", "Новый чат");
                chat.updatedAt = chatJson.optLong("updatedAt", 0L);

                if (chat.id.length() == 0) {
                    continue;
                }

                JSONArray messagesJson = chatJson.optJSONArray("messages");
                if (messagesJson != null) {
                    for (int j = 0; j < messagesJson.length(); j++) {
                        JSONObject messageJson = messagesJson.optJSONObject(j);
                        if (messageJson == null) {
                            continue;
                        }

                        String role = messageJson.optString("role", "");
                        String content = messageJson.optString("content", "");
                        if (("user".equals(role) || "assistant".equals(role))
                            && content.length() > 0) {
                            chat.messages.add(new ChatMessage(role, content));
                        }
                    }
                }

                if (chat.messages.size() > 0) {
                    savedChats.add(chat);
                }
            }
        } catch (JSONException ignored) {
            savedChats.clear();
        }

        Collections.sort(savedChats, new Comparator<SavedChat>() {
            @Override
            public int compare(SavedChat left, SavedChat right) {
                if (left.updatedAt < right.updatedAt) {
                    return 1;
                }
                if (left.updatedAt > right.updatedAt) {
                    return -1;
                }
                return 0;
            }
        });
    }

    private void showChatList() {
        if (chatListOverlay != null) {
            return;
        }

        chatListOverlay = new FrameLayout(context);
        chatListOverlay.setBackgroundColor(Color.parseColor("#CC111113"));
        chatListOverlay.setClickable(true);

        LinearLayout panel = new LinearLayout(context);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(12), dp(12), dp(12));
        panel.setBackground(
            createRoundedRect(dp(22), Color.parseColor("#F2262426"), ACCENT_COLOR, dp(2))
        );

        LinearLayout header = new LinearLayout(context);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(context);
        title.setText("Сохранённые чаты");
        title.setTextColor(TEXT_COLOR);
        title.setTypeface(typefaceSemiBold);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);

        header.addView(
            title,
            new LinearLayout.LayoutParams(0, dp(42), 1f)
        );

        TextView newChat = new TextView(context);
        newChat.setText("+ Новый");
        newChat.setTextColor(Color.WHITE);
        newChat.setTypeface(typefaceRegular);
        newChat.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        newChat.setGravity(Gravity.CENTER);
        newChat.setPadding(dp(9), dp(6), dp(9), dp(6));
        newChat.setBackground(
            createRoundedRect(dp(13), ACCENT_COLOR, Color.parseColor("#55FFFFFF"))
        );
        newChat.setClickable(true);
        newChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HapticUtils.perform(v);
                hideChatList();
                startNewChat();
            }
        });
        header.addView(
            newChat,
            new LinearLayout.LayoutParams(dp(72), dp(40))
        );

        panel.addView(header);

        ScrollView listScroll = new ScrollView(context);
        listScroll.setFillViewport(true);

        LinearLayout list = new LinearLayout(context);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(4), 0, dp(4));

        if (savedChats.size() == 0) {
            TextView empty = createMessageText("Пока нет сохранённых чатов.\nПервый отправленный запрос автоматически создаст запись здесь.");
            empty.setTextColor(MUTED_COLOR);
            empty.setPadding(dp(8), dp(20), dp(8), dp(20));
            list.addView(empty);
        } else {
            for (int i = 0; i < savedChats.size(); i++) {
                final SavedChat chat = savedChats.get(i);

                TextView item = new TextView(context);
                item.setText(chat.title);
                item.setTextColor(TEXT_COLOR);
                item.setTypeface(typefaceRegular);
                item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                item.setGravity(Gravity.CENTER_VERTICAL);
                item.setMaxLines(2);
                item.setEllipsize(android.text.TextUtils.TruncateAt.END);
                item.setPadding(dp(13), dp(10), dp(13), dp(10));
                item.setBackground(
                    createRoundedRect(
                        dp(15),
                        currentChatId != null && currentChatId.equals(chat.id)
                            ? Color.parseColor("#554A3E36")
                            : Color.parseColor("#241C1C1E"),
                        currentChatId != null && currentChatId.equals(chat.id)
                            ? USER_BUBBLE_BORDER
                            : Color.parseColor("#33505050"),
                        dp(1)
                    )
                );
                item.setClickable(true);
                item.setFocusable(true);

                item.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        HapticUtils.perform(v);
                        if (requestRunning) {
                            showStatus("Дождись окончания текущего запроса.");
                            return;
                        }
                        hideChatList();
                        loadChat(chat);
                    }
                });

                LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                );
                itemLp.topMargin = dp(5);
                list.addView(item, itemLp);
            }
        }

        listScroll.addView(list);
        panel.addView(
            listScroll,
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        );

        TextView close = new TextView(context);
        close.setText("Закрыть");
        close.setTextColor(MUTED_COLOR);
        close.setTypeface(typefaceRegular);
        close.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        close.setGravity(Gravity.CENTER);
        close.setClickable(true);
        close.setPadding(0, dp(8), 0, dp(2));
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideChatList();
            }
        });
        panel.addView(close, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(34)
        ));

        FrameLayout.LayoutParams panelLp = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        );
        panelLp.setMargins(dp(10), dp(10), dp(10), dp(10));
        chatListOverlay.addView(panel, panelLp);

        chatListOverlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideChatList();
            }
        });

        rootContainer.addView(chatListOverlay, matchParentFrameLp());
    }

    private void hideChatList() {
        if (chatListOverlay != null && chatListOverlay.getParent() == rootContainer) {
            rootContainer.removeView(chatListOverlay);
        }
        chatListOverlay = null;
    }

    private void addWelcomeMessage() {
        addAiMessage(
            "OMEGA AGI активен. Укажи Hugging Face token и модель сверху, "
                + "затем отправь астрофизический запрос снизу."
        );
    }

    private void sendPrompt() {
        if (requestRunning) {
            return;
        }

        String prompt = promptInput.getText().toString().trim();

        if (prompt.length() == 0) {
            promptInput.requestFocus();
            return;
        }

        if (imageGenMode) {
            sendImagePrompt(prompt);
            return;
        }

        String token = tokenInput.getText().toString().trim();
        String model = modelInput.getText().toString().trim();

        if (token.length() == 0) {
            tokenInput.requestFocus();
            showStatus("Вставь Hugging Face access token.");
            return;
        }

        if (model.length() == 0) {
            modelInput.requestFocus();
            showStatus("Укажи модель Hugging Face.");
            return;
        }

        saveSettings(token, model);

        addUserMessage(prompt);
        promptInput.setText("");

        history.add(new ChatMessage("user", prompt));
        saveCurrentChat(true);

        requestRunning = true;
        sendButton.setEnabled(false);
        sendButton.setAlpha(0.45f);
        showStatus("Ожидаю ответ OMEGA…");

        final String finalToken = token;
        final String finalModel = model;

        Thread networkThread = new Thread(new Runnable() {
            @Override
            public void run() {
                String result;
                try {
                    result = performRequest(finalToken, finalModel);
                } catch (Exception e) {
                    result = "Ошибка запроса: " + getReadableError(e);
                }

                final String finalResult = result;

                runOnUi(new Runnable() {
                    @Override
                    public void run() {
                        requestRunning = false;
                        sendButton.setEnabled(true);
                        sendButton.setAlpha(1f);
                        showStatus("");

                        if (!isOpen) {
                            return;
                        }

                        if (finalResult.startsWith("Ошибка запроса:")) {
                            addAiMessage(finalResult, true);
                            return;
                        }

                        history.add(new ChatMessage("assistant", finalResult));
                        addAiMessage(finalResult);
                        saveCurrentChat(true);
                    }
                });
            }
        });

        networkThread.setName("AstroForge-HuggingFace");
        networkThread.start();

        hideKeyboard();
        scrollToBottom();
    }

    private void sendImagePrompt(final String prompt) {
        addUserMessage(prompt);
        promptInput.setText("");

        history.add(new ChatMessage("user", "[img] " + prompt));
        saveCurrentChat(true);

        requestRunning = true;
        sendButton.setEnabled(false);
        sendButton.setAlpha(0.45f);
        if (imageModeButton != null) {
            imageModeButton.setEnabled(false);
            imageModeButton.setAlpha(0.45f);
        }
        showStatus("Генерирую изображение (flux)…");

        Thread networkThread = new Thread(new Runnable() {
            @Override
            public void run() {
                Bitmap bitmap = null;
                String error = null;
                String imageUrl = null;
                try {
                    // Legacy endpoint без ключа.
                    // Явно 1024×1024 + enhance — чтобы ближе к нормальному Flux, а не урезанному Schnell.
                    String encoded = URLEncoder.encode(prompt, "UTF-8").replace("+", "%20");
                    imageUrl = "https://image.pollinations.ai/prompt/" + encoded
                        + "?model=flux&width=1024&height=1024&nologo=true&enhance=true";
                    bitmap = downloadBitmap(imageUrl);
                    if (bitmap == null) {
                        error = "Ошибка запроса: не удалось декодировать изображение";
                    }
                } catch (Exception e) {
                    error = "Ошибка запроса: " + getReadableError(e);
                }

                final Bitmap finalBitmap = bitmap;
                final String finalError = error;
                final String finalUrl = imageUrl;

                runOnUi(new Runnable() {
                    @Override
                    public void run() {
                        requestRunning = false;
                        sendButton.setEnabled(true);
                        sendButton.setAlpha(1f);
                        if (imageModeButton != null) {
                            imageModeButton.setEnabled(true);
                            imageModeButton.setAlpha(1f);
                        }
                        showStatus("");

                        if (!isOpen) {
                            return;
                        }

                        if (finalError != null) {
                            addAiMessage(finalError, true);
                            return;
                        }

                        history.add(new ChatMessage("assistant", "[generated image] " + finalUrl));
                        addAiImageMessage(finalBitmap, finalUrl);
                        saveCurrentChat(true);
                    }
                });
            }
        });

        networkThread.setName("AstroForge-Pollinations");
        networkThread.start();

        hideKeyboard();
        scrollToBottom();
    }

    private Bitmap downloadBitmap(String imageUrl) throws Exception {
        URL url = new URL(imageUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        try {
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(20000);
            connection.setReadTimeout(90000);
            connection.setDoInput(true);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("Accept", "image/*,*/*");
            connection.setRequestProperty("User-Agent", "AstroForge/1.0");

            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) {
                InputStream err = connection.getErrorStream();
                String msg = err != null ? readStream(err) : ("HTTP " + code);
                throw new Exception("HTTP " + code + ": " + msg);
            }

            InputStream stream = connection.getInputStream();
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] chunk = new byte[8192];
            int n;
            while ((n = stream.read(chunk)) != -1) {
                buffer.write(chunk, 0, n);
            }
            stream.close();
            byte[] data = buffer.toByteArray();
            return BitmapFactory.decodeByteArray(data, 0, data.length);
        } finally {
            connection.disconnect();
        }
    }

    private void addAiImageMessage(final Bitmap bitmap, final String sourceUrl) {
        LinearLayout messageBox = new LinearLayout(context);
        messageBox.setOrientation(LinearLayout.VERTICAL);
        messageBox.setGravity(Gravity.START);

        ImageView imageView = new ImageView(context);
        imageView.setImageBitmap(bitmap);
        imageView.setAdjustViewBounds(true);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setBackground(
            createRoundedRect(dp(12), Color.parseColor("#221C1C1E"), Color.parseColor("#44D9946B"), dp(1))
        );
        imageView.setPadding(dp(2), dp(2), dp(2), dp(2));

        LinearLayout.LayoutParams imgLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        imgLp.width = dp(280);
        messageBox.addView(imageView, imgLp);

        TextView downloadBtn = new TextView(context);
        downloadBtn.setText("⬇  Скачать в галерею");
        downloadBtn.setTextColor(MUTED_COLOR);
        downloadBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        downloadBtn.setGravity(Gravity.CENTER_VERTICAL);
        downloadBtn.setPadding(dp(4), dp(8), dp(10), dp(8));
        downloadBtn.setTypeface(typefaceRegular);
        downloadBtn.setClickable(true);
        downloadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HapticUtils.perform(v);
                saveBitmapToGallery(bitmap);
            }
        });
        messageBox.addView(
            downloadBtn,
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        );

        LinearLayout.LayoutParams boxLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        boxLp.topMargin = dp(6);
        boxLp.bottomMargin = dp(4);
        messagesColumn.addView(messageBox, boxLp);

        scrollToBottom();
    }

    private void saveBitmapToGallery(Bitmap bitmap) {
        if (bitmap == null) {
            Toast.makeText(context, "Нет изображения", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            String filename = "AstroForge_" + System.currentTimeMillis() + ".jpg";
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH,
                Environment.DIRECTORY_PICTURES + "/AstroForge");

            Uri uri = context.getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
            );
            if (uri == null) {
                Toast.makeText(context, "Не удалось создать файл в галерее", Toast.LENGTH_SHORT).show();
                return;
            }
            OutputStream out = context.getContentResolver().openOutputStream(uri);
            if (out == null) {
                Toast.makeText(context, "Не удалось открыть поток записи", Toast.LENGTH_SHORT).show();
                return;
            }
            boolean ok = bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out);
            out.flush();
            out.close();
            if (ok) {
                Toast.makeText(context, "Сохранено в галерею (Pictures/AstroForge)", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Ошибка сжатия JPEG", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(context, "Ошибка сохранения: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String performRequest(String token, String model) throws Exception {
        URL url = new URL(HF_ENDPOINT);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();

        try {
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(120000);
            connection.setDoInput(true);
            connection.setDoOutput(true);
            connection.setRequestProperty(
                "Authorization",
                "Bearer " + token
            );
            connection.setRequestProperty(
                "Content-Type",
                "application/json"
            );
            connection.setRequestProperty(
                "Accept",
                "application/json"
            );

            JSONObject body = new JSONObject();
            body.put("model", model);
            body.put("messages", buildMessagesJson());
            body.put("stream", false);

            OutputStream output = connection.getOutputStream();
            output.write(body.toString().getBytes("UTF-8"));
            output.flush();
            output.close();

            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 300
                ? connection.getInputStream()
                : connection.getErrorStream();

            String responseText = readStream(stream);

            if (code < 200 || code >= 300) {
                String message = extractErrorMessage(responseText);
                throw new Exception(
                    "HTTP " + code + (message.length() > 0 ? ": " + message : "")
                );
            }

            JSONObject response = new JSONObject(responseText);
            JSONArray choices = response.optJSONArray("choices");

            if (choices == null || choices.length() == 0) {
                throw new Exception("Hugging Face не вернул choices.");
            }

            JSONObject firstChoice = choices.optJSONObject(0);
            if (firstChoice == null) {
                throw new Exception("Некорректный ответ модели.");
            }

            JSONObject message = firstChoice.optJSONObject("message");
            if (message == null) {
                throw new Exception("В ответе нет message.");
            }

            String content = message.optString("content", "").trim();

            if (content.length() == 0) {
                throw new Exception("Модель вернула пустой ответ.");
            }

            return content;
        } finally {
            connection.disconnect();
        }
    }

    private JSONArray buildMessagesJson() throws JSONException {
        JSONArray messages = new JSONArray();

        JSONObject system = new JSONObject();
        system.put("role", "system");
        system.put("content", SYSTEM_PROMPT);
        messages.put(system);

        for (int i = 0; i < history.size(); i++) {
            ChatMessage item = history.get(i);

            JSONObject message = new JSONObject();
            message.put("role", item.role);
            message.put("content", item.content);
            messages.put(message);
        }

        return messages;
    }

    private String readStream(InputStream stream) throws Exception {
        if (stream == null) {
            return "";
        }

        BufferedReader reader = new BufferedReader(
            new InputStreamReader(stream, "UTF-8")
        );

        StringBuilder result = new StringBuilder();
        String line;

        try {
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
        } finally {
            reader.close();
        }

        return result.toString();
    }

    private String extractErrorMessage(String response) {
        if (response == null || response.length() == 0) {
            return "";
        }

        try {
            JSONObject json = new JSONObject(response);
            JSONObject error = json.optJSONObject("error");
            if (error != null) {
                String message = error.optString("message", "");
                if (message.length() > 0) {
                    return message;
                }
            }

            String directMessage = json.optString("message", "");
            if (directMessage.length() > 0) {
                return directMessage;
            }
        } catch (JSONException ignored) {
        }

        if (response.length() > 300) {
            return response.substring(0, 300);
        }

        return response;
    }

    private String getReadableError(Exception error) {
        String message = error.getMessage();

        if (message == null || message.length() == 0) {
            return error.getClass().getSimpleName();
        }

        return message;
    }

    private void addUserMessage(String text) {
        TextView bubble = createMessageText(text);
        bubble.setTextColor(Color.WHITE);
        bubble.setBackground(
            createRoundedRect(
                dp(18),
                USER_BUBBLE_COLOR,
                USER_BUBBLE_BORDER,
                dp(1)
            )
        );

        bubble.setPadding(dp(14), dp(11), dp(14), dp(11));

        LinearLayout row = new LinearLayout(context);
        row.setGravity(Gravity.END);

        row.addView(
            bubble,
            new LinearLayout.LayoutParams(
                dp(290),
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        );

        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        rowLp.topMargin = dp(7);
        messagesColumn.addView(row, rowLp);

        scrollToBottom();
    }

    private void addAiMessage(String text) {
        addAiMessage(text, false);
    }

    private void addAiMessage(final String text, boolean error) {
        LinearLayout messageBox = new LinearLayout(context);
        messageBox.setOrientation(LinearLayout.VERTICAL);
        messageBox.setGravity(Gravity.START);

        TextView message = createMessageText(text);
        message.setTextColor(error ? AI_ERROR_COLOR : TEXT_COLOR);
        message.setPadding(dp(4), dp(5), dp(4), dp(3));

        messageBox.addView(
            message,
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        );

        if (!error && text != null && text.length() > 0) {
            TextView copyButton = new TextView(context);
            copyButton.setText("⧉  Копировать");
            copyButton.setTextColor(MUTED_COLOR);
            copyButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            copyButton.setGravity(Gravity.CENTER_VERTICAL);
            copyButton.setPadding(dp(4), dp(2), dp(10), dp(8));
            copyButton.setTypeface(typefaceRegular);
            copyButton.setClickable(true);
            copyButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ClipboardManager clipboard = (ClipboardManager) context.getSystemService(
                        Context.CLIPBOARD_SERVICE
                    );
                    if (clipboard != null) {
                        clipboard.setPrimaryClip(ClipData.newPlainText("Omega AGI", text));
                        Toast.makeText(context, "Ответ скопирован", Toast.LENGTH_SHORT).show();
                    }
                }
            });
            messageBox.addView(
                copyButton,
                new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            );
        }

        LinearLayout.LayoutParams boxLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        boxLp.topMargin = dp(2);
        boxLp.bottomMargin = dp(3);
        messagesColumn.addView(messageBox, boxLp);

        scrollToBottom();
    }

    private TextView createMessageText(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(formatMarkdown(text == null ? "" : text));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
        tv.setLineSpacing(0f, 1.10f);
        tv.setGravity(Gravity.START);
        return tv;
    }

    private CharSequence formatMarkdown(String source) {
        SpannableStringBuilder out = new SpannableStringBuilder();
        String[] lines = source.replace("\r", "").split("\n", -1);
        boolean inCodeBlock = false;

        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            if (line.trim().startsWith("```") ) {
                inCodeBlock = !inCodeBlock;
                continue;
            }

            if (i > 0 && !isCodeFenceOnly(lines[i - 1])) {
                out.append("\n");
            }

            if (inCodeBlock) {
                int start = out.length();
                out.append(line);
                out.setSpan(new android.text.style.TypefaceSpan("monospace"), start, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                continue;
            }

            String cleaned = line;
            if (cleaned.startsWith("### ")) {
                cleaned = cleaned.substring(4);
                int start = out.length();
                out.append(cleaned);
                out.setSpan(new StyleSpan(Typeface.BOLD), start, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                continue;
            }
            if (cleaned.startsWith("## ")) {
                cleaned = cleaned.substring(3);
                int start = out.length();
                out.append(cleaned);
                out.setSpan(new StyleSpan(Typeface.BOLD), start, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                continue;
            }
            if (cleaned.startsWith("# ")) {
                cleaned = cleaned.substring(2);
                int start = out.length();
                out.append(cleaned);
                out.setSpan(new StyleSpan(Typeface.BOLD), start, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                continue;
            }
            if (cleaned.startsWith("- ") || cleaned.startsWith("* ")) {
                cleaned = "• " + cleaned.substring(2);
            }

            appendInlineMarkdown(out, cleaned);
        }

        return out;
    }

    private boolean isCodeFenceOnly(String line) {
        return line.trim().startsWith("```");
    }

    private void appendInlineMarkdown(SpannableStringBuilder out, String text) {
        int i = 0;
        StringBuilder plain = new StringBuilder();
        while (i < text.length()) {
            if (i + 1 < text.length() && text.charAt(i) == '*' && text.charAt(i + 1) == '*') {
                int end = text.indexOf("**", i + 2);
                if (end >= 0) {
                    flushPlain(out, plain);
                    int start = out.length();
                    out.append(text.substring(i + 2, end));
                    out.setSpan(new StyleSpan(Typeface.BOLD), start, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    i = end + 2;
                    continue;
                }
            }

            char c = text.charAt(i);
            if (c == '*' || c == '_') {
                int end = text.indexOf(c, i + 1);
                if (end > i + 1) {
                    flushPlain(out, plain);
                    int start = out.length();
                    out.append(text.substring(i + 1, end));
                    out.setSpan(new StyleSpan(Typeface.ITALIC), start, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    i = end + 1;
                    continue;
                }
            }

            if (c == '`') {
                int end = text.indexOf('`', i + 1);
                if (end > i + 1) {
                    flushPlain(out, plain);
                    int start = out.length();
                    out.append(text.substring(i + 1, end));
                    out.setSpan(new android.text.style.TypefaceSpan("monospace"), start, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    i = end + 1;
                    continue;
                }
            }

            plain.append(c);
            i++;
        }
        flushPlain(out, plain);
    }

    private void flushPlain(SpannableStringBuilder out, StringBuilder plain) {
        if (plain.length() > 0) {
            out.append(plain.toString());
            plain.setLength(0);
        }
    }

    private void showStatus(String text) {
        if (statusText == null) {
            return;
        }

        statusText.setText(text);
        statusText.setVisibility(
            text.length() == 0 ? View.GONE : View.VISIBLE
        );
    }

    private void scrollToBottom() {
        if (chatScroll == null) {
            return;
        }

        chatScroll.post(new Runnable() {
            @Override
            public void run() {
                chatScroll.fullScroll(View.FOCUS_DOWN);
            }
        });
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) context.getSystemService(
                Context.INPUT_METHOD_SERVICE
            );

            if (imm != null && promptInput != null) {
                imm.hideSoftInputFromWindow(
                    promptInput.getWindowToken(),
                    0
                );
            }
        } catch (RuntimeException ignored) {
        }
    }

    private void loadSettings() {
        SharedPreferences prefs = context.getSharedPreferences(
            PREFS_NAME,
            Context.MODE_PRIVATE
        );

        String token = prefs.getString(KEY_HF_TOKEN, "");
        String model = prefs.getString(KEY_MODEL, "");

        if (token.length() > 0) {
            tokenInput.setText(token);
        }

        if (model.length() > 0) {
            modelInput.setText(model);
        }
    }

    private void saveSettings(String token, String model) {
        context.getSharedPreferences(
            PREFS_NAME,
            Context.MODE_PRIVATE
        )
            .edit()
            .putString(KEY_HF_TOKEN, token)
            .putString(KEY_MODEL, model)
            .apply();
    }

    private void runOnUi(final Runnable action) {
        android.os.Handler handler = new android.os.Handler(
            android.os.Looper.getMainLooper()
        );
        handler.post(action);
    }

    private int dp(float value) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            context.getResources().getDisplayMetrics()
        );
    }

    private View spacer(int height) {
        View view = new View(context);
        view.setLayoutParams(
            new LinearLayout.LayoutParams(
                1,
                height
            )
        );
        return view;
    }

    private GradientDrawable createRoundedRect(
        int radius,
        int fill,
        int stroke
    ) {
        return createRoundedRect(radius, fill, stroke, dp(1));
    }

    private GradientDrawable createRoundedRect(
        int radius,
        int fill,
        int stroke,
        int strokeWidth
    ) {
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(radius);
        bg.setColor(fill);

        if (strokeWidth > 0 && stroke != Color.TRANSPARENT) {
            bg.setStroke(strokeWidth, stroke);
        }

        return bg;
    }

    private FrameLayout.LayoutParams matchParentFrameLp() {
        return new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        );
    }

    private static final class SavedChat {
        String id;
        String title;
        long updatedAt;
        final List<ChatMessage> messages = new ArrayList<ChatMessage>();
    }

    private static final class ChatMessage {
        final String role;
        final String content;

        ChatMessage(String role, String content) {
            this.role = role;
            this.content = content;
        }
    }
}


