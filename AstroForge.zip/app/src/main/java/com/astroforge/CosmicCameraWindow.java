package com.astroforge;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Typeface;
import android.util.Size;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Полноэкранная панель «Космическая камера» на штатном Camera2 API. */
public final class CosmicCameraWindow {

    private static final int COLOR_BG = Color.rgb(24, 24, 24);
    private static final int COLOR_PANEL = Color.rgb(47, 47, 47);
    private static final int COLOR_BORDER = Color.rgb(92, 78, 67);
    private static final int COLOR_TEXT = Color.rgb(227, 225, 222);
    private static final int COLOR_ACCENT = Color.rgb(213, 139, 90);

    private final Activity activity;
    private final FrameLayout root;
    private final Typeface typeface;
    private final Runnable onClosed;

    private FrameLayout overlay;
    private TextureView previewView;
    private ImageButton shutterButton;
    private CameraDevice cameraDevice;
    private CameraCaptureSession captureSession;
    private ImageReader imageReader;
    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private String cameraId;
    private Size previewSize;
    private boolean open;
    private boolean surfaceReady;
    private boolean closing;
    private int displayRotation;

    public CosmicCameraWindow(Activity activity, FrameLayout root, Typeface typeface, Runnable onClosed) {
        this.activity = activity;
        this.root = root;
        this.typeface = typeface;
        this.onClosed = onClosed;
    }

    public boolean isOpen() {
        return open;
    }

    public void show() {
        if (open || closing) {
            return;
        }
        open = true;
        buildUi();
        startCameraThread();
        if (previewView.isAvailable()) {
            surfaceReady = true;
            updatePreviewTransform();
            openCamera();
        } else {
            previewView.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
                @Override
                public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
                    surfaceReady = true;
                    openCamera();
                }

                @Override
                public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
                    updatePreviewTransform();
                    if (cameraDevice != null) {
                        configureCameraSession();
                    }
                }

                @Override
                public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
                    surfaceReady = false;
                    closeCameraOnly();
                    return true;
                }

                @Override
                public void onSurfaceTextureUpdated(SurfaceTexture surface) {
                }
            });
        }
    }

    public void close() {
        if (!open || closing) {
            return;
        }
        closing = true;
        open = false;
        closeCameraOnly();
        stopCameraThread();

        if (overlay != null) {
            root.removeView(overlay);
            overlay = null;
        }

        closing = false;
        if (onClosed != null) {
            onClosed.run();
        }
    }

    private void buildUi() {
        overlay = new FrameLayout(activity);
        overlay.setBackgroundColor(COLOR_BG);
        overlay.setClickable(true);
        overlay.setFocusable(true);

        previewView = new TextureView(activity);
        FrameLayout.LayoutParams previewLp = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        );
        previewLp.gravity = Gravity.CENTER;
        overlay.addView(previewView, previewLp);

        View shade = new View(activity);
        shade.setBackgroundColor(Color.argb(60, 0, 0, 0));
        overlay.addView(shade, fullParams());

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(8), 0, dp(8), 0);
        header.setBackground(roundRect(dp(18), Color.argb(225, 47, 47, 47), COLOR_BORDER));

        TextView title = new TextView(activity);
        title.setText("Космическая камера");
        title.setTextColor(COLOR_TEXT);
        title.setTextSize(18f);
        if (typeface != null) {
            title.setTypeface(typeface);
        }
        title.setGravity(Gravity.CENTER_VERTICAL);

        TextView close = new TextView(activity);
        close.setText("✕");
        close.setTextColor(COLOR_TEXT);
        close.setTextSize(23f);
        close.setGravity(Gravity.CENTER);
        close.setPadding(dp(10), 0, dp(10), 0);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                close();
            }
        });

        header.addView(title, new LinearLayout.LayoutParams(0, dp(52), 1f));
        header.addView(close, new LinearLayout.LayoutParams(dp(52), dp(52)));

        FrameLayout.LayoutParams headerLp = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(52)
        );
        headerLp.gravity = Gravity.TOP;
        headerLp.leftMargin = dp(14);
        headerLp.rightMargin = dp(14);
        headerLp.topMargin = dp(14);
        overlay.addView(header, headerLp);

        TextView hint = new TextView(activity);
        hint.setText("Нажмите ●, чтобы сохранить снимок в Галерею");
        hint.setTextColor(Color.argb(230, 227, 225, 222));
        hint.setTextSize(13f);
        hint.setGravity(Gravity.CENTER);
        if (typeface != null) {
            hint.setTypeface(typeface);
        }
        FrameLayout.LayoutParams hintLp = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            dp(42)
        );
        hintLp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        hintLp.bottomMargin = dp(94);
        overlay.addView(hint, hintLp);

        shutterButton = new ImageButton(activity);
        shutterButton.setImageDrawable(new ShutterDrawable(dp(72), COLOR_TEXT, COLOR_ACCENT));
        shutterButton.setBackgroundColor(Color.TRANSPARENT);
        shutterButton.setContentDescription("Сделать снимок");
        shutterButton.setPadding(0, 0, 0, 0);
        shutterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                takePhoto();
            }
        });

        FrameLayout.LayoutParams shutterLp = new FrameLayout.LayoutParams(dp(82), dp(82));
        shutterLp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        shutterLp.bottomMargin = dp(10);
        overlay.addView(shutterButton, shutterLp);

        root.addView(overlay, fullParams());
    }

    private void startCameraThread() {
        cameraThread = new HandlerThread("AstroForgeCamera");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
    }

    private void stopCameraThread() {
        if (cameraThread != null) {
            cameraThread.quitSafely();
            try {
                cameraThread.join(1000L);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            cameraThread = null;
            cameraHandler = null;
        }
    }

    private void openCamera() {
        if (!open || !surfaceReady || cameraHandler == null) {
            return;
        }

        try {
            CameraManager manager = (CameraManager) activity.getSystemService(Context.CAMERA_SERVICE);
            String[] ids = manager.getCameraIdList();
            if (ids.length == 0) {
                showToast("Камера не найдена");
                return;
            }

            cameraId = chooseCamera(manager, ids);
            CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraId);
            StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map == null) {
                showToast("Камера не поддерживает предпросмотр");
                return;
            }

            Size[] previewSizes = map.getOutputSizes(SurfaceTexture.class);
            Size[] jpegSizes = map.getOutputSizes(ImageFormat.JPEG);
            if (previewSizes == null || previewSizes.length == 0 || jpegSizes == null || jpegSizes.length == 0) {
                showToast("Недоступен формат камеры");
                return;
            }

            previewSize = choosePreviewSize(previewSizes, previewView.getWidth(), previewView.getHeight());
            updatePreviewTransform();
            Size jpegSize = chooseJpegSize(jpegSizes);
            imageReader = ImageReader.newInstance(jpegSize.getWidth(), jpegSize.getHeight(), ImageFormat.JPEG, 2);
            imageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader reader) {
                    saveLatestImage(reader);
                }
            }, cameraHandler);

            if (Build.VERSION.SDK_INT >= 23 && activity.checkSelfPermission(android.Manifest.permission.CAMERA)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                return;
            }
            manager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice camera) {
                    cameraDevice = camera;
                    configureCameraSession();
                }

                @Override
                public void onDisconnected(CameraDevice camera) {
                    camera.close();
                    cameraDevice = null;
                }

                @Override
                public void onError(CameraDevice camera, int error) {
                    camera.close();
                    cameraDevice = null;
                    showToast("Не удалось открыть камеру");
                }
            }, cameraHandler);
        } catch (Throwable t) {
            showToast("Не удалось открыть камеру");
        }
    }

    private String chooseCamera(CameraManager manager, String[] ids) throws CameraAccessException {
        for (String id : ids) {
            CameraCharacteristics c = manager.getCameraCharacteristics(id);
            Integer facing = c.get(CameraCharacteristics.LENS_FACING);
            if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                return id;
            }
        }
        return ids[0];
    }

    private Size choosePreviewSize(Size[] sizes, int width, int height) {
        if (width <= 0 || height <= 0) {
            return sizes[0];
        }
        double target = (double) Math.max(width, height) / (double) Math.min(width, height);
        Size best = sizes[0];
        double bestScore = Double.MAX_VALUE;
        for (Size s : sizes) {
            if (s.getWidth() > 2560 || s.getHeight() > 2560) {
                continue;
            }
            double ratio = (double) Math.max(s.getWidth(), s.getHeight())
                / (double) Math.min(s.getWidth(), s.getHeight());
            double ratioError = Math.abs(ratio - target);
            double sizeError = Math.abs((double) Math.max(s.getWidth(), s.getHeight()) - (double) Math.max(width, height))
                + Math.abs((double) Math.min(s.getWidth(), s.getHeight()) - (double) Math.min(width, height));
            double score = ratioError * 10000.0 + sizeError * 0.01;
            if (score < bestScore) {
                bestScore = score;
                best = s;
            }
        }
        return best;
    }

    /**
     * Подгоняет предпросмотр под TextureView без растягивания и без
     * искусственного увеличения. Для TextureView важно не строить
     * transform вручную через setScale/postTranslate от начала координат:
     * в таком случае изображение может оказаться смещённым в угол.
     * setRectToRect с CENTER корректно центрирует весь буфер камеры.
     */
    private void updatePreviewTransform() {
        if (previewView == null || previewSize == null) {
            return;
        }

        int viewWidth = previewView.getWidth();
        int viewHeight = previewView.getHeight();
        if (viewWidth <= 0 || viewHeight <= 0) {
            return;
        }

        float bufferWidth = previewSize.getWidth();
        float bufferHeight = previewSize.getHeight();

        RectF bufferRect = new RectF(0f, 0f, bufferWidth, bufferHeight);
        RectF viewRect = new RectF(0f, 0f, viewWidth, viewHeight);
        Matrix matrix = new Matrix();
        matrix.setRectToRect(bufferRect, viewRect, Matrix.ScaleToFit.CENTER);
        previewView.setTransform(matrix);
    }

    private Size chooseJpegSize(Size[] sizes) {
        List<Size> list = new ArrayList<Size>(Arrays.asList(sizes));
        Collections.sort(list, new Comparator<Size>() {
            @Override
            public int compare(Size a, Size b) {
                long aa = (long) a.getWidth() * a.getHeight();
                long bb = (long) b.getWidth() * b.getHeight();
                return aa == bb ? 0 : (aa < bb ? 1 : -1);
            }
        });
        for (Size s : list) {
            if (s.getWidth() <= 8192 && s.getHeight() <= 8192) {
                return s;
            }
        }
        return list.get(0);
    }

    private void configureCameraSession() {
        if (cameraDevice == null || previewView == null || !previewView.isAvailable() || imageReader == null) {
            return;
        }
        try {
            SurfaceTexture texture = previewView.getSurfaceTexture();
            texture.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
            Surface previewSurface = new Surface(texture);
            Surface jpegSurface = imageReader.getSurface();

            final CaptureRequest.Builder builder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            builder.addTarget(previewSurface);
            builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);

            List<Surface> surfaces = new ArrayList<Surface>();
            surfaces.add(previewSurface);
            surfaces.add(jpegSurface);

            cameraDevice.createCaptureSession(surfaces, new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(CameraCaptureSession session) {
                    if (cameraDevice == null || !open) {
                        return;
                    }
                    captureSession = session;
                    try {
                        session.setRepeatingRequest(builder.build(), null, cameraHandler);
                    } catch (CameraAccessException e) {
                        showToast("Не удалось запустить предпросмотр");
                    }
                }

                @Override
                public void onConfigureFailed(CameraCaptureSession session) {
                    showToast("Не удалось настроить предпросмотр");
                }
            }, cameraHandler);
        } catch (Throwable t) {
            showToast("Ошибка инициализации камеры");
        }
    }

    private void takePhoto() {
        if (cameraDevice == null || captureSession == null || imageReader == null || cameraHandler == null) {
            showToast("Камера ещё запускается…");
            return;
        }
        try {
            CaptureRequest.Builder builder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            builder.addTarget(imageReader.getSurface());
            builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
            int rotation = activity.getWindowManager().getDefaultDisplay().getRotation();
            builder.set(CaptureRequest.JPEG_ORIENTATION, jpegOrientation(rotation));
            captureSession.capture(builder.build(), new CameraCaptureSession.CaptureCallback() {
            }, cameraHandler);
            showToast("Снимок сохраняется…");
        } catch (Throwable t) {
            showToast("Не удалось сделать снимок");
        }
    }

    private int jpegOrientation(int rotation) {
        int sensorOrientation = 90;
        try {
            CameraManager manager = (CameraManager) activity.getSystemService(Context.CAMERA_SERVICE);
            CameraCharacteristics c = manager.getCameraCharacteristics(cameraId);
            Integer value = c.get(CameraCharacteristics.SENSOR_ORIENTATION);
            if (value != null) {
                sensorOrientation = value;
            }
        } catch (Throwable ignored) {
        }
        return (sensorOrientation + rotationDegrees(rotation) + 360) % 360;
    }

    private int rotationDegrees(int rotation) {
        switch (rotation) {
            case Surface.ROTATION_90:
                return 90;
            case Surface.ROTATION_180:
                return 180;
            case Surface.ROTATION_270:
                return 270;
            default:
                return 0;
        }
    }

    private void saveLatestImage(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) {
                return;
            }
            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
            byte[] data = new byte[buffer.remaining()];
            buffer.get(data);
            String name = "AstroForge_" + new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date()) + ".jpg";
            saveBytes(data, name);
        } catch (Throwable t) {
            showToast("Не удалось сохранить снимок");
        } finally {
            if (image != null) {
                image.close();
            }
        }
    }

    private void saveBytes(byte[] data, String name) throws Exception {
        OutputStream out = null;
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AstroForge");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
                Uri uri = activity.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (uri == null) {
                    throw new Exception("MediaStore insert failed");
                }
                try {
                    out = activity.getContentResolver().openOutputStream(uri);
                    if (out == null) {
                        throw new Exception("Output stream unavailable");
                    }
                    out.write(data);
                    out.flush();
                    values.clear();
                    values.put(MediaStore.Images.Media.IS_PENDING, 0);
                    activity.getContentResolver().update(uri, values, null, null);
                } catch (Throwable t) {
                    activity.getContentResolver().delete(uri, null, null);
                    throw new RuntimeException(t);
                }
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "AstroForge");
                if (!dir.exists() && !dir.mkdirs()) {
                    throw new Exception("Directory creation failed");
                }
                File file = new File(dir, name);
                out = new FileOutputStream(file);
                out.write(data);
                out.flush();
            }
            showToast("Снимок сохранён в Галерею");
        } finally {
            if (out != null) {
                try {
                    out.close();
                } catch (Exception ignored) {
                }
            }
        }
    }

    private void closeCameraOnly() {
        if (captureSession != null) {
            try {
                captureSession.stopRepeating();
            } catch (Throwable ignored) {
            }
            try {
                captureSession.close();
            } catch (Throwable ignored) {
            }
            captureSession = null;
        }
        if (cameraDevice != null) {
            try {
                cameraDevice.close();
            } catch (Throwable ignored) {
            }
            cameraDevice = null;
        }
        if (imageReader != null) {
            try {
                imageReader.close();
            } catch (Throwable ignored) {
            }
            imageReader = null;
        }
    }

    private FrameLayout.LayoutParams fullParams() {
        return new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        );
    }

    private int dp(int value) {
        return Math.round(value * activity.getResources().getDisplayMetrics().density);
    }

    private android.graphics.drawable.Drawable roundRect(int radius, int fill, int stroke) {
        android.graphics.drawable.GradientDrawable drawable = new android.graphics.drawable.GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private void showToast(final String text) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (open && !activity.isFinishing()) {
                    Toast.makeText(activity, text, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private static final class ShutterDrawable extends android.graphics.drawable.Drawable {
        private final int size;
        private final int outerColor;
        private final int innerColor;
        private final android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        ShutterDrawable(int size, int outerColor, int innerColor) {
            this.size = size;
            this.outerColor = outerColor;
            this.innerColor = innerColor;
            setBounds(0, 0, size, size);
        }

        @Override
        public void draw(android.graphics.Canvas canvas) {
            float cx = getBounds().centerX();
            float cy = getBounds().centerY();
            float r = Math.min(getBounds().width(), getBounds().height()) * 0.46f;
            paint.setStyle(android.graphics.Paint.Style.FILL);
            paint.setColor(Color.argb(110, 0, 0, 0));
            canvas.drawCircle(cx, cy, r + 3f, paint);
            paint.setColor(outerColor);
            canvas.drawCircle(cx, cy, r, paint);
            paint.setColor(innerColor);
            canvas.drawCircle(cx, cy, r * 0.72f, paint);
        }

        @Override public void setAlpha(int alpha) { }
        @Override public void setColorFilter(android.graphics.ColorFilter colorFilter) { }
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }
}
