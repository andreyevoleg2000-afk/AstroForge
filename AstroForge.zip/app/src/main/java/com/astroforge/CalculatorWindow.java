package com.astroforge;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.Locale;

/**
 * Окно "Калькулятор" для нижнего бара.
 * Меню: глубокий тёмно-серый, окантовка тауп, кнопки без границ с нативной
 * белой рябью (волна от пальца к краям).
 * Три внутренних окна (единицы / обычный калькулятор / физика 2-из-4) открываются
 * ПОВЕРХ меню и используют матовое стекло, поля, dropdown и кнопку "Рассчитать"
 * из VelocityPanel.
 * AIDE-safe: без лямбд, без androidx, все захваченные локальные переменные — final.
 */
final class CalculatorWindow {

    private static final int ACCENT_COLOR        = 0xFFD9946B;
    private static final int ACCENT_BORDER_COLOR = Color.parseColor("#CCD9946B");
    private static final int FIELD_BG_COLOR      = Color.parseColor("#F21C1C1E");
    private static final int FIELD_BORDER_COLOR  = Color.parseColor("#B3E3E1DE");
    private static final int PILL_BG_COLOR       = Color.BLACK;
    private static final int DROPDOWN_BG_COLOR   = Color.parseColor("#FF1C1C1E");
    /** Глубокий тёмно-серый для меню калькулятора. */
    private static final int MENU_BG_COLOR       = Color.parseColor("#FF202024");
    /** Тауп-окантовка меню. */
    private static final int TAUPE_BORDER_COLOR  = Color.parseColor("#8A7A6C");

    private static final long OPEN_ANIM_DURATION_MS  = 360L;
    private static final long CLOSE_ANIM_DURATION_MS = 220L;
    private static final int CLOSE_DIRECTION_CENTER = 0;
    private static final int CLOSE_DIRECTION_LEFT   = -1;
    private static final int CLOSE_DIRECTION_RIGHT  = 1;

    private final Context context;
    private final FrameLayout rootContainer;
    private final Typeface typefaceRegular;
    private final Typeface typefaceSemiBold;

    /** Основание для единиц данных: 1024 (двоичные) или 1000 (десятичные). */
    private boolean dataBinary = true;

    // =========================================================
    //  Данные единиц измерения
    // =========================================================
    private static final class UnitDef {
        final String label;
        final double dec;
        final double bin;
        UnitDef(String label, double factor) { this.label = label; this.dec = factor; this.bin = factor; }
        UnitDef(String label, double dec, double bin) { this.label = label; this.dec = dec; this.bin = bin; }
    }

    private static final class Category {
        final String name;
        final UnitDef[] units;
        final boolean isData;
        Category(String name, UnitDef[] units, boolean isData) {
            this.name = name; this.units = units; this.isData = isData;
        }
    }

    private static double pow1024(int e) { double r = 1; for (int i = 0; i < e; i++) r *= 1024; return r; }
    private static double pow1000(int e) { double r = 1; for (int i = 0; i < e; i++) r *= 1000; return r; }

    private static final Category[] CATEGORIES = new Category[]{
        new Category("Время", new UnitDef[]{
						 new UnitDef("нс", 1e-9), new UnitDef("мкс", 1e-6), new UnitDef("мс", 1e-3),
						 new UnitDef("с", 1), new UnitDef("мин", 60), new UnitDef("ч", 3600),
						 new UnitDef("сутки", 86400), new UnitDef("неделя", 604800),
						 new UnitDef("месяц", 2629800), new UnitDef("год", 31557600),
						 new UnitDef("десятилетие", 315576000), new UnitDef("век", 3155760000d),
						 new UnitDef("тысячелетие", 31557600000d)
					 }, false),
        new Category("Данные", new UnitDef[]{
						 new UnitDef("бит", 0.125, 0.125),
						 new UnitDef("байт", 1, 1),
						 new UnitDef("КБ", pow1000(1), pow1024(1)),
						 new UnitDef("МБ", pow1000(2), pow1024(2)),
						 new UnitDef("ГБ", pow1000(3), pow1024(3)),
						 new UnitDef("ТБ", pow1000(4), pow1024(4)),
						 new UnitDef("ПБ", pow1000(5), pow1024(5)),
						 new UnitDef("ЭБ", pow1000(6), pow1024(6)),
						 new UnitDef("ЗБ", pow1000(7), pow1024(7)),
						 new UnitDef("Кбит", 125, 128),
						 new UnitDef("Мбит", 125000, 131072)
					 }, true),
        new Category("Вес", new UnitDef[]{
						 new UnitDef("мг", 1e-6), new UnitDef("г", 1e-3), new UnitDef("кг", 1),
						 new UnitDef("т", 1000), new UnitDef("кт", 1e6), new UnitDef("Мт", 1e9),
						 new UnitDef("карат", 2e-4), new UnitDef("гран", 6.479891e-5),
						 new UnitDef("унция", 0.028349523125), new UnitDef("фунт", 0.45359237),
						 new UnitDef("стоун", 6.35029318), new UnitDef("тонна US", 907.18474),
						 new UnitDef("тонна UK", 1016.0469088)
					 }, false),
        new Category("Расстояние", new UnitDef[]{
						 new UnitDef("нм", 1e-9), new UnitDef("мкм", 1e-6), new UnitDef("мм", 1e-3),
						 new UnitDef("см", 1e-2), new UnitDef("м", 1), new UnitDef("км", 1000),
						 new UnitDef("дюйм", 0.0254), new UnitDef("фут", 0.3048), new UnitDef("ярд", 0.9144),
						 new UnitDef("миля", 1609.344), new UnitDef("мор. миля", 1852),
						 new UnitDef("а.е.", 1.495978707e11), new UnitDef("св. год", 9.4607304725808e15),
						 new UnitDef("парсек", 3.085677581491367e16)
					 }, false),
        new Category("Размер", new UnitDef[]{
						 new UnitDef("нм", 1e-9), new UnitDef("мкм", 1e-6), new UnitDef("мм", 1e-3),
						 new UnitDef("см", 1e-2), new UnitDef("м", 1), new UnitDef("км", 1000),
						 new UnitDef("дюйм", 0.0254), new UnitDef("фут", 0.3048), new UnitDef("ярд", 0.9144),
						 new UnitDef("миля", 1609.344), new UnitDef("линия", 0.0021166667),
						 new UnitDef("точка", 0.0003527778)
					 }, false),
        new Category("Объём", new UnitDef[]{
						 new UnitDef("мл", 1e-6), new UnitDef("л", 1e-3), new UnitDef("м³", 1),
						 new UnitDef("см³", 1e-6), new UnitDef("дм³", 1e-3), new UnitDef("км³", 1e9),
						 new UnitDef("ч. ложка", 5e-6), new UnitDef("ст. ложка", 1.5e-5),
						 new UnitDef("стакан", 2.5e-4), new UnitDef("галлон US", 3.785411784e-3),
						 new UnitDef("галлон UK", 4.54609e-3), new UnitDef("пинта US", 4.73176473e-4),
						 new UnitDef("баррель", 0.158987294928), new UnitDef("фут³", 0.028316846592),
						 new UnitDef("дюйм³", 1.6387064e-5)
					 }, false),
        new Category("Меры плотности", new UnitDef[]{
						 new UnitDef("кг/м³", 1), new UnitDef("г/см³", 1000), new UnitDef("г/л", 1),
						 new UnitDef("кг/л", 1000), new UnitDef("т/м³", 1000), new UnitDef("мг/см³", 1),
						 new UnitDef("фунт/фут³", 16.01846337396014),
						 new UnitDef("фунт/галл US", 119.82642731689663),
						 new UnitDef("унция/дюйм³", 1729.994044)
					 }, false),
        new Category("Освещение", new UnitDef[]{
						 new UnitDef("лк", 1), new UnitDef("клк", 1000), new UnitDef("Млк", 1e6),
						 new UnitDef("фот", 10000), new UnitDef("фут-кандела", 10.763910416709722),
						 new UnitDef("нокс", 1e-3)
					 }, false)
    };

    // =========================================================
    //  Физические величины (2 из 4 -> 1 из 4)
    // =========================================================
    private static final String[] QUANT_LABELS = {"Масса", "Радиус", "Плотность", "Гравитация"};
    private static final UnitDef[] DENSITY_UNITS = CATEGORIES[6].units;
    private static final UnitDef[] GRAVITY_UNITS = new UnitDef[]{
        new UnitDef("м/с²", 1), new UnitDef("см/с²", 0.01), new UnitDef("км/с²", 1000),
        new UnitDef("g₀", 9.80665), new UnitDef("Гал", 0.01), new UnitDef("мГал", 1e-5)
    };
    private static final double EARTH_MASS = 5.972e24;
    private static final double EARTH_RADIUS = 6.371e6;

    private CalculatorWindow(Context context,
                            FrameLayout rootContainer,
                            Typeface typefaceRegular,
                            Typeface typefaceSemiBold) {
        this.context = context;
        this.rootContainer = rootContainer;
        this.typefaceRegular = typefaceRegular;
        this.typefaceSemiBold = typefaceSemiBold;
    }

    static void show(Context context,
                     FrameLayout rootContainer,
                     Typeface typefaceRegular,
                     Typeface typefaceSemiBold) {
        new CalculatorWindow(context, rootContainer, typefaceRegular, typefaceSemiBold).buildMenu();
    }

    private int dp(float value) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, value, context.getResources().getDisplayMetrics());
    }

    /** Вибрация + тактильный отклик одновременно (для «замочка»). */
    private void tickHaptic(View v) {
        try { HapticUtils.perform(v); } catch (Throwable ignore) { }
        try {
            Vibrator vib = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            if (vib != null) {
                vib.vibrate(VibrationEffect.createOneShot(18, 70));
            }
        } catch (Throwable ignore) { }
    }

    private interface OnPick { void onPicked(int index); }

    // =========================================================
    //  Универсальное окно: glass=true — матовое стекло из
    //  VelocityPanel; glass=false — меню (серый + тауп).
    // =========================================================
    private final class GlassWindow {
        final boolean glass;
        FrameLayout overlayRoot;
        FrameLayout windowFrame;
        FrameLayout dropdownLayer;
        PixelFillOverlay pixel;
        LinearLayout content;
        ValueAnimator openAnimator;
        ValueAnimator closeAnimator;
        boolean isClosing = false;
        boolean swipeClosing = false;
        boolean swipeFromLeftEdge = false;
        float swipeStartX = 0f; float swipeStartY = 0f;
        float swipeLastDx = 0f; float swipeLastDy = 0f;

        GlassWindow(boolean glassStyle) {
            this.glass = glassStyle;
            overlayRoot = new FrameLayout(context);
            overlayRoot.setBackgroundColor(Color.parseColor("#CC0F0F10"));
            overlayRoot.setClickable(true);
            overlayRoot.setOnClickListener(new View.OnClickListener() {
					@Override public void onClick(View v) { close(); }
				});
            overlayRoot.setOnTouchListener(new View.OnTouchListener() {
					@Override public boolean onTouch(View v, MotionEvent event) {
						return handleEdgeSwipe(event);
					}
				});

            windowFrame = new FrameLayout(context);
            windowFrame.setClickable(true);
            windowFrame.setOnClickListener(new View.OnClickListener() {
					@Override public void onClick(View v) { /* поглощаем клик */ }
				});
            GradientDrawable frameBg = new GradientDrawable();
            frameBg.setShape(GradientDrawable.RECTANGLE);
            frameBg.setCornerRadius(dp(28));
            if (glass) {
                frameBg.setColor(0xF21E1E20);
                frameBg.setStroke(dp(2), ACCENT_COLOR);
            } else {
                frameBg.setColor(MENU_BG_COLOR);
                frameBg.setStroke(dp(2), TAUPE_BORDER_COLOR);
            }
            windowFrame.setBackground(frameBg);
            windowFrame.setClipToOutline(true);
            windowFrame.setOutlineProvider(ViewOutlineProvider.BACKGROUND);

            if (glass) {
                ImageView blurBg = new ImageView(context);
                blurBg.setImageResource(R.drawable.background);
                blurBg.setScaleType(ImageView.ScaleType.CENTER_CROP);
                if (Build.VERSION.SDK_INT >= 31) {
                    blurBg.setRenderEffect(
                        RenderEffect.createBlurEffect(dp(44), dp(44), Shader.TileMode.CLAMP));
                }
                blurBg.setAlpha(0.88f);
                windowFrame.addView(blurBg, matchParentFrameLp());
                View tint = new View(context);
                tint.setBackgroundColor(Color.parseColor("#CC232326"));
                windowFrame.addView(tint, matchParentFrameLp());
            }

            ScrollView scrollView = new ScrollView(context);
            scrollView.setClipToPadding(false);
            scrollView.setOverScrollMode(View.OVER_SCROLL_NEVER);
            content = new LinearLayout(context);
            content.setOrientation(LinearLayout.VERTICAL);
            int pad = dp(20);
            content.setPadding(pad, pad, pad, pad);
            scrollView.addView(content, new ScrollView.LayoutParams(
								   ScrollView.LayoutParams.MATCH_PARENT,
								   ScrollView.LayoutParams.WRAP_CONTENT));
            windowFrame.addView(scrollView, matchParentFrameLp());

            if (glass) {
                pixel = new PixelFillOverlay(context);
                pixel.setVisibility(View.VISIBLE);
                windowFrame.addView(pixel, matchParentFrameLp());
                pixel.bringToFront();
            }

            FrameLayout.LayoutParams windowLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            int m = dp(18);
            windowLp.setMargins(m, m + dp(30), m, m + dp(30));
            overlayRoot.addView(windowFrame, windowLp);
            rootContainer.addView(overlayRoot, matchParentFrameLp());
            windowFrame.post(new Runnable() {
					@Override public void run() {
						if (overlayRoot != null && overlayRoot.getParent() == rootContainer) {
							startOpenAnimation();
						}
					}
				});
            dropdownLayer = new FrameLayout(context);
            dropdownLayer.setClipChildren(false);
            dropdownLayer.setClipToPadding(false);
            dropdownLayer.setElevation(dp(1000));
            overlayRoot.addView(dropdownLayer, matchParentFrameLp());
            dropdownLayer.bringToFront();
        }

        void addView(View v) { content.addView(v); }

        void addSpacer(int h) {
            View v = new View(context);
            v.setLayoutParams(new LinearLayout.LayoutParams(
								  LinearLayout.LayoutParams.MATCH_PARENT, h));
            content.addView(v);
        }

        TextView addTitle(String text) {
            TextView tv = new DigitTextView(context);
            tv.setText(text);
            tv.setTextColor(Color.WHITE);
            tv.setTypeface(typefaceSemiBold);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
            tv.setGravity(Gravity.START | Gravity.TOP);
            content.addView(tv);
            return tv;
        }

        void addLabel(String text) { content.addView(labelView(text)); }

        void close() { beginClose(CLOSE_DIRECTION_CENTER); }

        void beginClose(int direction) {
            if (isClosing) return;
            if (overlayRoot == null || overlayRoot.getParent() != rootContainer) return;
            isClosing = true;
            swipeClosing = false;
            startCloseAnimation(direction);
        }

        void startOpenAnimation() {
            if (windowFrame == null) return;
            if (openAnimator != null) { openAnimator.cancel(); openAnimator = null; }
            if (closeAnimator != null) { closeAnimator.cancel(); closeAnimator = null; }
            swipeClosing = false;
            swipeFromLeftEdge = false;
            windowFrame.setPivotX(windowFrame.getWidth() * 0.5f);
            windowFrame.setPivotY(windowFrame.getHeight() * 0.5f);
            windowFrame.setScaleX(0.965f);
            windowFrame.setScaleY(0.965f);
            windowFrame.setTranslationX(0f);
            windowFrame.setTranslationY(dp(10));
            if (pixel != null) { pixel.setVisibility(View.VISIBLE); pixel.setProgress(0f); pixel.setAlpha(1f); }
            openAnimator = ValueAnimator.ofFloat(0f, 1f);
            openAnimator.setDuration(OPEN_ANIM_DURATION_MS);
            openAnimator.setInterpolator(new DecelerateInterpolator(1.8f));
            openAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
					@Override public void onAnimationUpdate(ValueAnimator animation) {
						float p = ((Float) animation.getAnimatedValue()).floatValue();
						if (windowFrame != null) {
							windowFrame.setScaleX(0.965f + (0.035f * p));
							windowFrame.setScaleY(0.965f + (0.035f * p));
							windowFrame.setTranslationX(0f);
							windowFrame.setTranslationY(dp(10) * (1f - p));
						}
						if (pixel != null) {
							pixel.setProgress(p);
							if (p >= 1f) pixel.setVisibility(View.GONE);
						}
					}
				});
            openAnimator.start();
        }

        void startCloseAnimation(final int direction) {
            if (windowFrame == null || overlayRoot == null) { performImmediateClose(); return; }
            if (openAnimator != null) { openAnimator.cancel(); openAnimator = null; }
            if (closeAnimator != null) { closeAnimator.cancel(); closeAnimator = null; }
            final float endScale = 0.72f;
            final float endOffsetX;
            if (direction == CLOSE_DIRECTION_LEFT) {
                endOffsetX = -Math.max(dp(96), windowFrame.getWidth() * 0.22f);
            } else if (direction == CLOSE_DIRECTION_RIGHT) {
                endOffsetX = Math.max(dp(96), windowFrame.getWidth() * 0.22f);
            } else {
                endOffsetX = 0f;
            }
            final float endOffsetY = Math.max(dp(90), windowFrame.getHeight() * 0.18f);
            if (direction == CLOSE_DIRECTION_LEFT) {
                windowFrame.setPivotX(0f); windowFrame.setPivotY(windowFrame.getHeight());
            } else if (direction == CLOSE_DIRECTION_RIGHT) {
                windowFrame.setPivotX(windowFrame.getWidth()); windowFrame.setPivotY(windowFrame.getHeight());
            } else {
                windowFrame.setPivotX(windowFrame.getWidth() * 0.5f);
                windowFrame.setPivotY(windowFrame.getHeight() * 0.5f);
            }
            if (pixel != null) { pixel.setVisibility(View.VISIBLE); pixel.setProgress(1f); pixel.setAlpha(1f); }
            closeAnimator = ValueAnimator.ofFloat(1f, 0f);
            closeAnimator.setDuration(CLOSE_ANIM_DURATION_MS);
            closeAnimator.setInterpolator(new AccelerateInterpolator(1.6f));
            closeAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
					@Override public void onAnimationUpdate(ValueAnimator animation) {
						float p = ((Float) animation.getAnimatedValue()).floatValue();
						float f = 1f - p;
						if (windowFrame != null) {
							float scale = 1f - ((1f - endScale) * f);
							windowFrame.setScaleX(scale);
							windowFrame.setScaleY(scale);
							windowFrame.setTranslationX(endOffsetX * f);
							windowFrame.setTranslationY(endOffsetY * f);
						}
						if (pixel != null) pixel.setProgress(p);
					}
				});
            closeAnimator.addListener(new android.animation.Animator.AnimatorListener() {
					@Override public void onAnimationStart(android.animation.Animator a) { }
					@Override public void onAnimationEnd(android.animation.Animator a) { performImmediateClose(); }
					@Override public void onAnimationCancel(android.animation.Animator a) { performImmediateClose(); }
					@Override public void onAnimationRepeat(android.animation.Animator a) { }
				});
            closeAnimator.start();
        }

        boolean handleEdgeSwipe(MotionEvent event) {
            if (overlayRoot == null || windowFrame == null
                || overlayRoot.getParent() != rootContainer) return false;
            int action = event.getActionMasked();
            int edge = dp(28);
            switch (action) {
                case MotionEvent.ACTION_DOWN: {
						float x = event.getX();
						int w = overlayRoot.getWidth();
						if (w <= 0) return false;
						boolean fromLeft = x <= edge;
						boolean fromRight = x >= (w - edge);
						if (!fromLeft && !fromRight) return false;
						swipeClosing = true;
						swipeFromLeftEdge = fromLeft;
						swipeStartX = x; swipeStartY = event.getY();
						swipeLastDx = 0f; swipeLastDy = 0f;
						return true;
					}
                case MotionEvent.ACTION_MOVE: {
						if (!swipeClosing) return false;
						swipeLastDx = event.getX() - swipeStartX;
						swipeLastDy = event.getY() - swipeStartY;
						float drag = swipeFromLeftEdge ? swipeLastDx : -swipeLastDx;
						if (drag < 0f) drag = 0f;
						float progress = Math.min(1f, drag / (float) dp(220));
						float scale = 1f - (0.28f * progress);
						float tx = (swipeFromLeftEdge ? -1f : 1f)
							* Math.max(dp(24), windowFrame.getWidth() * 0.22f) * progress;
						float ty = Math.max(dp(18), windowFrame.getHeight() * 0.18f) * progress;
						if (swipeFromLeftEdge) windowFrame.setPivotX(0f);
						else windowFrame.setPivotX(windowFrame.getWidth());
						windowFrame.setPivotY(windowFrame.getHeight());
						windowFrame.setScaleX(scale); windowFrame.setScaleY(scale);
						windowFrame.setTranslationX(tx); windowFrame.setTranslationY(ty);
						return true;
					}
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL: {
						if (!swipeClosing) return false;
						float drag = swipeFromLeftEdge ? swipeLastDx : -swipeLastDx;
						boolean shouldClose = drag >= dp(84) || Math.abs(swipeLastDx) >= dp(84);
						if (shouldClose) {
							beginClose(swipeFromLeftEdge ? CLOSE_DIRECTION_LEFT : CLOSE_DIRECTION_RIGHT);
						} else {
							cancelSwipeGesture();
						}
						return true;
					}
                default:
                    return swipeClosing;
            }
        }

        void cancelSwipeGesture() {
            swipeClosing = false;
            if (windowFrame == null) return;
            windowFrame.setPivotX(windowFrame.getWidth() * 0.5f);
            windowFrame.setPivotY(windowFrame.getHeight() * 0.5f);
            windowFrame.animate().scaleX(1f).scaleY(1f).translationX(0f).translationY(0f)
                .setDuration(180L).setInterpolator(new DecelerateInterpolator(1.6f)).start();
        }

        void performImmediateClose() {
            if (overlayRoot != null && overlayRoot.getParent() == rootContainer) {
                rootContainer.removeView(overlayRoot);
            }
            if (openAnimator != null) { openAnimator.cancel(); openAnimator = null; }
            if (closeAnimator != null) { closeAnimator.removeAllListeners(); closeAnimator.cancel(); closeAnimator = null; }
            overlayRoot = null; windowFrame = null; pixel = null;
            isClosing = false; swipeClosing = false;
        }

        // ---------- dropdown (как в VelocityPanel) ----------
        void openDropdown(final View anchor, final String[] labels,
                          int selectedIndex, final OnPick callback) {
            dropdownLayer.removeAllViews();
            dropdownLayer.bringToFront();
            int[] anchorLoc = new int[2]; anchor.getLocationOnScreen(anchorLoc);
            int[] rootLoc = new int[2]; dropdownLayer.getLocationOnScreen(rootLoc);
            int relativeX = anchorLoc[0] - rootLoc[0];
            int relativeY = anchorLoc[1] - rootLoc[1];
            int anchorBottom = relativeY + anchor.getHeight();
            Rect visibleFrame = new Rect();
            rootContainer.getWindowVisibleDisplayFrame(visibleFrame);
            int visibleTop = visibleFrame.top - rootLoc[1];
            int visibleBottom = visibleFrame.bottom - rootLoc[1];
            View scrim = new View(context);
            scrim.setOnClickListener(new View.OnClickListener() {
					@Override public void onClick(View v) { dropdownLayer.removeAllViews(); }
				});
            dropdownLayer.addView(scrim, matchParentFrameLp());
            LinearLayout list = new LinearLayout(context);
            list.setOrientation(LinearLayout.VERTICAL);
            list.setBackground(createRoundedRect(dp(14), DROPDOWN_BG_COLOR, ACCENT_BORDER_COLOR, dp(1.25f)));
            list.setClipToOutline(true);
            list.setPadding(dp(6), dp(6), dp(6), dp(6));
            for (int i = 0; i < labels.length; i++) {
                final int idx = i;
                TextView item = new DigitTextView(context);
                item.setText(labels[i]);
                item.setTextColor(i == selectedIndex ? ACCENT_COLOR : Color.WHITE);
                item.setTypeface(i == selectedIndex ? typefaceSemiBold : typefaceRegular);
                item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                item.setPadding(dp(14), dp(10), dp(14), dp(10));
                item.setClickable(true); item.setFocusable(true);
                item.setOnClickListener(new View.OnClickListener() {
						@Override public void onClick(View v) {
							HapticUtils.perform(v);
							callback.onPicked(idx);
							dropdownLayer.removeAllViews();
						}
					});
                list.addView(item, new LinearLayout.LayoutParams(
								 LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            }
            int estimatedHeight = dp(12) + (labels.length * dp(40));
            int spaceBelow = Math.max(0, visibleBottom - anchorBottom - dp(8));
            int spaceAbove = Math.max(0, relativeY - visibleTop - dp(8));
            boolean showAbove = spaceBelow < estimatedHeight && spaceAbove > spaceBelow;
            final int maxHeight = Math.max(0, Math.min(estimatedHeight, showAbove ? spaceAbove : spaceBelow));
            ScrollView listScroll = new ScrollView(context) {
                @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                    int hSpec = heightMeasureSpec;
                    if (maxHeight > 0) {
                        int mode = View.MeasureSpec.getMode(hSpec);
                        int size = View.MeasureSpec.getSize(hSpec);
                        if (mode == View.MeasureSpec.UNSPECIFIED || size > maxHeight) {
                            hSpec = View.MeasureSpec.makeMeasureSpec(maxHeight, View.MeasureSpec.AT_MOST);
                        }
                    }
                    super.onMeasure(widthMeasureSpec, hSpec);
                }
            };
            listScroll.addView(list, new ScrollView.LayoutParams(
								   ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
            listScroll.setBackground(list.getBackground());
            list.setBackground(null);
            listScroll.setVerticalScrollBarEnabled(false);
            listScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
            FrameLayout.LayoutParams listLp = new FrameLayout.LayoutParams(dp(180), FrameLayout.LayoutParams.WRAP_CONTENT);
            listLp.leftMargin = Math.max(dp(8), relativeX + anchor.getWidth() - dp(180));
            if (showAbove) listLp.topMargin = Math.max(visibleTop + dp(8), relativeY - maxHeight - dp(4));
            else listLp.topMargin = anchorBottom + dp(4);
            dropdownLayer.addView(listScroll, listLp);
            listScroll.bringToFront();
        }
    }

    // =========================================================
    //  PixelFillOverlay — один в один из VelocityPanel
    // =========================================================
    private final class PixelFillOverlay extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Rect rect = new Rect();
        private float progress = 0f;
        private int cachedW = -1;
        private int cachedH = -1;
        private int tilePx = 1;
        private int cols = 0;
        private int rows = 0;
        private float[] thresholds = new float[0];

        PixelFillOverlay(Context context) {
            super(context);
            paint.setStyle(Paint.Style.FILL);
            setWillNotDraw(false);
            setClickable(false);
            setFocusable(false);
            setBackgroundColor(Color.TRANSPARENT);
        }

        void setProgress(float p) {
            if (p < 0f) p = 0f;
            if (p > 1f) p = 1f;
            if (progress == p) return;
            progress = p;
            invalidate();
        }

        private void ensureGeometry(int w, int h) {
            if (w == cachedW && h == cachedH && thresholds.length == cols * rows) return;
            cachedW = w; cachedH = h;
            int base = Math.min(w, h) / 18;
            tilePx = Math.max(dp(20), base);
            if (tilePx <= 0) tilePx = dp(20);
            cols = Math.max(1, (int) Math.ceil((double) w / (double) tilePx));
            rows = Math.max(1, (int) Math.ceil((double) h / (double) tilePx));
            thresholds = new float[cols * rows];
            float cx = w * 0.5f; float cy = h * 0.5f;
            float maxDist = (float) Math.sqrt((cx * cx) + (cy * cy));
            if (maxDist <= 0f) maxDist = 1f;
            int index = 0;
            for (int row = 0; row < rows; row++) {
                float y = (row * tilePx) + (tilePx * 0.5f);
                for (int col = 0; col < cols; col++) {
                    float x = (col * tilePx) + (tilePx * 0.5f);
                    float dx = x - cx; float dy = y - cy;
                    float norm = (float) Math.sqrt((dx * dx) + (dy * dy)) / maxDist;
                    if (norm < 0f) norm = 0f;
                    if (norm > 1f) norm = 1f;
                    thresholds[index++] = norm;
                }
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth(); int h = getHeight();
            if (w <= 0 || h <= 0) return;
            ensureGeometry(w, h);
            final int baseAlpha = 220;
            final int fillColor = 0xF21E1E20;
            final int accentColor = 0xFFD9946B;
            int fillR = Color.red(fillColor); int fillG = Color.green(fillColor); int fillB = Color.blue(fillColor);
            int accentR = Color.red(accentColor); int accentG = Color.green(accentColor); int accentB = Color.blue(accentColor);
            int index = 0;
            for (int row = 0; row < rows; row++) {
                int top = row * tilePx;
                int bottom = Math.min(h, top + tilePx);
                for (int col = 0; col < cols; col++) {
                    int left = col * tilePx;
                    int right = Math.min(w, left + tilePx);
                    float threshold = thresholds[index++];
                    float local = progress - threshold;
                    float alpha01;
                    if (local <= 0f) alpha01 = 1f;
                    else if (local >= 0.16f) alpha01 = 0f;
                    else {
                        float t = local / 0.16f;
                        alpha01 = 1f - (t * t * (3f - 2f * t));
                    }
                    if (alpha01 <= 0.01f) continue;
                    int alpha = (int) (baseAlpha * alpha01);
                    if (((row + col) & 7) == 0) paint.setColor(Color.argb(alpha, accentR, accentG, accentB));
                    else if (((row + col) & 3) == 0) paint.setColor(Color.argb(alpha, 52, 46, 44));
                    else paint.setColor(Color.argb(alpha, fillR, fillG, fillB));
                    rect.set(left, top, right, bottom);
                    canvas.drawRect(rect, paint);
                }
            }
        }
    }

    // =========================================================
    //  UI-хелперы
    // =========================================================
    private GradientDrawable createRoundedRect(float radius, int fillColor, int strokeColor, float strokeWidth) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(radius);
        gd.setColor(fillColor);
        gd.setStroke((int) strokeWidth, strokeColor);
        return gd;
    }

    private FrameLayout.LayoutParams matchParentFrameLp() {
        return new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
    }

    /** Нативная белая рябль без границы: волна от пальца к краям. */
    private RippleDrawable createBorderlessRipple() {
        ColorStateList csl = new ColorStateList(
            new int[][]{ new int[]{} }, new int[]{ Color.parseColor("#66FFFFFF") });
        ColorDrawable content = new ColorDrawable(Color.parseColor("#00000000"));
        ColorDrawable mask = new ColorDrawable(Color.BLACK);
        return new RippleDrawable(csl, content, mask);
    }

    private View spacerView(int h) {
        View v = new View(context);
        v.setLayoutParams(new LinearLayout.LayoutParams(
							  LinearLayout.LayoutParams.MATCH_PARENT, h));
        return v;
    }

    private TextView labelView(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#DDE3E1DE"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        return tv;
    }

    /** Кнопка "Рассчитать" — стиль из VelocityPanel. */
    private View calculateButton(final Runnable action) {
        TextView btn = new DigitTextView(context);
        btn.setText("Рассчитать");
        btn.setTextColor(Color.WHITE);
        btn.setTypeface(typefaceSemiBold);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(0, dp(14), 0, dp(14));
        btn.setBackground(createRoundedRect(dp(18), ACCENT_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        btn.setClickable(true); btn.setFocusable(true);
        btn.setLayoutParams(new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        btn.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					HapticUtils.perform(v);
					action.run();
				}
			});
        return btn;
    }

    private LinearLayout resultBox() {
        LinearLayout box = new LinearLayout(context);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(createRoundedRect(dp(16), Color.parseColor("#6F6B67"), Color.parseColor("#CCFFFFFF"), dp(1.5f)));
        int p = dp(14);
        box.setPadding(p, p, p, p);
        box.setLayoutParams(new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return box;
    }

    private TextView resultSectionTitle(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        return tv;
    }

    private View resultLine(String label, String value) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.VERTICAL);
        TextView labelView = new DigitTextView(context);
        labelView.setText(label);
        labelView.setTextColor(Color.parseColor("#BBFFFFFF"));
        labelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        row.addView(labelView);
        TextView valueView = new DigitTextView(context);
        valueView.setText(value);
        valueView.setTextColor(ACCENT_COLOR);
        valueView.setTypeface(typefaceSemiBold);
        valueView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        row.addView(valueView);
        return row;
    }

    private View resultSubLine(String label, String value) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        if (label != null && label.length() > 0) {
            TextView labelView = new DigitTextView(context);
            labelView.setText(label + "  ");
            labelView.setTextColor(Color.parseColor("#AAFFFFFF"));
            labelView.setTypeface(typefaceRegular);
            labelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            row.addView(labelView);
        }
        TextView valueView = new DigitTextView(context);
        valueView.setText(value);
        valueView.setTextColor(Color.parseColor("#DDFFFFFF"));
        valueView.setTypeface(typefaceRegular);
        valueView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        row.addView(valueView);
        return row;
    }

    private void resultError(LinearLayout holder, String message) {
        TextView tv = new DigitTextView(context);
        tv.setText(message);
        tv.setTextColor(Color.parseColor("#FFB4A0"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        holder.addView(tv);
    }

    private Double parseDouble(String text) {
        if (text == null) return null;
        String trimmed = text.trim().replace(',', '.');
        if (trimmed.isEmpty()) return null;
        try {
            return Double.parseDouble(trimmed);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static String fmtSmart(double v) {
        if (Double.isNaN(v)) return "NaN";
        if (Double.isInfinite(v)) return "∞";
        double a = Math.abs(v);
        if (a != 0 && (a >= 1e12 || a < 1e-6)) {
            return String.format(Locale.US, "%.6e", v);
        }
        String s = String.format(Locale.US, "%.8f", v);
        if (s.indexOf('.') >= 0) {
            int end = s.length();
            while (end > 0 && s.charAt(end - 1) == '0') end--;
            if (end > 0 && s.charAt(end - 1) == '.') end--;
            s = s.substring(0, end);
        }
        if (s.equals("-0")) s = "0";
        return s;
    }

    /** Продолженные дроби: точная дробь для десятичного результата, иначе null. */
    private static String toFraction(double v) {
        if (Double.isNaN(v) || Double.isInfinite(v)) return null;
        double a = Math.abs(v);
        if (a < 1e-12) return "0";
        if (a > 1e9) return null;
        long h0 = 0, h1 = 1, k0 = 1, k1 = 0;
        double x = a;
        for (int i = 0; i < 40; i++) {
            long ai = (long) Math.floor(x);
            long h2 = ai * h1 + h0;
            long k2 = ai * k1 + k0;
            if (k2 > 1000000L || h2 > 999999999L) break;
            double diff = Math.abs(a - ((double) h2) / ((double) k2));
            if (diff <= 1e-9 * Math.max(1.0, a)) {
                if (k2 == 1) return null; // целое — дробь не нужна
                String sign = v < 0 ? "−" : "";
                long whole = h2 / k2;
                long rem = h2 % k2;
                if (whole > 0 && rem > 0) return sign + whole + " " + rem + "/" + k2;
                if (whole > 0) return sign + whole;
                return sign + rem + "/" + k2;
            }
            h0 = h1; h1 = h2; k0 = k1; k1 = k2;
            double fracPart = x - ai;
            if (fracPart < 1e-12) break;
            x = 1.0 / fracPart;
        }
        return null;
    }

    private static String stack(Throwable t) {
        try {
            java.io.StringWriter sw = new java.io.StringWriter();
            t.printStackTrace(new java.io.PrintWriter(sw));
            String s = sw.toString();
            return s.length() > 1500 ? s.substring(0, 1500) + "…" : s;
        } catch (Throwable ignore) {
            return String.valueOf(t);
        }
    }

    // =========================================================
    //  Поля с единицами (стиль VelocityPanel)
    // =========================================================
    private static final class ValueUnitRow {
        View row;
        EditText input;
        UnitPillState unitState;
    }

    private static final class UnitPillState {
        TextView pillView;
        View rowView;
        int selectedIndex = 0;
        String[] labels;
    }

    private ValueUnitRow buildValueUnitRow(final GlassWindow win, final String[] unitLabels, String hint) {
        FrameLayout field = new FrameLayout(context);
        field.setBackground(createRoundedRect(dp(16), FIELD_BG_COLOR, FIELD_BORDER_COLOR, dp(1.25f)));
        field.setClipToOutline(true);
        final EditText input = new DigitEditText(context);
        input.setHint(hint);
        input.setHintTextColor(Color.parseColor("#77FFFFFF"));
        input.setTextColor(Color.WHITE);
        input.setTypeface(typefaceRegular);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        input.setSingleLine(true);
        input.setBackground(null);
        input.setInputType(InputType.TYPE_CLASS_NUMBER
						   | InputType.TYPE_NUMBER_FLAG_DECIMAL
						   | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setPadding(dp(16), dp(12), dp(120), dp(12));
        field.addView(input, matchParentFrameLp());

        final UnitPillState state = new UnitPillState();
        state.labels = unitLabels;
        state.selectedIndex = 0;
        final TextView pill = new DigitTextView(context);
        pill.setText(unitLabels[0]);
        pill.setTextColor(Color.WHITE);
        pill.setTypeface(typefaceSemiBold);
        pill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        pill.setGravity(Gravity.CENTER);
        pill.setMaxLines(1);
        pill.setEllipsize(android.text.TextUtils.TruncateAt.END);
        pill.setBackground(createRoundedRect(dp(14), PILL_BG_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        pill.setPadding(dp(12), dp(8), dp(12), dp(8));
        pill.setClickable(true); pill.setFocusable(true);
        FrameLayout.LayoutParams pillLp = new FrameLayout.LayoutParams(dp(104), FrameLayout.LayoutParams.WRAP_CONTENT);
        pillLp.gravity = Gravity.CENTER_VERTICAL | Gravity.END;
        pillLp.rightMargin = dp(8);
        field.addView(pill, pillLp);
        pill.setTranslationZ(dp(3f));
        state.pillView = pill;
        pill.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					HapticUtils.perform(v);
					win.openDropdown(pill, unitLabels, state.selectedIndex, new OnPick() {
							@Override public void onPicked(int i) {
								state.selectedIndex = i;
								pill.setText(unitLabels[i]);
							}
						});
				}
			});
        field.setLayoutParams(new LinearLayout.LayoutParams(
								  LinearLayout.LayoutParams.MATCH_PARENT, dp(50)));
        ValueUnitRow row = new ValueUnitRow();
        row.row = field;
        row.input = input;
        row.unitState = state;
        return row;
    }

    /** Чёрная пилюля-не-поле: открывает список целевых единиц. */
    private UnitPillState buildTargetPillRow(final GlassWindow win, final String[] labels) {
        final UnitPillState state = new UnitPillState();
        state.labels = labels;
        state.selectedIndex = 0;
        final FrameLayout row = new FrameLayout(context);
        row.setBackground(createRoundedRect(dp(16), PILL_BG_COLOR, FIELD_BORDER_COLOR, dp(1.25f)));
        row.setClipToOutline(true);
        final TextView tv = new DigitTextView(context);
        tv.setText(labels[0]);
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(12), dp(14), dp(12), dp(14));
        row.addView(tv, matchParentFrameLp());
        row.setClickable(true); row.setFocusable(true);
        row.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					tickHaptic(v);
					win.openDropdown(row, labels, state.selectedIndex, new OnPick() {
							@Override public void onPicked(int i) {
								state.selectedIndex = i;
								tv.setText(labels[i]);
							}
						});
				}
			});
        row.setLayoutParams(new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        state.pillView = tv;
        state.rowView = row;
        return state;
    }

    // =========================================================
    //  МЕНЮ КАЛЬКУЛЯТОРА
    // =========================================================
    private void buildMenu() {
        final GlassWindow win = new GlassWindow(false);
        win.addTitle("Калькулятор");
        win.addSpacer(dp(18));
        win.addView(menuButton("Единицы измерения", new Runnable() {
							@Override public void run() { openUnitsWindow(); }
						}));
        win.addSpacer(dp(6));
        win.addView(menuButton("Обычный калькулятор", new Runnable() {
							@Override public void run() { openBasicCalculator(); }
						}));
        win.addSpacer(dp(6));
        win.addView(menuButton("Плотность, радиус, масса и гравитация", new Runnable() {
							@Override public void run() { openPhysicsWindow(); }
						}));
        win.addSpacer(dp(10));
    }

    private View menuButton(String text, final Runnable action) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#E3E1DE"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        tv.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        tv.setPadding(dp(18), dp(16), dp(18), dp(16));
        tv.setMinHeight(dp(58));
        tv.setBackground(createBorderlessRipple());
        tv.setClickable(true); tv.setFocusable(true);
        tv.setLayoutParams(new LinearLayout.LayoutParams(
							   LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        tv.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) { tickHaptic(v); action.run(); }
			});
        return tv;
    }

    // =========================================================
    //  ОКНО 1: ЕДИНИЦЫ ИЗМЕРЕНИЯ (карусель-«замочек»)
    // =========================================================
    private void openUnitsWindow() {
        final GlassWindow win = new GlassWindow(true);
        win.addTitle("Единицы измерения");
        win.addSpacer(dp(16));

        final int itemWidth = dp(120);
        final LinearLayout items = new LinearLayout(context);
        items.setOrientation(LinearLayout.HORIZONTAL);
        final HorizontalScrollView carousel = new HorizontalScrollView(context);
        carousel.setHorizontalScrollBarEnabled(false);
        carousel.setOverScrollMode(View.OVER_SCROLL_NEVER);
        carousel.addView(items, new FrameLayout.LayoutParams(
							 FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.MATCH_PARENT));

        FrameLayout pill = new FrameLayout(context);
        pill.setBackground(createRoundedRect(dp(16), PILL_BG_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        pill.setClipToOutline(true);
        pill.addView(carousel, matchParentFrameLp());
        pill.setLayoutParams(new LinearLayout.LayoutParams(
								 LinearLayout.LayoutParams.MATCH_PARENT, dp(56)));
        win.addView(pill);
        win.addSpacer(dp(16));

        final LinearLayout convContainer = new LinearLayout(context);
        convContainer.setOrientation(LinearLayout.VERTICAL);
        win.addView(convContainer);
        win.addSpacer(dp(16));

        final TextView[] itemViews = new TextView[CATEGORIES.length];
        for (int i = 0; i < CATEGORIES.length; i++) {
            final int idx = i;
            TextView tv = new DigitTextView(context);
            tv.setText(CATEGORIES[i].name);
            tv.setGravity(Gravity.CENTER);
            tv.setMaxLines(1);
            tv.setEllipsize(android.text.TextUtils.TruncateAt.END);
            tv.setLayoutParams(new LinearLayout.LayoutParams(itemWidth, LinearLayout.LayoutParams.MATCH_PARENT));
            tv.setClickable(true); tv.setFocusable(true);
            tv.setOnClickListener(new View.OnClickListener() {
					@Override public void onClick(View v) {
						tickHaptic(v);
						centerItem(carousel, items, idx);
					}
				});
            itemViews[idx] = tv;
            items.addView(tv);
        }

        final int[] current = new int[]{0};
        final int[] applied = new int[]{-1};
        final Handler handler = new Handler(Looper.getMainLooper());
        final Runnable idleRunnable = new Runnable() {
            @Override public void run() {
                centerItem(carousel, items, current[0]);
                if (applied[0] != current[0]) {
                    applied[0] = current[0];
                    buildConversion(win, convContainer, CATEGORIES[applied[0]]);
                }
            }
        };
        carousel.setOnScrollChangeListener(new View.OnScrollChangeListener() {
				@Override public void onScrollChange(View v, int sx, int sy, int oldSx, int oldSy) {
					int centerX = sx + carousel.getWidth() / 2;
					int best = 0; int bestDist = Integer.MAX_VALUE;
					for (int i = 0; i < itemViews.length; i++) {
						View child = itemViews[i];
						int childCenter = child.getLeft() + child.getWidth() / 2;
						int d = Math.abs(childCenter - centerX);
						if (d < bestDist) { bestDist = d; best = i; }
					}
					if (best != current[0]) {
						current[0] = best;
						tickHaptic(carousel); // вибрация + тактильный на каждый шаг
					}
					styleCarouselItems(itemViews, centerX);
					handler.removeCallbacks(idleRunnable);
					handler.postDelayed(idleRunnable, 120);
				}
			});

        carousel.post(new Runnable() {
				@Override public void run() {
					int pad = Math.max(0, (carousel.getWidth() - itemWidth) / 2);
					items.setPadding(pad, 0, pad, 0);
					styleCarouselItems(itemViews, carousel.getWidth() / 2);
					applied[0] = 0;
					buildConversion(win, convContainer, CATEGORIES[0]);
				}
			});
    }

    private void styleCarouselItems(TextView[] itemViews, int centerX) {
        for (int i = 0; i < itemViews.length; i++) {
            View child = itemViews[i];
            int childCenter = child.getLeft() + child.getWidth() / 2;
            float d = Math.abs(childCenter - centerX);
            float t = 1f - Math.min(1f, d / (child.getWidth() * 1.4f));
            if (t < 0f) t = 0f;
            child.setScaleX(0.85f + 0.28f * t);
            child.setScaleY(0.85f + 0.28f * t);
            itemViews[i].setTextColor(Color.argb((int) (110 + 145 * t), 255, 255, 255));
            itemViews[i].setTypeface(t > 0.75f ? typefaceSemiBold : typefaceRegular);
            itemViews[i].setTextSize(TypedValue.COMPLEX_UNIT_SP, 13 + 3 * t);
        }
    }

    private void centerItem(HorizontalScrollView carousel, LinearLayout items, int idx) {
        View child = items.getChildAt(idx);
        if (child == null) return;
        int target = child.getLeft() + child.getWidth() / 2 - carousel.getWidth() / 2;
        carousel.smoothScrollTo(Math.max(0, target), 0);
    }

    private double categoryFactor(Category cat, int idx) {
        UnitDef u = cat.units[idx];
        return cat.isData && dataBinary ? u.bin : u.dec;
    }

    private void buildConversion(final GlassWindow win,
                                 final LinearLayout container,
                                 final Category cat) {
        container.removeAllViews();
        final LinearLayout inner = new LinearLayout(context);
        inner.setOrientation(LinearLayout.VERTICAL);

        if (cat.isData) {
            final TextView baseBtn = new DigitTextView(context);
            baseBtn.setText(dataBinary ? "Основание: 1024 (двоичные)" : "Основание: 1000 (десятичные)");
            baseBtn.setTextColor(ACCENT_COLOR);
            baseBtn.setTypeface(typefaceRegular);
            baseBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            baseBtn.setGravity(Gravity.CENTER);
            baseBtn.setPadding(dp(12), dp(8), dp(12), dp(8));
            baseBtn.setBackground(createBorderlessRipple());
            baseBtn.setClickable(true); baseBtn.setFocusable(true);
            baseBtn.setOnClickListener(new View.OnClickListener() {
					@Override public void onClick(View v) {
						tickHaptic(v);
						dataBinary = !dataBinary;
						buildConversion(win, container, cat);
					}
				});
            inner.addView(baseBtn);
            inner.addView(spacerView(dp(10)));
        }

        final String[] labels = new String[cat.units.length];
        for (int i = 0; i < labels.length; i++) labels[i] = cat.units[i].label;

        inner.addView(labelView("Значение"));
        inner.addView(spacerView(dp(6)));
        final ValueUnitRow fromRow = buildValueUnitRow(win, labels, "Введите значение");
        inner.addView(fromRow.row);
        inner.addView(spacerView(dp(14)));

        inner.addView(labelView("Перевести в"));
        inner.addView(spacerView(dp(6)));
        final UnitPillState targetState = buildTargetPillRow(win, labels);
        inner.addView(targetState.rowView);
        inner.addView(spacerView(dp(16)));

        final LinearLayout resultHolder = new LinearLayout(context);
        resultHolder.setOrientation(LinearLayout.VERTICAL);

        inner.addView(calculateButton(new Runnable() {
							  @Override public void run() {
								  onConvert(cat, fromRow, targetState, resultHolder);
							  }
						  }));
        inner.addView(spacerView(dp(12)));
        inner.addView(resultHolder);

        container.addView(inner);
        inner.setAlpha(0f); inner.setTranslationY(dp(8));
        inner.animate().alpha(1f).translationY(0f).setDuration(220)
            .setInterpolator(new DecelerateInterpolator(1.6f)).start();
    }

    private void onConvert(Category cat, ValueUnitRow fromRow, UnitPillState targetState, LinearLayout resultHolder) {
        resultHolder.removeAllViews();
        try {
            Double value = parseDouble(fromRow.input.getText().toString());
            if (value == null) {
                resultError(resultHolder, "Введите корректное значение.");
                return;
            }
            double fromFactor = categoryFactor(cat, fromRow.unitState.selectedIndex);
            double toFactor = categoryFactor(cat, targetState.selectedIndex);
            if (toFactor == 0) {
                resultError(resultHolder, "Некорректная целевая единица.");
                return;
            }
            double result = value * fromFactor / toFactor;
            String fromLabel = cat.units[fromRow.unitState.selectedIndex].label;
            String toLabel = cat.units[targetState.selectedIndex].label;

            LinearLayout box = resultBox();
            box.addView(resultSectionTitle("Результат"));
            box.addView(spacerView(dp(8)));
            box.addView(resultLine(fromLabel + " → " + toLabel, fmtSmart(result) + " " + toLabel));
            box.addView(spacerView(dp(6)));
            box.addView(resultSubLine("Исходно:", fmtSmart(value) + " " + fromLabel));
            resultHolder.addView(box);
        } catch (Throwable t) {
            resultError(resultHolder, "Ошибка при расчёте:\n" + stack(t));
        }
    }

    // =========================================================
    //  ОКНО 2: ОБЫЧНЫЙ КАЛЬКУЛЯТОР (научный + дроби)
    // =========================================================
    private void openBasicCalculator() {
        final GlassWindow win = new GlassWindow(true);
        win.addTitle("Калькулятор");
        win.addSpacer(dp(12));

        final StringBuilder expr = new StringBuilder();
        final boolean[] deg = new boolean[]{true};
        final String[] lastResult = new String[]{null};
        final boolean[] lastWasEquals = new boolean[]{false};

        final TextView exprView = new DigitTextView(context);
        exprView.setTextColor(Color.WHITE);
        exprView.setTypeface(typefaceRegular);
        exprView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        exprView.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        exprView.setSingleLine(true);
        exprView.setEllipsize(android.text.TextUtils.TruncateAt.START);
        exprView.setPadding(dp(16), dp(10), dp(16), dp(10));
        exprView.setBackground(createRoundedRect(dp(16), FIELD_BG_COLOR, FIELD_BORDER_COLOR, dp(1.25f)));
        exprView.setMinHeight(dp(56));
        win.addView(exprView);
        win.addSpacer(dp(6));

        final TextView resultView = new DigitTextView(context);
        resultView.setTextColor(ACCENT_COLOR);
        resultView.setTypeface(typefaceSemiBold);
        resultView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        resultView.setGravity(Gravity.END);
        resultView.setMinHeight(dp(24));
        win.addView(resultView);
        win.addSpacer(dp(8));

        final TextView degBtn = new DigitTextView(context);
        degBtn.setText("DEG");
        degBtn.setTextColor(Color.WHITE);
        degBtn.setTypeface(typefaceSemiBold);
        degBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        degBtn.setGravity(Gravity.CENTER);
        degBtn.setBackground(createBorderlessRipple());
        degBtn.setPadding(dp(14), dp(8), dp(14), dp(8));
        degBtn.setClickable(true); degBtn.setFocusable(true);
        degBtn.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					tickHaptic(v);
					deg[0] = !deg[0];
					degBtn.setText(deg[0] ? "DEG" : "RAD");
				}
			});
        win.addView(degBtn);
        win.addSpacer(dp(8));

        win.addView(calcRow(new String[]{"sin(", "cos(", "tan(", "ln(", "log("},
							expr, exprView, resultView, deg, lastResult, lastWasEquals));
        win.addView(calcRow(new String[]{"√(", "²", "^", "π", "e"},
							expr, exprView, resultView, deg, lastResult, lastWasEquals));
        win.addView(calcRow(new String[]{"(", ")", "!", "%", "a/b"},
							expr, exprView, resultView, deg, lastResult, lastWasEquals));
        win.addSpacer(dp(6));
        win.addView(calcRow(new String[]{"C", "±", "⌫", "÷"},
							expr, exprView, resultView, deg, lastResult, lastWasEquals));
        win.addView(calcRow(new String[]{"7", "8", "9", "×"},
							expr, exprView, resultView, deg, lastResult, lastWasEquals));
        win.addView(calcRow(new String[]{"4", "5", "6", "−"},
							expr, exprView, resultView, deg, lastResult, lastWasEquals));
        win.addView(calcRow(new String[]{"1", "2", "3", "+"},
							expr, exprView, resultView, deg, lastResult, lastWasEquals));
        win.addView(calcRow(new String[]{"0", ".", "=", ""},
							expr, exprView, resultView, deg, lastResult, lastWasEquals));
        win.addSpacer(dp(14));
    }

    private boolean isOperatorKey(String key) {
        return key.equals("÷") || key.equals("×") || key.equals("−") || key.equals("+")
            || key.equals("=") || key.equals("⌫") || key.equals("C") || key.equals("±")
            || key.equals("^") || key.equals("²") || key.equals("!") || key.equals("%");
    }

    private boolean isValueStartKey(String key) {
        if (key.length() == 0) return false;
        char c = key.charAt(0);
        return Character.isDigit(c) || c == '.' || c == 'π' || c == 'e' || c == '('
            || key.startsWith("sin(") || key.startsWith("cos(") || key.startsWith("tan(")
            || key.startsWith("ln(") || key.startsWith("log(") || key.startsWith("√(");
    }

    private View calcRow(String[] keys,
                         final StringBuilder expr,
                         final TextView exprView,
                         final TextView resultView,
                         final boolean[] deg,
                         final String[] lastResult,
                         final boolean[] lastWasEquals) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < keys.length; i++) {
            final String key = keys[i];
            TextView tv = new DigitTextView(context);
            if (key.length() == 0) {
                // пустая ячейка-распорка
                tv.setLayoutParams(new LinearLayout.LayoutParams(0, dp(50), 1f));
                row.addView(tv);
                continue;
            }
            tv.setText(key);
            boolean op = isOperatorKey(key);
            tv.setTextColor(op ? ACCENT_COLOR : Color.WHITE);
            tv.setTypeface(op ? typefaceSemiBold : typefaceRegular);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, key.length() > 2 ? 13 : 17);
            tv.setGravity(Gravity.CENTER);
            tv.setBackground(createBorderlessRipple());
            tv.setClickable(true); tv.setFocusable(true);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(50), 1f);
            lp.setMargins(dp(2), dp(2), dp(2), dp(2));
            tv.setLayoutParams(lp);
            tv.setOnClickListener(new View.OnClickListener() {
					@Override public void onClick(View v) {
						HapticUtils.perform(v);
						onCalcKey(key, expr, exprView, resultView, deg, lastResult, lastWasEquals);
					}
				});
            row.addView(tv);
        }
        return row;
    }

    private void onCalcKey(String key,
                           StringBuilder expr,
                           TextView exprView,
                           TextView resultView,
                           boolean[] deg,
                           String[] lastResult,
                           boolean[] lastWasEquals) {
        if (key.equals("C")) {
            expr.setLength(0);
            resultView.setText("");
            lastWasEquals[0] = false;
            exprView.setText("");
            return;
        }
        if (key.equals("⌫")) {
            String[] words = {"sin(", "cos(", "tan(", "ln(", "log(", "√("};
            String cur = expr.toString();
            boolean removed = false;
            for (String w : words) {
                if (cur.endsWith(w)) {
                    expr.setLength(expr.length() - w.length());
                    removed = true;
                    break;
                }
            }
            if (!removed && expr.length() > 0) {
                expr.setLength(expr.length() - 1);
            }
            lastWasEquals[0] = false;
            exprView.setText(expr.toString());
            return;
        }
        if (key.equals("±")) {
            toggleSign(expr);
            exprView.setText(expr.toString());
            return;
        }
        if (key.equals("a/b")) {
            String src = lastResult[0];
            if (src == null) {
                resultView.setText("Сначала посчитайте значение (=)");
                return;
            }
            Double v = parseDouble(src);
            if (v == null) {
                resultView.setText("Не удалось разобрать результат");
                return;
            }
            String frac = toFraction(v);
            resultView.setText(frac != null ? ("= " + frac) : "Не представимо точной дробью");
            return;
        }
        if (key.equals("=")) {
            onEquals(expr, resultView, deg, lastResult);
            lastWasEquals[0] = true;
            return;
        }
        // добавление токена
        if (lastWasEquals[0]) {
            if (isValueStartKey(key)) {
                expr.setLength(0);
            } else if (lastResult[0] != null) {
                expr.setLength(0);
                expr.append(lastResult[0]);
            }
            lastWasEquals[0] = false;
        }
        expr.append(key);
        exprView.setText(expr.toString());
    }

    private void toggleSign(StringBuilder expr) {
        int end = expr.length();
        if (end == 0) {
            expr.append('−');
            return;
        }
        int start = end;
        while (start > 0) {
            char c = expr.charAt(start - 1);
            if (Character.isDigit(c) || c == '.') start--;
            else break;
        }
        if (start == end) {
            expr.append('−');
            return;
        }
        if (start > 0 && expr.charAt(start - 1) == '−') {
            expr.deleteCharAt(start - 1);
        } else {
            expr.insert(start, '−');
        }
    }

    private void onEquals(StringBuilder expr, TextView resultView, boolean[] deg, String[] lastResult) {
        String s = expr.toString().trim();
        if (s.isEmpty()) return;
        int open = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == '(') open++;
            else if (s.charAt(i) == ')') open--;
        }
        StringBuilder closed = new StringBuilder(s);
        for (int i = 0; i < open; i++) closed.append(')');
        try {
            double v = ExprParser.eval(closed.toString(), deg[0]);
            String dec = fmtSmart(v);
            String frac = toFraction(v);
            resultView.setText("=" + dec + (frac != null ? ("  =  " + frac) : ""));
            lastResult[0] = dec;
        } catch (Throwable t) {
            resultView.setText("Ошибка: " + t.getMessage());
        }
    }

    // =========================================================
    //  Парсер выражений
    // =========================================================
    private static final class ExprParser {
        private final String s;
        private final boolean deg;
        private int p;

        private ExprParser(String s, boolean deg) { this.s = s; this.deg = deg; }

        static double eval(String expression, boolean deg) throws Exception {
            ExprParser ep = new ExprParser(expression, deg);
            double v = ep.parseExpr();
            ep.skipSpaces();
            if (ep.p < ep.s.length()) {
                throw new Exception("лишний символ '" + ep.s.charAt(ep.p) + "'");
            }
            return v;
        }

        private void skipSpaces() {
            while (p < s.length() && s.charAt(p) == ' ') p++;
        }

        private boolean eat(char c) {
            skipSpaces();
            if (p < s.length() && s.charAt(p) == c) { p++; return true; }
            return false;
        }

        private double parseExpr() throws Exception {
            double v = parseTerm();
            while (true) {
                if (eat('+')) v += parseTerm();
                else if (eat('−') || eat('-')) v -= parseTerm();
                else return v;
            }
        }

        private double parseTerm() throws Exception {
            double v = parseFactor();
            while (true) {
                if (eat('×') || eat('*')) v *= parseFactor();
                else if (eat('÷') || eat('/')) {
                    double d = parseFactor();
                    if (d == 0) throw new Exception("деление на ноль");
                    v /= d;
                } else return v;
            }
        }

        private double parseFactor() throws Exception {
            skipSpaces();
            if (eat('−') || eat('-')) return -parseFactor();
            if (eat('+')) return parseFactor();
            return parsePower();
        }

        private double parsePower() throws Exception {
            double base = parsePostfix();
            skipSpaces();
            if (eat('^')) {
                double e = parseFactor();
                return Math.pow(base, e);
            }
            return base;
        }

        private double parsePostfix() throws Exception {
            double v = parsePrimary();
            while (true) {
                if (eat('!')) v = factorial(v);
                else if (eat('%')) v = v / 100.0;
                else if (eat('²')) v = v * v;
                else return v;
            }
        }

        private double parsePrimary() throws Exception {
            skipSpaces();
            if (p >= s.length()) throw new Exception("неполное выражение");
            char c = s.charAt(p);
            if (c == '(') {
                p++;
                double v = parseExpr();
                if (!eat(')')) throw new Exception("не закрыта скобка");
                return v;
            }
            if (c == 'π') { p++; return Math.PI; }
            if (c == 'e') { p++; return Math.E; }
            if (Character.isDigit(c) || c == '.') return parseNumber();
            String[] funcs = {"sin(", "cos(", "tan(", "ln(", "log(", "√("};
            for (String f : funcs) {
                if (s.startsWith(f, p)) {
                    p += f.length();
                    double arg = parseExpr();
                    if (!eat(')')) throw new Exception("не закрыта скобка функции");
                    return applyFunc(f, arg);
                }
            }
            throw new Exception("непонятный символ '" + c + "'");
        }

        private double applyFunc(String f, double arg) throws Exception {
            if (f.equals("ln(")) {
                if (arg <= 0) throw new Exception("ln от неположительного");
                return Math.log(arg);
            }
            if (f.equals("log(")) {
                if (arg <= 0) throw new Exception("log от неположительного");
                return Math.log10(arg);
            }
            if (f.equals("√(")) {
                if (arg < 0) throw new Exception("корень из отрицательного");
                return Math.sqrt(arg);
            }
            double a = deg ? Math.toRadians(arg) : arg;
            if (f.equals("sin(")) return Math.sin(a);
            if (f.equals("cos(")) return Math.cos(a);
            if (f.equals("tan(")) {
                if (Math.abs(Math.cos(a)) < 1e-12) throw new Exception("тангенс не определён");
                return Math.tan(a);
            }
            throw new Exception("неизвестная функция");
        }

        private double parseNumber() throws Exception {
            int start = p;
            boolean dot = false;
            while (p < s.length()) {
                char c = s.charAt(p);
                if (Character.isDigit(c)) { p++; continue; }
                if (c == '.' && !dot) { dot = true; p++; continue; }
                break;
            }
            try {
                return Double.parseDouble(s.substring(start, p));
            } catch (NumberFormatException e) {
                throw new Exception("плохое число");
            }
        }

        private double factorial(double v) throws Exception {
            if (v < 0 || v > 170 || v != Math.floor(v)) {
                throw new Exception("факториал — целое 0…170");
            }
            double r = 1;
            for (long i = 2; i <= (long) v; i++) r *= i;
            return r;
        }
    }

    // =========================================================
    //  ОКНО 3: ПЛОТНОСТЬ / РАДИУС / МАССА / ГРАВИТАЦИЯ (2 из 4 -> 1 из 4)
    // =========================================================
    private void openPhysicsWindow() {
        final GlassWindow win = new GlassWindow(true);
        win.addTitle("Плотность, радиус, масса и гравитация");
        win.addSpacer(dp(14));

        final int[] known1 = new int[]{0};
        final int[] known2 = new int[]{1};
        final int[] out    = new int[]{2};
        final ValueUnitRow[] inputs = new ValueUnitRow[2];

        final LinearLayout inputsContainer = new LinearLayout(context);
        inputsContainer.setOrientation(LinearLayout.VERTICAL);
        final LinearLayout resultContainer = new LinearLayout(context);
        resultContainer.setOrientation(LinearLayout.VERTICAL);

        win.addLabel("Известно (1)");
        win.addSpacer(dp(6));
        final TextView pill1 = selectorPill(QUANT_LABELS[known1[0]]);
        win.addView(pill1);
        win.addSpacer(dp(12));
        win.addLabel("Известно (2)");
        win.addSpacer(dp(6));
        final TextView pill2 = selectorPill(QUANT_LABELS[known2[0]]);
        win.addView(pill2);
        win.addSpacer(dp(12));
        win.addLabel("Вычислить");
        win.addSpacer(dp(6));
        final TextView pillOut = selectorPill(QUANT_LABELS[out[0]]);
        win.addView(pillOut);
        win.addSpacer(dp(16));

        win.addView(inputsContainer);
        win.addSpacer(dp(16));
        win.addView(calculateButton(new Runnable() {
							@Override public void run() {
								onPhysicsCalculate(inputs, known1[0], known2[0], out[0], resultContainer);
							}
						}));
        win.addSpacer(dp(12));
        win.addView(resultContainer);
        win.addSpacer(dp(14));

        final Runnable[] refresher = new Runnable[1];
        refresher[0] = new Runnable() {
            @Override public void run() {
                pill1.setText(QUANT_LABELS[known1[0]]);
                pill2.setText(QUANT_LABELS[known2[0]]);
                pillOut.setText(QUANT_LABELS[out[0]]);
                rebuildPhysicsInputs(win, inputsContainer, inputs, known1[0], known2[0]);
                resultContainer.removeAllViews();
            }
        };

        pill1.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					tickHaptic(v);
					win.openDropdown(pill1, QUANT_LABELS, known1[0], new OnPick() {
							@Override public void onPicked(int i) {
								known1[0] = i;
								if (known2[0] == known1[0]) known2[0] = firstFree(known1[0], -1);
								if (out[0] == known1[0] || out[0] == known2[0]) {
									out[0] = firstFree(known1[0], known2[0]);
								}
								refresher[0].run();
							}
						});
				}
			});
        pill2.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					tickHaptic(v);
					final int[] options = freeOptions(known1[0], -1);
					win.openDropdown(pill2, optionLabels(options), indexOf(options, known2[0]), new OnPick() {
							@Override public void onPicked(int i) {
								known2[0] = options[i];
								if (out[0] == known1[0] || out[0] == known2[0]) {
									out[0] = firstFree(known1[0], known2[0]);
								}
								refresher[0].run();
							}
						});
				}
			});
        pillOut.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					tickHaptic(v);
					final int[] options = freeOptions(known1[0], known2[0]);
					win.openDropdown(pillOut, optionLabels(options), indexOf(options, out[0]), new OnPick() {
							@Override public void onPicked(int i) {
								out[0] = options[i];
								refresher[0].run();
							}
						});
				}
			});

        rebuildPhysicsInputs(win, inputsContainer, inputs, known1[0], known2[0]);
    }

    private TextView selectorPill(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tv.setGravity(Gravity.CENTER);
        tv.setBackground(createRoundedRect(dp(16), PILL_BG_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        tv.setPadding(dp(12), dp(12), dp(12), dp(12));
        tv.setClickable(true); tv.setFocusable(true);
        tv.setLayoutParams(new LinearLayout.LayoutParams(
							   LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return tv;
    }

    private int firstFree(int a, int b) {
        for (int i = 0; i < 4; i++) if (i != a && i != b) return i;
        return 0;
    }

    private int[] freeOptions(int a, int b) {
        int count = 0;
        for (int i = 0; i < 4; i++) if (i != a && i != b) count++;
        int[] r = new int[count];
        int k = 0;
        for (int i = 0; i < 4; i++) if (i != a && i != b) r[k++] = i;
        return r;
    }

    private String[] optionLabels(int[] options) {
        String[] r = new String[options.length];
        for (int i = 0; i < options.length; i++) r[i] = QUANT_LABELS[options[i]];
        return r;
    }

    private int indexOf(int[] options, int value) {
        for (int i = 0; i < options.length; i++) if (options[i] == value) return i;
        return 0;
    }

    private String[] labelsFor(int q) {
        if (q == 0) {
            PhysicsEngine.MassUnit[] u = PhysicsEngine.MassUnit.values();
            String[] r = new String[u.length];
            for (int i = 0; i < u.length; i++) r[i] = u[i].label;
            return r;
        }
        if (q == 1) {
            PhysicsEngine.DistanceUnit[] u = PhysicsEngine.DistanceUnit.values();
            String[] r = new String[u.length];
            for (int i = 0; i < u.length; i++) r[i] = u[i].label;
            return r;
        }
        UnitDef[] defs = q == 2 ? DENSITY_UNITS : GRAVITY_UNITS;
        String[] r = new String[defs.length];
        for (int i = 0; i < defs.length; i++) r[i] = defs[i].label;
        return r;
    }

    private String hintFor(int q) {
        switch (q) {
            case 0: return "Введите массу";
            case 1: return "Введите радиус";
            case 2: return "Введите плотность";
            default: return "Введите g";
        }
    }

    private void rebuildPhysicsInputs(GlassWindow win,
                                      LinearLayout container,
                                      ValueUnitRow[] inputs,
                                      int q1, int q2) {
        container.removeAllViews();
        container.addView(labelView(QUANT_LABELS[q1]));
        container.addView(spacerView(dp(6)));
        inputs[0] = buildValueUnitRow(win, labelsFor(q1), hintFor(q1));
        container.addView(inputs[0].row);
        container.addView(spacerView(dp(12)));
        container.addView(labelView(QUANT_LABELS[q2]));
        container.addView(spacerView(dp(6)));
        inputs[1] = buildValueUnitRow(win, labelsFor(q2), hintFor(q2));
        container.addView(inputs[1].row);
    }

    private double quantToSi(int q, int unitIdx, double value) {
        switch (q) {
            case 0: return PhysicsEngine.MassUnit.values()[unitIdx].toKg(value);
            case 1: return PhysicsEngine.DistanceUnit.values()[unitIdx].toMeters(value);
            case 2: return DENSITY_UNITS[unitIdx].dec * value;
            default: return GRAVITY_UNITS[unitIdx].dec * value;
        }
    }

    private double computePhysicsSI(int qa, double va, int qb, double vb, int out) throws Exception {
        if (!(va > 0) || !(vb > 0)) throw new Exception("Значения должны быть положительными.");
        boolean[] has = new boolean[4];
        double[] known = new double[4];
        known[qa] = va; has[qa] = true;
        known[qb] = vb; has[qb] = true;
        double M; double R;
        if (has[0] && has[1]) {
            M = known[0]; R = known[1];
        } else if (has[0] && has[2]) {
            M = known[0];
            R = Math.cbrt(3.0 * M / (4.0 * Math.PI * known[2]));
        } else if (has[0] && has[3]) {
            M = known[0];
            R = Math.sqrt(PhysicsEngine.G * M / known[3]);
        } else if (has[1] && has[2]) {
            R = known[1];
            M = known[2] * (4.0 / 3.0) * Math.PI * R * R * R;
        } else if (has[1] && has[3]) {
            R = known[1];
            M = known[3] * R * R / PhysicsEngine.G;
        } else if (has[2] && has[3]) {
            R = 3.0 * known[3] / (4.0 * Math.PI * PhysicsEngine.G * known[2]);
            M = known[2] * (4.0 / 3.0) * Math.PI * R * R * R;
        } else {
            throw new Exception("Выберите две разные известные величины.");
        }
        if (!(M > 0) || !(R > 0) || Double.isInfinite(M) || Double.isNaN(M)
            || Double.isInfinite(R) || Double.isNaN(R)) {
            throw new Exception("Значения вышли за пределы вычислений.");
        }
        switch (out) {
            case 0: return M;
            case 1: return R;
            case 2: return M / ((4.0 / 3.0) * Math.PI * R * R * R);
            default: return PhysicsEngine.G * M / (R * R);
        }
    }

    private void onPhysicsCalculate(ValueUnitRow[] inputs, int q1, int q2, int out, LinearLayout resultContainer) {
        resultContainer.removeAllViews();
        try {
            Double v1 = parseDouble(inputs[0].input.getText().toString());
            Double v2 = parseDouble(inputs[1].input.getText().toString());
            if (v1 == null || v2 == null) {
                resultError(resultContainer, "Заполните оба известных значения.");
                return;
            }
            double s1 = quantToSi(q1, inputs[0].unitState.selectedIndex, v1);
            double s2 = quantToSi(q2, inputs[1].unitState.selectedIndex, v2);
            double res = computePhysicsSI(q1, s1, q2, s2, out);
            renderPhysicsResult(resultContainer, out, res);
        } catch (Throwable t) {
            resultError(resultContainer, "Ошибка при расчёте: " + t.getMessage());
        }
    }

    private void renderPhysicsResult(LinearLayout resultContainer, int out, double v) {
        LinearLayout box = resultBox();
        box.addView(resultSectionTitle("Результат: " + QUANT_LABELS[out]));
        box.addView(spacerView(dp(8)));
        String main;
        if (out == 0) main = fmtSmart(v) + " кг";
        else if (out == 1) main = fmtSmart(v) + " м";
        else if (out == 2) main = fmtSmart(v) + " кг/м³";
        else main = fmtSmart(v) + " м/с²";
        box.addView(resultLine(QUANT_LABELS[out], main));
        box.addView(spacerView(dp(6)));
        if (out == 0) {
            box.addView(resultSubLine(null, String.format(Locale.US, "≈ %.4f масс Земли", v / EARTH_MASS)));
        } else if (out == 1) {
            box.addView(resultSubLine(null, String.format(Locale.US, "≈ %.4f радиусов Земли", v / EARTH_RADIUS)));
        } else if (out == 2) {
            box.addView(resultSubLine(null, String.format(Locale.US, "≈ %.4f г/см³  (относительно воды: %.2f)", v / 1000.0, v / 1000.0)));
        } else {
            box.addView(resultSubLine(null, String.format(Locale.US, "≈ %.4f g₀", v / 9.80665)));
        }
        resultContainer.addView(box);
    }
}
