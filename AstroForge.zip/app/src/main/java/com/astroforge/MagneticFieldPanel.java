package com.astroforge;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;
import java.util.Locale;

/**
 * Окно "Магнитное поле".
 * Дизайн и элементы скопированы с VelocityPanel.
 * Расчёт идёт через MagneticEngine -> C++ движок magneto_core.
 * AIDE-safe: без лямбд, без record, без androidx.
 */
final class MagneticFieldPanel {

    private static final int ACCENT_COLOR = 0xFFD9946B;
    private static final int ACCENT_BORDER_COLOR = Color.parseColor("#CCD9946B");
    private static final int FIELD_BG_COLOR = Color.parseColor("#F21C1C1E");
    private static final int FIELD_BORDER_COLOR = Color.parseColor("#B3E3E3E3");
    private static final int PILL_BG_COLOR = Color.BLACK;
    private static final int DROPDOWN_BG_COLOR = Color.parseColor("#FF1C1C1E");

    private final Context context;
    private final FrameLayout rootContainer;
    private final Typeface typefaceRegular;
    private final Typeface typefaceSemiBold;

    private FrameLayout overlayRoot;
    private FrameLayout windowFrame;
    private FrameLayout dropdownLayer;

    private LinearLayout resultContainer;
    private LinearLayout simContainer;

    private TextView modeButton;
    private TextView eventsButton;

    private boolean simulationMode = false;
    private boolean includeEvents = true;
    private volatile boolean calculating = false;
    private CalculationProgressOverlay calculationOverlay;

    private final Handler uiHandler = new Handler(Looper.getMainLooper());

    // Параметры объекта.
    private EditText massInput;
    private UnitPillState massUnit;

    private EditText radiusInput;
    private UnitPillState radiusUnit;

    private EditText coreRadiusInput;
    private UnitPillState coreRadiusUnit;

    private EditText densityInput;
    private UnitPillState densityUnit;

    private EditText heatFluxInput;
    private UnitPillState heatFluxUnit;

    private EditText rotationInput;
    private UnitPillState rotationUnit;

    private EditText dipoleInput;
    private EditText calibrationInput;

    // Параметры симуляции.
    private EditText yearsInput;
    private UnitPillState yearsUnit;

    private EditText stepsInput;
    private EditText seedInput;

    private EditText minHeatInput;
    private UnitPillState minHeatUnit;

    private EditText coolingInput;
    private UnitPillState coolingUnit;

    private EditText eventRateInput;
    private EditText gammaInput;

    private EditText dtMinInput;
    private UnitPillState dtMinUnit;

    private EditText dtMaxInput;
    private UnitPillState dtMaxUnit;

    private MagneticFieldPanel(
		Context context,
		FrameLayout rootContainer,
		Typeface typefaceRegular,
		Typeface typefaceSemiBold
    ) {
        this.context = context;
        this.rootContainer = rootContainer;
        this.typefaceRegular = typefaceRegular;
        this.typefaceSemiBold = typefaceSemiBold;
    }

    static void show(
		Context context,
		FrameLayout rootContainer,
		Typeface typefaceRegular,
		Typeface typefaceSemiBold
    ) {
        new MagneticFieldPanel(context, rootContainer, typefaceRegular, typefaceSemiBold).build();
    }

    private int dp(float value) {
        return (int) TypedValue.applyDimension(
			TypedValue.COMPLEX_UNIT_DIP,
			value,
			context.getResources().getDisplayMetrics()
        );
    }

    // =========================================================
    //  Построение окна
    // =========================================================

    private void build() {
        overlayRoot = new FrameLayout(context);
        overlayRoot.setBackgroundColor(Color.parseColor("#CC0F0F10"));
        overlayRoot.setClickable(true);
        overlayRoot.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					close();
				}
			});

        windowFrame = new FrameLayout(context);
        windowFrame.setClickable(true);
        windowFrame.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					// Поглощаем клик, чтобы окно не закрывалось при нажатии внутри.
				}
			});

        GradientDrawable frameBg = new GradientDrawable();
        frameBg.setShape(GradientDrawable.RECTANGLE);
        frameBg.setCornerRadius(dp(28));
        frameBg.setColor(0xF21E1E20);
        frameBg.setStroke(dp(2), ACCENT_COLOR);

        windowFrame.setBackground(frameBg);
        windowFrame.setClipToOutline(true);
        windowFrame.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);

        ImageView blurBg = new ImageView(context);
        blurBg.setImageResource(R.drawable.background);
        blurBg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        blurBg.setRenderEffect(RenderEffect.createBlurEffect(dp(44), dp(44), Shader.TileMode.CLAMP));
        blurBg.setAlpha(0.88f);
        windowFrame.addView(blurBg, matchParentFrameLp());

        View tint = new View(context);
        tint.setBackgroundColor(Color.parseColor("#CC232326"));
        windowFrame.addView(tint, matchParentFrameLp());
        AstroUiEffects.applyPaperEffect(windowFrame, context);

        ScrollView scrollView = new ScrollView(context);
        scrollView.setClipToPadding(false);
        scrollView.setVerticalScrollBarEnabled(false);
        scrollView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        LinearLayout content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        content.setPadding(pad, pad, pad, pad);

        content.addView(buildTitle());
        content.addView(spacer(dp(18)));

        content.addView(buildSectionTitle("Режим расчёта"));
        content.addView(spacer(dp(6)));
        modeButton = buildModeButton();
        content.addView(modeButton);
        content.addView(spacer(dp(18)));

        content.addView(buildSectionTitle("Параметры объекта"));
        content.addView(spacer(dp(8)));

        content.addView(buildLabel("Масса объекта"));
        content.addView(spacer(dp(6)));
        ValueUnitRow massRow = buildValueUnitRow(massLabels(), "Введите массу");
        massInput = massRow.input;
        massUnit = massRow.unitState;
        content.addView(massRow.row);
        content.addView(spacer(dp(14)));

        content.addView(buildLabel("Радиус объекта"));
        content.addView(spacer(dp(6)));
        ValueUnitRow radiusRow = buildValueUnitRow(distanceLabels(), "Введите радиус");
        radiusInput = radiusRow.input;
        radiusUnit = radiusRow.unitState;
        content.addView(radiusRow.row);
        content.addView(spacer(dp(14)));

        content.addView(buildLabel("Радиус ядра / динамо-области"));
        content.addView(spacer(dp(6)));
        ValueUnitRow coreRadiusRow = buildValueUnitRow(distanceLabels(), "Введите радиус ядра");
        coreRadiusInput = coreRadiusRow.input;
        coreRadiusUnit = coreRadiusRow.unitState;
        content.addView(coreRadiusRow.row);
        content.addView(spacer(dp(14)));

        content.addView(buildLabel("Плотность проводящей среды"));
        content.addView(spacer(dp(6)));
        ValueUnitRow densityRow = buildValueUnitRow(densityLabels(), "Введите плотность");
        densityInput = densityRow.input;
        densityUnit = densityRow.unitState;
        content.addView(densityRow.row);
        content.addView(spacer(dp(14)));

        content.addView(buildLabel("Конвективный тепловой поток"));
        content.addView(spacer(dp(6)));
        ValueUnitRow heatRow = buildValueUnitRow(heatFluxLabels(), "Введите тепловой поток");
        heatFluxInput = heatRow.input;
        heatFluxUnit = heatRow.unitState;
        content.addView(heatRow.row);
        content.addView(spacer(dp(14)));

        content.addView(buildLabel("Период вращения (необязательно)"));
        content.addView(spacer(dp(6)));
        ValueUnitRow rotationRow = buildValueUnitRow(rotationLabels(), "Например, 24");
        rotationInput = rotationRow.input;
        rotationUnit = rotationRow.unitState;
        content.addView(rotationRow.row);
        content.addView(spacer(dp(14)));

        content.addView(buildLabel("Доля дипольности, 0..1"));
        content.addView(spacer(dp(6)));
        dipoleInput = buildNumericTextField("По умолчанию 1.0");
        content.addView(dipoleInput);
        content.addView(spacer(dp(14)));

        content.addView(buildLabel("Калибровочный коэффициент"));
        content.addView(spacer(dp(6)));
        calibrationInput = buildNumericTextField("По умолчанию 1.0");
        content.addView(calibrationInput);
        content.addView(spacer(dp(18)));

        simContainer = new LinearLayout(context);
        simContainer.setOrientation(LinearLayout.VERTICAL);
        simContainer.setVisibility(View.GONE);
        buildSimContent(simContainer);
        content.addView(simContainer);

        content.addView(spacer(dp(18)));
        content.addView(buildCalculateButton());
        content.addView(spacer(dp(14)));
        content.addView(buildExplanationBlock());
        content.addView(spacer(dp(10)));

        resultContainer = new LinearLayout(context);
        resultContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(resultContainer);
        content.addView(spacer(dp(20)));

        scrollView.addView(
			content,
			new ScrollView.LayoutParams(
				ScrollView.LayoutParams.MATCH_PARENT,
				ScrollView.LayoutParams.WRAP_CONTENT
			)
        );

        windowFrame.addView(scrollView, matchParentFrameLp());

        FrameLayout.LayoutParams windowLp = new FrameLayout.LayoutParams(
			ViewGroup.LayoutParams.MATCH_PARENT,
			ViewGroup.LayoutParams.MATCH_PARENT
        );
        int screenMargin = dp(18);
        windowLp.setMargins(
			screenMargin,
			screenMargin + dp(30),
			screenMargin,
			screenMargin + dp(30)
        );

        overlayRoot.addView(windowFrame, windowLp);
        rootContainer.addView(overlayRoot, matchParentFrameLp());

        dropdownLayer = new FrameLayout(context);
        dropdownLayer.setClipChildren(false);
        dropdownLayer.setClipToPadding(false);
        dropdownLayer.setElevation(dp(1000));
        overlayRoot.addView(dropdownLayer, matchParentFrameLp());
        dropdownLayer.bringToFront();

        windowFrame.post(new Runnable() {
            @Override
            public void run() {
                if (overlayRoot != null && overlayRoot.getParent() == rootContainer && windowFrame != null) {
                    WindowOpenAnimation.start(windowFrame, context.getResources().getDisplayMetrics().density);
                }
            }
        });

    }

    private void close() {
        if (overlayRoot == null || windowFrame == null || overlayRoot.getParent() != rootContainer) {
            return;
        }

        final FrameLayout overlay = overlayRoot;

        windowFrame.animate()
			.alpha(0f)
			.scaleX(0.95f)
			.scaleY(0.95f)
			.setDuration(180L)
			.withEndAction(new Runnable() {
				@Override
				public void run() {
					if (overlay.getParent() == rootContainer) {
						rootContainer.removeView(overlay);
					}
					overlayRoot = null;
					windowFrame = null;
					dropdownLayer = null;
				}
			})
			.start();
    }

    // =========================================================
    //  UI-элементы
    // =========================================================

    private View buildTitle() {
        TextView tv = new DigitTextView(context);
        tv.setText("Магнитное поле");
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        tv.setGravity(Gravity.START | Gravity.TOP);
        return tv;
    }

    private TextView buildSectionTitle(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        return tv;
    }

    private TextView buildLabel(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#DDE3E1DE"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        return tv;
    }

    private View spacer(int heightPx) {
        View v = new View(context);
        v.setLayoutParams(new LinearLayout.LayoutParams(
							  LinearLayout.LayoutParams.MATCH_PARENT,
							  heightPx
						  ));
        return v;
    }

    private TextView buildModeButton() {
        final TextView btn = new DigitTextView(context);
        updateModeButtonText(btn);
        btn.setTextColor(Color.parseColor("#DDE3E1DE"));
        btn.setTypeface(typefaceRegular);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(dp(16), dp(12), dp(16), dp(12));

        GradientDrawable dashed = new GradientDrawable();
        dashed.setShape(GradientDrawable.RECTANGLE);
        dashed.setCornerRadius(dp(16));
        dashed.setColor(Color.TRANSPARENT);
        dashed.setStroke(dp(1.5f), Color.parseColor("#AAE3E3E3"), dp(8), dp(5));

        btn.setBackground(dashed);
        btn.setClickable(true);
        btn.setFocusable(true);
        btn.setLayoutParams(new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT,
								LinearLayout.LayoutParams.WRAP_CONTENT
							));

        btn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					HapticUtils.perform(v);
					simulationMode = !simulationMode;
					updateModeButtonText(btn);

					if (simContainer != null) {
						simContainer.setVisibility(simulationMode ? View.VISIBLE : View.GONE);
					}
				}
			});

        return btn;
    }

    private void updateModeButtonText(TextView btn) {
        if (btn == null) {
            return;
        }

        if (simulationMode) {
            btn.setText("Режим: симуляция по годам");
        } else {
            btn.setText("Режим: быстрый расчёт");
        }
    }

    private TextView buildEventsButton() {
        final TextView btn = new DigitTextView(context);
        updateEventsButtonText(btn);
        btn.setTextColor(Color.parseColor("#DDE3E1DE"));
        btn.setTypeface(typefaceRegular);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(dp(14), dp(10), dp(14), dp(10));

        GradientDrawable dashed = new GradientDrawable();
        dashed.setShape(GradientDrawable.RECTANGLE);
        dashed.setCornerRadius(dp(14));
        dashed.setColor(Color.TRANSPARENT);
        dashed.setStroke(dp(1.25f), Color.parseColor("#88E3E3E3"), dp(7), dp(4));

        btn.setBackground(dashed);
        btn.setClickable(true);
        btn.setFocusable(true);
        btn.setLayoutParams(new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT,
								LinearLayout.LayoutParams.WRAP_CONTENT
							));

        btn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					HapticUtils.perform(v);
					includeEvents = !includeEvents;
					updateEventsButtonText(btn);
				}
			});

        return btn;
    }

    private void updateEventsButtonText(TextView btn) {
        if (btn == null) {
            return;
        }

        if (includeEvents) {
            btn.setText("События инверсий: вкл");
        } else {
            btn.setText("События инверсий: выкл");
        }
    }

    private View buildCalculateButton() {
        TextView btn = new DigitTextView(context);
        btn.setText("Рассчитать");
        btn.setTextColor(Color.WHITE);
        btn.setTypeface(typefaceSemiBold);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(0, dp(14), 0, dp(14));
        btn.setBackground(createRoundedRect(dp(18), ACCENT_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        AstroUiEffects.applyControlShadow(btn, context);
        btn.setClickable(true);
        btn.setFocusable(true);
        btn.setLayoutParams(new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT,
								LinearLayout.LayoutParams.WRAP_CONTENT
							));

        btn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					HapticUtils.perform(v);
					onCalculatePressed();
				}
			});

        return btn;
    }

    private View buildExplanationBlock() {
        LinearLayout block = new LinearLayout(context);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setLayoutParams(new LinearLayout.LayoutParams(
								  LinearLayout.LayoutParams.MATCH_PARENT,
								  LinearLayout.LayoutParams.WRAP_CONTENT
							  ));

        TextView title = new DigitTextView(context);
        title.setText("Как считается магнитное поле");
        title.setTextColor(Color.WHITE);
        title.setTypeface(typefaceSemiBold);

        AstroUiEffects.applyExplanationTypeface(title, context);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        block.addView(title);
        block.addView(spacer(dp(8)));

        block.addView(buildExplanationLine("1) Закон динамо-скейлинга Кристенсена: B_core ≈ k · √(ρ·μ₀) · F^(1/3)."));
        block.addView(spacer(dp(4)));

        block.addView(buildExplanationLine("2) Поверхностное дипольное поле: B_surface ≈ f_dip · B_core · (R_core / R_planet)³."));
        block.addView(spacer(dp(4)));

        block.addView(buildExplanationLine("3) В симуляции тепловой поток может затухать со временем, а события инверсий генерируются по степенному scaling law с экспоненциальным cutoff."));

        return block;
    }

    private TextView buildExplanationLine(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#CFE3E1DE"));
        tv.setTypeface(typefaceRegular);
        AstroUiEffects.applyExplanationTypeface(tv, context);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        tv.setLineSpacing(dp(2), 1.08f);
        return tv;
    }

    private void buildSimContent(LinearLayout container) {
        container.addView(buildSectionTitle("Параметры симуляции"));
        container.addView(spacer(dp(8)));

        container.addView(buildLabel("Длительность симуляции"));
        container.addView(spacer(dp(6)));
        ValueUnitRow yearsRow = buildValueUnitRow(simTimeLabels(), "Например, 1000000");
        yearsInput = yearsRow.input;
        yearsUnit = yearsRow.unitState;
        container.addView(yearsRow.row);
        container.addView(spacer(dp(14)));

        container.addView(buildLabel("Количество точек"));
        container.addView(spacer(dp(6)));
        stepsInput = buildNumericTextField("По умолчанию 200");
        container.addView(stepsInput);
        container.addView(spacer(dp(14)));

        container.addView(buildLabel("Seed генератора событий"));
        container.addView(spacer(dp(6)));
        seedInput = buildNumericTextField("По умолчанию 42");
        container.addView(seedInput);
        container.addView(spacer(dp(14)));

        container.addView(buildLabel("Минимальный тепловой поток"));
        container.addView(spacer(dp(6)));
        ValueUnitRow minHeatRow = buildValueUnitRow(heatFluxLabels(), "По умолчанию 0");
        minHeatInput = minHeatRow.input;
        minHeatUnit = minHeatRow.unitState;
        container.addView(minHeatRow.row);
        container.addView(spacer(dp(14)));

        container.addView(buildLabel("Время охлаждения"));
        container.addView(spacer(dp(6)));
        ValueUnitRow coolingRow = buildValueUnitRow(simTimeLabels(), "По умолчанию годы / 10");
        coolingInput = coolingRow.input;
        coolingUnit = coolingRow.unitState;
        container.addView(coolingRow.row);
        container.addView(spacer(dp(14)));

        container.addView(buildLabel("Частота событий в год"));
        container.addView(spacer(dp(6)));
        eventRateInput = buildNumericTextField("По умолчанию 1e-6");
        container.addView(eventRateInput);
        container.addView(spacer(dp(14)));

        container.addView(buildLabel("Gamma scaling law"));
        container.addView(spacer(dp(6)));
        gammaInput = buildNumericTextField("По умолчанию 1.2");
        container.addView(gammaInput);
        container.addView(spacer(dp(14)));

        container.addView(buildLabel("Минимальное время ожидания событий"));
        container.addView(spacer(dp(6)));
        ValueUnitRow dtMinRow = buildValueUnitRow(simTimeLabels(), "По умолчанию 1 год");
        dtMinInput = dtMinRow.input;
        dtMinUnit = dtMinRow.unitState;
        container.addView(dtMinRow.row);
        container.addView(spacer(dp(14)));

        container.addView(buildLabel("Максимальное время ожидания событий"));
        container.addView(spacer(dp(6)));
        ValueUnitRow dtMaxRow = buildValueUnitRow(simTimeLabels(), "По умолчанию по длительности");
        dtMaxInput = dtMaxRow.input;
        dtMaxUnit = dtMaxRow.unitState;
        container.addView(dtMaxRow.row);
        container.addView(spacer(dp(14)));

        eventsButton = buildEventsButton();
        container.addView(eventsButton);
    }

    private EditText buildNumericTextField(String hint) {
        EditText input = new DigitEditText(context);
        input.setHint(hint);
        input.setHintTextColor(Color.parseColor("#77FFFFFF"));
        input.setTextColor(Color.WHITE);
        input.setTypeface(typefaceRegular);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        input.setSingleLine(true);
        input.setBackground(createRoundedRect(dp(16), FIELD_BG_COLOR, FIELD_BORDER_COLOR, dp(1.25f)));
        AstroUiEffects.applyControlShadow(input, context);
        input.setPadding(dp(16), dp(12), dp(16), dp(12));
        input.setInputType(InputType.TYPE_CLASS_NUMBER
						   | InputType.TYPE_NUMBER_FLAG_DECIMAL
						   | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setLayoutParams(new LinearLayout.LayoutParams(
								  LinearLayout.LayoutParams.MATCH_PARENT,
								  dp(50)
							  ));
        return input;
    }

    // =========================================================
    //  Поля с единицами
    // =========================================================

    private static final class ValueUnitRow {
        View row;
        EditText input;
        UnitPillState unitState;
    }

    private static final class UnitPillState {
        TextView pillView;
        int selectedIndex = 0;
        String[] labels;
    }

    private ValueUnitRow buildValueUnitRow(final String[] unitLabels, String hint) {
        FrameLayout field = new FrameLayout(context);
        field.setBackground(createRoundedRect(dp(16), FIELD_BG_COLOR, FIELD_BORDER_COLOR, dp(1.25f)));
        AstroUiEffects.applyControlShadow(field, context);
        field.setClipToOutline(true);

        final EditText input = new DigitEditText(context);
        input.setHint(hint);
        input.setHintTextColor(Color.parseColor("#77FFFFFF"));
        input.setTextColor(Color.WHITE);
        input.setTypeface(typefaceRegular);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        input.setSingleLine(true);
        input.setBackground(null);
        AstroUiEffects.applyControlShadow(input, context);
        input.setInputType(InputType.TYPE_CLASS_NUMBER
						   | InputType.TYPE_NUMBER_FLAG_DECIMAL
						   | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setPadding(dp(16), dp(12), dp(128), dp(12));
        field.addView(input, matchParentFrameLp());

        final UnitPillState state = new UnitPillState();
        state.labels = unitLabels;
        state.selectedIndex = 0;

        final TextView pill = new DigitTextView(context);
        pill.setText(unitLabels[0]);
        pill.setTextColor(Color.WHITE);
        pill.setTypeface(typefaceSemiBold);
        pill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        pill.setGravity(Gravity.CENTER);
        pill.setMaxLines(1);
        pill.setEllipsize(android.text.TextUtils.TruncateAt.END);
        pill.setBackground(createRoundedRect(dp(14), PILL_BG_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        pill.setPadding(dp(12), dp(8), dp(12), dp(8));
        pill.setClickable(true);
        pill.setFocusable(true);

        FrameLayout.LayoutParams pillLp = new FrameLayout.LayoutParams(
			dp(112),
			FrameLayout.LayoutParams.WRAP_CONTENT
        );
        pillLp.gravity = Gravity.CENTER_VERTICAL | Gravity.END;
        pillLp.rightMargin = dp(8);
        field.addView(pill, pillLp);
        pill.setTranslationZ(dp(3f));

        state.pillView = pill;

        pill.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					HapticUtils.perform(v);
					openDropdown(pill, unitLabels, state.selectedIndex, new OnUnitSelected() {
							@Override
							public void onSelected(int newIndex) {
								state.selectedIndex = newIndex;
								pill.setText(unitLabels[newIndex]);
							}
						});
				}
			});

        field.setLayoutParams(new LinearLayout.LayoutParams(
								  LinearLayout.LayoutParams.MATCH_PARENT,
								  dp(50)
							  ));

        ValueUnitRow row = new ValueUnitRow();
        row.row = field;
        row.input = input;
        row.unitState = state;
        return row;
    }

    private String[] massLabels() {
        MassUnit[] values = MassUnit.values();
        String[] labels = new String[values.length];
        for (int i = 0; i < values.length; i++) {
            labels[i] = values[i].label;
        }
        return labels;
    }

    private String[] distanceLabels() {
        DistanceUnit[] values = DistanceUnit.values();
        String[] labels = new String[values.length];
        for (int i = 0; i < values.length; i++) {
            labels[i] = values[i].label;
        }
        return labels;
    }

    private String[] densityLabels() {
        DensityUnit[] values = DensityUnit.values();
        String[] labels = new String[values.length];
        for (int i = 0; i < values.length; i++) {
            labels[i] = values[i].label;
        }
        return labels;
    }

    private String[] heatFluxLabels() {
        HeatFluxUnit[] values = HeatFluxUnit.values();
        String[] labels = new String[values.length];
        for (int i = 0; i < values.length; i++) {
            labels[i] = values[i].label;
        }
        return labels;
    }

    private String[] rotationLabels() {
        RotationUnit[] values = RotationUnit.values();
        String[] labels = new String[values.length];
        for (int i = 0; i < values.length; i++) {
            labels[i] = values[i].label;
        }
        return labels;
    }

    private String[] simTimeLabels() {
        SimTimeUnit[] values = SimTimeUnit.values();
        String[] labels = new String[values.length];
        for (int i = 0; i < values.length; i++) {
            labels[i] = values[i].label;
        }
        return labels;
    }

    // =========================================================
    //  Dropdown
    // =========================================================

    private interface OnUnitSelected {
        void onSelected(int index);
    }

    private void openDropdown(
		final View anchor,
		final String[] labels,
		int selectedIndex,
		final OnUnitSelected callback
    ) {
        if (dropdownLayer == null) {
            return;
        }

        dropdownLayer.removeAllViews();
        dropdownLayer.bringToFront();

        int[] anchorLoc = new int[2];
        anchor.getLocationOnScreen(anchorLoc);

        int[] rootLoc = new int[2];
        dropdownLayer.getLocationOnScreen(rootLoc);

        int relativeX = anchorLoc[0] - rootLoc[0];
        int relativeY = anchorLoc[1] - rootLoc[1];
        int anchorBottom = relativeY + anchor.getHeight();

        Rect visibleFrame = new Rect();
        rootContainer.getWindowVisibleDisplayFrame(visibleFrame);

        int visibleTop = visibleFrame.top - rootLoc[1];
        int visibleBottom = visibleFrame.bottom - rootLoc[1];

        View scrim = new View(context);
        scrim.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (dropdownLayer != null) {
						dropdownLayer.removeAllViews();
					}
				}
			});
        dropdownLayer.addView(scrim, matchParentFrameLp());

        LinearLayout list = new LinearLayout(context);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setBackground(createRoundedRect(dp(14), DROPDOWN_BG_COLOR, ACCENT_BORDER_COLOR, dp(1.25f)));
        list.setClipToOutline(true);
        list.setPadding(dp(6), dp(6), dp(6), dp(6));

        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView item = new DigitTextView(context);
            item.setText(labels[i]);
            item.setTextColor(i == selectedIndex ? ACCENT_COLOR : Color.WHITE);
            item.setTypeface(i == selectedIndex ? typefaceSemiBold : typefaceRegular);
            AstroUiEffects.applyUnitTypeface(item, context);
            item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            item.setPadding(dp(14), dp(10), dp(14), dp(10));
            item.setClickable(true);
            item.setFocusable(true);
            item.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						HapticUtils.perform(v);
						callback.onSelected(idx);
						if (dropdownLayer != null) {
							dropdownLayer.removeAllViews();
						}
					}
				});
            list.addView(item, new LinearLayout.LayoutParams(
							 LinearLayout.LayoutParams.MATCH_PARENT,
							 LinearLayout.LayoutParams.WRAP_CONTENT
						 ));
        }

        int estimatedHeight = dp(12) + (labels.length * dp(40));
        int spaceBelow = visibleBottom - anchorBottom - dp(8);
        int spaceAbove = relativeY - visibleTop - dp(8);

        if (spaceBelow < 0) {
            spaceBelow = 0;
        }

        if (spaceAbove < 0) {
            spaceAbove = 0;
        }

        boolean showAbove = spaceBelow < estimatedHeight && spaceAbove > spaceBelow;

        final int maxHeight = Math.max(
			0,
			Math.min(estimatedHeight, showAbove ? spaceAbove : spaceBelow)
        );

        ScrollView listScroll = new ScrollView(context) {
            @Override
            protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                int hSpec = heightMeasureSpec;
                if (maxHeight > 0) {
                    int mode = View.MeasureSpec.getMode(hSpec);
                    int size = View.MeasureSpec.getSize(hSpec);
                    if (mode == View.MeasureSpec.UNSPECIFIED || size > maxHeight) {
                        hSpec = View.MeasureSpec.makeMeasureSpec(maxHeight, View.MeasureSpec.AT_MOST);
                    }
                }
                super.onMeasure(widthMeasureSpec, hSpec);
            }
        };

        listScroll.addView(list, new ScrollView.LayoutParams(
							   ScrollView.LayoutParams.MATCH_PARENT,
							   ScrollView.LayoutParams.WRAP_CONTENT
						   ));

        listScroll.setBackground(list.getBackground());
        list.setBackground(null);
        listScroll.setVerticalScrollBarEnabled(false);
        listScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        FrameLayout.LayoutParams listLp = new FrameLayout.LayoutParams(
			dp(190),
			FrameLayout.LayoutParams.WRAP_CONTENT
        );

        listLp.leftMargin = Math.max(dp(8), relativeX + anchor.getWidth() - dp(190));

        if (showAbove) {
            listLp.topMargin = Math.max(visibleTop + dp(8), relativeY - maxHeight - dp(4));
        } else {
            listLp.topMargin = anchorBottom + dp(4);
        }

        dropdownLayer.addView(listScroll, listLp);
        listScroll.bringToFront();
    }

    // =========================================================
    //  Расчёт
    // =========================================================

    private void onCalculatePressed() {
        if (calculating) {
            return;
        }

        if (resultContainer == null) {
            return;
        }

        resultContainer.removeAllViews();

        if (!MagneticEngine.isNativeLoaded()) {
            showResultError(
				"Нативная библиотека magneto_core не загружена.\n" +
				"Собери C++ файл magneto_core.cpp в libmagneto_core.so и подключи её к AIDE Plus."
            );
            return;
        }

        try {
            final PlanetParams planet = readPlanetParams();
            final SimulationConfig config = simulationMode ? readSimulationConfig() : null;
            final boolean sim = simulationMode;

            final LinearLayout box = resultBox();
            TextView title = resultSectionTitle(sim ? "Симуляция выполняется…" : "Расчёт выполняется…");
            box.addView(title);
            box.addView(spacer(dp(6)));

            TextView progress = new DigitTextView(context);
            progress.setText("Пожалуйста, подождите");
            progress.setTextColor(Color.parseColor("#CCFFFFFF"));
            progress.setTypeface(typefaceRegular);
            progress.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            box.addView(progress);

            resultContainer.addView(box);

            calculating = true;

            if (sim) {
                calculationOverlay = new CalculationProgressOverlay(context, rootContainer);
                calculationOverlay.begin("Магнитное поле", ACCENT_COLOR);
            }

            PerformancePools.math().execute(new Runnable() {
					@Override
					public void run() {
						try {
							if (sim) {
								final SimulationResult result =
                                    MagneticEngine.simulate(planet, config, new MagneticEngine.ProgressListener() {
                                        @Override
                                        public void onProgress(int currentStep, int totalSteps, double currentYears, double totalYears) {
                                            int percent = totalSteps <= 0 ? 0 : (int) (((long) currentStep * 100L) / totalSteps);
                                            if (calculationOverlay != null) {
                                                calculationOverlay.update(percent, currentYears, "Магнитная симуляция");
                                            }
                                        }
                                    });

								uiHandler.post(new Runnable() {
										@Override
										public void run() {
											calculating = false;
                                        if (calculationOverlay != null) {
                                            calculationOverlay.update(100, config.years, "Расчёт завершён");
                                            calculationOverlay.finish();
                                            calculationOverlay = null;
                                        }
											if (overlayRoot == null || resultContainer == null) {
												return;
											}
											resultContainer.removeAllViews();
											renderSimulation(result);
										}
									});
							} else {
								final DirectResult result =
                                    MagneticEngine.direct(planet);

								uiHandler.post(new Runnable() {
										@Override
										public void run() {
											calculating = false;
                                        if (calculationOverlay != null) {
                                            calculationOverlay.fail("Ошибка расчёта");
                                            calculationOverlay = null;
                                        }
											if (overlayRoot == null || resultContainer == null) {
												return;
											}
											resultContainer.removeAllViews();
											renderDirect(result);
										}
									});
							}
						} catch (final Throwable t) {
							uiHandler.post(new Runnable() {
									@Override
									public void run() {
										calculating = false;
										if (calculationOverlay != null) {
							calculationOverlay.fail("Ошибка расчёта");
							calculationOverlay = null;
						}
						if (overlayRoot == null || resultContainer == null) {
											return;
										}
										resultContainer.removeAllViews();
										showResultError("Ошибка расчёта:\n" + message(t));
									}
								});
						}
					}
				});
        } catch (Throwable t) {
            resultContainer.removeAllViews();
            showResultError("Ошибка ввода:\n" + message(t));
        }
    }

    private PlanetParams readPlanetParams() {
        double massKg = MassUnit.values()[massUnit.selectedIndex]
			.toKg(requirePositive(massInput, "Масса объекта"));

        double radiusM = DistanceUnit.values()[radiusUnit.selectedIndex]
			.toMeters(requirePositive(radiusInput, "Радиус объекта"));

        double coreRadiusM = DistanceUnit.values()[coreRadiusUnit.selectedIndex]
			.toMeters(requirePositive(coreRadiusInput, "Радиус ядра"));

        if (coreRadiusM >= radiusM) {
            throw new IllegalArgumentException("Радиус ядра должен быть меньше радиуса объекта.");
        }

        double densityKgM3 = DensityUnit.values()[densityUnit.selectedIndex]
			.toKgM3(requirePositive(densityInput, "Плотность"));

        double heatFluxWm2 = HeatFluxUnit.values()[heatFluxUnit.selectedIndex]
			.toWm2(requireNonNegative(heatFluxInput, "Тепловой поток"));

        Double rotationValue = parseDouble(rotationInput.getText().toString());
        double rotationHours = 0.0;

        if (rotationValue != null) {
            if (!Double.isFinite(rotationValue) || rotationValue < 0.0) {
                throw new IllegalArgumentException("Период вращения должен быть неотрицательным числом.");
            }

            rotationHours = rotationValue * RotationUnit.values()[rotationUnit.selectedIndex].toHours;
        }

        double dipole = optionalPositive(dipoleInput, 1.0);
        if (dipole < 0.0 || dipole > 1.0) {
            throw new IllegalArgumentException("Доля дипольности должна быть в диапазоне 0..1.");
        }

        double calibration = optionalPositive(calibrationInput, 1.0);

        return new PlanetParams(
			massKg,
			radiusM,
			coreRadiusM,
			densityKgM3,
			heatFluxWm2,
			rotationHours,
			dipole,
			calibration
        );
    }

    private SimulationConfig readSimulationConfig() {
        double years = SimTimeUnit.values()[yearsUnit.selectedIndex]
			.toYears(requirePositive(yearsInput, "Длительность симуляции"));

        int steps = intOrDefault(stepsInput, 200);
        if (steps <= 0) {
            steps = 200;
        }

        if (steps > 200000) {
            throw new IllegalArgumentException("Слишком много точек симуляции. Уменьши количество точек до 200000 или меньше.");
        }

        long seed = longOrDefault(seedInput, 42L);

        double minHeat = HeatFluxUnit.values()[minHeatUnit.selectedIndex]
			.toWm2(optionalNonNegative(minHeatInput, 0.0));

        double coolingDefault = Math.max(1.0, years / 10.0);
        double cooling = SimTimeUnit.values()[coolingUnit.selectedIndex]
			.toYears(optionalPositive(coolingInput, coolingDefault));

        double eventRate = optionalNonNegative(eventRateInput, 1.0e-6);
        double gamma = optionalPositive(gammaInput, 1.2);

        double dtMinDefault = Math.max(1.0e-6, years * 1.0e-6);
        double dtMin = SimTimeUnit.values()[dtMinUnit.selectedIndex]
			.toYears(optionalPositive(dtMinInput, dtMinDefault));

        double dtMaxDefault = Math.max(dtMin * 1000.0, years);
        double dtMax = SimTimeUnit.values()[dtMaxUnit.selectedIndex]
			.toYears(optionalPositive(dtMaxInput, dtMaxDefault));

        if (dtMax < dtMin) {
            dtMax = dtMin * 10.0;
        }

        return new SimulationConfig(
			years,
			steps,
			seed,
			minHeat,
			cooling,
			eventRate,
			gamma,
			dtMin,
			dtMax,
			includeEvents
        );
    }

    private double requirePositive(EditText input, String name) {
        Double value = parseDouble(input.getText().toString());
        if (value == null || !Double.isFinite(value) || value <= 0.0) {
            throw new IllegalArgumentException(name + ": введите положительное число.");
        }
        return value;
    }

    private double requireNonNegative(EditText input, String name) {
        Double value = parseDouble(input.getText().toString());
        if (value == null || !Double.isFinite(value) || value < 0.0) {
            throw new IllegalArgumentException(name + ": введите неотрицательное число.");
        }
        return value;
    }

    private double optionalPositive(EditText input, double defaultValue) {
        Double value = parseDouble(input.getText().toString());
        if (value == null) {
            return defaultValue;
        }

        if (!Double.isFinite(value) || value <= 0.0) {
            throw new IllegalArgumentException("Значение должно быть положительным числом.");
        }

        return value;
    }

    private double optionalNonNegative(EditText input, double defaultValue) {
        Double value = parseDouble(input.getText().toString());
        if (value == null) {
            return defaultValue;
        }

        if (!Double.isFinite(value) || value < 0.0) {
            throw new IllegalArgumentException("Значение должно быть неотрицательным числом.");
        }

        return value;
    }

    private int intOrDefault(EditText input, int defaultValue) {
        Double value = parseDouble(input.getText().toString());
        if (value == null || !Double.isFinite(value)) {
            return defaultValue;
        }
        return (int) Math.round(value);
    }

    private long longOrDefault(EditText input, long defaultValue) {
        Double value = parseDouble(input.getText().toString());
        if (value == null || !Double.isFinite(value)) {
            return defaultValue;
        }
        return Math.round(value);
    }

    private Double parseDouble(String text) {
        if (text == null) {
            return null;
        }

        String trimmed = text.trim().replace(',', '.');

        if (trimmed.isEmpty()) {
            return null;
        }

        try {
            return Double.parseDouble(trimmed);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private String message(Throwable t) {
        if (t == null) {
            return "Неизвестная ошибка";
        }

        String m = t.getMessage();
        if (m == null || m.trim().isEmpty()) {
            return t.getClass().getSimpleName();
        }

        return m;
    }

    // =========================================================
    //  Отображение результата
    // =========================================================

    private void renderDirect(DirectResult result) {
        LinearLayout box = resultBox();

        box.addView(resultSectionTitle("Результат"));
        box.addView(spacer(dp(8)));

        box.addView(resultLine("Поле в ядре / динамо-области", formatField(result.coreFieldTesla)));
        box.addView(spacer(dp(8)));

        box.addView(resultLine("Поле на поверхности", formatField(result.surfaceFieldTesla)));
        box.addView(spacer(dp(8)));

        box.addView(resultLine(
						"Дипольный момент",
						String.format(Locale.US, "%.6e A·m²", result.dipoleMomentAm2)
					));
        box.addView(spacer(dp(8)));

        box.addView(resultLine(
						"Использованный тепловой поток",
						String.format(Locale.US, "%.6g Вт/м²", result.energyFluxUsedWm2)
					));
        box.addView(spacer(dp(8)));

        box.addView(resultLine(
						"Доля дипольности",
						String.format(Locale.US, "%.3f", result.dipoleFractionUsed)
					));
        box.addView(spacer(dp(8)));

        box.addView(resultLine(
						"Магнитная энергетическая плотность",
						String.format(Locale.US, "%.6e Дж/м³", result.magneticEnergyDensityJm3)
					));
        box.addView(spacer(dp(8)));

        box.addView(resultLine(
						"Магнитное давление",
						String.format(Locale.US, "%.6e Па", result.magneticPressurePa)
					));

        resultContainer.addView(box);
    }

    private void renderSimulation(SimulationResult result) {
        LinearLayout box = resultBox();

        box.addView(resultSectionTitle("Результат симуляции"));
        box.addView(spacer(dp(8)));

        List<SimulationPoint> points = result.points;

        box.addView(resultLine(
						"Диапазон времени",
						formatYears(0.0) + " → " + formatYears(result.config.years)
					));
        box.addView(spacer(dp(8)));

        box.addView(resultLine("Количество точек", String.valueOf(points.size())));
        box.addView(spacer(dp(8)));

        if (!points.isEmpty()) {
            SimulationPoint first = points.get(0);
            SimulationPoint last = points.get(points.size() - 1);

            box.addView(resultLine("Начало", formatPoint(first)));
            box.addView(spacer(dp(8)));

            box.addView(resultLine("Конец", formatPoint(last)));
            box.addView(spacer(dp(8)));

            box.addView(resultLine("Событий за симуляцию", String.valueOf(last.cumulativeEvents)));
            box.addView(spacer(dp(8)));

            box.addView(resultLine(
							"Полярность в конце",
							last.polarity >= 0.0 ? "положительная" : "отрицательная"
						));
            box.addView(spacer(dp(10)));

            TextView historyTitle = new DigitTextView(context);
            historyTitle.setText("Выборка точек:");
            historyTitle.setTextColor(Color.parseColor("#AAFFFFFF"));
            historyTitle.setTypeface(typefaceRegular);
            historyTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            box.addView(historyTitle);
            box.addView(spacer(dp(4)));

            int maxEntries = 12;
            int step = Math.max(1, points.size() / maxEntries);

            for (int i = 0; i < points.size(); i += step) {
                SimulationPoint p = points.get(i);
                box.addView(resultLine("Точка " + (i + 1), formatPoint(p)));
            }
        }

        resultContainer.addView(box);
    }

    private String formatPoint(SimulationPoint p) {
        return String.format(
			Locale.US,
			"t = %s\nB_core = %s\nB_surface = %s\nсобытий = %d",
			formatYears(p.timeYears),
			formatTeslaShort(p.coreFieldTesla),
			formatTeslaShort(p.surfaceFieldTesla),
			p.cumulativeEvents
        );
    }

    private String formatField(double tesla) {
        if (!Double.isFinite(tesla)) {
            return "-";
        }

        return String.format(
			Locale.US,
			"%.6g Тл\n%.6g Гс\n%.6g мкТл",
			tesla,
			tesla * 1.0e4,
			tesla * 1.0e6
        );
    }

    private String formatTeslaShort(double tesla) {
        if (!Double.isFinite(tesla)) {
            return "-";
        }

        return String.format(Locale.US, "%.6g Тл", tesla);
    }

    private String formatYears(double years) {
        if (!Double.isFinite(years)) {
            return "-";
        }

        if (years >= 1.0e9) {
            return String.format(Locale.US, "%.3f Gyr", years / 1.0e9);
        }

        if (years >= 1.0e6) {
            return String.format(Locale.US, "%.3f Myr", years / 1.0e6);
        }

        if (years >= 1.0e3) {
            return String.format(Locale.US, "%.3f kyr", years / 1.0e3);
        }

        return String.format(Locale.US, "%.1f лет", years);
    }

    private LinearLayout resultBox() {
        LinearLayout box = new LinearLayout(context);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(createRoundedRect(
							  dp(16),
							  Color.parseColor("#6F6B67"),
							  Color.parseColor("#CCFFFFFF"),
							  dp(1.5f)
						  ));

        int p = dp(14);
        box.setPadding(p, p, p, p);
        box.setLayoutParams(new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT,
								LinearLayout.LayoutParams.WRAP_CONTENT
							));

        return box;
    }

    private TextView resultSectionTitle(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        return tv;
    }

    private View resultLine(String label, String value) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.VERTICAL);

        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT,
			LinearLayout.LayoutParams.WRAP_CONTENT
        );
        rowLp.bottomMargin = dp(8);
        row.setLayoutParams(rowLp);

        TextView labelView = new DigitTextView(context);
        labelView.setText(label);
        labelView.setTextColor(Color.parseColor("#BBFFFFFF"));
        labelView.setTypeface(typefaceRegular);
        labelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        row.addView(labelView);

        TextView valueView = new DigitTextView(context);
        valueView.setText(value);
        valueView.setTextColor(ACCENT_COLOR);
        valueView.setTypeface(typefaceSemiBold);
        valueView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        row.addView(valueView);

        return row;
    }

    private void showResultError(String message) {
        if (resultContainer == null) {
            return;
        }

        TextView tv = new DigitTextView(context);
        tv.setText(message);
        tv.setTextColor(Color.parseColor("#FFB4A0"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        resultContainer.addView(tv);
    }

    // =========================================================
    //  Единицы измерения
    // =========================================================

    private enum MassUnit {
        KG("кг", 1.0),
        EARTH_MASS("M⊕", 5.972e24),
        JUPITER_MASS("M♃", 1.898e27),
        SOLAR_MASS("M☉", 1.9885e30);

        final String label;
        final double toKgFactor;

        MassUnit(String label, double toKgFactor) {
            this.label = label;
            this.toKgFactor = toKgFactor;
        }

        double toKg(double value) {
            return value * toKgFactor;
        }
    }

    private enum DistanceUnit {
        METERS("м", 1.0),
        KILOMETERS("км", 1.0e3),
        EARTH_RADIUS("R⊕", 6.371e6),
        JUPITER_RADIUS("R♃", 6.9911e7),
        AU("а.е.", 1.495978707e11);

        final String label;
        final double toMetersFactor;

        DistanceUnit(String label, double toMetersFactor) {
            this.label = label;
            this.toMetersFactor = toMetersFactor;
        }

        double toMeters(double value) {
            return value * toMetersFactor;
        }
    }

    private enum DensityUnit {
        KG_M3("кг/м³", 1.0),
        G_CM3("г/см³", 1000.0);

        final String label;
        final double toKgM3Factor;

        DensityUnit(String label, double toKgM3Factor) {
            this.label = label;
            this.toKgM3Factor = toKgM3Factor;
        }

        double toKgM3(double value) {
            return value * toKgM3Factor;
        }
    }

    private enum HeatFluxUnit {
        W_M2("Вт/м²", 1.0),
        MW_M2("мВт/м²", 1.0e-3);

        final String label;
        final double toWm2Factor;

        HeatFluxUnit(String label, double toWm2Factor) {
            this.label = label;
            this.toWm2Factor = toWm2Factor;
        }

        double toWm2(double value) {
            return value * toWm2Factor;
        }
    }

    private enum RotationUnit {
        HOURS("часы", 1.0),
        DAYS("сутки", 24.0);

        final String label;
        final double toHours;

        RotationUnit(String label, double toHours) {
            this.label = label;
            this.toHours = toHours;
        }
    }

    private enum SimTimeUnit {
        YEARS("годы", 1.0),
        KYR("тыс. лет", 1.0e3),
        MYR("млн лет", 1.0e6),
        GYR("млрд лет", 1.0e9);

        final String label;
        final double toYearsFactor;

        SimTimeUnit(String label, double toYearsFactor) {
            this.label = label;
            this.toYearsFactor = toYearsFactor;
        }

        double toYears(double value) {
            return value * toYearsFactor;
        }
    }

    // =========================================================
    //  Утилиты
    // =========================================================

    private GradientDrawable createRoundedRect(
		float radius,
		int fillColor,
		int strokeColor,
		float strokeWidth
    ) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(radius);
        gd.setColor(fillColor);
        gd.setStroke((int) strokeWidth, strokeColor);
        return gd;
    }

    private FrameLayout.LayoutParams matchParentFrameLp() {
        return new FrameLayout.LayoutParams(
			FrameLayout.LayoutParams.MATCH_PARENT,
			FrameLayout.LayoutParams.MATCH_PARENT
        );
    }
}
