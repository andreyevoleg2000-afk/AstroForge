package com.astroforge;

/**
 * Simplified 2.5PN radiation-reaction helper.
 * Kept conservative and optional. The gravity window does not enable it by default.
 */
public class PN25 {

    public static final double G = 6.67430e-11;
    public static final double C = 299792458.0;

    private static final double C5 = C * C * C * C * C;

    public static void addPN25AccelerationForBody(
            int n,
            int i,
            DoubleDouble[] masses,
            DoubleDouble[] px,
            DoubleDouble[] py,
            DoubleDouble[] pz,
            DoubleDouble[] vx,
            DoubleDouble[] vy,
            DoubleDouble[] vz,
            DoubleDouble sumX,
            DoubleDouble sumY,
            DoubleDouble sumZ,
            double softening
    ) {
        if (n <= 1 || i < 0 || i >= n) {
            return;
        }

        double mi = masses[i].doubleValue();
        if (mi <= 0.0) {
            return;
        }

        double xi = px[i].doubleValue();
        double yi = py[i].doubleValue();
        double zi = pz[i].doubleValue();

        double vxi = vx[i].doubleValue();
        double vyi = vy[i].doubleValue();
        double vzi = vz[i].doubleValue();

        double soft2 = softening * softening;

        double axPN = 0.0;
        double ayPN = 0.0;
        double azPN = 0.0;

        for (int j = 0; j < n; j++) {
            if (i == j) {
                continue;
            }

            double mj = masses[j].doubleValue();
            if (mj <= 0.0) {
                continue;
            }

            double totalMass = mi + mj;
            if (totalMass <= 0.0) {
                continue;
            }

            double rx = xi - px[j].doubleValue();
            double ry = yi - py[j].doubleValue();
            double rz = zi - pz[j].doubleValue();

            double rvx = vxi - vx[j].doubleValue();
            double rvy = vyi - vy[j].doubleValue();
            double rvz = vzi - vz[j].doubleValue();

            double r2 = rx * rx + ry * ry + rz * rz + soft2;
            if (r2 <= 0.0) {
                continue;
            }

            double r = Math.sqrt(r2);
            double invR = 1.0 / r;

            double nx = rx * invR;
            double ny = ry * invR;
            double nz = rz * invR;

            double v2 = rvx * rvx + rvy * rvy + rvz * rvz;
            double rdot = (rx * rvx + ry * rvy + rz * rvz) * invR;

            double gm = G * totalMass;
            double potential = gm / r;
            double r3 = r2 * r;

            double factor = (8.0 / 5.0) * G * G * mi * mj / (C5 * r3);
            if (Double.isNaN(factor) || Double.isInfinite(factor)) {
                continue;
            }

            double termN =
                    (0.75 * v2 + (17.0 / 12.0) * rdot * rdot - potential) * rdot;

            double termV =
                    -(0.25 * v2 + (1.0 / 12.0) * rdot * rdot + potential);

            axPN += factor * (termN * nx + termV * rvx);
            ayPN += factor * (termN * ny + termV * rvy);
            azPN += factor * (termN * nz + termV * rvz);
        }

        if (!Double.isNaN(axPN) && !Double.isInfinite(axPN)) {
            sumX.add(axPN);
        }
        if (!Double.isNaN(ayPN) && !Double.isInfinite(ayPN)) {
            sumY.add(ayPN);
        }
        if (!Double.isNaN(azPN) && !Double.isInfinite(azPN)) {
            sumZ.add(azPN);
        }
    }
}
