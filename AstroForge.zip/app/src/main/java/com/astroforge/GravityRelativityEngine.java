package com.astroforge;

import java.util.Locale;

/**
 * 3+1-расчёт собственного ускорения наблюдателя.
 *
 * Базовая модель:
 * f(r) = 1 - 2GM/(c²r) + GQ²/(4πɛ0c⁴r²) - Λr²/3
 *
 * Для статического наблюдателя в Schwarzschild/RN-подобной метрике:
 * a = |∂r-сила| / sqrt(f)
 *
 * Дополнительно:
 * - скорость наблюдателя даёт гамма-фактор проекции 4-ускорения;
 * - спин источника даёт поправку Лензе-Тирринга в 3+1-форме;
 * - источник может двигаться по заданной скорости;
 * - интегрирование идёт 1 год с dt = 1 с;
 * - накопление суммы выполняется в 16-компонентном expansion.
 */
final class GravityRelativityEngine {

    static final int YEAR_SECONDS = 31557600; // Julian year

    /**
     * Если true — геометрия r² считается через expansion-умножение.
     * Это медленнее, но соответствует требованию максимальной точности.
     */
    private static final boolean FULL_EXPANSION_GEOMETRY = true;

    private static final double G = 6.67430e-11;
    private static final double C = 299792458.0;
    private static final double EPS0 = 8.8541878128e-12;
    private static final double PI = Math.PI;

    static final class Params {
        double x;
        double y;
        double z;

        double massKg;

        double observerVx;
        double observerVy;
        double observerVz;

        double spin;

        double sourceVx;
        double sourceVy;
        double sourceVz;

        double chargeC;
        double lambda;
    }

    private GravityRelativityEngine() {
        // utility
    }

    static String compute(Params p) {
        final int total = YEAR_SECONDS;

        GravityExpansionMath.Context ctx = new GravityExpansionMath.Context();

        double[] sum = new double[GravityExpansionMath.N];
        double[] accExp = new double[GravityExpansionMath.N];
        double[] scaleExp = new double[GravityExpansionMath.N];
        double[] avgExp = new double[GravityExpansionMath.N];

        double[] ex = new double[GravityExpansionMath.N];
        double[] ey = new double[GravityExpansionMath.N];
        double[] ez = new double[GravityExpansionMath.N];

        double[] tmp1 = new double[GravityExpansionMath.N];
        double[] tmp2 = new double[GravityExpansionMath.N];
        double[] tmp3 = new double[GravityExpansionMath.N];
        double[] r2Exp = new double[GravityExpansionMath.N];

        GravityExpansionMath.zero(sum);

        double lastA = 0.0;

        double c2 = C * C;
        double c3 = c2 * C;
        double c4 = c2 * c2;

        for (int t = 0; t <= total; t++) {
            if ((t & 0x3FFFF) == 0) {
                GravityResultStore.progress = (int) (((long) t * 100L) / total);

                if (GravityResultStore.state != GravityResultStore.RUNNING) {
                    return "";
                }
            }

            double time = (double) t;

            double sx = p.sourceVx * time;
            double sy = p.sourceVy * time;
            double sz = p.sourceVz * time;

            double rx = p.x - sx;
            double ry = p.y - sy;
            double rz = p.z - sz;

            double r2;

            if (FULL_EXPANSION_GEOMETRY) {
                GravityExpansionMath.fromDouble(rx, ex);
                GravityExpansionMath.fromDouble(ry, ey);
                GravityExpansionMath.fromDouble(rz, ez);

                GravityExpansionMath.multiply(ex, ex, tmp1, ctx);
                GravityExpansionMath.multiply(ey, ey, tmp2, ctx);
                GravityExpansionMath.add(tmp1, tmp2, tmp3, ctx.work1, ctx.work2);

                GravityExpansionMath.multiply(ez, ez, tmp1, ctx);
                GravityExpansionMath.add(tmp3, tmp1, r2Exp, ctx.work1, ctx.work2);

                r2 = GravityExpansionMath.toDouble(r2Exp);
            } else {
                r2 = rx * rx + ry * ry + rz * rz;
            }

            if (!Double.isFinite(r2) || r2 <= 1.0e-300) {
                r2 = 1.0e-300;
            }

            double r = Math.sqrt(r2);

            double v2 =
				p.observerVx * p.observerVx +
				p.observerVy * p.observerVy +
				p.observerVz * p.observerVz;

            double beta2 = v2 / c2;

            if (beta2 < 0.0) {
                beta2 = 0.0;
            }

            if (beta2 > 0.999999999999) {
                beta2 = 0.999999999999;
            }

            double gamma = 1.0 / Math.sqrt(1.0 - beta2);

            double rs = 2.0 * G * p.massKg / c2;
            double q2 = G * p.chargeC * p.chargeC / (4.0 * PI * EPS0 * c4);

            double f = 1.0 - rs / r + q2 / r2 - p.lambda * r2 / 3.0;

            if (!Double.isFinite(f) || f < 1.0e-300) {
                f = 1.0e-300;
            }

            double chargeTerm =
				G * p.chargeC * p.chargeC /
				(4.0 * PI * EPS0 * c4 * r2 * r);

            double numerator =
				G * p.massKg / r2
				- chargeTerm
				- c2 * p.lambda * r / 3.0;

            double spinFactor = 1.0;

            if (p.spin != 0.0) {
                double horizontal = Math.sqrt(Math.max(0.0, rx * rx + ry * ry));
                double cosLat = horizontal / r;

                double spinTerm = G * p.spin / (c3 * r2);

                spinFactor = 1.0 + 2.0 * spinTerm * cosLat;

                if (!Double.isFinite(spinFactor) || spinFactor < 1.0e-300) {
                    spinFactor = 1.0e-300;
                }
            }

            double a =
				Math.abs(numerator)
				* gamma
				* spinFactor
				/ Math.sqrt(f);

            if (!Double.isFinite(a)) {
                a = 0.0;
            }

            lastA = a;

            GravityExpansionMath.fromDouble(a, accExp);
            GravityExpansionMath.add(sum, accExp, sum, ctx.work1, ctx.work2);
        }

        GravityExpansionMath.fromDouble(1.0 / (total + 1.0), scaleExp);
        GravityExpansionMath.multiply(sum, scaleExp, avgExp, ctx);

        double avg = GravityExpansionMath.toDouble(avgExp);

        GravityResultStore.progress = 100;

        StringBuilder sb = new StringBuilder();

        sb.append("Среднее собственное ускорение: ")
			.append(formatAcceleration(avg))
			.append(" м/с²\n");

        sb.append("Мгновенное в конце года: ")
			.append(formatAcceleration(lastA))
			.append(" м/с²\n");

        sb.append("Точность: 16-component Floating-Point Expansion (Shewchuk/Dekker), режим 1024-bit\n");

        sb.append("Симуляция: 1 год, dt = 1 с, шагов = ")
			.append(total + 1)
			.append("\n");

        sb.append("Верхние компоненты expansion: ")
			.append(GravityExpansionMath.toShortString(avgExp));

        return sb.toString();
    }

    private static String formatAcceleration(double v) {
        if (!Double.isFinite(v) || v == 0.0) {
            return "0.000000e+00";
        }

        return String.format(Locale.US, "%.12e", v);
    }
}

final class GravityResultStore {
    static final int IDLE = 0;
    static final int RUNNING = 1;
    static final int DONE = 2;
    static final int ERROR = 3;
    static final int CANCELLED = 4;

    static volatile int state = IDLE;
    static volatile int progress = 0;
    static volatile String result = null;
    static volatile String error = null;

    private GravityResultStore() {
        // utility
    }

    static void reset() {
        state = IDLE;
        progress = 0;
        result = null;
        error = null;
    }
}
