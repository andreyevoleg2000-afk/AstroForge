package com.astroforge;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.util.Log;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 3D-визуализатор для Relativity3DEngine.
 *
 * Android OpenGL ES 2.0, Java 17, без NDK.
 *
 * Идея визуализации:
 *  - физический движок считает 3 тела;
 *  - квадратная поверхность представляет условную 2D-срезку пространства;
 *  - масса каждого тела создаёт локальное углубление;
 *  - UV-текстура растягивается по всей поверхности и изгибается вместе с ней;
 *  - сами тела рисуются как сферы поверх деформированной ткани.
 *
 * Файл не требует внешних библиотек.
 */
public final class Relativity3DVisualizer extends GLSurfaceView {

    private final RendererImpl renderer;

    public Relativity3DVisualizer(Context context) {
        super(context);
        setEGLContextClientVersion(2);
        setPreserveEGLContextOnPause(true);
        renderer = new RendererImpl(context);
        setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);

        getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                requestSurfaceRefreshRate(holder.getSurface());
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
                requestSurfaceRefreshRate(holder.getSurface());
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                // GLSurfaceView owns the surface lifecycle.
            }
        });
    }

    private static void requestSurfaceRefreshRate(Surface surface) {
        if (surface == null || !surface.isValid()) {
            return;
        }
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                surface.setFrameRate(
                        120.0f,
                        Surface.FRAME_RATE_COMPATIBILITY_DEFAULT,
                        Surface.CHANGE_FRAME_RATE_ONLY_IF_SEAMLESS);
            }
        } catch (Throwable ignore) {
            // A refresh-rate hint is optional and must never break rendering.
        }
    }

    public Relativity3DEngine getPhysicsEngine() {
        return renderer.engine;
    }

    // -------------------------------------------------------------------------
    // Управление камерой
    // -------------------------------------------------------------------------

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        renderer.onTouch(event);
        return true;
    }

    private static final class RendererImpl implements GLSurfaceView.Renderer {

        private static final int GRID = 65;
        private static final int VERTEX_COUNT = GRID * GRID;
        private static final int STRIP_INDEX_COUNT = GRID * 2;

        // Размер видимой ткани в метрах физического мира.
        // Значение маленькое относительно полного 27000-светолетнего мира движка,
        // чтобы планеты были заметны в кадре.
        private static final double FABRIC_SIZE_M = 6.0e8;
        private static final double HALF_FABRIC_M = FABRIC_SIZE_M * 0.5;

        // Физическое время на один кадр. 1 час достаточно быстрый,
        // но ещё не превращает один кадр в марафон численного интегратора.
        private static final double SIMULATION_SECONDS_PER_FRAME = 3600.0;

        // Визуальный коэффициент глубины искривления ткани.
        private static final double CURVATURE_VISUAL_SCALE = 1.0;

        // Стабилизатор поверхности в метрах.
        private static final double SURFACE_SOFTENING_M = 7.5e6;

        // Типичная масса для визуального нормирования провала.
        private static final double REFERENCE_MASS_KG = 5.972e24;

        private final Context context;
        private final Relativity3DEngine engine;
        private final AtomicBoolean mathRunning = new AtomicBoolean(false);
        private final AtomicInteger mathGeneration = new AtomicInteger(0);
        private volatile MeshFrame readyFrame;
        private MeshFrame renderFrame;
        private MeshFrame workFrame;

        private final short[] strip = new short[STRIP_INDEX_COUNT];
        private final ShortBuffer stripBuffer;

        private final double[] gridX = new double[VERTEX_COUNT];
        private final double[] gridZ = new double[VERTEX_COUNT];

        private int program;
        private int sphereProgram;
        private int textureId;

        private int aPosition;
        private int aNormal;
        private int aUv;
        private int uMvp;
        private int uModel;
        private int uLight;
        private int uTexture;
        private int uGridIntensity;

        private int sphereAPosition;
        private int sphereANormal;
        private int sphereMvp;
        private int sphereModel;
        private int sphereColor;
        private int sphereLight;

        private final float[] projection = new float[16];
        private final float[] view = new float[16];
        private final float[] model = new float[16];
        private final float[] mvp = new float[16];
        private final float[] tmp = new float[16];

        private float cameraYaw = 35.0f;
        private float cameraPitch = 38.0f;
        private float cameraDistance = 3.4f;

        private float previousX;
        private float previousY;
        private boolean dragging;

        // Сферическая сетка для планет.
        private FloatBuffer sphereVertexBuffer;
        private FloatBuffer sphereNormalBuffer;
        private ShortBuffer sphereIndexBuffer;
        private int sphereIndexCount;

        RendererImpl(Context context) {
            this.context = context.getApplicationContext();
            this.engine = new Relativity3DEngine();

            ByteBuffer ib = ByteBuffer.allocateDirect(strip.length * 2)
                    .order(ByteOrder.nativeOrder());
            stripBuffer = ib.asShortBuffer();

            renderFrame = new MeshFrame();
            workFrame = new MeshFrame();
            buildGridCoordinates();
            buildGridTopology();
            setupThreePlanets();
        }

        // ---------------------------------------------------------------------
        // Физика
        // ---------------------------------------------------------------------

        private void setupThreePlanets() {
            final double radius = 8.0e6;
            final double mass = 5.972e24;

            // Радиус треугольника относительно его центра масс.
            final double orbitRadius = 1.0e8;
            final double omega = Math.sqrt(
				Relativity3DEngine.GRAVITATIONAL_CONSTANT * mass /
				(Math.sqrt(3.0) * orbitRadius * orbitRadius * orbitRadius));

            for (int i = 0; i < 3; i++) {
                double angle = (Math.PI * 2.0 * i) / 3.0;
                double x = Math.cos(angle) * orbitRadius;
                double z = Math.sin(angle) * orbitRadius;

                // Тангенциальная скорость для совместного вращения.
                double vx = -Math.sin(angle) * orbitRadius * omega;
                double vz = Math.cos(angle) * orbitRadius * omega;

                engine.addBody(
					"Planet-" + (i + 1),
					Relativity3DEngine.MATERIAL_ROCK,
					mass,
					radius,
					5514.0,
					new Relativity3DEngine.Vec3(x, 0.0, z),
					new Relativity3DEngine.Vec3(vx, 0.0, vz),
					new Relativity3DEngine.Vec3(0.0, 0.0, 0.000000001)
                );
            }
        }

        private void buildGridCoordinates() {
            for (int j = 0; j < GRID; j++) {
                double v = (double) j / (double) (GRID - 1);
                double z = -HALF_FABRIC_M + FABRIC_SIZE_M * v;
                for (int i = 0; i < GRID; i++) {
                    double u = (double) i / (double) (GRID - 1);
                    double x = -HALF_FABRIC_M + FABRIC_SIZE_M * u;
                    int index = j * GRID + i;
                    gridX[index] = x;
                    gridZ[index] = z;
                }
            }
        }

        private static final class BodySnapshot {
            final int count;
            final double[] x;
            final double[] z;
            final double[] massKg;
            final double[] radiusM;
            final double[] qY;
            final boolean[] alive;

            BodySnapshot(int count) {
                this.count = count;
                x = new double[count];
                z = new double[count];
                massKg = new double[count];
                radiusM = new double[count];
                qY = new double[count];
                alive = new boolean[count];
            }
        }

        private static final class MeshFrame {
            final float[] vertices = new float[VERTEX_COUNT * 3];
            final float[] normals = new float[VERTEX_COUNT * 3];
            final float[] uv = new float[VERTEX_COUNT * 2];
            final FloatBuffer vertexBuffer;
            final FloatBuffer normalBuffer;
            final FloatBuffer uvBuffer;
            volatile BodySnapshot bodies;

            MeshFrame() {
                ByteBuffer vb = ByteBuffer.allocateDirect(vertices.length * 4)
                        .order(ByteOrder.nativeOrder());
                vertexBuffer = vb.asFloatBuffer();
                ByteBuffer nb = ByteBuffer.allocateDirect(normals.length * 4)
                        .order(ByteOrder.nativeOrder());
                normalBuffer = nb.asFloatBuffer();
                ByteBuffer ub = ByteBuffer.allocateDirect(uv.length * 4)
                        .order(ByteOrder.nativeOrder());
                uvBuffer = ub.asFloatBuffer();
            }

            void uploadToGpu() {
                vertexBuffer.position(0);
                vertexBuffer.put(vertices).position(0);
                normalBuffer.position(0);
                normalBuffer.put(normals).position(0);
                uvBuffer.position(0);
                uvBuffer.put(uv).position(0);
            }
        }

        private BodySnapshot snapshotBodies() {
            int count = engine.getBodyCount();
            BodySnapshot snapshot = new BodySnapshot(count);
            for (int i = 0; i < count; i++) {
                Relativity3DEngine.Body body = engine.getBodyByIndex(i);
                if (body == null) {
                    continue;
                }
                snapshot.x[i] = body.position.x;
                snapshot.z[i] = body.position.z;
                snapshot.massKg[i] = body.massKg;
                snapshot.radiusM[i] = body.radiusM;
                snapshot.qY[i] = body.quaternion[1];
                snapshot.alive[i] = body.alive;
            }
            return snapshot;
        }

        private double displacementAt(BodySnapshot bodies, double x, double z) {
            double total = 0.0;
            if (bodies == null) {
                return 0.0;
            }

            for (int i = 0; i < bodies.count; i++) {
                if (!bodies.alive[i]) {
                    continue;
                }
                double dx = x - bodies.x[i];
                double dz = z - bodies.z[i];
                double nx = dx / FABRIC_SIZE_M;
                double nz = dz / FABRIC_SIZE_M;
                double soft = SURFACE_SOFTENING_M / FABRIC_SIZE_M;
                double r = Math.sqrt(nx * nx + nz * nz + soft * soft);

                double massFactor = Math.sqrt(Math.max(0.0, bodies.massKg[i]) / REFERENCE_MASS_KG);
                double radiusFactor = Math.sqrt(Math.max(1.0, bodies.radiusM[i]) / 8.0e6);
                double influence = massFactor * radiusFactor / Math.max(0.012, r);
                double depression = 0.72 * influence / (1.0 + 0.95 * influence);
                total -= depression;
            }
            return total * CURVATURE_VISUAL_SCALE;
        }

        private void computeSurfaceHeights(MeshFrame frame, BodySnapshot bodies, int from, int to) {
            for (int index = from; index < to; index++) {
                double h = displacementAt(bodies, gridX[index], gridZ[index]);
                int p = index * 3;
                int t = index * 2;
                frame.vertices[p] = (float) (gridX[index] / HALF_FABRIC_M);
                frame.vertices[p + 1] = (float) (h / HALF_FABRIC_M);
                frame.vertices[p + 2] = (float) (gridZ[index] / HALF_FABRIC_M);

                int j = index / GRID;
                int i = index - j * GRID;
                frame.uv[t] = (float) i / (float) (GRID - 1) * 8.0f;
                frame.uv[t + 1] = (float) j / (float) (GRID - 1) * 8.0f;
            }
        }

        private void computeSurfaceNormals(MeshFrame frame, int from, int to) {
            // Heights are guaranteed to be complete for the whole grid before
            // this phase starts. That makes cross-worker neighbor reads safe.
            for (int index = from; index < to; index++) {
                int j = index / GRID;
                int i = index - j * GRID;
                int left = Math.max(0, i - 1) + j * GRID;
                int right = Math.min(GRID - 1, i + 1) + j * GRID;
                int down = i + Math.max(0, j - 1) * GRID;
                int up = i + Math.min(GRID - 1, j + 1) * GRID;

                double hL = frame.vertices[left * 3 + 1];
                double hR = frame.vertices[right * 3 + 1];
                double hD = frame.vertices[down * 3 + 1];
                double hU = frame.vertices[up * 3 + 1];
                double sx = (hR - hL) * 0.5 * (GRID - 1);
                double sz = (hU - hD) * 0.5 * (GRID - 1);

                float nx = (float) (-sx);
                float ny = 1.0f;
                float nz = (float) (-sz);
                float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
                if (len < 1.0e-6f) {
                    len = 1.0f;
                }

                int p = index * 3;
                frame.normals[p] = nx / len;
                frame.normals[p + 1] = ny / len;
                frame.normals[p + 2] = nz / len;
            }
        }

        private void scheduleMathFrame() {
            if (!mathRunning.compareAndSet(false, true)) {
                return;
            }

            final MeshFrame target = workFrame;
            final BodySnapshot bodies = snapshotBodies();
            final CountDownLatch meshHeightsDone = new CountDownLatch(6);
            final AtomicInteger completed = new AtomicInteger(0);
            final int generation = mathGeneration.incrementAndGet();
            final int verticesPerWorker = (VERTEX_COUNT + 5) / 6;

            for (int worker = 0; worker < PerformancePools.MATH_THREADS; worker++) {
                final int workerId = worker;
                PerformancePools.math().execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            if (workerId == 0) {
                                // One of the seven math workers advances the numerical
                                // physics state while the other six build the visual mesh.
                                engine.step(SIMULATION_SECONDS_PER_FRAME);
                            } else {
                                int meshWorker = workerId - 1;
                                int from = meshWorker * verticesPerWorker;
                                int to = Math.min(VERTEX_COUNT, from + verticesPerWorker);
                                if (from < to) {
                                    computeSurfaceHeights(target, bodies, from, to);
                                    meshHeightsDone.countDown();
                                    try {
                                        meshHeightsDone.await();
                                    } catch (InterruptedException e) {
                                        Thread.currentThread().interrupt();
                                    }
                                    computeSurfaceNormals(target, from, to);
                                } else {
                                    meshHeightsDone.countDown();
                                }
                            }
                        } catch (Throwable t) {
                            Log.w("AstroForgeMath", "Worker " + workerId + " failed in frame " + generation, t);
                            if (workerId != 0) {
                                meshHeightsDone.countDown();
                            }
                        } finally {
                            if (completed.incrementAndGet() == PerformancePools.MATH_THREADS) {
                                target.bodies = bodies;
                                readyFrame = target;
                                mathRunning.set(false);
                            }
                        }
                    }
                });
            }
        }

        private void buildGridTopology() {
            int p = 0;
            for (int y = 0; y < GRID - 1; y++) {
                for (int x = 0; x < GRID; x++) {
                    strip[p++] = (short) (y * GRID + x);
                    strip[p++] = (short) ((y + 1) * GRID + x);
                }
            }

            stripBuffer.position(0);
            stripBuffer.put(strip).position(0);
        }

        // ---------------------------------------------------------------------
        // OpenGL
        // ---------------------------------------------------------------------

        @Override
		public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            GLES20.glClearColor(0.008f, 0.012f, 0.022f, 1.0f);
            GLES20.glEnable(GLES20.GL_DEPTH_TEST);
            GLES20.glDepthFunc(GLES20.GL_LEQUAL);
            GLES20.glDisable(GLES20.GL_CULL_FACE);

            program = createProgram(VERTEX_SHADER, FRAGMENT_SHADER);
            sphereProgram = createProgram(SPHERE_VERTEX_SHADER, SPHERE_FRAGMENT_SHADER);

            aPosition = GLES20.glGetAttribLocation(program, "aPosition");
            aNormal = GLES20.glGetAttribLocation(program, "aNormal");
            aUv = GLES20.glGetAttribLocation(program, "aUv");
            uMvp = GLES20.glGetUniformLocation(program, "uMvp");
            uModel = GLES20.glGetUniformLocation(program, "uModel");
            uLight = GLES20.glGetUniformLocation(program, "uLight");
            uTexture = GLES20.glGetUniformLocation(program, "uTexture");
            uGridIntensity = GLES20.glGetUniformLocation(program, "uGridIntensity");

            sphereAPosition = GLES20.glGetAttribLocation(sphereProgram, "aPosition");
            sphereANormal = GLES20.glGetAttribLocation(sphereProgram, "aNormal");
            sphereMvp = GLES20.glGetUniformLocation(sphereProgram, "uMvp");
            sphereModel = GLES20.glGetUniformLocation(sphereProgram, "uModel");
            sphereColor = GLES20.glGetUniformLocation(sphereProgram, "uColor");
            sphereLight = GLES20.glGetUniformLocation(sphereProgram, "uLight");

            textureId = createGridTexture();
            createSphereMesh(16, 24);
            scheduleMathFrame();
        }

        @Override
        public void onSurfaceChanged(javax.microedition.khronos.opengles.GL10 gl, int width, int height) {
            GLES20.glViewport(0, 0, width, height);
            float aspect = (float) width / Math.max(1, height);
            Matrix.perspectiveM(projection, 0, 52.0f, aspect, 0.05f, 30.0f);
        }

        @Override
        public void onDrawFrame(javax.microedition.khronos.opengles.GL10 gl) {
            MeshFrame ready = readyFrame;
            if (ready != null && ready != renderFrame) {
                MeshFrame previousRender = renderFrame;
                renderFrame = ready;
                workFrame = previousRender;
                renderFrame.uploadToGpu();
                readyFrame = null;
            }

            if (!mathRunning.get()) {
                // Keep exactly one numerical frame in flight. Rendering never waits
                // for the math workers; it consumes the last completed frame.
                scheduleMathFrame();
            }

            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

            updateCameraMatrices();
            drawFabric();
            drawPlanets();
        }

        private void updateCameraMatrices() {
            float yaw = (float) Math.toRadians(cameraYaw);
            float pitch = (float) Math.toRadians(cameraPitch);

            float cx = (float) (Math.cos(pitch) * Math.sin(yaw) * cameraDistance);
            float cy = (float) (Math.sin(pitch) * cameraDistance);
            float cz = (float) (Math.cos(pitch) * Math.cos(yaw) * cameraDistance);

            Matrix.setLookAtM(
				view,
				0,
				cx,
				cy,
				cz,
				0.0f,
				-0.15f,
				0.0f,
				0.0f,
				1.0f,
				0.0f
            );
        }

        private void drawFabric() {
            GLES20.glUseProgram(program);

            Matrix.setIdentityM(model, 0);
            Matrix.multiplyMM(tmp, 0, view, 0, model, 0);
            Matrix.multiplyMM(mvp, 0, projection, 0, tmp, 0);

            GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0);
            GLES20.glUniformMatrix4fv(uModel, 1, false, model, 0);
            GLES20.glUniform3f(uLight, -0.4f, 1.0f, 0.35f);
            GLES20.glUniform1f(uGridIntensity, 1.25f);

            GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId);
            GLES20.glUniform1i(uTexture, 0);

            renderFrame.vertexBuffer.position(0);
            GLES20.glEnableVertexAttribArray(aPosition);
            GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, 0, renderFrame.vertexBuffer);

            renderFrame.normalBuffer.position(0);
            GLES20.glEnableVertexAttribArray(aNormal);
            GLES20.glVertexAttribPointer(aNormal, 3, GLES20.GL_FLOAT, false, 0, renderFrame.normalBuffer);

            renderFrame.uvBuffer.position(0);
            GLES20.glEnableVertexAttribArray(aUv);
            GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, 0, renderFrame.uvBuffer);

            for (int row = 0; row < GRID - 1; row++) {
                stripBuffer.position(row * STRIP_INDEX_COUNT);
                GLES20.glDrawElements(
					GLES20.GL_TRIANGLE_STRIP,
					STRIP_INDEX_COUNT,
					GLES20.GL_UNSIGNED_SHORT,
					stripBuffer
                );
            }

            GLES20.glDisableVertexAttribArray(aPosition);
            GLES20.glDisableVertexAttribArray(aNormal);
            GLES20.glDisableVertexAttribArray(aUv);
        }

        private void drawPlanets() {
            if (sphereVertexBuffer == null) {
                return;
            }

            GLES20.glUseProgram(sphereProgram);
            GLES20.glEnable(GLES20.GL_CULL_FACE);
            GLES20.glCullFace(GLES20.GL_BACK);

            sphereVertexBuffer.position(0);
            GLES20.glEnableVertexAttribArray(sphereAPosition);
            GLES20.glVertexAttribPointer(sphereAPosition, 3, GLES20.GL_FLOAT, false, 0, sphereVertexBuffer);

            sphereNormalBuffer.position(0);
            GLES20.glEnableVertexAttribArray(sphereANormal);
            GLES20.glVertexAttribPointer(sphereANormal, 3, GLES20.GL_FLOAT, false, 0, sphereNormalBuffer);

            GLES20.glUniform3f(sphereLight, -0.7f, 1.0f, 0.4f);

            BodySnapshot bodies = renderFrame.bodies;
            if (bodies == null) {
                GLES20.glDisableVertexAttribArray(sphereAPosition);
                GLES20.glDisableVertexAttribArray(sphereANormal);
                GLES20.glDisable(GLES20.GL_CULL_FACE);
                return;
            }

            for (int i = 0; i < bodies.count; i++) {
                if (!bodies.alive[i]) {
                    continue;
                }

                double x = bodies.x[i] / HALF_FABRIC_M;
                double z = bodies.z[i] / HALF_FABRIC_M;
                double h = displacementAt(bodies, bodies.x[i], bodies.z[i]);

                float y = (float) (h / HALF_FABRIC_M);
                float renderRadius = (float) Math.max(0.028, Math.min(0.16, bodies.radiusM[i] / HALF_FABRIC_M * 28.0));

                Matrix.setIdentityM(model, 0);
                Matrix.translateM(model, 0, (float) x, y + renderRadius * 0.60f, (float) z);
                Matrix.rotateM(model, 0, (float) Math.toDegrees(bodies.qY[i]), 0.0f, 1.0f, 0.0f);
                Matrix.scaleM(model, 0, renderRadius, renderRadius, renderRadius);

                Matrix.multiplyMM(tmp, 0, view, 0, model, 0);
                Matrix.multiplyMM(mvp, 0, projection, 0, tmp, 0);

                GLES20.glUniformMatrix4fv(sphereMvp, 1, false, mvp, 0);
                GLES20.glUniformMatrix4fv(sphereModel, 1, false, model, 0);

                float c;
                if (i == 0) {
                    c = 0.86f;
                } else if (i == 1) {
                    c = 0.55f;
                } else {
                    c = 0.66f;
                }
                GLES20.glUniform4f(sphereColor, c, c * 0.82f, c * 0.58f, 1.0f);

                sphereIndexBuffer.position(0);
                GLES20.glDrawElements(
					GLES20.GL_TRIANGLES,
					sphereIndexCount,
					GLES20.GL_UNSIGNED_SHORT,
					sphereIndexBuffer
                );
            }

            GLES20.glDisableVertexAttribArray(sphereAPosition);
            GLES20.glDisableVertexAttribArray(sphereANormal);
            GLES20.glDisable(GLES20.GL_CULL_FACE);
        }

        // ---------------------------------------------------------------------
        // Сферическая сетка
        // ---------------------------------------------------------------------

        private void createSphereMesh(int stacks, int slices) {
            int verticesCount = (stacks + 1) * (slices + 1);
            float[] positions = new float[verticesCount * 3];
            float[] normalsData = new float[verticesCount * 3];
            short[] indices = new short[stacks * slices * 6];

            int p = 0;
            int n = 0;

            for (int stack = 0; stack <= stacks; stack++) {
                double v = (double) stack / (double) stacks;
                double phi = Math.PI * v;
                double sinPhi = Math.sin(phi);
                double cosPhi = Math.cos(phi);

                for (int slice = 0; slice <= slices; slice++) {
                    double u = (double) slice / (double) slices;
                    double theta = 2.0 * Math.PI * u;
                    double x = Math.cos(theta) * sinPhi;
                    double y = cosPhi;
                    double z = Math.sin(theta) * sinPhi;

                    positions[p++] = (float) x;
                    positions[p++] = (float) y;
                    positions[p++] = (float) z;

                    normalsData[n++] = (float) x;
                    normalsData[n++] = (float) y;
                    normalsData[n++] = (float) z;
                }
            }

            int q = 0;
            for (int stack = 0; stack < stacks; stack++) {
                for (int slice = 0; slice < slices; slice++) {
                    int a = stack * (slices + 1) + slice;
                    int b = a + 1;
                    int c = a + (slices + 1);
                    int d = c + 1;

                    indices[q++] = (short) a;
                    indices[q++] = (short) c;
                    indices[q++] = (short) b;

                    indices[q++] = (short) b;
                    indices[q++] = (short) c;
                    indices[q++] = (short) d;
                }
            }

            ByteBuffer vb = ByteBuffer.allocateDirect(positions.length * 4)
				.order(ByteOrder.nativeOrder());
            sphereVertexBuffer = vb.asFloatBuffer();
            sphereVertexBuffer.put(positions).position(0);

            ByteBuffer nb = ByteBuffer.allocateDirect(normalsData.length * 4)
				.order(ByteOrder.nativeOrder());
            sphereNormalBuffer = nb.asFloatBuffer();
            sphereNormalBuffer.put(normalsData).position(0);

            ByteBuffer ib = ByteBuffer.allocateDirect(indices.length * 2)
				.order(ByteOrder.nativeOrder());
            sphereIndexBuffer = ib.asShortBuffer();
            sphereIndexBuffer.put(indices).position(0);
            sphereIndexCount = indices.length;
        }

        // ---------------------------------------------------------------------
        // Текстура ткани
        // ---------------------------------------------------------------------

        private int createGridTexture() {
            final int size = 256;
            Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.rgb(8, 13, 22));
            canvas.drawRect(0, 0, size, size, paint);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1.0f);
            paint.setColor(Color.argb(115, 85, 125, 155));

            int major = 32;
            for (int i = 0; i <= size; i += major) {
                canvas.drawLine(i, 0, i, size, paint);
                canvas.drawLine(0, i, size, i, paint);
            }

            paint.setStrokeWidth(0.5f);
            paint.setColor(Color.argb(55, 100, 150, 190));
            for (int i = 0; i <= size; i += 8) {
                canvas.drawLine(i, 0, i, size, paint);
                canvas.drawLine(0, i, size, i, paint);
            }

            int[] texture = new int[1];
            GLES20.glGenTextures(1, texture, 0);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture[0]);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_REPEAT);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_REPEAT);

            android.opengl.GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0);
            bitmap.recycle();
            return texture[0];
        }

        // ---------------------------------------------------------------------
        // Touch
        // ---------------------------------------------------------------------

        void onTouch(MotionEvent event) {
            float x = event.getX();
            float y = event.getY();

            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    previousX = x;
                    previousY = y;
                    dragging = true;
                    break;

                case MotionEvent.ACTION_MOVE:
                    if (dragging) {
                        float dx = x - previousX;
                        float dy = y - previousY;

                        cameraYaw += dx * 0.45f;
                        cameraPitch -= dy * 0.30f;
                        cameraPitch = Math.max(8.0f, Math.min(82.0f, cameraPitch));

                        previousX = x;
                        previousY = y;
                    }
                    break;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dragging = false;
                    break;

                default:
                    break;
            }
        }

        // ---------------------------------------------------------------------
        // GLSL
        // ---------------------------------------------------------------------

        private static final String VERTEX_SHADER =
		"uniform mat4 uMvp;\n" +
		"uniform mat4 uModel;\n" +
		"attribute vec3 aPosition;\n" +
		"attribute vec3 aNormal;\n" +
		"attribute vec2 aUv;\n" +
		"varying vec3 vNormal;\n" +
		"varying vec2 vUv;\n" +
		"varying vec3 vWorld;\n" +
		"void main(){\n" +
		"  vec4 world = uModel * vec4(aPosition,1.0);\n" +
		"  vWorld = world.xyz;\n" +
		"  vNormal = mat3(uModel) * aNormal;\n" +
		"  vUv = aUv;\n" +
		"  gl_Position = uMvp * vec4(aPosition,1.0);\n" +
		"}\n";

        private static final String FRAGMENT_SHADER =
		"precision mediump float;\n" +
		"uniform sampler2D uTexture;\n" +
		"uniform vec3 uLight;\n" +
		"uniform float uGridIntensity;\n" +
		"varying vec3 vNormal;\n" +
		"varying vec2 vUv;\n" +
		"varying vec3 vWorld;\n" +
		"void main(){\n" +
		"  vec3 n = normalize(vNormal);\n" +
		"  float light = 0.30 + 0.70 * max(dot(n, normalize(uLight)), 0.0);\n" +
		"  vec3 tex = texture2D(uTexture, vUv).rgb;\n" +
		"  float horizon = 0.94 + 0.06 * clamp(vWorld.y + 0.6, 0.0, 1.0);\n" +
		"  vec3 color = tex * light * horizon * uGridIntensity;\n" +
		"  gl_FragColor = vec4(color, 1.0);\n" +
		"}\n";

        private static final String SPHERE_VERTEX_SHADER =
		"uniform mat4 uMvp;\n" +
		"uniform mat4 uModel;\n" +
		"attribute vec3 aPosition;\n" +
		"attribute vec3 aNormal;\n" +
		"varying vec3 vNormal;\n" +
		"void main(){\n" +
		"  vNormal = mat3(uModel) * aNormal;\n" +
		"  gl_Position = uMvp * vec4(aPosition,1.0);\n" +
		"}\n";

        private static final String SPHERE_FRAGMENT_SHADER =
		"precision mediump float;\n" +
		"uniform vec4 uColor;\n" +
		"uniform vec3 uLight;\n" +
		"varying vec3 vNormal;\n" +
		"void main(){\n" +
		"  vec3 n = normalize(vNormal);\n" +
		"  float l = 0.22 + 0.78 * max(dot(n, normalize(uLight)), 0.0);\n" +
		"  gl_FragColor = vec4(uColor.rgb * l, uColor.a);\n" +
		"}\n";

        private static int createProgram(String vertexSource, String fragmentSource) {
            int vertex = compileShader(GLES20.GL_VERTEX_SHADER, vertexSource);
            int fragment = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentSource);

            int p = GLES20.glCreateProgram();
            if (p == 0) {
                throw new RuntimeException("glCreateProgram failed");
            }

            GLES20.glAttachShader(p, vertex);
            GLES20.glAttachShader(p, fragment);
            GLES20.glLinkProgram(p);

            int[] status = new int[1];
            GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, status, 0);
            if (status[0] == 0) {
                String log = GLES20.glGetProgramInfoLog(p);
                GLES20.glDeleteProgram(p);
                throw new RuntimeException("Program link failed: " + log);
            }

            GLES20.glDeleteShader(vertex);
            GLES20.glDeleteShader(fragment);
            return p;
        }

        private static int compileShader(int type, String source) {
            int shader = GLES20.glCreateShader(type);
            if (shader == 0) {
                throw new RuntimeException("glCreateShader failed");
            }

            GLES20.glShaderSource(shader, source);
            GLES20.glCompileShader(shader);

            int[] status = new int[1];
            GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0);
            if (status[0] == 0) {
                String log = GLES20.glGetShaderInfoLog(shader);
                GLES20.glDeleteShader(shader);
                throw new RuntimeException("Shader compile failed: " + log);
            }

            return shader;
        }
    }
}

