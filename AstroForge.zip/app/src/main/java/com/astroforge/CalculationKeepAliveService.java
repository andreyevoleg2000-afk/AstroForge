package com.astroforge;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

/**
 * Keeps long calculations alive while the Activity is backgrounded.
 * The numerical work remains in the existing worker pools/engines.
 */
public final class CalculationKeepAliveService extends Service {

    public static final String ACTION_START = "com.astroforge.CALC_KEEPALIVE_START";
    public static final String ACTION_STOP = "com.astroforge.CALC_KEEPALIVE_STOP";

    private static final String PREFS = "astroforge_calculation_progress";
    private static final String KEY_ACTIVE = "active";
    private static final String KEY_TITLE = "title";
    private static final String KEY_TEXT = "text";
    private static final String KEY_PERCENT = "percent";

    private static final String CHANNEL_ID = "astroforge_calculations";
    private static final String CHANNEL_NAME = "Длительные расчёты";
    private static final int NOTIFICATION_ID = 1842;

    private NotificationManager notificationManager;
    private Handler notificationHandler;
    private Runnable notificationPoller;

    public static void start(Context context, String title) {
        Context app = context.getApplicationContext();
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_ACTIVE, true)
                .putString(KEY_TITLE, title == null ? "Расчёт" : title)
                .putString(KEY_TEXT, "Подготовка расчёта…")
                .putInt(KEY_PERCENT, 0)
                .apply();

        Intent intent = new Intent(app, CalculationKeepAliveService.class);
        intent.setAction(ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) {
            app.startForegroundService(intent);
        } else {
            app.startService(intent);
        }
    }

    public static void update(Context context, int percent, String text) {
        Context app = context.getApplicationContext();
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_ACTIVE, true)
                .putInt(KEY_PERCENT, Math.max(0, Math.min(100, percent)))
                .putString(KEY_TEXT, text == null ? "Выполняется расчёт…" : text)
                .apply();
    }

    public static void stop(Context context) {
        Context app = context.getApplicationContext();
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_ACTIVE, false)
                .apply();

        // The running foreground service sees KEY_ACTIVE=false on its next poll and stops itself.
    }

    @Override
    public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        createChannel();

        notificationHandler = new Handler(Looper.getMainLooper());
        notificationPoller = new Runnable() {
            @Override
            public void run() {
                try {
                    android.content.SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
                    if (!prefs.getBoolean(KEY_ACTIVE, false)) {
                        stopSelf();
                        return;
                    }
                    String title = prefs.getString(KEY_TITLE, "Расчёт");
                    String text = prefs.getString(KEY_TEXT, "Выполняется расчёт…");
                    int percent = prefs.getInt(KEY_PERCENT, 0);
                    updateNotification(title, text, percent);
                } catch (Throwable ignored) {
                }
                notificationHandler.postDelayed(this, 500L);
            }
        };
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            if (intent == null || ACTION_START.equals(intent.getAction())) {
                android.content.SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
                String title = prefs.getString(KEY_TITLE, "Расчёт");
                String text = prefs.getString(KEY_TEXT, "Запуск расчёта…");
                int percent = prefs.getInt(KEY_PERCENT, 0);
                startForegroundCompat(title, text, percent);
                if (notificationHandler != null) {
                    notificationHandler.removeCallbacks(notificationPoller);
                    notificationHandler.post(notificationPoller);
                }
                return START_NOT_STICKY;
            }

            if (ACTION_STOP.equals(intent.getAction())) {
                stopSelf();
                return START_NOT_STICKY;
            }
        } catch (Throwable ignored) {
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        if (notificationHandler != null && notificationPoller != null) {
            notificationHandler.removeCallbacks(notificationPoller);
        }
        try {
            stopForeground(true);
        } catch (Throwable ignored) {
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26 && notificationManager != null) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Ход длительных расчётов AstroForge");
            channel.setShowBadge(false);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String title, String text, int percent) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent pendingIntent = null;
        if (launch != null) {
            pendingIntent = PendingIntent.getActivity(
                    this,
                    NOTIFICATION_ID,
                    launch,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
        }

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        builder.setContentTitle(title == null ? "AstroForge" : title)
                .setContentText(text == null ? "Выполняется расчёт…" : text)
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setProgress(100, Math.max(0, Math.min(100, percent)), percent <= 0);

        if (pendingIntent != null) {
            builder.setContentIntent(pendingIntent);
        }
        return builder.build();
    }

    private void startForegroundCompat(String title, String text, int percent) {
        Notification notification = buildNotification(title, text, percent);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                    NOTIFICATION_ID,
                    notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            );
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void updateNotification(String title, String text, int percent) {
        if (notificationManager == null) {
            return;
        }
        try {
            notificationManager.notify(NOTIFICATION_ID, buildNotification(title, text, percent));
        } catch (Throwable ignored) {
        }
    }
}
