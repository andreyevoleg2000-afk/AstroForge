package com.astroforge;

/**
 * Настройки временной симуляции.
 */
public final class SimulationConfig {

    public final double years;
    public final int steps;
    public final long seed;
    public final double minHeatFluxWm2;
    public final double coolingTimeYears;
    public final double eventRatePerYear;
    public final double gamma;
    public final double dtMinYears;
    public final double dtMaxYears;
    public final boolean includeEvents;

    public SimulationConfig(
		double years,
		int steps,
		long seed,
		double minHeatFluxWm2,
		double coolingTimeYears,
		double eventRatePerYear,
		double gamma,
		double dtMinYears,
		double dtMaxYears,
		boolean includeEvents
    ) {
        if (!Double.isFinite(years) || years <= 0.0) {
            throw new MagnetoException("years должен быть положительным конечным числом.");
        }

        if (steps <= 0) {
            throw new MagnetoException("steps должен быть больше нуля.");
        }

        if (!Double.isFinite(minHeatFluxWm2) || minHeatFluxWm2 < 0.0) {
            throw new MagnetoException("minHeatFluxWm2 должен быть неотрицательным конечным числом.");
        }

        if (!Double.isFinite(coolingTimeYears) || coolingTimeYears < 0.0) {
            throw new MagnetoException("coolingTimeYears должен быть неотрицательным конечным числом.");
        }

        if (!Double.isFinite(eventRatePerYear) || eventRatePerYear < 0.0) {
            throw new MagnetoException("eventRatePerYear должен быть неотрицательным конечным числом.");
        }

        if (!Double.isFinite(gamma) || gamma <= 0.0) {
            throw new MagnetoException("gamma должен быть положительным конечным числом.");
        }

        if (!Double.isFinite(dtMinYears) || dtMinYears <= 0.0) {
            throw new MagnetoException("dtMinYears должен быть положительным конечным числом.");
        }

        if (!Double.isFinite(dtMaxYears) || dtMaxYears < dtMinYears) {
            throw new MagnetoException("dtMaxYears должен быть больше или равен dtMinYears.");
        }

        this.years = years;
        this.steps = steps;
        this.seed = seed;
        this.minHeatFluxWm2 = minHeatFluxWm2;
        this.coolingTimeYears = coolingTimeYears;
        this.eventRatePerYear = eventRatePerYear;
        this.gamma = gamma;
        this.dtMinYears = dtMinYears;
        this.dtMaxYears = dtMaxYears;
        this.includeEvents = includeEvents;
    }
}
