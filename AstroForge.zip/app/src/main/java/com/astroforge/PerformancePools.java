package com.astroforge;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Shared CPU pools for the performance-oriented parts of AstroForge.
 *
 * The Android View hierarchy itself remains main-thread-only. The 8-thread UI
 * pool is therefore used for parallel preparation of strings/data/assets that
 * are later committed to Views on the main thread. The 7-thread math pool is
 * reserved for numerical work so the Android main/UI thread remains free for
 * input and frame submission.
 */
public final class PerformancePools {
    public static final int UI_THREADS = 8;
    public static final int MATH_THREADS = 7;

    private static final ExecutorService UI_EXECUTOR = Executors.newFixedThreadPool(
            UI_THREADS, new NamedFactory("astroforge-ui-prep-"));

    private static final ExecutorService MATH_EXECUTOR = Executors.newFixedThreadPool(
            MATH_THREADS, new NamedFactory("astroforge-math-"));

    private PerformancePools() {
    }

    public static ExecutorService ui() {
        return UI_EXECUTOR;
    }

    public static ExecutorService math() {
        return MATH_EXECUTOR;
    }

    private static final class NamedFactory implements ThreadFactory {
        private final String prefix;
        private final AtomicInteger next = new AtomicInteger();

        NamedFactory(String prefix) {
            this.prefix = prefix;
        }

        @Override
        public Thread newThread(final Runnable runnable) {
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    runnable.run();
                }
            }, prefix + next.getAndIncrement());
            thread.setDaemon(true);
            return thread;
        }
    }
}
