package com.astroforge;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Внутренняя клавиатура для космических заметок.
 * Это обычная вьюха, не системная IME.
 */
public final class CosmicNotesKeyboard {

    private static final String PREFS = "cosmic_notes_keyboard";
    private static final String PREF_PHRASES = "saved_phrases";
    private static final int MAX_PHRASES = 32;

    private static final int MODE_LETTERS = 0;
    private static final int MODE_EMOJI = 1;
    private static final int MODE_PHRASES = 2;
    private static final int MODE_SYSTEM = 3;

    private CosmicNotesKeyboard() {
    }

    public static View create(final Activity activity,
                              final Typeface typeface,
                              final EditText[] activeFieldHolder,
                              final EditText titleField,
                              final EditText contentField,
                              final TextView status) {
        final KeyboardPalette palette = resolvePalette(activity);
        final KeyboardController controller = new KeyboardController(
            activity, typeface, palette, activeFieldHolder, titleField, contentField, status
        );
        return controller.root;
    }

    private static final class KeyboardPalette {
        final int windowBg;
        final int panelBg;
        final int keyBg;
        final int keyBgSoft;
        final int keyStroke;
        final int keyText;
        final int accent;
        final int accentSoft;
        final int hintText;
        final int chipText;
        final int chipStroke;

        KeyboardPalette(int windowBg, int panelBg, int keyBg, int keyBgSoft, int keyStroke,
                        int keyText, int accent, int accentSoft, int hintText,
                        int chipText, int chipStroke) {
            this.windowBg = windowBg;
            this.panelBg = panelBg;
            this.keyBg = keyBg;
            this.keyBgSoft = keyBgSoft;
            this.keyStroke = keyStroke;
            this.keyText = keyText;
            this.accent = accent;
            this.accentSoft = accentSoft;
            this.hintText = hintText;
            this.chipText = chipText;
            this.chipStroke = chipStroke;
        }
    }

    private static final class KeyboardController {
        private final Activity activity;
        private final Typeface typeface;
        private final KeyboardPalette palette;
        private final EditText[] activeFieldHolder;
        private final EditText titleField;
        private final EditText contentField;
        private final TextView status;

        private final LinearLayout root;
        private final TextView lettersTab;
        private final TextView emojiTab;
        private final TextView phrasesTab;
        private final TextView systemTab;
        private final TextView systemHint;
        private final FrameLayout pagesHost;
        private final View lettersPage;
        private final View emojiPage;
        private final View phrasesPage;
        private LinearLayout phrasesContainer;

        private int mode = MODE_LETTERS;

        KeyboardController(Activity activity,
                           Typeface typeface,
                           KeyboardPalette palette,
                           EditText[] activeFieldHolder,
                           EditText titleField,
                           EditText contentField,
                           TextView status) {
            this.activity = activity;
            this.typeface = typeface;
            this.palette = palette;
            this.activeFieldHolder = activeFieldHolder;
            this.titleField = titleField;
            this.contentField = contentField;
            this.status = status;

            root = new LinearLayout(activity);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setPadding(dp(activity, 12), dp(activity, 12), dp(activity, 12), dp(activity, 12));
            root.setBackground(makeRounded(palette.panelBg, palette.keyStroke, activity));

            LinearLayout topRow = new LinearLayout(activity);
            topRow.setOrientation(LinearLayout.HORIZONTAL);
            topRow.setGravity(Gravity.CENTER_VERTICAL);

            TextView header = new DigitTextView(activity);
            header.setText("Клавиатура");
            styleText(header, typeface, 15f, palette.keyText);
            topRow.addView(header, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            lettersTab = createTab("ABC", palette.accent, palette.panelBg);
            emojiTab = createTab("🙂", palette.keyBgSoft, palette.keyText);
            phrasesTab = createTab("Фразы", palette.keyBgSoft, palette.keyText);
            systemTab = createTab("⌨", palette.accentSoft, palette.keyText);

            lettersTab.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						setMode(MODE_LETTERS);
					}
				});
            emojiTab.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						setMode(MODE_EMOJI);
					}
				});
            phrasesTab.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						setMode(MODE_PHRASES);
					}
				});
            systemTab.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						setMode(MODE_SYSTEM);
					}
				});

            topRow.addView(lettersTab);
            topRow.addView(emojiTab);
            topRow.addView(phrasesTab);
            topRow.addView(systemTab);
            root.addView(topRow, new LinearLayout.LayoutParams(
							 ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            systemHint = new DigitTextView(activity);
            systemHint.setText("Нативная клавиатура включена");
            styleText(systemHint, typeface, 12f, palette.hintText);
            systemHint.setGravity(Gravity.CENTER_HORIZONTAL);
            systemHint.setPadding(dp(activity, 6), dp(activity, 6), dp(activity, 6), dp(activity, 6));
            systemHint.setVisibility(View.GONE);
            root.addView(systemHint, new LinearLayout.LayoutParams(
							 ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            pagesHost = new FrameLayout(activity);
            LinearLayout.LayoutParams pagesLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 238));
            pagesLp.topMargin = dp(activity, 10);
            root.addView(pagesHost, pagesLp);

            lettersPage = buildLettersPage();
            emojiPage = buildEmojiPage();
            phrasesPage = buildPhrasesPage();

            pagesHost.addView(lettersPage, matchParentLp());
            pagesHost.addView(emojiPage, matchParentLp());
            pagesHost.addView(phrasesPage, matchParentLp());

            setMode(MODE_LETTERS);
        }

        private View buildLettersPage() {
            ScrollView scroll = new ScrollView(activity);
            scroll.setFillViewport(true);

            LinearLayout body = new LinearLayout(activity);
            body.setOrientation(LinearLayout.VERTICAL);

            body.addView(buildLetterRow(new String[]{"й", "ц", "у", "к", "е", "н", "г", "ш", "щ", "з", "х", "ъ"}));
            body.addView(buildLetterRow(new String[]{"ф", "ы", "в", "а", "п", "р", "о", "л", "д", "ж", "э"}));
            body.addView(buildLetterRow(new String[]{"я", "ч", "с", "м", "и", "т", "ь", "б", "ю", ".", ","}));

            LinearLayout actions = new LinearLayout(activity);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            actions.setPadding(0, dp(activity, 8), 0, 0);
            actions.addView(createActionKey("⌫", new View.OnClickListener() {
									@Override
									public void onClick(View v) {
										deleteBackward();
									}
								}), weightedKeyLp(activity, 1f));

            actions.addView(createActionKey("␣", new View.OnClickListener() {
									@Override
									public void onClick(View v) {
										insertText(" ");
									}
								}), weightedKeyLp(activity, 1f));

            actions.addView(createActionKey("↵", new View.OnClickListener() {
									@Override
									public void onClick(View v) {
										handleEnter();
									}
								}), weightedKeyLp(activity, 1f));

            body.addView(actions);

            LinearLayout bottom = new LinearLayout(activity);
            bottom.setOrientation(LinearLayout.HORIZONTAL);
            bottom.setPadding(0, dp(activity, 8), 0, 0);

            bottom.addView(createActionKey("Коп.", new View.OnClickListener() {
								   @Override
								   public void onClick(View v) {
									   copyCurrentSelectionOrText();
								   }
							   }), weightedKeyLp(activity, 1f));

            bottom.addView(createActionKey("Вст.", new View.OnClickListener() {
								   @Override
								   public void onClick(View v) {
									   pasteClipboard();
								   }
							   }), weightedKeyLp(activity, 1f));

            bottom.addView(createActionKey("+Фр.", new View.OnClickListener() {
								   @Override
								   public void onClick(View v) {
									   addPhraseFromField();
								   }
							   }), weightedKeyLp(activity, 1f));

            bottom.addView(createActionKey("Сист.", new View.OnClickListener() {
								   @Override
								   public void onClick(View v) {
									   setMode(MODE_SYSTEM);
								   }
							   }), weightedKeyLp(activity, 1f));

            body.addView(bottom);

            scroll.addView(body, new ScrollView.LayoutParams(
							   ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            return scroll;
        }

        private View buildEmojiPage() {
            ScrollView scroll = new ScrollView(activity);
            scroll.setFillViewport(true);

            LinearLayout body = new LinearLayout(activity);
            body.setOrientation(LinearLayout.VERTICAL);

            TextView caption = new DigitTextView(activity);
            caption.setText("Эмодзи из res/drawable/emoji");
            styleText(caption, typeface, 12f, palette.hintText);
            caption.setPadding(0, 0, 0, dp(activity, 8));
            body.addView(caption);

            List<Integer> emojiIds = collectEmojiDrawables(activity);
            if (emojiIds.isEmpty()) {
                body.addView(buildFallbackEmojiGrid());
            } else {
                body.addView(buildEmojiGrid(emojiIds));
            }

            scroll.addView(body, new ScrollView.LayoutParams(
							   ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            return scroll;
        }

        private View buildPhrasesPage() {
            ScrollView scroll = new ScrollView(activity);
            scroll.setFillViewport(true);

            LinearLayout body = new LinearLayout(activity);
            body.setOrientation(LinearLayout.VERTICAL);

            TextView caption = new DigitTextView(activity);
            caption.setText("Словарь фраз");
            styleText(caption, typeface, 12f, palette.hintText);
            caption.setPadding(0, 0, 0, dp(activity, 8));
            body.addView(caption);

            TextView addButton = createActionKey("Добавить из поля", new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						addPhraseFromField();
						refreshPhraseChips();
					}
				});
            LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            addLp.bottomMargin = dp(activity, 8);
            body.addView(addButton, addLp);

            phrasesContainer = new LinearLayout(activity);
            phrasesContainer.setOrientation(LinearLayout.VERTICAL);
            body.addView(phrasesContainer);

            refreshPhraseChips();

            scroll.addView(body, new ScrollView.LayoutParams(
							   ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            return scroll;
        }

        private View buildFallbackEmojiGrid() {
            LinearLayout grid = new LinearLayout(activity);
            grid.setOrientation(LinearLayout.VERTICAL);

            String[][] rows = new String[][]{
                {"🙂", "🪐", "✨", "🌌"},
                {"📝", "📌", "💫", "🚀"},
                {"🌠", "🧠", "🧭", "🌙"}
            };

            for (int i = 0; i < rows.length; i++) {
                grid.addView(buildTextEmojiRow(rows[i]));
            }
            return grid;
        }

        private View buildTextEmojiRow(String[] emojis) {
            LinearLayout row = new LinearLayout(activity);
            row.setOrientation(LinearLayout.HORIZONTAL);

            for (int i = 0; i < emojis.length; i++) {
                row.addView(createEmojiTextButton(emojis[i]), weightedKeyLp(activity, 1f));
            }
            return row;
        }

        private View buildEmojiGrid(List<Integer> emojiIds) {
            LinearLayout grid = new LinearLayout(activity);
            grid.setOrientation(LinearLayout.VERTICAL);

            int index = 0;
            while (index < emojiIds.size()) {
                LinearLayout row = new LinearLayout(activity);
                row.setOrientation(LinearLayout.HORIZONTAL);

                for (int col = 0; col < 4 && index < emojiIds.size(); col++) {
                    row.addView(createEmojiImageButton(emojiIds.get(index).intValue()), weightedKeyLp(activity, 1f));
                    index++;
                }
                grid.addView(row);
            }
            return grid;
        }

        private View buildLetterRow(String[] labels) {
            LinearLayout row = new LinearLayout(activity);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, dp(activity, 4), 0, 0);

            for (int i = 0; i < labels.length; i++) {
                row.addView(createLetterKey(labels[i]), weightedKeyLp(activity, 1f));
            }
            return row;
        }

        private TextView createTab(String label, int fillColor, int textColor) {
            TextView tab = new DigitTextView(activity);
            tab.setText(label);
            styleText(tab, typeface, 12.5f, textColor);
            tab.setGravity(Gravity.CENTER);
            tab.setPadding(dp(activity, 12), dp(activity, 8), dp(activity, 12), dp(activity, 8));
            tab.setBackground(makeRounded(fillColor, palette.keyStroke, activity));
            tab.setClickable(true);
            tab.setFocusable(true);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.leftMargin = dp(activity, 6);
            tab.setLayoutParams(lp);
            return tab;
        }

        private TextView createLetterKey(final String label) {
            return createActionKey(label, new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						insertText(label);
					}
				});
        }

        private TextView createActionKey(final String label, View.OnClickListener clickListener) {
            TextView key = new DigitTextView(activity);
            key.setText(label);
            styleText(key, typeface, 13.5f, palette.keyText);
            key.setGravity(Gravity.CENTER);
            key.setPadding(dp(activity, 10), dp(activity, 10), dp(activity, 10), dp(activity, 10));
            key.setMinHeight(dp(activity, 42));
            key.setBackground(makeRounded(palette.keyBg, palette.keyStroke, activity));
            key.setClickable(true);
            key.setFocusable(true);
            key.setOnClickListener(clickListener);
            return key;
        }

        private TextView createEmojiTextButton(final String emoji) {
            TextView key = new DigitTextView(activity);
            key.setText(emoji);
            styleText(key, typeface, 17f, palette.keyText);
            key.setGravity(Gravity.CENTER);
            key.setPadding(dp(activity, 8), dp(activity, 8), dp(activity, 8), dp(activity, 8));
            key.setMinHeight(dp(activity, 42));
            key.setBackground(makeRounded(palette.keyBgSoft, palette.keyStroke, activity));
            key.setClickable(true);
            key.setFocusable(true);
            key.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						insertText(emoji);
					}
				});
            return key;
        }

        private View createEmojiImageButton(final int resId) {
            FrameLayout key = new FrameLayout(activity);
            key.setBackground(makeRounded(palette.keyBgSoft, palette.keyStroke, activity));
            key.setPadding(dp(activity, 8), dp(activity, 8), dp(activity, 8), dp(activity, 8));
            key.setClickable(true);
            key.setFocusable(true);

            ImageView icon = new ImageView(activity);
            icon.setImageResource(resId);
            icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(dp(activity, 28), dp(activity, 28));
            iconLp.gravity = Gravity.CENTER;
            key.addView(icon, iconLp);

            key.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						insertEmojiLabel(resId);
					}
				});
            return key;
        }

        private void insertEmojiLabel(int resId) {
            String label = resourceEntryName(activity, resId);
            if (label == null || label.trim().isEmpty()) {
                label = "emoji";
            }
            insertText("[" + label + "]");
            status.setText("Эмодзи вставлена");
        }

        private void setMode(int newMode) {
            mode = newMode;

            boolean system = mode == MODE_SYSTEM;
            lettersPage.setVisibility(mode == MODE_LETTERS ? View.VISIBLE : View.GONE);
            emojiPage.setVisibility(mode == MODE_EMOJI ? View.VISIBLE : View.GONE);
            phrasesPage.setVisibility(mode == MODE_PHRASES ? View.VISIBLE : View.GONE);
            systemHint.setVisibility(system ? View.VISIBLE : View.GONE);

            titleField.setShowSoftInputOnFocus(system);
            contentField.setShowSoftInputOnFocus(system);

            updateTab(lettersTab, mode == MODE_LETTERS, palette.accent, palette.panelBg);
            updateTab(emojiTab, mode == MODE_EMOJI, palette.accent, palette.keyBgSoft);
            updateTab(phrasesTab, mode == MODE_PHRASES, palette.accent, palette.keyBgSoft);
            updateTab(systemTab, system, palette.accentSoft, palette.keyBgSoft);

            if (system) {
                showSystemKeyboard();
            } else {
                hideSystemKeyboard();
                status.setText(mode == MODE_LETTERS ? "Клавиатура" : "Кастомная клавиатура");
            }
        }

        private void updateTab(TextView tab, boolean selected, int selectedFill, int normalFill) {
            if (tab == null) return;
            tab.setBackground(makeRounded(selected ? selectedFill : normalFill, palette.keyStroke, activity));
        }

        private void showSystemKeyboard() {
            EditText field = currentField();
            if (field == null) return;
            field.requestFocus();
            InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.showSoftInput(field, InputMethodManager.SHOW_IMPLICIT);
            }
            status.setText("Нативная клавиатура включена");
        }

        private void hideSystemKeyboard() {
            View focused = activity.getCurrentFocus();
            InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null && focused != null) {
                imm.hideSoftInputFromWindow(focused.getWindowToken(), 0);
            }
        }

        private EditText currentField() {
            if (activeFieldHolder != null && activeFieldHolder.length > 0 && activeFieldHolder[0] != null) {
                return activeFieldHolder[0];
            }
            return contentField;
        }

        private void insertText(String text) {
            EditText field = currentField();
            if (field == null || text == null) return;
            Editable editable = field.getText();
            if (editable == null) return;

            int start = field.getSelectionStart();
            int end = field.getSelectionEnd();
            if (start < 0 || end < 0) {
                editable.append(text);
                field.setSelection(editable.length());
            } else {
                int min = Math.min(start, end);
                int max = Math.max(start, end);
                editable.replace(min, max, text);
                field.setSelection(min + text.length());
            }
            field.requestFocus();
        }

        private void deleteBackward() {
            EditText field = currentField();
            if (field == null) return;
            Editable editable = field.getText();
            if (editable == null) return;

            int start = field.getSelectionStart();
            int end = field.getSelectionEnd();
            if (start < 0 || end < 0) return;

            int min = Math.min(start, end);
            int max = Math.max(start, end);

            if (min != max) {
                editable.delete(min, max);
                field.setSelection(min);
            } else if (min > 0) {
                editable.delete(min - 1, min);
                field.setSelection(min - 1);
            }
            field.requestFocus();
        }

        private void handleEnter() {
            EditText field = currentField();
            if (field == null) return;
            if (field == titleField) {
                contentField.requestFocus();
                if (activeFieldHolder != null && activeFieldHolder.length > 0) {
                    activeFieldHolder[0] = contentField;
                }
                status.setText("Переход в заметку");
            } else {
                insertText("\n");
            }
        }

        private void copyCurrentSelectionOrText() {
            EditText field = currentField();
            if (field == null) return;

            String text = selectedText(field);
            if (text == null || text.trim().isEmpty()) {
                text = safeText(field.getText());
            }
            if (text == null || text.trim().isEmpty()) {
                status.setText("Нечего копировать");
                return;
            }

            ClipboardManager cm = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("cosmic_note", text));
                status.setText("Скопировано");
            }
        }

        private void pasteClipboard() {
            ClipboardManager cm = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip()) {
                status.setText("Буфер пуст");
                return;
            }

            ClipData clip = cm.getPrimaryClip();
            if (clip == null || clip.getItemCount() == 0) {
                status.setText("Буфер пуст");
                return;
            }

            CharSequence pasted = clip.getItemAt(0).coerceToText(activity);
            if (pasted == null) {
                status.setText("Буфер пуст");
                return;
            }

            insertText(pasted.toString());
            status.setText("Вставлено");
        }

        private void addPhraseFromField() {
            EditText field = currentField();
            if (field == null) return;

            String phrase = selectedText(field);
            if (phrase == null || phrase.trim().isEmpty()) {
                phrase = safeText(field.getText());
            }
            if (phrase == null || phrase.trim().isEmpty()) {
                status.setText("Фраза пустая");
                return;
            }

            List<String> phrases = loadPhrases(activity);
            if (!phrases.contains(phrase)) {
                phrases.add(0, phrase);
                while (phrases.size() > MAX_PHRASES) {
                    phrases.remove(phrases.size() - 1);
                }
                savePhrases(activity, phrases);
                status.setText("Фраза добавлена в словарь");
            } else {
                status.setText("Фраза уже есть");
            }
        }

        private void refreshPhraseChips() {
            phrasesContainer.removeAllViews();

            List<String> phrases = loadPhrases(activity);
            if (phrases.isEmpty()) {
                TextView empty = new DigitTextView(activity);
                empty.setText("Пока пусто. Добавь фразу из заметки.");
                styleText(empty, typeface, 12.5f, palette.hintText);
                empty.setPadding(0, dp(activity, 8), 0, dp(activity, 4));
                phrasesContainer.addView(empty);
                return;
            }

            HorizontalScrollView scroll = new HorizontalScrollView(activity);
            scroll.setHorizontalScrollBarEnabled(false);

            LinearLayout row = new LinearLayout(activity);
            row.setOrientation(LinearLayout.HORIZONTAL);

            for (int i = 0; i < phrases.size(); i++) {
                final String phrase = phrases.get(i);
                TextView chip = createPhraseChip(phrase);
                row.addView(chip);
            }

            scroll.addView(row, new HorizontalScrollView.LayoutParams(
							   ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            phrasesContainer.addView(scroll);
        }

        private TextView createPhraseChip(final String phrase) {
            TextView chip = new DigitTextView(activity);
            chip.setText(shortenPhrase(phrase));
            styleText(chip, typeface, 12.5f, palette.chipText);
            chip.setPadding(dp(activity, 12), dp(activity, 8), dp(activity, 12), dp(activity, 8));
            chip.setGravity(Gravity.CENTER);
            chip.setBackground(makeRounded(palette.keyBgSoft, palette.chipStroke, activity));
            chip.setClickable(true);
            chip.setFocusable(true);
            chip.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						insertText(phrase);
						status.setText("Фраза вставлена");
					}
				});

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = dp(activity, 8);
            lp.bottomMargin = dp(activity, 8);
            chip.setLayoutParams(lp);
            return chip;
        }

        private String shortenPhrase(String phrase) {
            if (phrase == null) return "";
            String clean = phrase.trim().replace('\n', ' ');
            if (clean.length() <= 24) return clean;
            return clean.substring(0, 24) + "…";
        }
    }

    private static KeyboardPalette resolvePalette(Context context) {
        boolean dark = (context.getResources().getConfiguration().uiMode
            & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;

        if (dark) {
            return new KeyboardPalette(
                Color.parseColor("#8A786C"),
                Color.parseColor("#6D5D53"),
                Color.parseColor("#5B4C42"),
                Color.parseColor("#706055"),
                Color.parseColor("#8B776A"),
                Color.parseColor("#F2ECE6"),
                Color.parseColor("#D18B61"),
                Color.parseColor("#8D7767"),
                Color.parseColor("#E3D8CD"),
                Color.parseColor("#F1ECE6"),
                Color.parseColor("#8C786A")
            );
        }

        return new KeyboardPalette(
            Color.parseColor("#F4E6DA"),
            Color.parseColor("#EFE0D1"),
            Color.parseColor("#F8EEE1"),
            Color.parseColor("#F1E2D1"),
            Color.parseColor("#C7A58F"),
            Color.parseColor("#4E3B31"),
            Color.parseColor("#D58B5A"),
            Color.parseColor("#E2C9B5"),
            Color.parseColor("#8A786C"),
            Color.parseColor("#5A463B"),
            Color.parseColor("#D2B39C")
        );
    }

    private static void styleText(TextView tv, Typeface typeface, float sizeSp, int color) {
        tv.setTextColor(color);
        tv.setTextSize(sizeSp);
        if (typeface != null) {
            tv.setTypeface(typeface);
        }
    }

    private static List<String> loadPhrases(Context context) {
        List<String> phrases = new ArrayList<String>();
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = prefs.getString(PREF_PHRASES, null);
        if (raw == null || raw.trim().isEmpty()) {
            return phrases;
        }

        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                String value = arr.optString(i, "").trim();
                if (!value.isEmpty() && !phrases.contains(value)) {
                    phrases.add(value);
                }
            }
        } catch (Throwable ignored) {
        }
        return phrases;
    }

    private static void savePhrases(Context context, List<String> phrases) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        JSONArray arr = new JSONArray();
        if (phrases != null) {
            for (int i = 0; i < phrases.size(); i++) {
                String value = phrases.get(i);
                if (value != null && !value.trim().isEmpty()) {
                    arr.put(value);
                }
            }
        }
        prefs.edit().putString(PREF_PHRASES, arr.toString()).apply();
    }

    private static List<Integer> collectEmojiDrawables(final Context context) {
        List<Integer> result = new ArrayList<Integer>();
        Field[] fields = R.drawable.class.getFields();
        for (int i = 0; i < fields.length; i++) {
            Field field = fields[i];
            String name = field.getName();
            if (name == null) continue;
            String lower = name.toLowerCase(Locale.US);
            if (lower.contains("emoji")) {
                try {
                    result.add(Integer.valueOf(field.getInt(null)));
                } catch (Throwable ignored) {
                }
            }
        }

        Collections.sort(result, new Comparator<Integer>() {
				@Override
				public int compare(Integer a, Integer b) {
					String nameA = resourceEntryName(context, a.intValue());
					String nameB = resourceEntryName(context, b.intValue());
					if (nameA == null) nameA = "";
					if (nameB == null) nameB = "";
					return nameA.compareToIgnoreCase(nameB);
				}
			});
        return result;
    }

    private static String resourceEntryName(Context context, int resId) {
        try {
            return context.getResources().getResourceEntryName(resId);
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static String selectedText(EditText field) {
        if (field == null) return "";
        Editable editable = field.getText();
        if (editable == null) return "";
        int start = field.getSelectionStart();
        int end = field.getSelectionEnd();
        if (start < 0 || end < 0 || start == end) {
            return "";
        }
        int min = Math.min(start, end);
        int max = Math.max(start, end);
        return editable.subSequence(min, max).toString();
    }

    private static String safeText(CharSequence text) {
        return text == null ? "" : text.toString();
    }

    private static LinearLayout.LayoutParams weightedKeyLp(Context context, float weight) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        lp.leftMargin = dp(context, 2);
        lp.rightMargin = dp(context, 2);
        return lp;
    }

    private static FrameLayout.LayoutParams matchParentLp() {
        return new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        );
    }

    private static int dp(Context context, float value) {
        return (int) (value * context.getResources().getDisplayMetrics().density + 0.5f);
    }

    private static GradientDrawable makeRounded(int fillColor, int strokeColor, Context context) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(dp(context, 18));
        gd.setColor(fillColor);
        gd.setStroke(dp(context, 1), strokeColor);
        return gd;
    }
}

