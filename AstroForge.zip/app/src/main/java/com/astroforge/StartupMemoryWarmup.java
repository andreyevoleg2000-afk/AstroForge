package com.astroforge;

import android.util.Log;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Грубый startup pre-touch: реально записывает в выделяемые страницы памяти.
 *
 * Это НЕ способ «заблокировать» RAM за процессом после освобождения ссылки:
 * ART/ОС не дают Java-коду такой гарантии. После очистки ссылок буфер может
 * быть освобождён/перераспределён. Класс сознательно делает именно короткий
 * transient pre-touch, чтобы не превращать запуск в гарантированный OOM.
 */
public final class StartupMemoryWarmup {
    private static final String TAG = "AstroForgeMem";

    // Меняйте здесь под устройство. 24 MB — безопасный стартовый вариант.
    private static final int PRETOUCH_MB = 24;
    private static final int PAGE_SIZE = 4096;
    private static final byte FILL_VALUE = (byte) 0xA5;

    private StartupMemoryWarmup() {
    }

    public static void preTouch() {
        int targetBytes = PRETOUCH_MB * 1024 * 1024;

        // Не забираем слишком большую долю heap/native budget.
        long maxRuntime = Runtime.getRuntime().maxMemory();
        long safetyCap = Math.max(4L * 1024 * 1024, maxRuntime / 20L);
        targetBytes = (int) Math.min(targetBytes, safetyCap);

        ByteBuffer buffer = null;
        long started = System.nanoTime();
        long touched = 0L;

        try {
            buffer = ByteBuffer.allocateDirect(targetBytes)
                    .order(ByteOrder.nativeOrder());

            // Пишем по каждой странице, чтобы lazy allocation действительно
            // затронула физические/OS-backed страницы, а не только виртуальный диапазон.
            for (int offset = 0; offset < targetBytes; offset += PAGE_SIZE) {
                buffer.put(offset, FILL_VALUE);
                touched++;
            }

            // Несколько точек в конце тоже читаем, чтобы компилятор не мог
            // трактовать операцию как полностью мёртвую.
            int last = Math.max(0, targetBytes - 1);
            int mid = Math.max(0, targetBytes / 2);
            int checksum = buffer.get(0) + buffer.get(mid) + buffer.get(last);
            Log.i(TAG, "Pre-touch touched=" + touched + " pages, bytes="
                    + targetBytes + ", checksum=" + checksum);
        } catch (OutOfMemoryError oom) {
            Log.w(TAG, "Pre-touch skipped because native memory allocation failed", oom);
        } finally {
            // Ссылку очищаем сразу. Нельзя честно гарантировать, что после этого
            // память останется физически закреплена за процессом.
            buffer = null;
        }

        long elapsedMs = (System.nanoTime() - started) / 1_000_000L;
        Log.i(TAG, "Pre-touch finished in " + elapsedMs + "ms");
    }
}
