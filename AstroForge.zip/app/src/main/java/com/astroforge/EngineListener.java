package com.astroforge;

public interface EngineListener {

    void onStatus(String message);

    void onFinished(String message);

    void onError(String message);
}
