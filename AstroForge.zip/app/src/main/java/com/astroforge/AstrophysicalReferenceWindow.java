package com.astroforge;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/**
 * Полноценное окно встроенного астрофизического справочника.
 * Контент читается из assets/astrophysical_reference.txt.
 */
final class AstrophysicalReferenceWindow {

    private static final String TAG = "AstroForgeReference";

    private static final int COLOR_DARK_PANEL = Color.parseColor("#2F2F2F");
    private static final int COLOR_DARK_BAR = Color.parseColor("#242424");
    private static final int COLOR_DARK_BORDER = Color.parseColor("#404040");
    private static final int COLOR_TEXT_NEAR_WHITE = Color.parseColor("#E3E1DE");
    private static final int COLOR_MUTED = Color.parseColor("#B8B5B0");
    private static final int COLOR_ACCENT = Color.parseColor("#D58B5A");
    private static final int COLOR_FORMULA = Color.parseColor("#282828");
    private static final int COLOR_TABLE_HEADER = Color.parseColor("#383838");

    private final Activity activity;
    private final ViewGroup root;
    private final Runnable onClosed;
    private final Typeface typeface;

    private FrameLayout overlay;
    private boolean closing;

    AstrophysicalReferenceWindow(
            Activity activity,
            ViewGroup root,
            Typeface typeface,
            Runnable onClosed
    ) {
        this.activity = activity;
        this.root = root;
        this.typeface = typeface != null ? typeface : Typeface.SERIF;
        this.onClosed = onClosed;
    }

    void show() {
        if (overlay != null || root == null) {
            return;
        }

        overlay = new FrameLayout(activity);
        overlay.setBackgroundColor(Color.argb(155, 0, 0, 0));
        overlay.setClickable(true);
        overlay.setFocusable(true);

        LinearLayout window = new LinearLayout(activity);
        window.setOrientation(LinearLayout.VERTICAL);
        window.setBackground(round(28, COLOR_DARK_BAR, COLOR_DARK_BORDER));
        window.setClipToOutline(true);
        window.setElevation(dp(18));

        FrameLayout.LayoutParams windowLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        );
        windowLp.gravity = Gravity.CENTER;
        windowLp.setMargins(dp(10), dp(18), dp(10), dp(18));
        overlay.addView(window, windowLp);

        window.addView(
                createHeader(),
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dp(86)
                )
        );

        View divider = new View(activity);
        divider.setBackgroundColor(COLOR_DARK_BORDER);
        window.addView(
                divider,
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dp(1)
                )
        );

        ScrollView scroll = new ScrollView(activity);
        scroll.setFillViewport(false);
        scroll.setClipToPadding(false);
        scroll.setPadding(0, dp(6), 0, dp(20));

        LinearLayout content = new LinearLayout(activity);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(10), dp(18), dp(24));
        buildContent(content);

        scroll.addView(
                content,
                new ScrollView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                )
        );

        window.addView(
                scroll,
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        0,
                        1f
                )
        );

        root.addView(overlay, fullScreenLp());
        overlay.bringToFront();

        overlay.setAlpha(0f);
        window.setScaleX(0.985f);
        window.setScaleY(0.985f);

        overlay.animate().alpha(1f).setDuration(220).start();
        window.animate().scaleX(1f).scaleY(1f).setDuration(260).start();
    }

    void close() {
        if (overlay == null || closing) {
            return;
        }

        closing = true;
        final FrameLayout current = overlay;

        current.animate()
                .alpha(0f)
                .setDuration(180)
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        if (root != null && current.getParent() == root) {
                            root.removeView(current);
                        }

                        overlay = null;
                        closing = false;

                        if (onClosed != null) {
                            onClosed.run();
                        }
                    }
                })
                .start();
    }

    boolean isOpen() {
        return overlay != null;
    }

    private LinearLayout createHeader() {
        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(10), dp(10), dp(14), dp(8));

        TextView back = text("‹", 36);
        back.setGravity(Gravity.CENTER);
        back.setTextColor(COLOR_TEXT_NEAR_WHITE);
        back.setContentDescription("Назад");
        back.setBackground(round(18, COLOR_DARK_PANEL, Color.TRANSPARENT));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                close();
            }
        });
        addRipple(back);

        header.addView(
                back,
                new LinearLayout.LayoutParams(dp(54), dp(58))
        );

        LinearLayout titles = new LinearLayout(activity);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setGravity(Gravity.CENTER_VERTICAL);
        titles.setPadding(dp(12), 0, 0, 0);

        TextView title = text("Астрофизический справочник", 19);
        title.setTypeface(typeface, Typeface.BOLD);
        titles.addView(title);

        TextView subtitle = text(
                "Модели, формулы и область применимости",
                12
        );
        subtitle.setTextColor(COLOR_MUTED);
        titles.addView(
                subtitle,
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                )
        );

        header.addView(
                titles,
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        1f
                )
        );

        TextView badge = text("AUG 2026", 10);
        badge.setGravity(Gravity.CENTER);
        badge.setTextColor(COLOR_ACCENT);
        badge.setTypeface(typeface, Typeface.BOLD);
        badge.setBackground(
                round(
                        12,
                        Color.parseColor("#332C27"),
                        Color.parseColor("#614432")
                )
        );

        header.addView(
                badge,
                new LinearLayout.LayoutParams(dp(76), dp(32))
        );

        return header;
    }

    private void buildContent(LinearLayout content) {
        addIntroCard(content);

        String raw = loadRawText();
        String[] blocks = raw.split("\\n\\s*\\n");

        for (String block : blocks) {
            String s = block.trim();

            if (s.isEmpty()) {
                continue;
            }

            if (s.startsWith("[[TABLE:")) {
                addTable(content, parseTableIndex(s));
            } else if (isMainHeading(s)) {
                addHeading(content, s, true);
            } else if (isSubHeading(s)) {
                addHeading(content, s, false);
            } else if (s.startsWith("• ")) {
                addBullet(content, s.substring(2));
            } else if (isFormula(s)) {
                addFormula(content, s);
            } else {
                addParagraph(content, s);
            }
        }

        TextView footer = text(
                "AstroForge • встроенный справочник\n"
                        + "Источник: AstroForge_Astrophysical_Reference_Corrected.docx",
                10
        );
        footer.setTextColor(Color.parseColor("#888580"));
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(24), 0, 0);
        content.addView(footer);
    }

    private void addIntroCard(LinearLayout content) {
        LinearLayout card = new LinearLayout(activity);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(14));
        card.setBackground(round(20, COLOR_DARK_PANEL, COLOR_DARK_BORDER));

        TextView kicker = text("ТЕХНИЧЕСКОЕ ИЗДАНИЕ", 10);
        kicker.setTextColor(COLOR_ACCENT);
        kicker.setTypeface(typeface, Typeface.BOLD);
        card.addView(kicker);

        TextView title = text("АСТРОФИЗИЧЕСКИЙ СПРАВОЧНИК", 22);
        title.setTypeface(typeface, Typeface.BOLD);
        title.setPadding(0, dp(4), 0, dp(4));
        card.addView(title);

        TextView desc = text(
                "Методики расчётов, физические модели и формулы.\n"
                        + "Скорость объектов • HZ • ESI • астробиология • гравитация • "
                        + "N-body • PN • предел Роша • атмосфера • магнитное поле • "
                        + "орбитальный период.",
                12
        );
        desc.setTextColor(COLOR_MUTED);
        card.addView(desc);

        content.addView(
                card,
                marginLp(dp(10), dp(12), dp(0), dp(18))
        );
    }

    private void addHeading(
            LinearLayout content,
            String value,
            boolean major
    ) {
        TextView tv = text(value, major ? 18 : 14);
        tv.setTypeface(typeface, Typeface.BOLD);
        tv.setTextColor(
                major ? COLOR_TEXT_NEAR_WHITE : COLOR_ACCENT
        );
        tv.setPadding(
                major ? 0 : dp(2),
                major ? dp(16) : dp(9),
                0,
                dp(5)
        );
        content.addView(
                tv,
                marginLp(
                        0,
                        major ? dp(14) : dp(7),
                        0,
                        0
                )
        );

        if (major) {
            View line = new View(activity);
            line.setBackgroundColor(COLOR_DARK_BORDER);
            content.addView(
                    line,
                    new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            dp(1)
                    )
            );
        }
    }

    private void addParagraph(LinearLayout content, String value) {
        TextView tv = text(value, 13);
        tv.setTextColor(COLOR_TEXT_NEAR_WHITE);
        tv.setLineSpacing(0f, 1.12f);
        content.addView(
                tv,
                marginLp(0, dp(5), 0, dp(5))
        );
    }

    private void addBullet(LinearLayout content, String value) {
        TextView tv = text("•  " + value, 13);
        tv.setTextColor(COLOR_TEXT_NEAR_WHITE);
        tv.setLineSpacing(0f, 1.1f);
        tv.setPadding(dp(4), dp(2), 0, dp(2));
        content.addView(
                tv,
                marginLp(0, dp(2), 0, dp(2))
        );
    }

    private void addFormula(LinearLayout content, String value) {
        TextView tv = text(value, 14);
        tv.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        tv.setTextColor(Color.parseColor("#F0E9E1"));
        tv.setGravity(Gravity.CENTER_VERTICAL);
        tv.setPadding(dp(14), dp(11), dp(14), dp(11));
        tv.setInputType(
                InputType.TYPE_CLASS_TEXT
                        | InputType.TYPE_TEXT_FLAG_MULTI_LINE
        );
        tv.setBackground(round(16, COLOR_FORMULA, COLOR_DARK_BORDER));

        content.addView(
                tv,
                marginLp(0, dp(6), 0, dp(8))
        );
    }

    private void addTable(LinearLayout content, int index) {
        String[][] rows = table(index);

        if (rows == null || rows.length == 0) {
            return;
        }

        HorizontalScrollView horizontal =
                new HorizontalScrollView(activity);
        horizontal.setHorizontalScrollBarEnabled(false);

        LinearLayout table = new LinearLayout(activity);
        table.setOrientation(LinearLayout.VERTICAL);
        table.setBackground(round(16, COLOR_FORMULA, COLOR_DARK_BORDER));
        table.setPadding(dp(1), dp(1), dp(1), dp(1));

        for (int r = 0; r < rows.length; r++) {
            LinearLayout row = new LinearLayout(activity);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setBackgroundColor(
                    r == 0
                            ? COLOR_TABLE_HEADER
                            : Color.TRANSPARENT
            );

            for (String cell : rows[r]) {
                TextView tv = text(cell, 11);
                tv.setTypeface(
                        typeface,
                        r == 0 ? Typeface.BOLD : Typeface.NORMAL
                );
                tv.setTextColor(
                        r == 0
                                ? COLOR_TEXT_NEAR_WHITE
                                : COLOR_MUTED
                );
                tv.setGravity(Gravity.CENTER_VERTICAL);
                tv.setPadding(dp(10), dp(9), dp(10), dp(9));

                row.addView(
                        tv,
                        new LinearLayout.LayoutParams(
                                dp(150),
                                ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                );
            }

            table.addView(
                    row,
                    new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                    )
            );
        }

        horizontal.addView(table);
        content.addView(
                horizontal,
                marginLp(0, dp(8), 0, dp(12))
        );
    }

    private String loadRawText() {
        StringBuilder sb = new StringBuilder();

        try {
            InputStream in = activity.getAssets().open("astrophysical_reference.txt");
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(in, StandardCharsets.UTF_8)
            );

            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append('\n');
                }
                return sb.toString();
            } finally {
                reader.close();
            }
        } catch (Exception assetError) {
            android.util.Log.e(
                    TAG,
                    "Не удалось открыть справочник из assets",
                    assetError
            );
            return "Не удалось загрузить содержимое справочника.";
        }
    }

    private int parseTableIndex(String marker) {
        try {
            int start = marker.indexOf(':') + 1;
            int end = marker.indexOf(']');

            if (start <= 0 || end <= start) {
                return -1;
            }

            return Integer.parseInt(
                    marker.substring(start, end).trim()
            );
        } catch (RuntimeException ignored) {
            return -1;
        }
    }

    private String[][] table(int index) {
        switch (index) {
            case 0:
                return new String[][]{
                        {"Величина", "Обозначение", "Значение"},
                        {"Гравитационная постоянная", "G", "6,67430 × 10⁻¹¹ м³·кг⁻¹·с⁻²"},
                        {"Скорость света", "c", "299 792 458 м/с (точно в SI)"},
                        {"Масса Земли", "M⊕", "≈ 5,9722 × 10²⁴ кг"},
                        {"Средний радиус Земли", "R⊕", "≈ 6 371 км"},
                        {"Солнечная постоянная", "S⊕", "≈ 1 361 Вт/м²"},
                        {"Астрономическая единица", "AU", "149 597 870 700 м (точно)"}
                };

            case 1:
                return new String[][]{
                        {"Граница", "Смысл", "≈ расстояние для Солнца"},
                        {"Recent Venus", "Оптимистичная внутренняя граница", "0,75 AU"},
                        {"Runaway Greenhouse", "Консервативная внутренняя граница", "0,97 AU"},
                        {"Moist Greenhouse", "Дополнительный внутренний диагностический предел", "0,99 AU"},
                        {"Maximum Greenhouse", "Консервативная внешняя граница", "1,70 AU"},
                        {"Early Mars", "Оптимистичная внешняя граница", "1,77 AU"}
                };

            case 2:
                return new String[][]{
                        {"Параметр", "Эталон", "Вес w"},
                        {"Радиус", "1 R⊕", "0,57"},
                        {"Средняя плотность", "1 ρ⊕", "1,07"},
                        {"Скорость убегания", "1 v_esc,⊕", "0,70"},
                        {"Температура поверхности", "288 K", "5,58"}
                };

            case 3:
                return new String[][]{
                        {"Класс", "Ориентировочная средняя плотность", "Пример"},
                        {"Землеподобное каменистое тело", "≈ 5–6 г/см³", "Земля ≈ 5,51 г/см³"},
                        {"Марсоподобное каменистое тело", "≈ 3,5–4,0 г/см³", "Марс ≈ 3,93 г/см³"},
                        {"Ледяное тело", "примерно 1–3 г/см³, зависит от доли пород", "Европа ≈ 3,01 г/см³"},
                        {"Газовый гигант", "≈ 0,7–1,7 г/см³", "Юпитер ≈ 1,33 г/см³"},
                        {"Ледяной гигант", "≈ 1,2–2 г/см³", "Нептун ≈ 1,64 г/см³"}
                };

            case 4:
                return new String[][]{
                        {"Модуль", "Базовая модель", "Что выводить пользователю"},
                        {"Скорость", "Two-body / vis-viva", "Скорость + система отсчёта + допущения"},
                        {"HZ", "Kopparapu 1D climate model", "Граница + выбранная климатическая модель"},
                        {"ESI", "ESI4 или ESI(S,R)", "Число + входные параметры + неопределённости"},
                        {"Астробиология", "Набор независимых диагностик", "Объяснение факторов, без «вероятности жизни»"},
                        {"Гравитация", "Newton N-body", "Состояние + масштаб шага + O(N²)"},
                        {"PN", "Pairwise approximation или full EIH", "Явное название модели"},
                        {"Roche", "Rigid + fluid limits", "Диапазон, а не точка разрушения"},
                        {"Атмосфера", "Teq + barometric + Jeans diagnostic", "λ_exo и применимость"},
                        {"Магнитное поле", "Dynamo scaling only with thermal inputs", "Неопределённость, а не ложная точность"},
                        {"Период", "Kepler two-body", "Сидерический период + масса системы"}
                };

            default:
                return null;
        }
    }

    private boolean isMainHeading(String value) {
        if (value.equals("Введение и область применимости")
                || value.equals("Источники")) {
            return true;
        }

        return value.matches("\\d+\\. [^\\n]+")
                && !value.matches("\\d+\\.\\d+\\. .+");
    }

    private boolean isSubHeading(String value) {
        return value.matches("\\d+\\.\\d+\\. .+");
    }

    private boolean isFormula(String value) {
        if (value.length() > 180) {
            return false;
        }

        return value.contains("=")
                && (
                value.contains("√")
                        || value.contains("²")
                        || value.contains("³")
                        || value.contains("⁴")
                        || value.contains("π")
                        || value.contains("Σ")
                        || value.contains("∫")
                        || value.contains("GM")
                        || value.contains("ESI")
                        || value.contains("T_eq")
                        || value.contains("Δφ")
        );
    }

    private TextView text(String value, float sizeSp) {
        TextView tv = new TextView(activity);
        tv.setText(value);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        tv.setTextColor(COLOR_TEXT_NEAR_WHITE);
        tv.setIncludeFontPadding(true);
        tv.setTypeface(typeface);
        return tv;
    }

    private GradientDrawable round(
            float radius,
            int fill,
            int stroke
    ) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(dp(radius));
        gd.setColor(fill);

        if (stroke != Color.TRANSPARENT) {
            gd.setStroke(dp(1), stroke);
        }

        return gd;
    }

    private void addRipple(View view) {
        try {
            TypedValue out = new TypedValue();
            activity.getTheme().resolveAttribute(
                    android.R.attr.selectableItemBackground,
                    out,
                    true
            );

            if (out.resourceId != 0) {
                view.setForeground(
                        activity.getDrawable(out.resourceId)
                );
            }
        } catch (RuntimeException ignored) {
            // Нажатие работает и без декоративного ripple.
        }

        view.setClickable(true);
        view.setFocusable(true);
    }

    private FrameLayout.LayoutParams fullScreenLp() {
        return new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        );
    }

    private LinearLayout.LayoutParams marginLp(
            int left,
            int top,
            int right,
            int bottom
    ) {
        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );
        lp.setMargins(left, top, right, bottom);
        return lp;
    }

    private int dp(float value) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                value,
                activity.getResources().getDisplayMetrics()
        );
    }
}
