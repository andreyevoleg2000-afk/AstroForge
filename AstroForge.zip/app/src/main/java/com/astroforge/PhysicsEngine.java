package com.astroforge;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Физическое ядро AstroForge.
 *
 * Этап 3 (точность на сверхдлинных промежутках без "бзыков"):
 * - основа = этап 2: шаг привязан к минимальному орбитальному периоду,
 *   массивы ускорений переиспользуются, история прорежена, порог столкновения = сумма радиусов;
 * - НОВОЕ: в историю пишется ТРИ величины: {t, мгновенная_скорость, средняя_характеристическая_скорость};
 *   средняя получается усреднением полной энергии по окну вывода и восстановлением v = sqrt(mu/a);
 *   благодаря симплектичности энергия осциллирует вокруг истины без дрейфа, поэтому на окне в
 *   миллион периодов усреднение даёт ровную физичную среднюю скорость — это убирает "бзыки" на
 *   миллиарде лет, не трогая идеальный короткий режим (там окно по-прежнему рисует мгновенную);
 * - диагностика: lastQuality / lastDtSeconds / lastStepsPerMinPeriod / lastSubSteps.
 *
 * Внешний интерфейс (simulate, Body, единицы, Orekit-мост) НЕ изменён.
 * Совместимость с AIDE: без лямбд, без var, без records, без подчёркиваний в числах.
 */
public final class PhysicsEngine {

    public static final double G = 6.67430e-11; // м³·кг⁻¹·с⁻²

    public static volatile String lastEngine = "legacy";
    public static volatile String lastOrekitError = null;

    // ----- Диагностика точности последнего расчёта -----
    public static volatile String lastQuality = "-";
    public static volatile double lastDtSeconds = 0.0;
    public static volatile double lastStepsPerMinPeriod = 0.0;
    public static volatile long lastSubSteps = 0L;

    // ----- Тюнинг legacy-интегратора -----
    private static final double STEPS_PER_PERIOD_TARGET = 400.0;
    private static final long MAX_SUBSTEPS = 15000000L;
    private static final int PROGRESS_TICKS = 200;
    private static final long HISTORY_POINTS = 1000L;

    // =========================================================
    //  Единицы измерения
    // =========================================================

    public enum MassUnit {
        KG     ("кг",      1.0),
        TONNE  ("т",       1.0e3),
        CERES  ("Церера",  9.3835e20),
        PLUTO  ("Плутон",  1.303e22),
        MOON   ("Луна",    7.342e22),
        EARTH  ("Земля",   5.972e24),
        NEPTUNE("Нептун",  1.024e26),
        JUPITER("Юпитер",  1.898e27),
        SUN    ("Солнце",  1.989e30);

        public final String label;
        private final double toKgFactor;

        MassUnit(String label, double toKgFactor) {
            this.label = label;
            this.toKgFactor = toKgFactor;
        }

        public double toKg(double value) {
            return value * toKgFactor;
        }
    }

    public enum DistanceUnit {
        METER       ("м",        1.0),
        KM          ("км",       1.0e3),
        EARTH_RADIUS("R Земли",  6.371e6),
        AU          ("а.е.",     1.496e11),
        LIGHT_YEAR  ("св. год",  9.461e15);

        public final String label;
        private final double toMeterFactor;

        DistanceUnit(String label, double toMeterFactor) {
            this.label = label;
            this.toMeterFactor = toMeterFactor;
        }

        public double toMeters(double value) {
            return value * toMeterFactor;
        }
    }

    public enum TimeUnit {
        SECOND("с",   1.0),
        MINUTE("мин", 60.0),
        HOUR  ("ч",   3600.0),
        DAY   ("дн.", 86400.0),
        YEAR  ("лет", 3.15576e7);

        public final String label;
        public final double seconds;

        TimeUnit(String label, double seconds) {
            this.label = label;
            this.seconds = seconds;
        }

        public double toSeconds(double value) {
            return value * seconds;
        }
    }

    // =========================================================
    //  Body
    // =========================================================

    public static final class Body {
        public final String name;
        public final double massKg;

        public double x, y;
        public double vx, vy;

        public boolean alive;

        public final double radiusM;
        public final double initialSpeedMs;

        // history entry = { time_s, instant_speed_ms, windowed_char_speed_ms }
        public final List<double[]> history;

        public Body(String name,
                    double massKg,
                    double x,
                    double y,
                    double vx,
                    double vy) {
            this.name = name;
            this.massKg = massKg;
            this.x = x;
            this.y = y;
            this.vx = vx;
            this.vy = vy;
            this.alive = true;
            this.initialSpeedMs = Math.sqrt(vx * vx + vy * vy);

            double density = 5500.0;
            this.radiusM = Math.cbrt(3.0 * massKg / (4.0 * Math.PI * density));

            this.history = new ArrayList<double[]>();
            // На старте средняя = мгновенной (орбита только задана).
            this.history.add(new double[]{0.0, this.initialSpeedMs, this.initialSpeedMs});
        }

        public double speed() {
            return Math.sqrt(vx * vx + vy * vy);
        }
    }

    // =========================================================
    //  Результаты
    // =========================================================

    public static final class OrbitalResult {
        public final double circularSpeedMs;
        public final double escapeSpeedMs;

        public OrbitalResult(double circularSpeedMs, double escapeSpeedMs) {
            this.circularSpeedMs = circularSpeedMs;
            this.escapeSpeedMs = escapeSpeedMs;
        }
    }

    public static final class SimulationResult {
        public final List<Body> bodies;

        public SimulationResult(List<Body> bodies) {
            this.bodies = bodies;
        }
    }

    // =========================================================
    //  Колбэки
    // =========================================================

    public interface ProgressCallback {
        void onProgress(int currentStep, int totalSteps);
    }

    public interface CancelToken {
        boolean isCancelled();
    }

    // =========================================================
    //  Опции Orekit
    // =========================================================

    public static final class OrekitOptions {
        public boolean useOrekit = true;
        public boolean fallbackToLegacy = true;
        public int centralBodyIndex = -1;
        public double centralMu = Double.NaN;
        public String frameName = "EME2000";
        public double integratorStepSeconds = 60.0;
    }

    // =========================================================
    //  Простой расчёт орбитальных скоростей
    // =========================================================

    public static OrbitalResult computeOrbitalSpeeds(double parentMassKg, double distanceM) {
        double circular = Math.sqrt(G * parentMassKg / distanceM);
        double escape = circular * Math.sqrt(2.0);
        return new OrbitalResult(circular, escape);
    }

    // =========================================================
    //  Публичный вход симуляции
    // =========================================================

    public static SimulationResult simulate(List<Body> bodies,
                                            double totalTimeSeconds,
                                            int steps,
                                            ProgressCallback progress,
                                            CancelToken cancel) {
        return simulate(bodies, totalTimeSeconds, steps, progress, cancel, new OrekitOptions());
    }

    public static SimulationResult simulate(List<Body> bodies,
                                            double totalTimeSeconds,
                                            int steps,
                                            ProgressCallback progress,
                                            CancelToken cancel,
                                            OrekitOptions options) {
        if (bodies == null || bodies.isEmpty()) {
            throw new IllegalArgumentException("Нет тел для симуляции.");
        }

        if (steps < 1) {
            steps = 1;
        }

        if (options == null) {
            options = new OrekitOptions();
        }

        if (options.useOrekit) {
            try {
                lastOrekitError = null;

                Class<?> bridge = Class.forName("com.astroforge.OrekitPhysics");

                Method m = bridge.getMethod(
					"simulate",
					List.class,
					double.class,
					int.class,
					ProgressCallback.class,
					CancelToken.class,
					OrekitOptions.class
                );

                Object result = m.invoke(null, bodies, totalTimeSeconds, steps, progress, cancel, options);

                if (result instanceof SimulationResult) {
                    lastEngine = "Orekit";
                    return (SimulationResult) result;
                }

                lastOrekitError = "Orekit bridge returned null result.";
            } catch (Throwable t) {
                Throwable cause = t;

                if (t instanceof InvocationTargetException) {
                    Throwable target = ((InvocationTargetException) t).getTargetException();
                    if (target != null) {
                        cause = target;
                    }
                }

                lastEngine = "legacy";
                lastOrekitError = String.valueOf(cause);

                if (!options.fallbackToLegacy) {
                    throw new RuntimeException("Orekit simulation failed: " + cause, cause);
                }
            }
        } else {
            lastEngine = "legacy";
        }

        return simulateLegacy(bodies, totalTimeSeconds, steps, progress, cancel);
    }

    // =========================================================
    //  Legacy-физика: шаг по периоду + усреднение энергии по окну вывода
    // =========================================================

    private static SimulationResult simulateLegacy(List<Body> bodies,
                                                   double totalTimeSeconds,
                                                   int steps,
                                                   ProgressCallback progress,
                                                   CancelToken cancel) {
        if (bodies == null || bodies.isEmpty()) {
            throw new IllegalArgumentException("Нет тел для симуляции.");
        }

        if (steps < 1) {
            steps = 1;
        }

        final int n = bodies.size();
        final double total = totalTimeSeconds > 0.0 ? totalTimeSeconds : 0.0;

        // Центральное тело = самое массивное.
        int centerIdx = 0;
        double maxM = -1.0;
        for (int i = 0; i < n; i++) {
            double m = bodies.get(i).massKg;
            if (m > maxM) {
                maxM = m;
                centerIdx = i;
            }
        }
        final Body center = bodies.get(centerIdx);
        final double muCenter = G * center.massKg;

        // Минимальный кеплеровский период среди не-центральных тел.
        double minPeriod = Double.POSITIVE_INFINITY;
        for (int i = 0; i < n; i++) {
            if (i == centerIdx) continue;

            Body b = bodies.get(i);
            double dx = b.x - center.x;
            double dy = b.y - center.y;
            double r = Math.sqrt(dx * dx + dy * dy);

            if (r > 0.0 && muCenter > 0.0) {
                double t = 2.0 * Math.PI * Math.sqrt((r * r * r) / muCenter);
                if (t > 0.0 && t < minPeriod) {
                    minPeriod = t;
                }
            }
        }

        // Выбор шага dt.
        double dt;
        if (minPeriod < Double.POSITIVE_INFINITY && minPeriod > 0.0) {
            dt = minPeriod / STEPS_PER_PERIOD_TARGET;
        } else {
            dt = total / (double) Math.max(60, steps);
        }

        if (dt <= 0.0 || Double.isInfinite(dt) || Double.isNaN(dt)) {
            dt = total / (double) Math.max(60, steps);
        }

        if (dt > total && total > 0.0) {
            dt = total;
        }

        long needSub = (dt > 0.0) ? (long) Math.ceil(total / dt) : 1L;
        if (needSub < 1L) needSub = 1L;

        if (needSub > MAX_SUBSTEPS) {
            dt = total / (double) MAX_SUBSTEPS;
            needSub = MAX_SUBSTEPS;
        }

        final long totalSub = needSub;

        double effStepsPerPeriod = (minPeriod < Double.POSITIVE_INFINITY && dt > 0.0)
			? (minPeriod / dt)
			: 0.0;

        int qualityCode;
        if (effStepsPerPeriod >= 100.0) {
            qualityCode = 0;
        } else if (effStepsPerPeriod >= 40.0) {
            qualityCode = 1;
        } else {
            qualityCode = 2;
        }

        lastDtSeconds = dt;
        lastStepsPerMinPeriod = effStepsPerPeriod;
        lastSubSteps = totalSub;
        lastQuality = (qualityCode == 0) ? "высокая"
			: (qualityCode == 1) ? "средняя"
			: "низкая (показана средняя скорость)";

        // Массивы ускорений — один раз.
        double[] ax = new double[n];
        double[] ay = new double[n];
        double[] axNew = new double[n];
        double[] ayNew = new double[n];

        computeAccelerations(bodies, ax, ay);

        // Аккумуляторы усреднения энергии по окну вывода (per body).
        double[] winESum = new double[n];
        long[] winECount = new long[n];

        // Сфера влияния.
        double maxInitDist = 0.0;
        for (int i = 0; i < n; i++) {
            Body b = bodies.get(i);
            double d = Math.sqrt(b.x * b.x + b.y * b.y);
            if (d > maxInitDist) maxInitDist = d;
        }
        double sphereOfInfluence = maxInitDist * 10.0;
        if (sphereOfInfluence < 1.0) sphereOfInfluence = 1.0e12;

        // Прогресс по времени.
        final double tickSize = (total > 0.0) ? (total / (double) PROGRESS_TICKS) : 0.0;
        int nextTick = 1;
        if (progress != null) {
            progress.onProgress(0, PROGRESS_TICKS);
        }

        final long historyInterval = Math.max(1L, totalSub / HISTORY_POINTS);

        final double halfDtSq = 0.5 * dt * dt;
        final double halfDt = 0.5 * dt;

        for (long sub = 1L; sub <= totalSub; sub++) {
            if ((sub & 1023L) == 0L) {
                if (cancel != null && cancel.isCancelled()) {
                    break;
                }
            }

            // Velocity Verlet: координаты.
            for (int i = 0; i < n; i++) {
                Body b = bodies.get(i);
                if (!b.alive) continue;
                b.x += b.vx * dt + ax[i] * halfDtSq;
                b.y += b.vy * dt + ay[i] * halfDtSq;
            }

            computeAccelerations(bodies, axNew, ayNew);

            // Velocity Verlet: скорости.
            for (int i = 0; i < n; i++) {
                Body b = bodies.get(i);
                if (!b.alive) continue;
                b.vx += (ax[i] + axNew[i]) * halfDt;
                b.vy += (ay[i] + ayNew[i]) * halfDt;
            }

            System.arraycopy(axNew, 0, ax, 0, n);
            System.arraycopy(ayNew, 0, ay, 0, n);

            final double t = sub * dt;

            // Накопление энергии относительно центра для усреднения по окну.
            if (muCenter > 0.0) {
                for (int i = 0; i < n; i++) {
                    Body b = bodies.get(i);
                    if (!b.alive) continue;

                    double dx = b.x - center.x;
                    double dy = b.y - center.y;
                    double r = Math.sqrt(dx * dx + dy * dy);
                    if (r <= 0.0) continue;

                    double dvx = b.vx - center.vx;
                    double dvy = b.vy - center.vy;
                    double v2 = dvx * dvx + dvy * dvy;

                    double e = 0.5 * v2 - muCenter / r;
                    winESum[i] += e;
                    winECount[i] += 1L;
                }
            }

            // Столкновения и выход за сферу влияния.
            for (int i = 0; i < n; i++) {
                Body bi = bodies.get(i);
                if (!bi.alive) continue;

                double distFromCenter = Math.sqrt(bi.x * bi.x + bi.y * bi.y);
                if (distFromCenter > sphereOfInfluence) {
                    bi.alive = false;
                    double sp = bi.speed();
                    bi.history.add(new double[]{t, sp, sp});
                    continue;
                }

                for (int j = i + 1; j < n; j++) {
                    Body bj = bodies.get(j);
                    if (!bj.alive) continue;

                    double dx = bi.x - bj.x;
                    double dy = bi.y - bj.y;
                    double dist = Math.sqrt(dx * dx + dy * dy);
                    double collisionThreshold = bi.radiusM + bj.radiusM;

                    if (dist < collisionThreshold) {
                        bi.alive = false;
                        bj.alive = false;
                        double spi = bi.speed();
                        double spj = bj.speed();
                        bi.history.add(new double[]{t, spi, spi});
                        bj.history.add(new double[]{t, spj, spj});
                    }
                }
            }

            // История — прореженно, с усреднённой характеристической скоростью.
            if (sub % historyInterval == 0L || sub == totalSub) {
                for (int i = 0; i < n; i++) {
                    Body b = bodies.get(i);
                    if (!b.alive) continue;

                    double instant = b.speed();
                    double vchar = instant;

                    if (winECount[i] > 0L && muCenter > 0.0) {
                        double eMean = winESum[i] / (double) winECount[i];
                        if (eMean < 0.0) {
                            double a = -muCenter / (2.0 * eMean);
                            if (a > 0.0) {
                                vchar = Math.sqrt(muCenter / a);
                            }
                        }
                    }

                    b.history.add(new double[]{t, instant, vchar});

                    winESum[i] = 0.0;
                    winECount[i] = 0L;
                }
            }

            // Прогресс.
            if (progress != null && tickSize > 0.0) {
                while (nextTick <= PROGRESS_TICKS && t >= nextTick * tickSize) {
                    progress.onProgress(nextTick, PROGRESS_TICKS);
                    nextTick++;
                }
            }
        }

        if (progress != null && nextTick <= PROGRESS_TICKS) {
            progress.onProgress(PROGRESS_TICKS, PROGRESS_TICKS);
        }

        return new SimulationResult(bodies);
    }

    /**
     * Гравитационные ускорения. Softening = 1 км.
     */
    private static void computeAccelerations(List<Body> bodies, double[] ax, double[] ay) {
        int n = bodies.size();

        for (int i = 0; i < n; i++) {
            ax[i] = 0.0;
            ay[i] = 0.0;
        }

        double softening2 = 1000.0 * 1000.0;

        for (int i = 0; i < n; i++) {
            Body bi = bodies.get(i);
            if (!bi.alive) continue;

            for (int j = i + 1; j < n; j++) {
                Body bj = bodies.get(j);
                if (!bj.alive) continue;

                double dx = bj.x - bi.x;
                double dy = bj.y - bi.y;

                double r2 = dx * dx + dy * dy + softening2;
                double r = Math.sqrt(r2);

                double f = G / (r2 * r);

                double fx = f * dx;
                double fy = f * dy;

                ax[i] += fx * bj.massKg;
                ay[i] += fy * bj.massKg;

                ax[j] -= fx * bi.massKg;
                ay[j] -= fy * bi.massKg;
            }
        }
    }

    // =========================================================
    //  Форматирование скорости
    // =========================================================

    public static String formatSpeed(double speedMs) {
        if (speedMs >= 1000.0) {
            return String.format(Locale.US, "%.3f км/с", speedMs / 1000.0);
        }
        return String.format(Locale.US, "%.2f м/с", speedMs);
    }

    private PhysicsEngine() {
        // utility
    }
}
