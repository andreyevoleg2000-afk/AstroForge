package com.astroforge;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.ColorSpace;
import android.graphics.RenderEffect;
import android.graphics.RuntimeShader;
import android.graphics.Shader;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;

import android.graphics.ImageDecoder;

/**
 * AstroForge color pipeline.
 *
 * Provides:
 *  - Display P3 decoding through ImageDecoder;
 *  - wide-color window configuration;
 *  - RenderEffect + AGSL color grading;
 *  - contrast, saturation, color gain and pseudo-HDR tone mapping.
 *
 * Requires Android 13 / API 33+, which matches the application's minSdk.
 */
public final class ColorPipeline {

    private ColorPipeline() {
        // Utility class.
    }

    /**
     * AGSL shader used by RenderEffect.
     *
     * The tone mapping is deliberately restrained: bright values are compressed
     * instead of simply clipping to white, while midtones receive more contrast.
     */
    private static final String COLOR_SHADER =
            "uniform shader input;" +
            "uniform float contrast;" +
            "uniform float saturation;" +
            "uniform float gain;" +
            "uniform float hdr;" +
            "" +
            "half4 main(float2 p) {" +
            "    half4 px = input.eval(p);" +
            "    half3 c = px.rgb;" +
            "" +
            "    // Exposure / color gain." +
            "    c *= half(gain);" +
            "" +
            "    // Pseudo-HDR: compress highlights instead of hard clipping." +
            "    half3 mapped = c / (half3(1.0) + c);" +
            "    c = mix(c, mapped, half(hdr));" +
            "" +
            "    // Luma-preserving saturation boost." +
            "    half luma = dot(c, half3(0.2126, 0.7152, 0.0722));" +
            "    half3 gray = half3(luma);" +
            "    c = mix(gray, c, half(saturation));" +
            "" +
            "    // Contrast around middle gray." +
            "    c = (c - half3(0.5)) * half(contrast) + half3(0.5);" +
            "" +
            "    c = clamp(c, half3(0.0), half3(1.0));" +
            "    return half4(c, px.a);" +
            "}";

    /**
     * Configures the Activity window for wide-color rendering.
     *
     * The numeric value 1 is Window's WIDE_COLOR_GAMUT mode. Using the numeric
     * value avoids compatibility problems with incomplete Android SDK stubs used
     * by some mobile IDEs, while the actual platform API remains the same.
     */
    public static void configureWideColorWindow(Window window) {
        if (window == null) {
            return;
        }

        try {
            window.setColorMode(1); // COLOR_MODE_WIDE_COLOR_GAMUT
        } catch (RuntimeException ignored) {
            // Devices without a wide-color display simply keep their normal mode.
        }
    }

    /**
     * Decodes a drawable resource directly into Display P3.
     *
     * The decoder callback is written as an explicit anonymous class instead of a
     * lambda so it works cleanly with older Java/Android IDE parsers as well.
     */
    public static void setP3Image(final ImageView imageView,
                                  final Activity activity,
                                  final int resourceId) {
        if (imageView == null || activity == null) {
            return;
        }

        try {
            ImageDecoder.Source source = ImageDecoder.createSource(
                    activity.getResources(), resourceId);

            Bitmap bitmap = ImageDecoder.decodeBitmap(
                    source,
                    new ImageDecoder.OnHeaderDecodedListener() {
                        @Override
                        public void onHeaderDecoded(ImageDecoder decoder,
                                                     ImageDecoder.ImageInfo info,
                                                     ImageDecoder.Source source) {
                            ColorSpace p3 = ColorSpace.get(
                                    ColorSpace.Named.DISPLAY_P3);

                            decoder.setTargetColorSpace(p3);
                            decoder.setAllocator(ImageDecoder.ALLOCATOR_HARDWARE);
                        }
                    });

            imageView.setImageBitmap(bitmap);
        } catch (Exception ignored) {
            // If decoding fails, fall back to the normal drawable resource.
            imageView.setImageResource(resourceId);
        }
    }

    /**
     * Creates the RenderEffect used for the main visual image.
     *
     * @param contrast contrast multiplier, 1.0 = neutral
     * @param saturation saturation multiplier, 1.0 = neutral
     * @param gain brightness/color gain, 1.0 = neutral
     * @param hdr pseudo-HDR amount, 0.0..1.0
     */
    public static RenderEffect createColorEffect(float contrast,
                                                  float saturation,
                                                  float gain,
                                                  float hdr) {
        RuntimeShader shader = new RuntimeShader(COLOR_SHADER);

        shader.setFloatUniform("contrast", contrast);
        shader.setFloatUniform("saturation", saturation);
        shader.setFloatUniform("gain", gain);
        shader.setFloatUniform("hdr", hdr);

        return RenderEffect.createRuntimeShaderEffect(shader, "input");
    }

    /**
     * Applies the default vivid Display-P3/pseudo-HDR grade to a View.
     */
    public static void applyVivid(View view) {
        if (view == null) {
            return;
        }

        view.setRenderEffect(createColorEffect(
                1.18f, // contrast
                1.28f, // saturation
                1.08f, // gain
                0.72f  // pseudo-HDR
        ));
    }

    /**
     * Removes the color effect from a View.
     */
    public static void clear(View view) {
        if (view != null) {
            view.setRenderEffect(null);
        }
    }
}
