package com.astroforge;

import java.util.ArrayList;
import java.util.Random;

/**
 * Вычислительное ядро магнитного поля (Закон масштабного соответствия Кристенсена).
 * Полностью реализовано на чистой Java (без JNI/C++), чтобы гарантированно 
 * работать в AIDE Plus без необходимости собирать нативные .so библиотеки.
 * 
 * Использует 64-битную точность (double) для сверхточных астрофизических вычислений.
 */
public final class MagneticEngine {

    // Магнитная постоянная (Гн/м)
    private static final double MU0 = 4.0e-7 * Math.PI;

    private MagneticEngine() {
        // Utility class
    }

    /**
     * Всегда возвращает true, так как движок теперь встроен в Java.
     * Метод оставлен для совместимости с MagneticFieldPanel.
     */
    public static boolean isNativeLoaded() {
        return true;
    }

    /**
     * Быстрый прямой расчёт магнитного поля.
     */
    public static DirectResult direct(PlanetParams params) {
        if (params == null) {
            throw new MagnetoException("PlanetParams не может быть null.");
        }

        FieldValues values = computeFieldValues(params, params.heatFluxWm2);

        return new DirectResult(
			values.coreFieldTesla,
			values.surfaceFieldTesla,
			values.dipoleMomentAm2,
			values.dipoleFractionUsed,
			values.energyFluxUsedWm2,
			values.magneticEnergyDensityJm3,
			values.magneticPressurePa
        );
    }

    /**
     * Симуляция магнитного поля на протяжении заданного числа лет.
     */
    public static SimulationResult simulate(PlanetParams params, SimulationConfig config) {
        return simulate(params, config, null);
    }

    public interface ProgressListener {
        void onProgress(int currentStep, int totalSteps, double currentYears, double totalYears);
    }

    public static SimulationResult simulate(PlanetParams params, SimulationConfig config, ProgressListener progressListener) {
        if (params == null) {
            throw new MagnetoException("PlanetParams не может быть null.");
        }
        if (config == null) {
            throw new MagnetoException("SimulationConfig не может быть null.");
        }

        ArrayList<SimulationPoint> points = new ArrayList<SimulationPoint>(config.steps);

        // 1. Генерируем времена событий (инверсий) по степенному закону (Unified Scaling Law)
        ArrayList<Double> eventTimes = generateEventTimes(config);

        // 2. Шаг по времени
        double timeStep = 0.0;
        if (config.steps > 1) {
            timeStep = config.years / (double) (config.steps - 1);
        }

        double polarity = 1.0;
        int eventIndex = 0;
        int cumulativeEvents = 0;

        // 3. Основной цикл симуляции
        for (int i = 0; i < config.steps; i++) {
            double timeYears = (config.steps > 1) ? (i * timeStep) : 0.0;
            if (timeYears > config.years) {
                timeYears = config.years;
            }

            // Обрабатываем события инверсии, которые произошли к моменту timeYears
            while (eventIndex < eventTimes.size() && eventTimes.get(eventIndex) <= timeYears) {
                polarity = -polarity;
                cumulativeEvents++;
                eventIndex++;
            }

            // Вычисляем тепловой поток с учётом остывания ядра
            double currentHeatFlux = heatFluxAtTime(
				timeYears,
				params.heatFluxWm2,
				config.minHeatFluxWm2,
				config.coolingTimeYears
            );

            // Считаем поле для текущего момента времени
            FieldValues values = computeFieldValues(params, currentHeatFlux);

            points.add(new SimulationPoint(
						   timeYears,
						   currentHeatFlux,
						   values.coreFieldTesla,
						   values.surfaceFieldTesla,
						   values.dipoleMomentAm2,
						   polarity,
						   cumulativeEvents
					   ));

            if (progressListener != null && (i == 0 || i == config.steps - 1 || (i % Math.max(1, config.steps / 100) == 0))) {
                progressListener.onProgress(i + 1, config.steps, timeYears, config.years);
            }
        }

        return new SimulationResult(params, config, points);
    }

    // =========================================================
    //  Физическое ядро (Закон Кристенсена)
    // =========================================================

    private static class FieldValues {
        double coreFieldTesla;
        double surfaceFieldTesla;
        double dipoleMomentAm2;
        double dipoleFractionUsed;
        double energyFluxUsedWm2;
        double magneticEnergyDensityJm3;
        double magneticPressurePa;
    }

    private static FieldValues computeFieldValues(PlanetParams planet, double heatFluxWm2) {
        FieldValues result = new FieldValues();

        result.dipoleFractionUsed = clamp(planet.dipoleFraction, 0.0, 1.0);
        result.energyFluxUsedWm2 = (Double.isFinite(heatFluxWm2) && heatFluxWm2 >= 0.0) ? heatFluxWm2 : 0.0;

        if (planet.radiusM <= 0.0 || planet.coreRadiusM <= 0.0 || 
            planet.coreRadiusM >= planet.radiusM || planet.densityKgM3 <= 0.0) {
            return result;
        }

        // 1. Закон динамо-скейлинга Кристенсена: B_core ~ k * sqrt(rho * mu0) * F^(1/3)
        double calibration = planet.calibrationFactor;
        if (!Double.isFinite(calibration) || calibration <= 0.0) {
            calibration = 1.0;
        }

        result.coreFieldTesla = calibration * Math.sqrt(planet.densityKgM3 * MU0) * Math.cbrt(result.energyFluxUsedWm2);

        // 2. Геометрический переход к поверхности: B_surface = f_dip * B_core * (R_core / R_planet)^3
        double ratio = planet.coreRadiusM / planet.radiusM;
        double geometricFactor = ratio * ratio * ratio;

        // Эмпирическая поправка для перехода от среднеобъёмного поля ядра к поверхностному диполю
		double surfaceCorrection = 0.5; 
		result.surfaceFieldTesla = surfaceCorrection * result.dipoleFractionUsed * result.coreFieldTesla * geometricFactor;

        // 3. Дипольный момент: M = (4*pi/mu0) * B_surface * R_planet^3
        result.dipoleMomentAm2 = (4.0 * Math.PI / MU0) * result.surfaceFieldTesla * 
			planet.radiusM * planet.radiusM * planet.radiusM;

        // 4. Магнитная энергия и давление: u = B^2 / (2*mu0)
        result.magneticEnergyDensityJm3 = (result.coreFieldTesla * result.coreFieldTesla) / (2.0 * MU0);
        result.magneticPressurePa = result.magneticEnergyDensityJm3;

        return result;
    }

    private static double heatFluxAtTime(double timeYears, double initialHeatFlux, double minHeatFlux, double coolingTime) {
        double floor = (Double.isFinite(minHeatFlux) && minHeatFlux >= 0.0) ? minHeatFlux : 0.0;

        if (!Double.isFinite(initialHeatFlux) || initialHeatFlux < 0.0) {
            return floor;
        }

        if (!Double.isFinite(coolingTime) || coolingTime <= 0.0) {
            return Math.max(initialHeatFlux, floor);
        }

        double decayed = floor + (initialHeatFlux - floor) * Math.exp(-timeYears / coolingTime);

        if (!Double.isFinite(decayed)) {
            return Math.max(initialHeatFlux, floor);
        }

        return Math.max(decayed, floor);
    }

    // =========================================================
    //  Генератор событий (Unified Scaling Law для инверсий)
    // =========================================================

    private static ArrayList<Double> generateEventTimes(SimulationConfig config) {
        ArrayList<Double> events = new ArrayList<Double>();

        if (!config.includeEvents || config.eventRatePerYear <= 0.0 || config.years <= config.dtMinYears) {
            return events;
        }

        Random random = new Random(config.seed);
        double meanWaitingYears = 1.0 / config.eventRatePerYear;
        double currentTime = 0.0;
        int rejectionCounter = 0;
        final int MAX_REJECTIONS = 50000;

        while (true) {
            double remaining = config.years - currentTime;
            if (remaining < config.dtMinYears) break;

            double upperBound = Math.min(config.dtMaxYears, remaining);
            if (upperBound < config.dtMinYears) break;

            double candidateWait = sampleTruncatedPowerLaw(config.dtMinYears, upperBound, config.gamma, random.nextDouble());

            double acceptance = 1.0;
            if (Double.isFinite(meanWaitingYears) && meanWaitingYears > 0.0) {
                acceptance = Math.exp(-candidateWait / meanWaitingYears);
                if (!Double.isFinite(acceptance)) acceptance = 0.0;
            }

            if (acceptance <= 0.0) {
                if (++rejectionCounter > MAX_REJECTIONS) break;
                continue;
            }

            if (random.nextDouble() < acceptance) {
                currentTime += candidateWait;
                if (currentTime > config.years) break;
                events.add(currentTime);
                rejectionCounter = 0;
            } else {
                if (++rejectionCounter > MAX_REJECTIONS) break;
            }
        }

        return events;
    }

    private static double sampleTruncatedPowerLaw(double dtMin, double dtMax, double gamma, double uniform01) {
        if (dtMax <= dtMin) return dtMin;

        double u = clamp(uniform01, 0.0, 1.0);

        if (Math.abs(gamma - 1.0) < 1.0e-10) {
            double logMin = Math.log(dtMin);
            double logMax = Math.log(dtMax);
            double sampled = Math.exp(logMin + (logMax - logMin) * u);
            return clamp(sampled, dtMin, dtMax);
        }

        double exponent = 1.0 - gamma;
        double minTerm = Math.pow(dtMin, exponent);
        double maxTerm = Math.pow(dtMax, exponent);
        double base = (maxTerm - minTerm) * u + minTerm;

        if (!Double.isFinite(base) || base <= 0.0) return dtMin;

        double sampled = Math.pow(base, 1.0 / exponent);
        return clamp(sampled, dtMin, dtMax);
    }

    private static double clamp(double value, double min, double max) {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }
}
