package com.astroforge;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayDeque;

public class CheckpointWriter {

    private final File outFile;
    private final Object lock = new Object();
    private final ArrayDeque<byte[]> queue = new ArrayDeque<byte[]>();

    private volatile boolean running = false;

    private Thread thread;
    private BufferedOutputStream out;

    public CheckpointWriter(File dir, String fileName) {
        this.outFile = new File(dir, fileName);
    }

    public void start() {
        if (running) {
            return;
        }

        running = true;

        thread = new Thread(new Runnable() {
            @Override
            public void run() {
                writerLoop();
            }
        }, "checkpoint-writer");

        thread.start();
    }

    public void submit(byte[] data) {
        if (!running || data == null) {
            return;
        }

        synchronized (lock) {
            queue.addLast(data);
            lock.notifyAll();
        }
    }

    private void writerLoop() {
        try {
            File parent = outFile.getParentFile();
            if (parent != null && !parent.exists()) {
                parent.mkdirs();
            }

            out = new BufferedOutputStream(new FileOutputStream(outFile, true), 262144);

            while (true) {
                byte[] data = null;

                synchronized (lock) {
                    while (queue.isEmpty() && running) {
                        try {
                            lock.wait();
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                            return;
                        }
                    }

                    if (!queue.isEmpty()) {
                        data = queue.removeFirst();
                    }
                }

                if (data == null) {
                    if (!running) {
                        break;
                    }
                    continue;
                }

                out.write(data);
                out.flush();
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
            } catch (IOException e) {
                // Ignore.
            }
        }
    }

    public void stop() {
        synchronized (lock) {
            running = false;
            lock.notifyAll();
        }

        if (thread != null) {
            try {
                thread.join(30000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
