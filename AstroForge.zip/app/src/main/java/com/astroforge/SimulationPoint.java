package com.astroforge;

/**
 * Одна точка временной симуляции.
 */
public final class SimulationPoint {

    public final double timeYears;
    public final double heatFluxWm2;
    public final double coreFieldTesla;
    public final double surfaceFieldTesla;
    public final double dipoleMomentAm2;
    public final double polarity;
    public final int cumulativeEvents;

    public SimulationPoint(
		double timeYears,
		double heatFluxWm2,
		double coreFieldTesla,
		double surfaceFieldTesla,
		double dipoleMomentAm2,
		double polarity,
		int cumulativeEvents
    ) {
        this.timeYears = timeYears;
        this.heatFluxWm2 = heatFluxWm2;
        this.coreFieldTesla = coreFieldTesla;
        this.surfaceFieldTesla = surfaceFieldTesla;
        this.dipoleMomentAm2 = dipoleMomentAm2;
        this.polarity = polarity;
        this.cumulativeEvents = cumulativeEvents;
    }
}
