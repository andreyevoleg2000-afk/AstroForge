package com.astroforge;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

/**
 * Всплывающее окно "Плотность".
 * Дизайн, поля с единицами, dropdown и анимации намеренно повторяют VelocityPanel.
 * Кнопка "Рассчитать" взята целиком из VelocityPanel (тот же стиль/цвет/радиус).
 * Формула: ρ = m / (4/3 · π · r³). Масса и радиус приводятся к SI через
 * PhysicsEngine.MassUnit / PhysicsEngine.DistanceUnit.
 * AIDE-safe: без лямбд, без androidx, с обычными анонимными классами.
 */
final class DensityPanel {

    private static final int ACCENT_COLOR        = 0xFFD9946B;
    private static final int ACCENT_BORDER_COLOR = Color.parseColor("#CCD9946B");
    private static final int FIELD_BG_COLOR      = Color.parseColor("#F21C1C1E");
    private static final int FIELD_BORDER_COLOR  = Color.parseColor("#B3E3E3E3");
    private static final int PILL_BG_COLOR       = Color.BLACK;
    private static final int DROPDOWN_BG_COLOR   = Color.parseColor("#FF1C1C1E");

    private static final long OPEN_ANIM_DURATION_MS  = 360L;
    private static final long CLOSE_ANIM_DURATION_MS = 220L;

    private static final int CLOSE_DIRECTION_CENTER = 0;
    private static final int CLOSE_DIRECTION_LEFT   = -1;
    private static final int CLOSE_DIRECTION_RIGHT  = 1;

    private final Context context;
    private final FrameLayout rootContainer;
    private final Typeface typefaceRegular;
    private final Typeface typefaceSemiBold;

    private FrameLayout overlayRoot;
    private FrameLayout windowFrame;
    private FrameLayout dropdownLayer;
    private PixelFillOverlay pixelFillOverlay;

    private ValueAnimator openAnimator;
    private ValueAnimator closeAnimator;
    private boolean isClosing = false;

    private boolean swipeClosing = false;
    private boolean swipeFromLeftEdge = false;
    private float swipeStartX = 0f;
    private float swipeStartY = 0f;
    private float swipeLastDx = 0f;
    private float swipeLastDy = 0f;

    // Поля ввода
    private EditText massInput;
    private UnitPillState massUnit;
    private EditText radiusInput;
    private UnitPillState radiusUnit;

    // Контейнер результата
    private LinearLayout resultContainer;

    private DensityPanel(Context context,
                         FrameLayout rootContainer,
                         Typeface typefaceRegular,
                         Typeface typefaceSemiBold) {
        this.context = context;
        this.rootContainer = rootContainer;
        this.typefaceRegular = typefaceRegular;
        this.typefaceSemiBold = typefaceSemiBold;
    }

    static void show(Context context,
                     FrameLayout rootContainer,
                     Typeface typefaceRegular,
                     Typeface typefaceSemiBold) {
        new DensityPanel(context, rootContainer, typefaceRegular, typefaceSemiBold).build();
    }

    private int dp(float value) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                value,
                context.getResources().getDisplayMetrics()
        );
    }

    // =========================================================
    //  Построение окна
    // =========================================================
    private void build() {
        overlayRoot = new FrameLayout(context);
        overlayRoot.setBackgroundColor(Color.parseColor("#CC0F0F10"));
        overlayRoot.setClickable(true);
        overlayRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                close();
            }
        });

        windowFrame = new FrameLayout(context);
        windowFrame.setClickable(true);
        windowFrame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Поглощаем клик внутри окна.
            }
        });
        overlayRoot.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return handleEdgeSwipe(event);
            }
        });

        GradientDrawable frameBg = new GradientDrawable();
        frameBg.setShape(GradientDrawable.RECTANGLE);
        frameBg.setCornerRadius(dp(28));
        frameBg.setColor(0xF21E1E20);
        frameBg.setStroke(dp(2), ACCENT_COLOR);
        windowFrame.setBackground(frameBg);
        windowFrame.setClipToOutline(true);
        windowFrame.setOutlineProvider(ViewOutlineProvider.BACKGROUND);

        ImageView blurBg = new ImageView(context);
        blurBg.setImageResource(R.drawable.background);
        blurBg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        if (Build.VERSION.SDK_INT >= 31) {
            blurBg.setRenderEffect(
                    RenderEffect.createBlurEffect(dp(44), dp(44), Shader.TileMode.CLAMP)
            );
        }
        blurBg.setAlpha(0.88f);
        windowFrame.addView(blurBg, matchParentFrameLp());

        View tint = new View(context);
        tint.setBackgroundColor(Color.parseColor("#CC232326"));
        windowFrame.addView(tint, matchParentFrameLp());
        AstroUiEffects.applyPaperEffect(windowFrame, context);

        ScrollView scrollView = new ScrollView(context);
        scrollView.setClipToPadding(false);
        scrollView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        LinearLayout content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        content.setPadding(pad, pad, pad, pad);

        content.addView(buildTitle());
        content.addView(spacer(dp(18)));

        content.addView(buildLabel("Масса объекта"));
        content.addView(spacer(dp(6)));
        ValueUnitRow massRow = buildMassField();
        massInput = massRow.input;
        massUnit  = massRow.unitState;
        content.addView(massRow.row);

        content.addView(spacer(dp(14)));

        content.addView(buildLabel("Радиус объекта"));
        content.addView(spacer(dp(6)));
        ValueUnitRow radiusRow = buildRadiusField();
        radiusInput = radiusRow.input;
        radiusUnit  = radiusRow.unitState;
        content.addView(radiusRow.row);

        content.addView(spacer(dp(18)));

        // Кнопка "Рассчитать" — дизайн целиком из VelocityPanel
        content.addView(buildCalculateButton());

        content.addView(spacer(dp(14)));

        // Блок-пояснение формулы (по аналогии с buildExplanationBlock в VelocityPanel)
        content.addView(buildExplanationBlock());

        content.addView(spacer(dp(10)));

        resultContainer = new LinearLayout(context);
        resultContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(resultContainer);

        content.addView(spacer(dp(20)));

        scrollView.addView(content, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT
        ));
        windowFrame.addView(scrollView, matchParentFrameLp());

        attachPixelFillOverlay();

        FrameLayout.LayoutParams windowLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        );
        int screenMargin = dp(18);
        windowLp.setMargins(
                screenMargin,
                screenMargin + dp(30),
                screenMargin,
                screenMargin + dp(30)
        );
        overlayRoot.addView(windowFrame, windowLp);
        rootContainer.addView(overlayRoot, matchParentFrameLp());

        windowFrame.post(new Runnable() {
            @Override
            public void run() {
                if (overlayRoot != null && overlayRoot.getParent() == rootContainer) {
                    startOpenAnimation();
                }
            }
        });

        dropdownLayer = new FrameLayout(context);
        dropdownLayer.setClipChildren(false);
        dropdownLayer.setClipToPadding(false);
        dropdownLayer.setElevation(dp(1000));
        overlayRoot.addView(dropdownLayer, matchParentFrameLp());
        dropdownLayer.bringToFront();
    }

    // =========================================================
    //  Мелкие UI-хелперы
    // =========================================================
    private View buildTitle() {
        TextView tv = new DigitTextView(context);
        tv.setText("Плотность");
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        tv.setGravity(Gravity.START | Gravity.TOP);
        return tv;
    }

    private TextView buildLabel(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#DDE3E1DE"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        return tv;
    }

    private View spacer(int heightPx) {
        View v = new View(context);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                heightPx
        ));
        return v;
    }

    // =========================================================
    //  Поля с единицами
    // =========================================================
    private static final class ValueUnitRow {
        View row;
        EditText input;
        UnitPillState unitState;
    }

    private static final class UnitPillState {
        TextView pillView;
        int selectedIndex = 0;
        String[] labels;
    }

    private ValueUnitRow buildMassField() {
        String[] labels = new String[PhysicsEngine.MassUnit.values().length];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = PhysicsEngine.MassUnit.values()[i].label;
        }
        return buildValueUnitRow(labels, "Введите массу");
    }

    private ValueUnitRow buildRadiusField() {
        String[] labels = new String[PhysicsEngine.DistanceUnit.values().length];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = PhysicsEngine.DistanceUnit.values()[i].label;
        }
        return buildValueUnitRow(labels, "Введите радиус");
    }

    private ValueUnitRow buildValueUnitRow(final String[] unitLabels, String hint) {
        FrameLayout field = new FrameLayout(context);
        field.setBackground(createRoundedRect(dp(16), FIELD_BG_COLOR, FIELD_BORDER_COLOR, dp(1.25f)));
        AstroUiEffects.applyControlShadow(field, context);
        field.setClipToOutline(true);

        final EditText input = new DigitEditText(context);
        input.setHint(hint);
        input.setHintTextColor(Color.parseColor("#77FFFFFF"));
        input.setTextColor(Color.WHITE);
        input.setTypeface(typefaceRegular);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        input.setSingleLine(true);
        input.setBackground(null);
        AstroUiEffects.applyControlShadow(input, context);
        input.setInputType(InputType.TYPE_CLASS_NUMBER
                | InputType.TYPE_NUMBER_FLAG_DECIMAL
                | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setPadding(dp(16), dp(12), dp(120), dp(12));
        field.addView(input, matchParentFrameLp());

        final UnitPillState state = new UnitPillState();
        state.labels = unitLabels;
        state.selectedIndex = 0;

        final TextView pill = new DigitTextView(context);
        pill.setText(unitLabels[0]);
        pill.setTextColor(Color.WHITE);
        pill.setTypeface(typefaceSemiBold);
        pill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        pill.setGravity(Gravity.CENTER);
        pill.setMaxLines(1);
        pill.setEllipsize(android.text.TextUtils.TruncateAt.END);
        pill.setBackground(createRoundedRect(dp(14), PILL_BG_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        pill.setPadding(dp(12), dp(8), dp(12), dp(8));
        pill.setClickable(true);
        pill.setFocusable(true);

        FrameLayout.LayoutParams pillLp = new FrameLayout.LayoutParams(
                dp(104),
                FrameLayout.LayoutParams.WRAP_CONTENT
        );
        pillLp.gravity = Gravity.CENTER_VERTICAL | Gravity.END;
        pillLp.rightMargin = dp(8);
        field.addView(pill, pillLp);
        pill.setTranslationZ(dp(3f));
        state.pillView = pill;

        pill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HapticUtils.perform(v);
                openDropdown(pill, unitLabels, state.selectedIndex, new OnUnitSelected() {
                    @Override
                    public void onSelected(int newIndex) {
                        state.selectedIndex = newIndex;
                        pill.setText(unitLabels[newIndex]);
                    }
                });
            }
        });

        field.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(50)
        ));

        ValueUnitRow row = new ValueUnitRow();
        row.row = field;
        row.input = input;
        row.unitState = state;
        return row;
    }

    // =========================================================
    //  Dropdown
    // =========================================================
    private interface OnUnitSelected {
        void onSelected(int index);
    }

    private void openDropdown(final View anchor,
                              final String[] labels,
                              int selectedIndex,
                              final OnUnitSelected callback) {
        dropdownLayer.removeAllViews();
        dropdownLayer.bringToFront();

        int[] anchorLoc = new int[2];
        anchor.getLocationOnScreen(anchorLoc);
        int[] rootLoc = new int[2];
        dropdownLayer.getLocationOnScreen(rootLoc);
        int relativeX = anchorLoc[0] - rootLoc[0];
        int relativeY = anchorLoc[1] - rootLoc[1];
        int anchorBottom = relativeY + anchor.getHeight();

        Rect visibleFrame = new Rect();
        rootContainer.getWindowVisibleDisplayFrame(visibleFrame);
        int visibleTop = visibleFrame.top - rootLoc[1];
        int visibleBottom = visibleFrame.bottom - rootLoc[1];

        View scrim = new View(context);
        scrim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dropdownLayer.removeAllViews();
            }
        });
        dropdownLayer.addView(scrim, matchParentFrameLp());

        LinearLayout list = new LinearLayout(context);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setBackground(createRoundedRect(dp(14), DROPDOWN_BG_COLOR, ACCENT_BORDER_COLOR, dp(1.25f)));
        list.setClipToOutline(true);
        list.setPadding(dp(6), dp(6), dp(6), dp(6));

        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView item = new DigitTextView(context);
            item.setText(labels[i]);
            item.setTextColor(i == selectedIndex ? ACCENT_COLOR : Color.WHITE);
            item.setTypeface(i == selectedIndex ? typefaceSemiBold : typefaceRegular);
            AstroUiEffects.applyUnitTypeface(item, context);
            item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            item.setPadding(dp(14), dp(10), dp(14), dp(10));
            item.setClickable(true);
            item.setFocusable(true);
            item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    HapticUtils.perform(v);
                    callback.onSelected(idx);
                    dropdownLayer.removeAllViews();
                }
            });
            list.addView(item, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            ));
        }

        int estimatedHeight = dp(12) + (labels.length * dp(40));
        int spaceBelow = visibleBottom - anchorBottom - dp(8);
        int spaceAbove = relativeY - visibleTop - dp(8);
        if (spaceBelow < 0) spaceBelow = 0;
        if (spaceAbove < 0) spaceAbove = 0;
        boolean showAbove = spaceBelow < estimatedHeight && spaceAbove > spaceBelow;
        final int maxHeight = Math.max(
                0,
                Math.min(estimatedHeight, showAbove ? spaceAbove : spaceBelow)
        );

        ScrollView listScroll = new ScrollView(context) {
            @Override
            protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                int hSpec = heightMeasureSpec;
                if (maxHeight > 0) {
                    int mode = View.MeasureSpec.getMode(hSpec);
                    int size = View.MeasureSpec.getSize(hSpec);
                    if (mode == View.MeasureSpec.UNSPECIFIED || size > maxHeight) {
                        hSpec = View.MeasureSpec.makeMeasureSpec(maxHeight, View.MeasureSpec.AT_MOST);
                    }
                }
                super.onMeasure(widthMeasureSpec, hSpec);
            }
        };
        listScroll.addView(list, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT
        ));
        listScroll.setBackground(list.getBackground());
        list.setBackground(null);
        listScroll.setVerticalScrollBarEnabled(false);
        listScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        FrameLayout.LayoutParams listLp = new FrameLayout.LayoutParams(
                dp(180),
                FrameLayout.LayoutParams.WRAP_CONTENT
        );
        listLp.leftMargin = Math.max(dp(8), relativeX + anchor.getWidth() - dp(180));
        if (showAbove) {
            listLp.topMargin = Math.max(visibleTop + dp(8), relativeY - maxHeight - dp(4));
        } else {
            listLp.topMargin = anchorBottom + dp(4);
        }
        dropdownLayer.addView(listScroll, listLp);
        listScroll.bringToFront();
    }

    // =========================================================
    //  Кнопка расчёта (дизайн — из VelocityPanel) и результат
    // =========================================================
    private View buildCalculateButton() {
        TextView btn = new DigitTextView(context);
        btn.setText("Рассчитать");
        btn.setTextColor(Color.WHITE);
        btn.setTypeface(typefaceSemiBold);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(0, dp(14), 0, dp(14));
        btn.setBackground(createRoundedRect(dp(18), ACCENT_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        AstroUiEffects.applyControlShadow(btn, context);
        btn.setClickable(true);
        btn.setFocusable(true);
        btn.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HapticUtils.perform(v);
                onCalculatePressed();
            }
        });
        return btn;
    }

    private View buildExplanationBlock() {
        LinearLayout block = new LinearLayout(context);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        TextView title = new DigitTextView(context);
        title.setText("Как считается плотность");
        title.setTextColor(Color.WHITE);
        title.setTypeface(typefaceSemiBold);

        AstroUiEffects.applyExplanationTypeface(title, context);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        block.addView(title);
        block.addView(spacer(dp(8)));
        block.addView(buildExplanationLine("1) Приводим массу m и радиус r к SI (кг и м)."));
        block.addView(spacer(dp(4)));
        block.addView(buildExplanationLine("2) Объём шара: V = 4/3 · π · r³."));
        block.addView(spacer(dp(4)));
        block.addView(buildExplanationLine("3) Средняя плотность: ρ = m / V = m / (4/3 · π · r³)."));
        block.addView(spacer(dp(4)));
        block.addView(buildExplanationLine("4) Для наглядности результат также переводится в г/см³ (1 г/см³ = 1000 кг/м³)."));
        return block;
    }

    private TextView buildExplanationLine(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#CFE3E1DE"));
        tv.setTypeface(typefaceRegular);
        AstroUiEffects.applyExplanationTypeface(tv, context);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        tv.setLineSpacing(dp(2), 1.08f);
        return tv;
    }

    /** Обёрнуто в try/catch(Throwable): любая ошибка больше не роняет приложение. */
    private void onCalculatePressed() {
        try {
            resultContainer.removeAllViews();

            Double massValue   = parseDouble(massInput.getText().toString());
            Double radiusValue = parseDouble(radiusInput.getText().toString());

            if (massValue == null || massValue <= 0) {
                showResultError("Введите корректную массу объекта (положительное число).");
                return;
            }
            if (radiusValue == null || radiusValue <= 0) {
                showResultError("Введите корректный радиус объекта (положительное число).");
                return;
            }

            double massKg   = PhysicsEngine.MassUnit.values()[massUnit.selectedIndex].toKg(massValue);
            double radiusM  = PhysicsEngine.DistanceUnit.values()[radiusUnit.selectedIndex].toMeters(radiusValue);

            double volumeM3 = (4.0 / 3.0) * Math.PI * radiusM * radiusM * radiusM;
            if (volumeM3 <= 0 || Double.isInfinite(volumeM3) || Double.isNaN(volumeM3)) {
                showResultError("Не удалось вычислить объём: проверьте радиус.");
                return;
            }

            double densityKgM3 = massKg / volumeM3;
            if (Double.isInfinite(densityKgM3) || Double.isNaN(densityKgM3)) {
                showResultError("Результат вышел за пределы вычислений. Проверьте введённые значения.");
                return;
            }

            showResult(massKg, radiusM, volumeM3, densityKgM3);
        } catch (Throwable t) {
            resultContainer.removeAllViews();
            showResultError("Ошибка при расчёте:\n" + stack(t));
        }
    }

    private Double parseDouble(String text) {
        if (text == null) return null;
        String trimmed = text.trim().replace(',', '.');
        if (trimmed.isEmpty()) return null;
        try {
            return Double.parseDouble(trimmed);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void showResultError(String message) {
        TextView tv = new DigitTextView(context);
        tv.setText(message);
        tv.setTextColor(Color.parseColor("#FFB4A0"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        resultContainer.addView(tv);
    }

    private void showResult(double massKg, double radiusM, double volumeM3, double densityKgM3) {
        LinearLayout box = resultBox();
        box.addView(resultSectionTitle("Результат"));
        box.addView(spacer(dp(8)));

        // Главная цифра — плотность в кг/м³
        box.addView(resultLine("Средняя плотность", formatDensityKgM3(densityKgM3)));
        box.addView(spacer(dp(6)));
        // Дублируем в г/см³ — привычнее для сравнения с водой/планетами
        box.addView(resultLine("То же в г/см³", String.format(Locale.US, "%.4f г/см³", densityKgM3 / 1000.0)));
        box.addView(spacer(dp(10)));

        // Второстепенные величины
        box.addView(resultSubLine("Объём", formatVolume(volumeM3)));
        box.addView(spacer(dp(4)));
        box.addView(resultSubLine("Масса (SI)", String.format(Locale.US, "%.4e кг", massKg)));
        box.addView(spacer(dp(4)));
        box.addView(resultSubLine("Радиус (SI)", String.format(Locale.US, "%.4e м", radiusM)));
        box.addView(spacer(dp(10)));

        // Сравнение с эталонами — чтобы результат был «живым»
        box.addView(buildReferenceBlock(densityKgM3));

        resultContainer.addView(box);
    }

    private LinearLayout buildReferenceBlock(double densityKgM3) {
        LinearLayout wrap = new LinearLayout(context);
        wrap.setOrientation(LinearLayout.VERTICAL);

        TextView title = new DigitTextView(context);
        title.setText("Сравнение с эталонами");
        title.setTextColor(Color.parseColor("#AAFFFFFF"));
        title.setTypeface(typefaceRegular);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        wrap.addView(title);
        wrap.addView(spacer(dp(4)));

        // Эталонные плотности в кг/м³
        addReferenceLine(wrap, "Вода (жидкая)",        1000.0,  densityKgM3);
        addReferenceLine(wrap, "Лёд водяной",           917.0,  densityKgM3);
        addReferenceLine(wrap, "Силикатная порода",    3000.0,  densityKgM3);
        addReferenceLine(wrap, "Железо",               7874.0,  densityKgM3);
        addReferenceLine(wrap, "Земля (средняя)",      5514.0,  densityKgM3);
        addReferenceLine(wrap, "Луна (средняя)",       3344.0,  densityKgM3);
        addReferenceLine(wrap, "Солнце (средняя)",     1408.0,  densityKgM3);
        addReferenceLine(wrap, "Белый карлик (порядок)", 1.0e9, densityKgM3);
        addReferenceLine(wrap, "Нейтронная звезда (порядок)", 4.0e17, densityKgM3);

        return wrap;
    }

    private void addReferenceLine(LinearLayout parent, String name, double refKgM3, double actualKgM3) {
        double ratio = actualKgM3 / refKgM3;
        String ratioText;
        if (ratio >= 1000.0) {
            ratioText = String.format(Locale.US, "в %.2e раз плотнее", ratio);
        } else if (ratio <= 0.001) {
            ratioText = String.format(Locale.US, "в %.2e раз разреженнее", 1.0 / ratio);
        } else if (ratio >= 1.0) {
            ratioText = String.format(Locale.US, "в %.2f раз плотнее", ratio);
        } else {
            ratioText = String.format(Locale.US, "в %.2f раз разреженнее", 1.0 / ratio);
        }

        TextView tv = new DigitTextView(context);
        tv.setText("• " + name + " (" + formatDensityKgM3(refKgM3) + ") — " + ratioText);
        tv.setTextColor(Color.parseColor("#BBFFFFFF"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        tv.setLineSpacing(dp(1), 1.06f);
        parent.addView(tv);
    }

    private String formatDensityKgM3(double kgM3) {
        if (kgM3 >= 1.0e6 || kgM3 < 1.0e-3) {
            return String.format(Locale.US, "%.4e кг/м³", kgM3);
        }
        return String.format(Locale.US, "%.2f кг/м³", kgM3);
    }

    private String formatVolume(double m3) {
        if (m3 >= 1.0e9 || m3 < 1.0e-3) {
            return String.format(Locale.US, "%.4e м³", m3);
        }
        return String.format(Locale.US, "%.2f м³", m3);
    }

    // =========================================================
    //  Анимации открытия/закрытия и свайп (как в VelocityPanel)
    // =========================================================
    private void close() {
        beginClose(CLOSE_DIRECTION_CENTER);
    }

    private void beginClose(int direction) {
        if (isClosing) {
            return;
        }
        if (overlayRoot == null || overlayRoot.getParent() != rootContainer) {
            return;
        }
        isClosing = true;
        swipeClosing = false;
        startCloseAnimation(direction);
    }

    private void startOpenAnimation() {
        if (windowFrame == null) return;
        if (openAnimator != null) {
            openAnimator.cancel();
            openAnimator = null;
        }
        if (closeAnimator != null) {
            closeAnimator.cancel();
            closeAnimator = null;
        }
        swipeClosing = false;
        swipeFromLeftEdge = false;

        windowFrame.setPivotX(windowFrame.getWidth() * 0.5f);
        windowFrame.setPivotY(windowFrame.getHeight() * 0.5f);
        windowFrame.setScaleX(0.965f);
        windowFrame.setScaleY(0.965f);
        windowFrame.setTranslationX(0f);
        windowFrame.setTranslationY(dp(10));

        if (pixelFillOverlay != null) {
            pixelFillOverlay.setVisibility(View.VISIBLE);
            pixelFillOverlay.setProgress(0f);
            pixelFillOverlay.setAlpha(1f);
        }

        openAnimator = ValueAnimator.ofFloat(0f, 1f);
        openAnimator.setDuration(OPEN_ANIM_DURATION_MS);
        openAnimator.setInterpolator(new DecelerateInterpolator(1.8f));
        openAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float p = ((Float) animation.getAnimatedValue()).floatValue();
                if (windowFrame != null) {
                    windowFrame.setScaleX(0.965f + (0.035f * p));
                    windowFrame.setScaleY(0.965f + (0.035f * p));
                    windowFrame.setTranslationX(0f);
                    windowFrame.setTranslationY(dp(10) * (1f - p));
                }
                if (pixelFillOverlay != null) {
                    pixelFillOverlay.setProgress(p);
                    if (p >= 1f) {
                        pixelFillOverlay.setVisibility(View.GONE);
                    }
                }
            }
        });
        openAnimator.start();
    }

    private void startCloseAnimation(final int direction) {
        if (windowFrame == null || overlayRoot == null) {
            performImmediateClose();
            return;
        }
        if (openAnimator != null) {
            openAnimator.cancel();
            openAnimator = null;
        }
        if (closeAnimator != null) {
            closeAnimator.cancel();
            closeAnimator = null;
        }

        final float endScale = 0.72f;
        final float endOffsetX;
        if (direction == CLOSE_DIRECTION_LEFT) {
            endOffsetX = -Math.max(dp(96), windowFrame.getWidth() * 0.22f);
        } else if (direction == CLOSE_DIRECTION_RIGHT) {
            endOffsetX = Math.max(dp(96), windowFrame.getWidth() * 0.22f);
        } else {
            endOffsetX = 0f;
        }
        final float endOffsetY = Math.max(dp(90), windowFrame.getHeight() * 0.18f);

        if (direction == CLOSE_DIRECTION_LEFT) {
            windowFrame.setPivotX(0f);
            windowFrame.setPivotY(windowFrame.getHeight());
        } else if (direction == CLOSE_DIRECTION_RIGHT) {
            windowFrame.setPivotX(windowFrame.getWidth());
            windowFrame.setPivotY(windowFrame.getHeight());
        } else {
            windowFrame.setPivotX(windowFrame.getWidth() * 0.5f);
            windowFrame.setPivotY(windowFrame.getHeight() * 0.5f);
        }

        if (pixelFillOverlay != null) {
            pixelFillOverlay.setVisibility(View.VISIBLE);
            pixelFillOverlay.setProgress(1f);
            pixelFillOverlay.setAlpha(1f);
        }

        closeAnimator = ValueAnimator.ofFloat(1f, 0f);
        closeAnimator.setDuration(CLOSE_ANIM_DURATION_MS);
        closeAnimator.setInterpolator(new AccelerateInterpolator(1.6f));
        closeAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float p = ((Float) animation.getAnimatedValue()).floatValue();
                float fraction = 1f - p;
                if (windowFrame != null) {
                    float scale = 1f - ((1f - endScale) * fraction);
                    windowFrame.setScaleX(scale);
                    windowFrame.setScaleY(scale);
                    windowFrame.setTranslationX(endOffsetX * fraction);
                    windowFrame.setTranslationY(endOffsetY * fraction);
                }
                if (pixelFillOverlay != null) {
                    pixelFillOverlay.setProgress(p);
                }
            }
        });
        closeAnimator.addListener(new android.animation.Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(android.animation.Animator animation) { }
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                performImmediateClose();
            }
            @Override
            public void onAnimationCancel(android.animation.Animator animation) {
                performImmediateClose();
            }
            @Override
            public void onAnimationRepeat(android.animation.Animator animation) { }
        });
        closeAnimator.start();
    }

    private boolean handleEdgeSwipe(MotionEvent event) {
        if (overlayRoot == null
                || windowFrame == null
                || overlayRoot.getParent() != rootContainer) {
            return false;
        }
        int action = event.getActionMasked();
        int edge = dp(28);
        switch (action) {
            case MotionEvent.ACTION_DOWN: {
                float x = event.getX();
                float y = event.getY();
                int w = overlayRoot.getWidth();
                if (w <= 0) {
                    return false;
                }
                boolean fromLeft = x <= edge;
                boolean fromRight = x >= (w - edge);
                if (!fromLeft && !fromRight) {
                    return false;
                }
                swipeClosing = true;
                swipeFromLeftEdge = fromLeft;
                swipeStartX = x;
                swipeStartY = y;
                swipeLastDx = 0f;
                swipeLastDy = 0f;
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (!swipeClosing) {
                    return false;
                }
                swipeLastDx = event.getX() - swipeStartX;
                swipeLastDy = event.getY() - swipeStartY;
                float drag = swipeFromLeftEdge ? swipeLastDx : -swipeLastDx;
                if (drag < 0f) {
                    drag = 0f;
                }
                float progress = Math.min(1f, drag / (float) dp(220));
                float scale = 1f - (0.28f * progress);
                float tx = (swipeFromLeftEdge ? -1f : 1f)
                        * Math.max(dp(24), windowFrame.getWidth() * 0.22f)
                        * progress;
                float ty = Math.max(dp(18), windowFrame.getHeight() * 0.18f) * progress;
                if (swipeFromLeftEdge) {
                    windowFrame.setPivotX(0f);
                } else {
                    windowFrame.setPivotX(windowFrame.getWidth());
                }
                windowFrame.setPivotY(windowFrame.getHeight());
                windowFrame.setScaleX(scale);
                windowFrame.setScaleY(scale);
                windowFrame.setTranslationX(tx);
                windowFrame.setTranslationY(ty);
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                if (!swipeClosing) {
                    return false;
                }
                float drag = swipeFromLeftEdge ? swipeLastDx : -swipeLastDx;
                boolean shouldClose = drag >= dp(84) || Math.abs(swipeLastDx) >= dp(84);
                if (shouldClose) {
                    beginClose(swipeFromLeftEdge ? CLOSE_DIRECTION_LEFT : CLOSE_DIRECTION_RIGHT);
                } else {
                    cancelSwipeGesture();
                }
                return true;
            }
            default:
                return swipeClosing;
        }
    }

    private void cancelSwipeGesture() {
        swipeClosing = false;
        if (windowFrame == null) {
            return;
        }
        windowFrame.setPivotX(windowFrame.getWidth() * 0.5f);
        windowFrame.setPivotY(windowFrame.getHeight() * 0.5f);
        windowFrame.animate()
                .scaleX(1f)
                .scaleY(1f)
                .translationX(0f)
                .translationY(0f)
                .setDuration(180L)
                .setInterpolator(new DecelerateInterpolator(1.6f))
                .start();
    }

    private void performImmediateClose() {
        if (overlayRoot != null && overlayRoot.getParent() == rootContainer) {
            rootContainer.removeView(overlayRoot);
        }
        if (openAnimator != null) {
            openAnimator.cancel();
            openAnimator = null;
        }
        if (closeAnimator != null) {
            closeAnimator.removeAllListeners();
            closeAnimator.cancel();
            closeAnimator = null;
        }
        if (pixelFillOverlay != null) {
            pixelFillOverlay.setProgress(1f);
            pixelFillOverlay.setVisibility(View.GONE);
        }
        overlayRoot = null;
        windowFrame = null;
        pixelFillOverlay = null;
        isClosing = false;
        swipeClosing = false;
        swipeFromLeftEdge = false;
        swipeStartX = 0f;
        swipeStartY = 0f;
        swipeLastDx = 0f;
        swipeLastDy = 0f;
    }

    private void attachPixelFillOverlay() {
        if (windowFrame == null) return;
        pixelFillOverlay = new PixelFillOverlay(context);
        pixelFillOverlay.setVisibility(View.VISIBLE);
        windowFrame.addView(pixelFillOverlay, matchParentFrameLp());
        pixelFillOverlay.bringToFront();
    }

    private final class PixelFillOverlay extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Rect rect = new Rect();
        private float progress = 0f;
        private int cachedW = -1;
        private int cachedH = -1;
        private int tilePx = 1;
        private int cols = 0;
        private int rows = 0;
        private float[] thresholds = new float[0];

        PixelFillOverlay(Context context) {
            super(context);
            paint.setStyle(Paint.Style.FILL);
            setWillNotDraw(false);
            setClickable(false);
            setFocusable(false);
            setBackgroundColor(Color.TRANSPARENT);
        }

        void setProgress(float p) {
            if (p < 0f) p = 0f;
            if (p > 1f) p = 1f;
            if (progress == p) {
                return;
            }
            progress = p;
            invalidate();
        }

        private void ensureGeometry(int w, int h) {
            if (w == cachedW && h == cachedH && thresholds.length == cols * rows) {
                return;
            }
            cachedW = w;
            cachedH = h;
            int base = Math.min(w, h) / 18;
            tilePx = Math.max(dp(20), base);
            if (tilePx <= 0) {
                tilePx = dp(20);
            }
            cols = Math.max(1, (int) Math.ceil((double) w / (double) tilePx));
            rows = Math.max(1, (int) Math.ceil((double) h / (double) tilePx));
            thresholds = new float[cols * rows];
            float cx = w * 0.5f;
            float cy = h * 0.5f;
            float maxDist = (float) Math.sqrt((cx * cx) + (cy * cy));
            if (maxDist <= 0f) {
                maxDist = 1f;
            }
            int index = 0;
            for (int row = 0; row < rows; row++) {
                float y = (row * tilePx) + (tilePx * 0.5f);
                for (int col = 0; col < cols; col++) {
                    float x = (col * tilePx) + (tilePx * 0.5f);
                    float dx = x - cx;
                    float dy = y - cy;
                    float norm = (float) Math.sqrt((dx * dx) + (dy * dy)) / maxDist;
                    if (norm < 0f) norm = 0f;
                    if (norm > 1f) norm = 1f;
                    thresholds[index++] = norm;
                }
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) {
                return;
            }
            ensureGeometry(w, h);
            final int baseAlpha = 220;
            final int fillColor = 0xF21E1E20;
            final int accentColor = 0xFFD9946B;
            int fillR = Color.red(fillColor);
            int fillG = Color.green(fillColor);
            int fillB = Color.blue(fillColor);
            int accentR = Color.red(accentColor);
            int accentG = Color.green(accentColor);
            int accentB = Color.blue(accentColor);
            int index = 0;
            for (int row = 0; row < rows; row++) {
                int top = row * tilePx;
                int bottom = Math.min(h, top + tilePx);
                for (int col = 0; col < cols; col++) {
                    int left = col * tilePx;
                    int right = Math.min(w, left + tilePx);
                    float threshold = thresholds[index++];
                    float local = progress - threshold;
                    float alpha01;
                    if (local <= 0f) {
                        alpha01 = 1f;
                    } else if (local >= 0.16f) {
                        alpha01 = 0f;
                    } else {
                        float t = local / 0.16f;
                        alpha01 = 1f - (t * t * (3f - 2f * t));
                    }
                    if (alpha01 <= 0.01f) {
                        continue;
                    }
                    int alpha = (int) (baseAlpha * alpha01);
                    if (((row + col) & 7) == 0) {
                        paint.setColor(Color.argb(alpha, accentR, accentG, accentB));
                    } else if (((row + col) & 3) == 0) {
                        paint.setColor(Color.argb(alpha, 52, 46, 44));
                    } else {
                        paint.setColor(Color.argb(alpha, fillR, fillG, fillB));
                    }
                    rect.set(left, top, right, bottom);
                    canvas.drawRect(rect, paint);
                }
            }
        }
    }

    // =========================================================
    //  Утилиты отображения результата
    // =========================================================
    private LinearLayout resultBox() {
        LinearLayout box = new LinearLayout(context);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(createRoundedRect(
                dp(16),
                Color.parseColor("#6F6B67"),
                Color.parseColor("#CCFFFFFF"),
                dp(1.5f)
        ));
        int p = dp(14);
        box.setPadding(p, p, p, p);
        box.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        return box;
    }

    private TextView resultSectionTitle(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        return tv;
    }

    private View resultLine(String label, String value) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.VERTICAL);

        TextView labelView = new DigitTextView(context);
        labelView.setText(label);
        labelView.setTextColor(Color.parseColor("#BBFFFFFF"));
        labelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        row.addView(labelView);

        TextView valueView = new DigitTextView(context);
        valueView.setText(value);
        valueView.setTextColor(ACCENT_COLOR);
        valueView.setTypeface(typefaceSemiBold);
        valueView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        row.addView(valueView);

        return row;
    }

    private View resultSubLine(String label, String value) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);

        TextView labelView = new DigitTextView(context);
        labelView.setText(label + ":  ");
        labelView.setTextColor(Color.parseColor("#AAFFFFFF"));
        labelView.setTypeface(typefaceRegular);
        labelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        row.addView(labelView);

        TextView valueView = new DigitTextView(context);
        valueView.setText(value);
        valueView.setTextColor(Color.parseColor("#DDFFFFFF"));
        valueView.setTypeface(typefaceRegular);
        valueView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        row.addView(valueView);

        return row;
    }

    private GradientDrawable createRoundedRect(float radius,
                                               int fillColor,
                                               int strokeColor,
                                               float strokeWidth) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(radius);
        gd.setColor(fillColor);
        gd.setStroke((int) strokeWidth, strokeColor);
        return gd;
    }

    private FrameLayout.LayoutParams matchParentFrameLp() {
        return new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        );
    }

    /** Короткий stack trace для показа в окне. */
    private static String stack(Throwable t) {
        try {
            java.io.StringWriter sw = new java.io.StringWriter();
            t.printStackTrace(new java.io.PrintWriter(sw));
            String s = sw.toString();
            return s.length() > 1500 ? s.substring(0, 1500) + "…" : s;
        } catch (Throwable ignore) {
            return String.valueOf(t);
        }
    }
}
