package com.astroforge;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;

/** Shared window-opening animation matching the "Скорость объекта" panel. */
final class WindowOpenAnimation {
    private static final long DURATION_MS = 360L;
    private static final float START_SCALE = 0.965f;
    private static final float END_SCALE = 1.0f;
    private static final float TRANSLATION_DP = 10f;

    private WindowOpenAnimation() { }

    static void start(final FrameLayout window, final float density) {
        if (window == null) return;

        window.animate().cancel();
        window.setPivotX(window.getWidth() * 0.5f);
        window.setPivotY(window.getHeight() * 0.5f);
        window.setScaleX(START_SCALE);
        window.setScaleY(START_SCALE);
        window.setTranslationX(0f);
        window.setTranslationY(TRANSLATION_DP * density);

        final PixelFillOverlay overlay = new PixelFillOverlay(window.getContext(), density);
        overlay.setVisibility(View.VISIBLE);
        window.addView(overlay, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ));
        overlay.bringToFront();

        ValueAnimator animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(DURATION_MS);
        animator.setInterpolator(new DecelerateInterpolator(1.8f));
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float p = ((Float) animation.getAnimatedValue()).floatValue();
                if (window != null) {
                    window.setScaleX(START_SCALE + ((END_SCALE - START_SCALE) * p));
                    window.setScaleY(START_SCALE + ((END_SCALE - START_SCALE) * p));
                    window.setTranslationX(0f);
                    window.setTranslationY((TRANSLATION_DP * density) * (1f - p));
                }
                if (overlay != null) {
                    overlay.setProgress(p);
                    if (p >= 1f && overlay.getParent() == window) {
                        window.removeView(overlay);
                    }
                }
            }
        });
        animator.start();
    }

    private static final class PixelFillOverlay extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Rect rect = new Rect();
        private final float density;
        private float progress = 0f;
        private int cachedW = -1;
        private int cachedH = -1;
        private int tilePx = 1;
        private int cols = 0;
        private int rows = 0;
        private float[] thresholds = new float[0];

        PixelFillOverlay(android.content.Context context, float density) {
            super(context);
            this.density = density;
            paint.setStyle(Paint.Style.FILL);
            setWillNotDraw(false);
            setClickable(false);
            setFocusable(false);
            setBackgroundColor(Color.TRANSPARENT);
        }

        void setProgress(float p) {
            if (p < 0f) p = 0f;
            if (p > 1f) p = 1f;
            if (progress == p) return;
            progress = p;
            invalidate();
        }

        private int dp(float value) {
            return Math.max(1, (int) (value * density + 0.5f));
        }

        private void ensureGeometry(int w, int h) {
            if (w == cachedW && h == cachedH && thresholds.length == cols * rows) {
                return;
            }

            cachedW = w;
            cachedH = h;

            int base = Math.min(w, h) / 18;
            tilePx = Math.max(dp(20), base);
            if (tilePx <= 0) tilePx = dp(20);

            cols = Math.max(1, (int) Math.ceil((double) w / (double) tilePx));
            rows = Math.max(1, (int) Math.ceil((double) h / (double) tilePx));
            thresholds = new float[cols * rows];

            float cx = w * 0.5f;
            float cy = h * 0.5f;
            float maxDist = (float) Math.sqrt((cx * cx) + (cy * cy));
            if (maxDist <= 0f) maxDist = 1f;

            int index = 0;
            for (int row = 0; row < rows; row++) {
                float y = (row * tilePx) + (tilePx * 0.5f);
                for (int col = 0; col < cols; col++) {
                    float x = (col * tilePx) + (tilePx * 0.5f);
                    float dx = x - cx;
                    float dy = y - cy;
                    float norm = (float) Math.sqrt((dx * dx) + (dy * dy)) / maxDist;
                    if (norm < 0f) norm = 0f;
                    if (norm > 1f) norm = 1f;
                    thresholds[index++] = norm;
                }
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;

            ensureGeometry(w, h);

            final int baseAlpha = 220;
            final int fillColor = 0xF21E1E20;
            final int accentColor = 0xFFD9946B;

            int fillR = Color.red(fillColor);
            int fillG = Color.green(fillColor);
            int fillB = Color.blue(fillColor);
            int accentR = Color.red(accentColor);
            int accentG = Color.green(accentColor);
            int accentB = Color.blue(accentColor);

            int index = 0;
            for (int row = 0; row < rows; row++) {
                int top = row * tilePx;
                int bottom = Math.min(h, top + tilePx);

                for (int col = 0; col < cols; col++) {
                    int left = col * tilePx;
                    int right = Math.min(w, left + tilePx);

                    float threshold = thresholds[index++];
                    float local = progress - threshold;

                    float alpha01;
                    if (local <= 0f) {
                        alpha01 = 1f;
                    } else if (local >= 0.16f) {
                        alpha01 = 0f;
                    } else {
                        float t = local / 0.16f;
                        alpha01 = 1f - (t * t * (3f - 2f * t));
                    }

                    if (alpha01 <= 0.01f) continue;

                    int alpha = (int) (baseAlpha * alpha01);
                    if (((row + col) & 7) == 0) {
                        paint.setColor(Color.argb(alpha, accentR, accentG, accentB));
                    } else if (((row + col) & 3) == 0) {
                        paint.setColor(Color.argb(alpha, 52, 46, 44));
                    } else {
                        paint.setColor(Color.argb(alpha, fillR, fillG, fillB));
                    }

                    rect.set(left, top, right, bottom);
                    canvas.drawRect(rect, paint);
                }
            }
        }
    }
}
