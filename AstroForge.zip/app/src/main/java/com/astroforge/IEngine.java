package com.astroforge;

public interface IEngine {

    void addBody(BodySpec body);

    void start();

    void stop();

    boolean isRunning();
}
