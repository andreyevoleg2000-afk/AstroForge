package com.astroforge;

/**
 * Физические параметры объекта. Все единицы — СИ.
 * Обычный неизменяемый класс (без record) для совместимости с AIDE Plus.
 */
public final class PlanetParams {

    public final double massKg;
    public final double radiusM;
    public final double coreRadiusM;
    public final double densityKgM3;
    public final double heatFluxWm2;
    public final double rotationPeriodHours;
    public final double dipoleFraction;
    public final double calibrationFactor;

    public PlanetParams(
		double massKg,
		double radiusM,
		double coreRadiusM,
		double densityKgM3,
		double heatFluxWm2,
		double rotationPeriodHours,
		double dipoleFraction,
		double calibrationFactor
    ) {
        if (!Double.isFinite(massKg) || massKg <= 0.0) {
            throw new MagnetoException("massKg должен быть положительным конечным числом.");
        }

        if (!Double.isFinite(radiusM) || radiusM <= 0.0) {
            throw new MagnetoException("radiusM должен быть положительным конечным числом.");
        }

        if (!Double.isFinite(coreRadiusM) || coreRadiusM <= 0.0) {
            throw new MagnetoException("coreRadiusM должен быть положительным конечным числом.");
        }

        if (coreRadiusM >= radiusM) {
            throw new MagnetoException("coreRadiusM должен быть меньше radiusM.");
        }

        if (!Double.isFinite(densityKgM3) || densityKgM3 <= 0.0) {
            throw new MagnetoException("densityKgM3 должен быть положительным конечным числом.");
        }

        if (!Double.isFinite(heatFluxWm2) || heatFluxWm2 < 0.0) {
            throw new MagnetoException("heatFluxWm2 должен быть неотрицательным конечным числом.");
        }

        if (!Double.isFinite(rotationPeriodHours) || rotationPeriodHours < 0.0) {
            throw new MagnetoException("rotationPeriodHours должен быть неотрицательным конечным числом.");
        }

        if (!Double.isFinite(dipoleFraction) || dipoleFraction < 0.0 || dipoleFraction > 1.0) {
            throw new MagnetoException("dipoleFraction должен быть в диапазоне [0..1].");
        }

        if (!Double.isFinite(calibrationFactor) || calibrationFactor <= 0.0) {
            throw new MagnetoException("calibrationFactor должен быть положительным конечным числом.");
        }

        this.massKg = massKg;
        this.radiusM = radiusM;
        this.coreRadiusM = coreRadiusM;
        this.densityKgM3 = densityKgM3;
        this.heatFluxWm2 = heatFluxWm2;
        this.rotationPeriodHours = rotationPeriodHours;
        this.dipoleFraction = dipoleFraction;
        this.calibrationFactor = calibrationFactor;
    }
}
