package com.astroforge;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Результат симуляции на временном интервале.
 */
public final class SimulationResult {

    public final PlanetParams params;
    public final SimulationConfig config;
    public final List<SimulationPoint> points;

    public SimulationResult(
		PlanetParams params,
		SimulationConfig config,
		List<SimulationPoint> points
    ) {
        if (params == null) {
            throw new MagnetoException("PlanetParams не может быть null.");
        }

        if (config == null) {
            throw new MagnetoException("SimulationConfig не может быть null.");
        }

        if (points == null) {
            throw new MagnetoException("Список точек симуляции не может быть null.");
        }

        this.params = params;
        this.config = config;
        this.points = Collections.unmodifiableList(new ArrayList<SimulationPoint>(points));

        if (this.points.size() != config.steps) {
            throw new MagnetoException(
				"Количество точек симуляции не совпадает с config.steps: " +
				this.points.size() + " != " + config.steps
            );
        }
    }

    public int pointCount() {
        return points.size();
    }

    public SimulationPoint first() {
        return points.get(0);
    }

    public SimulationPoint last() {
        return points.get(points.size() - 1);
    }
}
