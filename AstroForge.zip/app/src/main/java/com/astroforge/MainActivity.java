package com.astroforge;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.Manifest;
import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.ViewTreeObserver;
import java.util.concurrent.CountDownLatch;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.Surface;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/**
 * AstroForge — заготовка интерфейса астрофизического калькулятора.
 * Все кнопки — пустышки (заглушки на будущее), реальной логики внутри нет.
 * Так как minSdk = 33, весь код ниже опирается на Outline.setPath() для
 * невыпуклых фигур клипа (разрешено для клипа начиная с API 30) БЕЗ
 * проверок Build.VERSION — он гарантированно доступен на любом устройстве,
 * куда попадёт это приложение.
 */
public class MainActivity extends Activity {

    // Идентификаторы кнопок нижнего бара
    private static final int ID_AI = 0;
    private static final int ID_NOTES = 1;
    private static final int ID_CALC = 2;
    private static final int ID_PLANET = 3;
    private static final int ID_SETTINGS = 4;
    private static final int ID_NONE = -1; // нажатие на панельку (не на нижний бар)

    private static final String TAG_NOTES_SHORTCUT = "cosmic_notes_shortcut";
    private static final String TAG_CAMERA_SHORTCUT = "cosmic_camera_shortcut";
    private static final String TAG_DEV_PLAQUE = "dev_plaque";
    private static final int REQUEST_CAMERA_PERMISSION = 4101;

    private String[] panelNames;
    private String[] panelDescriptions;
    private FrameLayout rootContainer;
    private int baseUiChildCount = 0;
    private int lastBuiltOrientation = Configuration.ORIENTATION_UNDEFINED;
    private FrameLayout portraitUiContainer;
    private FrameLayout landscapeUiContainer;
    private FrameLayout uiBuildTarget;
    private boolean baseUiCreated = false;
    private boolean landscapeUiActive = false;

    // Keep the localization observer installed once. Layout-only animations must not
    // force a full-tree localization pass every frame.
    private ViewTreeObserver.OnGlobalLayoutListener localizationLayoutListener;
    private boolean localizationObserverInstalled = false;
    private int lastLocalizedRootChildCount = -1;
    private View lastLocalizedRootTopChild;
    private String lastLocalizedLanguage = "";

    // --- состояние нижнего бара (только для портретной ориентации) ---
    private final int[] defaultSlot = {2, 0, 1, 3, 4};
    private int[] currentSlot = new int[5];
    private int currentCenterId = ID_AI;
    private View[] navButtons = new View[5];
    private FrameLayout[] navSlotHolders = new FrameLayout[5];
    private TextView selectedFunctionPill;
    private Typeface appTypeface;

    // --- Настройки / тактильный отклик / темы / эксперименты ---
    private static final String PREFS_NAME = "astroforge_prefs";
    private static final String KEY_HAPTIC = "haptic_enabled";
    private static final String KEY_LANGUAGE = "language";
    private static final String KEY_CUSTOM_KEYBOARD = "custom_keyboard_enabled";
    private static final String TAG_SETTINGS_OVERLAY = "settings_overlay";
    private static final String TAG_THEME_SELECTOR = "theme_selector";

    private boolean hapticEnabled = true;
    private boolean customKeyboardEnabled = false;
    private String language = Localization.LANG_RU;
    private boolean settingsOpen = false;
    private View settingsOverlayView;
    private LinearLayout settingsButtonsColumn;
    private View hapticExpandPanel;
    private boolean hapticPanelExpanded = false;

    private AstrophysicalReferenceWindow referenceWindow;
    private CosmicCameraWindow cosmicCameraWindow;
    private boolean pendingCameraOpen = false;

    // Базовые цвета OMEGA
    private static final int COLOR_DARK_PANEL = Color.parseColor("#2F2F2F");
    private static final int COLOR_DARK_BAR = Color.parseColor("#242424");
    private static final int COLOR_DARK_BORDER = Color.parseColor("#404040");
    private static final int COLOR_TEXT_NEAR_WHITE = Color.parseColor("#E3E1DE");
    private static final int COLOR_ACCENT_PEACH_CLAY = Color.parseColor("#D58B5A");
    private static final int COLOR_RIGHT_PANEL = Color.parseColor("#2D2D2D");
    private static final int COLOR_PILL_FILL = Color.parseColor("#2E2E2E");
    private static final int COLOR_COFFEE_PANEL = Color.parseColor("#483C32");
    private static final int COLOR_COFFEE_BORDER = Color.parseColor("#5C4E43");

    private static final int PANEL_ROW_HEIGHT_LANDSCAPE_DP = 56;
    private static final int PANEL_ROW_HEIGHT_PORTRAIT_DP = 60;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setDecorFitsSystemWindows(false);
        setContentView(R.layout.main);
        rootContainer = findViewById(R.id.root_container);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        hapticEnabled = prefs.getBoolean(KEY_HAPTIC, true);
        customKeyboardEnabled = prefs.getBoolean(KEY_CUSTOM_KEYBOARD, false);
        language = prefs.getString(KEY_LANGUAGE, Localization.LANG_RU);
        Localization.setLanguage(language);

        initTypography();
        enterFullscreenMode();
        preparePanelNamesParallel();

        panelDescriptions = new String[]{
			"Показывает, с какой скоростью объект движется по орбите вокруг центрального тела и как эта скорость зависит от массы и расстояния.",
			"Рассчитывает длительность одного оборота планеты вокруг звезды — то есть, сколько длится её год.",
			"Определяет диапазон расстояний от звезды, где на поверхности планеты может существовать жидкая вода.",
			"Помогает оценить массу планеты по её радиусу, плотности и другим известным параметрам.",
			"Вычисляет радиус планеты — то есть, насколько велика она по размеру.",
			"Показывает, насколько плотно упаковано вещество планеты, то есть её массу на единицу объёма.",
			"Рассчитывает силу тяжести на поверхности планеты — с какой силой она притягивает объекты.",
			"Оценивает, насколько стабильна гравитация планеты для потенциальной жизни и атмосферы.",
			"Оценивает наличие и силу магнитного поля планеты, которое защищает её от космического излучения.",
			"Индекс схожести с Землёй — показывает, насколько условия на планете напоминают земные.",
			"Оценивает потенциальную возможность существования жизни на планете по совокупности её параметров.",
			"Рассчитывает минимальное расстояние, ближе которого спутник разрушается приливными силами планеты.",
			"Описывает возможный состав и плотность атмосферы планеты на основе её массы и температуры.",
			"Запускает Orbital Lab прямо внутри AstroForge: создавайте планеты и звёзды, задавайте физические параметры и наблюдайте за движением и столкновениями в 3D.",
			"Рассчитывает идеальную круговую орбиту по простой ньютоновской формуле: орбитальную скорость и период из массы центрального тела и расстояния."
        };

        buildUi();
        registerBackCallback();
        installLocalizationObserver();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // The current tree already reacts to size changes through normal layout.
        // Rebuild only when the orientation-specific structure actually changes.
        if (newConfig.orientation != lastBuiltOrientation) {
            if (cosmicCameraWindow != null && cosmicCameraWindow.isOpen()) {
                cosmicCameraWindow.close();
                cosmicCameraWindow = null;
                applyContentBlur(false);
            }
            buildUi();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        enterFullscreenMode();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            enterFullscreenMode();
        }
    }

    private void enterFullscreenMode() {
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        getWindow().setDecorFitsSystemWindows(false);
        requestHighRefreshRate();

        View decorView = getWindow().getDecorView();
        WindowInsetsController controller = decorView.getWindowInsetsController();
        if (controller != null) {
            controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
            controller.setSystemBarsBehavior(
				WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            );
        }
    }

    private void registerBackCallback() {
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
					OnBackInvokedDispatcher.PRIORITY_DEFAULT,
					new OnBackInvokedCallback() {
						@Override
						public void onBackInvoked() {
							MainActivity.this.onBackPressed();
						}
					}
                );
            } catch (Throwable ignored) {
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (rootContainer == null) return;

        View themeSel = rootContainer.findViewWithTag(TAG_THEME_SELECTOR);
        if (themeSel != null) {
            closeThemeSelectorIfOpen();
            return;
        }
        if (referenceWindow != null && referenceWindow.isOpen()) {
            closeReferenceWindow();
            return;
        }
        if (cosmicCameraWindow != null && cosmicCameraWindow.isOpen()) {
            cosmicCameraWindow.close();
            cosmicCameraWindow = null;
            applyContentBlur(false);
            return;
        }
        if (settingsOpen) {
            closeSettingsPanel();
            return;
        }

        int count = rootContainer.getChildCount();
        if (count > baseUiChildCount) {
            View top = rootContainer.getChildAt(count - 1);
            if (top != null) {
                top.performClick();
            }
        }
    }

    // =========================================================
    //  Сборка интерфейса
    // =========================================================
    private void buildUi() {
        int orientation = getResources().getConfiguration().orientation;
        lastBuiltOrientation = orientation;
        if (!baseUiCreated) {
            createPersistentBaseUi();
        }
        applyOrientationVisibility(orientation);
    }

    /**
     * Creates both orientation layouts once. Rotation switches visibility instead of
     * destroying and rebuilding hundreds of Views, drawables and listeners.
     */
    private void createPersistentBaseUi() {
        currentCenterId = ID_AI;
        System.arraycopy(defaultSlot, 0, currentSlot, 0, 5);
        navButtons = new View[5];
        navSlotHolders = new FrameLayout[5];
        selectedFunctionPill = null;
        settingsOpen = false;
        settingsOverlayView = null;
        settingsButtonsColumn = null;
        hapticExpandPanel = null;
        hapticPanelExpanded = false;
        referenceWindow = null;
        cosmicCameraWindow = null;
        pendingCameraOpen = false;

        // The XML root starts empty. Keep its background and both layout variants
        // alive for the whole Activity lifetime.
        ImageView backgroundView = new ImageView(this);
        backgroundView.setImageResource(R.drawable.background);
        backgroundView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        rootContainer.addView(backgroundView, matchParentFrameLp());

        portraitUiContainer = new FrameLayout(this);
        landscapeUiContainer = new FrameLayout(this);
        rootContainer.addView(portraitUiContainer, matchParentFrameLp());
        rootContainer.addView(landscapeUiContainer, matchParentFrameLp());

        uiBuildTarget = portraitUiContainer;
        buildPortraitUi();

        uiBuildTarget = landscapeUiContainer;
        buildLandscapeUi();
        uiBuildTarget = null;

        addNotesShortcutButton();
        baseUiChildCount = rootContainer.getChildCount();
        baseUiCreated = true;
    }

    private void applyOrientationVisibility(int orientation) {
        if (portraitUiContainer == null || landscapeUiContainer == null) return;
        boolean landscape = orientation == Configuration.ORIENTATION_LANDSCAPE;
        boolean changed = landscape != landscapeUiActive;

        portraitUiContainer.setVisibility(landscape ? View.GONE : View.VISIBLE);
        landscapeUiContainer.setVisibility(landscape ? View.VISIBLE : View.GONE);
        landscapeUiActive = landscape;

        // Preserve the original behavior: switching orientation resets the moving
        // navigation buttons, but it no longer destroys the actual View instances.
        if (changed && navSlotHolders != null && navSlotHolders[0] != null) {
            currentCenterId = ID_AI;
            System.arraycopy(defaultSlot, 0, currentSlot, 0, 5);
            placeButtonsInSlots();
            updateSelectedFunctionPill(getFunctionLabel(ID_AI));
        }
    }

    // ---------- ПОРТРЕТ ----------
    private void buildPortraitUi() {
        SmoothScrollView scrollView = new SmoothScrollView(this);
        configureScrollView(scrollView);
        scrollView.setClipToPadding(false);

        LinearLayout panelsLayout = new LinearLayout(this);
        panelsLayout.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        panelsLayout.setPadding(pad, pad, pad, pad + dp(100));

        for (int i = 0; i < panelNames.length; i++) {
            panelsLayout.addView(createPanelItem(i, panelNames[i], panelDescriptions[i], false));
        }

        scrollView.addView(
			panelsLayout,
			new ScrollView.LayoutParams(
				ScrollView.LayoutParams.MATCH_PARENT,
				ScrollView.LayoutParams.WRAP_CONTENT
			)
        );
        uiBuildTarget.addView(scrollView, matchParentFrameLp());

        FrameLayout barRoot = buildBottomBar();
        FrameLayout.LayoutParams barLp = new FrameLayout.LayoutParams(
			FrameLayout.LayoutParams.MATCH_PARENT,
			dp(94)
        );
        barLp.gravity = Gravity.BOTTOM;
        uiBuildTarget.addView(barRoot, barLp);

        selectedFunctionPill = createSelectedFunctionPill(getFunctionLabel(currentCenterId));
        FrameLayout.LayoutParams pillLp = new FrameLayout.LayoutParams(
			FrameLayout.LayoutParams.WRAP_CONTENT,
			FrameLayout.LayoutParams.WRAP_CONTENT
        );
        pillLp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        pillLp.bottomMargin = dp(108);
        uiBuildTarget.addView(selectedFunctionPill, pillLp);

        placeButtonsInSlots();
    }

    private void addNotesShortcutButton() {
        if (rootContainer == null) return;

        View existingNotes = rootContainer.findViewWithTag(TAG_NOTES_SHORTCUT);
        if (existingNotes != null) rootContainer.removeView(existingNotes);

        View existingCamera = rootContainer.findViewWithTag(TAG_CAMERA_SHORTCUT);
        if (existingCamera != null) rootContainer.removeView(existingCamera);

        FrameLayout.LayoutParams notesLp = new FrameLayout.LayoutParams(dp(52), dp(52));
        notesLp.gravity = Gravity.TOP | Gravity.END;
        notesLp.topMargin = dp(14);
        notesLp.rightMargin = dp(14);

        FrameLayout.LayoutParams cameraLp = new FrameLayout.LayoutParams(dp(52), dp(52));
        cameraLp.gravity = Gravity.TOP | Gravity.END;
        cameraLp.topMargin = dp(14);
        cameraLp.rightMargin = dp(74);

        FrameLayout notesButton = createTopShortcutButton(TAG_NOTES_SHORTCUT, "🗂️");
        notesButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					performAppHaptic(v);
					openNotesShelf();
				}
			});
        rootContainer.addView(notesButton, notesLp);

        FrameLayout cameraButton = createTopShortcutButton(TAG_CAMERA_SHORTCUT, "📸");
        cameraButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					performAppHaptic(v);
					openCosmicCamera();
				}
			});
        rootContainer.addView(cameraButton, cameraLp);
    }

    private FrameLayout createTopShortcutButton(String tag, String emoji) {
        FrameLayout button = new FrameLayout(this);
        button.setTag(tag);
        button.setBackground(createRoundedRect(dp(18), COLOR_DARK_PANEL, COLOR_COFFEE_BORDER));
        button.setAlpha(0.97f);

        TextView icon = new DigitTextView(this);
        icon.setText(emoji);
        styleText(icon, 20f);
        icon.setGravity(Gravity.CENTER);
        button.addView(icon, matchParentFrameLp());

        applyRipple(button);
        button.setClickable(true);
        button.setFocusable(true);
        return button;
    }

    private FrameLayout buildBottomBar() {
        final float bumpReserve = dp(16);
        FrameLayout barRoot = new FrameLayout(this);

        final Path outlinePath = new Path();
        final int[] outlineSize = {-1, -1};
        barRoot.setOutlineProvider(new ViewOutlineProvider() {
				@Override
				public void getOutline(View view, Outline outline) {
					int w = view.getWidth();
					int h = view.getHeight();
					if (w <= 0 || h <= 0) return;
                    if (w != outlineSize[0] || h != outlineSize[1]) {
                        updateBumpPath(outlinePath, w, h, bumpReserve);
                        outlineSize[0] = w;
                        outlineSize[1] = h;
                    }
					outline.setPath(outlinePath);
				}
			});
        barRoot.setClipToOutline(true);

        View background = new View(this);
        background.setBackgroundColor(themeBarColor());
        barRoot.addView(background, matchParentFrameLp());

        TopBorderView topBorder = new TopBorderView(bumpReserve);
        barRoot.addView(topBorder, matchParentFrameLp());

        LinearLayout slotsRow = new LinearLayout(this);
        slotsRow.setOrientation(LinearLayout.HORIZONTAL);
        FrameLayout.LayoutParams slotsRowLp = matchParentFrameLp();
        slotsRowLp.topMargin = (int) bumpReserve;
        barRoot.addView(slotsRow, slotsRowLp);

        for (int slot = 0; slot < 5; slot++) {
            FrameLayout holder = new FrameLayout(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
				0, LinearLayout.LayoutParams.MATCH_PARENT, 1f);
            if (slot == 2) holder.setTranslationY(-dp(9));
            slotsRow.addView(holder, lp);
            navSlotHolders[slot] = holder;
        }

        navButtons[ID_AI] = createNavButton(ID_AI, Localization.t("Режим ИИ"), "🪐", new String[]{"✨", "🛰️", "🌌"});
        navButtons[ID_NOTES] = createNavButton(ID_NOTES, Localization.t("Космические заметки"), "📝", new String[]{"🌠", "", "✍️"});
        navButtons[ID_CALC] = createNavButton(ID_CALC, Localization.t("Калькулятор"), "🧮", new String[]{"➗", "✖️", "➕"});
        navButtons[ID_PLANET] = createNavButton(ID_PLANET, Localization.t("Генератор планет"), "🎲", new String[]{"🪐", "🌍", "✨"});
        navButtons[ID_SETTINGS] = createNavButton(ID_SETTINGS, Localization.t("Настройки"), "⚙️", new String[]{"🔧", "️", ""});

        return barRoot;
    }

    private void updateBumpPath(Path path, int w, int h, float bumpReserve) {
        path.rewind();
        float corner = dp(22);
        float bumpHeight = dp(14);
        float bumpHalfWidth = w * 0.11f;
        float cx = w / 2f;

        path.moveTo(0, h);
        path.lineTo(0, bumpReserve + corner);
        path.quadTo(0, bumpReserve, corner, bumpReserve);
        path.lineTo(cx - bumpHalfWidth, bumpReserve);
        path.cubicTo(
			cx - bumpHalfWidth * 0.35f, bumpReserve,
			cx - bumpHalfWidth * 0.55f, bumpReserve - bumpHeight,
			cx, bumpReserve - bumpHeight
        );
        path.cubicTo(
			cx + bumpHalfWidth * 0.55f, bumpReserve - bumpHeight,
			cx + bumpHalfWidth * 0.35f, bumpReserve,
			cx + bumpHalfWidth, bumpReserve
        );
        path.lineTo(w - corner, bumpReserve);
        path.quadTo(w, bumpReserve, w, bumpReserve + corner);
        path.lineTo(w, h);
        path.close();
    }

    private void updateTopBorderPath(Path path, int w, float bumpReserve) {
        path.rewind();
        float corner = dp(22);
        float bumpHeight = dp(14);
        float bumpHalfWidth = w * 0.11f;
        float cx = w / 2f;

        path.moveTo(0, bumpReserve + corner);
        path.quadTo(0, bumpReserve, corner, bumpReserve);
        path.lineTo(cx - bumpHalfWidth, bumpReserve);
        path.cubicTo(
			cx - bumpHalfWidth * 0.35f, bumpReserve,
			cx - bumpHalfWidth * 0.55f, bumpReserve - bumpHeight,
			cx, bumpReserve - bumpHeight
        );
        path.cubicTo(
			cx + bumpHalfWidth * 0.55f, bumpReserve - bumpHeight,
			cx + bumpHalfWidth * 0.35f, bumpReserve,
			cx + bumpHalfWidth, bumpReserve
        );
        path.lineTo(w - corner, bumpReserve);
        path.quadTo(w, bumpReserve, w, bumpReserve + corner);
    }

    private class TopBorderView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final float bumpReserve;
        private int cachedWidth = -1;

        TopBorderView(float bumpReserve) {
            super(MainActivity.this);
            this.bumpReserve = bumpReserve;
            paint.setColor(themeAccentColor());
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(3f);
            paint.setStrokeCap(Paint.Cap.BUTT);
            paint.setStrokeJoin(Paint.Join.ROUND);
            setBackgroundColor(Color.TRANSPARENT);
            setWillNotDraw(false);
            setClickable(false);
            setFocusable(false);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth();
            if (w <= 0) return;
            if (w != cachedWidth) {
                updateTopBorderPath(path, w, bumpReserve);
                cachedWidth = w;
            }
            canvas.save();
            canvas.translate(0f, 0.5f);
            canvas.drawPath(path, paint);
            canvas.restore();
        }
    }

    private TextView createSelectedFunctionPill(String label) {
        TextView tv = new DigitTextView(this);
        tv.setText(label);
        styleText(tv, 15f);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(22), dp(12), dp(22), dp(12));
        tv.setMinHeight(dp(46));
        tv.setTextColor(COLOR_TEXT_NEAR_WHITE);

        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(23));
        bg.setColor(COLOR_PILL_FILL);
        bg.setStroke(3, themeAccentColor());
        tv.setBackground(bg);
        tv.setAlpha(1f);
        tv.setClickable(false);
        tv.setFocusable(false);
        return tv;
    }

    private void updateSelectedFunctionPill(String label) {
        if (selectedFunctionPill != null) {
            selectedFunctionPill.setText(label);
        }
    }

    private String getFunctionLabel(int id) {
        switch (id) {
            case ID_AI: return Localization.t("Режим ИИ");
            case ID_NOTES: return Localization.t("Космические заметки");
            case ID_CALC: return Localization.t("Калькулятор");
            case ID_PLANET: return Localization.t("Генератор планет");
            case ID_SETTINGS: return Localization.t("Настройки");
            default: return Localization.t("Режим ИИ");
        }
    }

    private void placeButtonsInSlots() {
        for (int id = 0; id < 5; id++) {
            reparent(navButtons[id], navSlotHolders[currentSlot[id]]);
        }
    }

    // ---------- АЛЬБОМ ----------
    private void buildLandscapeUi() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        FrameLayout leftSide = new FrameLayout(this);
        SmoothScrollView scrollView = new SmoothScrollView(this);
        configureScrollView(scrollView);
        LinearLayout panelsLayout = new LinearLayout(this);
        panelsLayout.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        panelsLayout.setPadding(pad, pad, pad, pad);
        for (int i = 0; i < panelNames.length; i++) {
            panelsLayout.addView(createPanelItem(i, panelNames[i], panelDescriptions[i], true));
        }
        scrollView.addView(panelsLayout, new ScrollView.LayoutParams(
							   ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        leftSide.addView(scrollView, matchParentFrameLp());

        View divider = new View(this);
        divider.setBackgroundColor(Color.parseColor("#CCE3E3E3"));

        LinearLayout rightSide = new LinearLayout(this);
        rightSide.setOrientation(LinearLayout.VERTICAL);
        rightSide.setBackgroundColor(COLOR_RIGHT_PANEL);
        int padR = dp(10);
        rightSide.setPadding(padR, padR, padR, padR);
        rightSide.addView(createBigNavButton(ID_AI, "🪐", new String[]{"✨", "🛰️", "🌌"}, getString(R.string.nav_ai)));
        rightSide.addView(createBigNavButton(ID_NOTES, "📝", new String[]{"🌠", "📓", "️"}, getString(R.string.nav_notes)));
        rightSide.addView(createBigNavButton(ID_CALC, "🧮", new String[]{"➗", "✖️", "➕"}, getString(R.string.nav_calc)));
        rightSide.addView(createBigNavButton(ID_PLANET, "🎲", new String[]{"🪐", "🌍", "✨"}, getString(R.string.nav_planet)));
        rightSide.addView(createBigNavButton(ID_SETTINGS, "⚙️", new String[]{"🔧", "🛠️", "🔩"}, getString(R.string.nav_settings)));

        row.addView(leftSide, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 0.68f));
        row.addView(divider, new LinearLayout.LayoutParams(dp(2), LinearLayout.LayoutParams.MATCH_PARENT));
        row.addView(rightSide, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 0.32f));
        uiBuildTarget.addView(row, matchParentFrameLp());
    }

    // =========================================================
    //  Кнопки-панельки
    // =========================================================
    private View createSimplePanelButtonContent(final int panelIndex, String name) {
        TextView tv = new DigitTextView(this);
        tv.setText(name);
        styleText(tv, 16f);
        tv.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        int padH = dp(20);
        int padV = dp(18);
        tv.setPadding(padH, padV, padH, padV);
        tv.setBackground(createRoundedRect(dp(18), themePanelColor(), themeBorderColor()));
        applyRipple(tv);
        tv.setClickable(true);
        tv.setFocusable(true);
        tv.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					onPanelPressed(panelIndex, v);
				}
			});
        return tv;
    }

    private View createBlurredPanelButtonContent(final int panelIndex, String name) {
        FrameLayout container = new FrameLayout(this);
        container.setBackground(createRoundedRect(dp(18), themePanelColor(), themeBorderColor()));
        container.setClipToOutline(true);

        TextView tv = new DigitTextView(this);
        tv.setText(name);
        styleText(tv, 15f);
        tv.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        int padH = dp(18);
        int padV = dp(16);
        tv.setPadding(padH, padV, padH, padV);
        container.addView(tv, matchParentFrameLp());

        applyRipple(container);
        container.setClickable(true);
        container.setFocusable(true);
        container.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					onPanelPressed(panelIndex, v);
				}
			});
        return container;
    }

    private View createPanelItem(final int panelIndex, String name, String description, final boolean landscapeStyle) {
        LinearLayout itemContainer = new LinearLayout(this);
        itemContainer.setOrientation(LinearLayout.VERTICAL);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        View mainButton = landscapeStyle
			? createBlurredPanelButtonContent(panelIndex, name)
			: createSimplePanelButtonContent(panelIndex, name);

        LinearLayout.LayoutParams mainLp = new LinearLayout.LayoutParams(
			0, landscapeStyle ? LinearLayout.LayoutParams.MATCH_PARENT : LinearLayout.LayoutParams.WRAP_CONTENT, 5f);
        row.addView(mainButton, mainLp);

        final FrameLayout chevronToggle = createChevronToggle();
        LinearLayout.LayoutParams chevronLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f);
        chevronLp.leftMargin = dp(8);
        row.addView(chevronToggle, chevronLp);

        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT,
			landscapeStyle ? dp(PANEL_ROW_HEIGHT_LANDSCAPE_DP) : LinearLayout.LayoutParams.WRAP_CONTENT);
        itemContainer.addView(row, rowLp);

        int rowHeightDp = landscapeStyle ? PANEL_ROW_HEIGHT_LANDSCAPE_DP : PANEL_ROW_HEIGHT_PORTRAIT_DP;
        final int expandedHeightPx = dp(rowHeightDp * 3);
        final View descriptionPanel = createDescriptionPanel(description);

        LinearLayout.LayoutParams descLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0);
        descLp.topMargin = dp(8);
        itemContainer.addView(descriptionPanel, descLp);

        final View chevronIcon = chevronToggle.getChildAt(0);
        final boolean[] expanded = new boolean[]{false};

        chevronToggle.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					performAppHaptic(v);
					toggleDescriptionPanel(descriptionPanel, chevronIcon, expanded, expandedHeightPx);
				}
			});

        LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        itemLp.bottomMargin = landscapeStyle ? dp(10) : dp(12);
        itemContainer.setLayoutParams(itemLp);
        return itemContainer;
    }

    private FrameLayout createChevronToggle() {
        FrameLayout container = new FrameLayout(this);
        container.setBackground(createRoundedRect(dp(14), themePanelColor(), themeBorderColor()));

        ChevronDownView chevron = new ChevronDownView();
        FrameLayout.LayoutParams chevronLp = new FrameLayout.LayoutParams(dp(18), dp(18));
        chevronLp.gravity = Gravity.CENTER;
        container.addView(chevron, chevronLp);

        applyRipple(container);
        container.setClickable(true);
        container.setFocusable(true);
        return container;
    }

    private class ChevronDownView extends View {
        private final Paint paint;
        private final Path path = new Path();
        private int cachedWidth = -1;
        private int cachedHeight = -1;

        ChevronDownView() {
            super(MainActivity.this);
            paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setColor(COLOR_ACCENT_PEACH_CLAY);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            setWillNotDraw(false);
            setClickable(false);
            setFocusable(false);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;

            if (w != cachedWidth || h != cachedHeight) {
                float cx = w / 2f;
                float cy = h / 2f;
                float armX = w * 0.28f;
                float armY = h * 0.16f;
                path.rewind();
                path.moveTo(cx - armX, cy - armY);
                path.lineTo(cx, cy + armY);
                path.lineTo(cx + armX, cy - armY);
                cachedWidth = w;
                cachedHeight = h;
            }
            canvas.drawPath(path, paint);
        }
    }

    private View createDescriptionPanel(String description) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(createRoundedRect(dp(16), COLOR_COFFEE_PANEL, COLOR_COFFEE_BORDER));
        panel.setClipToOutline(true);

        int padH = dp(16);
        int padV = dp(14);
        panel.setPadding(padH, padV, padH, padV);

        TextView desc = new DigitTextView(this);
        desc.setText(description);
        styleText(desc, 14f);
        panel.addView(desc, new LinearLayout.LayoutParams(
						  LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView more = new DigitTextView(this);
        more.setText("Подробнее");
        styleText(more, 13f);
        more.setTextColor(COLOR_ACCENT_PEACH_CLAY);
        more.setGravity(Gravity.CENTER);
        int moreH = dp(16);
        int moreV = dp(8);
        more.setPadding(moreH, moreV, moreH, moreV);
        more.setBackground(createRoundedRect(dp(14), Color.TRANSPARENT, COLOR_ACCENT_PEACH_CLAY));
        applyRipple(more);
        more.setClickable(true);
        more.setFocusable(true);
        more.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) { /* Заглушка */ }
			});

        LinearLayout.LayoutParams moreLp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        moreLp.topMargin = dp(12);
        panel.addView(more, moreLp);
        return panel;
    }

    private void toggleDescriptionPanel(final View panel, final View chevronIcon, final boolean[] expandedState, final int expandedHeightPx) {
        boolean expand = !expandedState[0];
        expandedState[0] = expand;

        chevronIcon.animate().rotation(expand ? 180f : 0f).setDuration(180).start();

        final ViewGroup.LayoutParams lp = panel.getLayoutParams();
        int startHeight = Math.max(lp.height, 0);
        int endHeight = expand ? expandedHeightPx : 0;
        if (startHeight == endHeight) return;

        ValueAnimator animator = ValueAnimator.ofInt(startHeight, endHeight);
        animator.setDuration(220);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
				@Override
				public void onAnimationUpdate(ValueAnimator animation) {
					lp.height = ((Integer) animation.getAnimatedValue()).intValue();
					panel.setLayoutParams(lp);
				}
			});
        animator.start();
    }

    private void onPanelPressed(int panelIndex, View v) {
        performAppHaptic(v);
        switch (panelIndex) {
            case 0: openVelocityPanel(); break;
            case 1: openYearOnObjectPanel(); break;
            case 2: openHabitableZonePanel(); break;
            case 3: openMassPanel(); break;
            case 4: openRadiusPanel(); break;
            case 6: openGravityAccelerationPanel(); break;
            case 5: openDensityPanel(); break;
            case 8: openMagneticFieldPanel(); break;
            case 9: openEsiPanel(); break;
            case 10: openAstrobiologicalAnalysisPanel(); break;
            case 11: openRocheLimitPanel(); break;
            case 7: openGravityStabilityPanel(); break;
            case 13: startActivity(new Intent(MainActivity.this, OrbitalLabActivity.class)); break;
            case 14:
                // === НОВОЕ: окно пока не должно открываться — выдаём плашку о разработке ===
                showDevPlaque(Localization.t(
								  "⚠️ Это окно открылось из-за неправильной работы кода. «Идеальная круговая орбита» пока в разработке — скоро раздел будет использоваться!"));
                break;
            default: break;
        }
    }

    // === НОВОЕ: плашка-предупреждение о разделе в разработке ===
    private void showDevPlaque(String message) {
        if (rootContainer == null) return;

        View existing = rootContainer.findViewWithTag(TAG_DEV_PLAQUE);
        if (existing != null) rootContainer.removeView(existing);

        final TextView plaque = new DigitTextView(this);
        plaque.setTag(TAG_DEV_PLAQUE);
        plaque.setText(message);
        styleText(plaque, 14f);
        plaque.setGravity(Gravity.CENTER);
        int padH = dp(18);
        int padV = dp(14);
        plaque.setPadding(padH, padV, padH, padV);
        plaque.setBackground(createRoundedRect(dp(18), COLOR_COFFEE_PANEL, COLOR_ACCENT_PEACH_CLAY));
        plaque.setAlpha(0f);
        plaque.setClickable(false);
        plaque.setFocusable(false);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
			FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.topMargin = dp(24);
        lp.leftMargin = dp(24);
        lp.rightMargin = dp(24);
        rootContainer.addView(plaque, lp);
        plaque.bringToFront();

        plaque.animate().alpha(1f).setDuration(220).start();
        plaque.postDelayed(new Runnable() {
				@Override
				public void run() {
					plaque.animate().alpha(0f).setDuration(260).setListener(new AnimatorListenerAdapter() {
							@Override
							public void onAnimationEnd(Animator animation) {
								if (rootContainer != null && plaque.getParent() == rootContainer) {
									rootContainer.removeView(plaque);
								}
							}
						}).start();
				}
			}, 3400);
    }

    private void openAiModeWindow() {
        try {
            if (rootContainer == null) return;
            AiModeWindow.show(this, rootContainer, appTypeface, appTypeface);
        } catch (Throwable t) {
            Toast.makeText(this, "Не удалось открыть режим ИИ.", Toast.LENGTH_SHORT).show();
        }
    }

    private void openCalculatorWindow() {
        try {
            if (rootContainer == null) return;
            CalculatorWindow.show(this, rootContainer, appTypeface, appTypeface);
        } catch (Throwable t) {
            Toast.makeText(this, "Не удалось открыть калькулятор.", Toast.LENGTH_SHORT).show();
        }
    }

    private void openEsiPanel() {
        try {
            if (rootContainer == null) return;
            EsiPanel.show(this, rootContainer, appTypeface, appTypeface);
        } catch (Throwable t) {}
    }

    private void openRocheLimitPanel() {
        try {
            if (rootContainer == null) return;
            RocheLimitPanel.show(this, rootContainer, appTypeface, appTypeface);
        } catch (Throwable t) {}
    }

    private void openVelocityPanel() {
        try {
            if (rootContainer == null) return;
            VelocityPanel.show(this, rootContainer, appTypeface, appTypeface);
        } catch (Throwable t) {}
    }

    private void openYearOnObjectPanel() {
        try {
            if (rootContainer == null) return;
            YearOnObjectPanel.show(this, rootContainer, appTypeface, appTypeface);
        } catch (Throwable t) {}
    }

    private void openHabitableZonePanel() {
        try {
            if (rootContainer == null) return;
            HabitableZonePanel.show(this, rootContainer, appTypeface, appTypeface);
        } catch (Throwable t) {}
    }

    private void openMassPanel() {
        try {
            if (rootContainer == null) return;
            MassPanel.show(this, rootContainer, appTypeface, appTypeface);
        } catch (Throwable t) {}
    }

    private void openRadiusPanel() {
        try {
            if (rootContainer == null) return;
            RadiusPanel.show(this, rootContainer, appTypeface, appTypeface);
        } catch (Throwable t) {}
    }

    private void openDensityPanel() {
        try {
            if (rootContainer == null) return;
            DensityPanel.show(this, rootContainer, appTypeface, appTypeface);
        } catch (Throwable t) {}
    }

    private void openGravityStabilityPanel() {
        try {
            if (rootContainer == null) return;
            GravityStabilityPanel.show(this, rootContainer, appTypeface, appTypeface);
        } catch (Throwable t) {}
    }

    private void openAstrobiologicalAnalysisPanel() {
        try {
            if (rootContainer == null) return;
            AstrobiologicalAnalysisPanel.show(this, rootContainer, appTypeface, appTypeface);
        } catch (Throwable t) {}
    }

    private void openMagneticFieldPanel() {
        try {
            if (rootContainer == null) return;
            MagneticFieldPanel.show(this, rootContainer, appTypeface, appTypeface);
        } catch (Throwable t) {}
    }

    private void openGravityAccelerationPanel() {
        try {
            if (rootContainer == null) return;
            GravityAccelerationPanel.show(this, rootContainer, appTypeface, appTypeface);
        } catch (Throwable t) {}
    }

    private void openOrbitalPanel() {
        try {
            if (rootContainer == null) return;
            OrbitalPanel.show(this, rootContainer, appTypeface, appTypeface);
        } catch (Throwable t) {}
    }

    private void openCosmicNotesEditor() {
        try {
            if (rootContainer == null) return;
            CosmicNotesWindow.showEditor(this, rootContainer, appTypeface);
        } catch (Throwable t) {}
    }

    private void openNotesShelf() {
        try {
            if (rootContainer == null) return;
            CosmicNotesWindow.showShelf(this, rootContainer, appTypeface);
        } catch (Throwable t) {}
    }

    private void openCosmicCamera() {
        if (rootContainer == null) return;
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA)
			!= PackageManager.PERMISSION_GRANTED) {
            pendingCameraOpen = true;
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
            return;
        }
        if (cosmicCameraWindow != null && cosmicCameraWindow.isOpen()) return;

        applyContentBlur(true);
        cosmicCameraWindow = new CosmicCameraWindow(this, rootContainer, appTypeface, new Runnable() {
				@Override
				public void run() {
					cosmicCameraWindow = null;
					applyContentBlur(false);
				}
			});
        cosmicCameraWindow.show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            boolean shouldOpen = pendingCameraOpen;
            pendingCameraOpen = false;
            if (granted && shouldOpen) {
                openCosmicCamera();
            } else if (shouldOpen) {
                Toast.makeText(this, "Для Космической камеры нужен доступ к камере.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // =========================================================
    //  Кнопки нижнего бара (маленькие, портрет)
    // =========================================================
    private View createNavButton(final int id, final String label, String mainEmoji, String[] clusterEmojis) {
        FrameLayout container = new FrameLayout(this);
        container.setBackground(createRoundedRect(dp(18), themePanelColor(), themeBorderColor()));
        addFadedEmojiCluster(container, clusterEmojis);

        ImageView icon = new ImageView(this);
        icon.setImageBitmap(emojiToTintedBitmap(mainEmoji, dp(22), themeAccentColor()));
        FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(dp(30), dp(30));
        iconLp.gravity = Gravity.CENTER;
        container.addView(icon, iconLp);

        applyRipple(container);
        container.setClickable(true);
        container.setFocusable(true);
        container.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					onAnyButtonPressed(id, v);
					updateSelectedFunctionPill(getFunctionLabel(id));
				}
			});
        return container;
    }

    // =========================================================
    //  Большие кнопки-панельки нижнего бара (альбом)
    // =========================================================
    private View createBigNavButton(final int id, String mainEmoji, String[] clusterEmojis, String label) {
        FrameLayout container = new FrameLayout(this);
        container.setBackground(createRoundedRect(dp(18), themePanelColor(), themeAccentColor()));
        addFadedEmojiCluster(container, clusterEmojis);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.HORIZONTAL);
        content.setGravity(Gravity.CENTER_VERTICAL);
        int padH = dp(16);
        int padV = dp(14);
        content.setPadding(padH, padV, padH, padV);

        ImageView icon = new ImageView(this);
        icon.setImageBitmap(emojiToTintedBitmap(mainEmoji, dp(22), themeAccentColor()));
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(30), dp(30));
        iconLp.rightMargin = dp(12);
        content.addView(icon, iconLp);

        TextView tv = new DigitTextView(this);
        tv.setText(label);
        styleText(tv, 15f);
        content.addView(tv, new LinearLayout.LayoutParams(
							LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        container.addView(content, matchParentFrameLp());

        applyRipple(container);
        container.setClickable(true);
        container.setFocusable(true);
        container.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					onAnyButtonPressed(id, v);
				}
			});

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(64));
        lp.bottomMargin = dp(10);
        container.setLayoutParams(lp);
        return container;
    }

    // =========================================================
    //  Логика "кнопка занимает центр / возвращается на своё место"
    // =========================================================
    private void onAnyButtonPressed(int id, View v) {
        performAppHaptic(v);

        if (currentCenterId != ID_AI) {
            swapPositions(currentCenterId, ID_AI);
            currentCenterId = ID_AI;
        }

        if (id == ID_AI) {
            openAiModeWindow();
            return;
        }

        if (id == ID_NOTES) {
            openCosmicNotesEditor();
        }

        // === кнопка Калькулятор на нижнем баре открывает окно калькулятора ===
        if (id == ID_CALC) {
            openCalculatorWindow();
        }

        if (id == ID_SETTINGS) {
            if (id != ID_NONE && id != ID_AI) {
                swapPositions(id, currentCenterId);
                currentCenterId = id;
            }
            updateSelectedFunctionPill(getFunctionLabel(currentCenterId));
            openSettingsPanel();
            return;
        }

        if (id != ID_NONE && id != ID_AI) {
            swapPositions(id, currentCenterId);
            currentCenterId = id;
        }

        updateSelectedFunctionPill(getFunctionLabel(currentCenterId));
    }

    private void swapPositions(int idA, int idB) {
        if (landscapeUiActive || navSlotHolders[0] == null) return;
        int slotA = currentSlot[idA];
        int slotB = currentSlot[idB];
        currentSlot[idA] = slotB;
        currentSlot[idB] = slotA;
        crossFadeToSlot(navButtons[idA], navSlotHolders[slotB]);
        crossFadeToSlot(navButtons[idB], navSlotHolders[slotA]);
    }

    private void crossFadeToSlot(final View button, final FrameLayout newHolder) {
        button.animate().alpha(0f).setDuration(90).withEndAction(new Runnable() {
				@Override
				public void run() {
					reparent(button, newHolder);
					button.animate().alpha(1f).setDuration(140).start();
				}
			}).start();
    }

    private void reparent(View v, FrameLayout newParent) {
        ViewGroup old = (ViewGroup) v.getParent();
        if (old == newParent) return;
        if (old != null) old.removeView(v);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(46), dp(46));
        lp.gravity = Gravity.CENTER;
        newParent.addView(v, lp);
    }

    // =========================================================
    //  Тактильный отклик (вкл/выкл)
    // =========================================================
    private void performAppHaptic(View v) {
        if (hapticEnabled && v != null) HapticUtils.perform(v);
    }

    private void setHapticEnabled(boolean enabled) {
        hapticEnabled = enabled;
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putBoolean(KEY_HAPTIC, enabled).apply();
    }

    // === НОВОЕ: экспериментальная кастомная клавиатура ===
    private void setCustomKeyboardEnabled(boolean enabled) {
        customKeyboardEnabled = enabled;
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putBoolean(KEY_CUSTOM_KEYBOARD, enabled).apply();
    }

    // --- Тема ---
    private int themePanelColor() { return COLOR_DARK_PANEL; }
    private int themeBarColor() { return COLOR_DARK_BAR; }
    private int themeBorderColor() { return COLOR_DARK_BORDER; }
    private int themeAccentColor() { return COLOR_ACCENT_PEACH_CLAY; }

    private void closeSettingsPanelImmediate() {
        if (settingsOverlayView != null && rootContainer != null) rootContainer.removeView(settingsOverlayView);
        settingsOverlayView = null;
        settingsButtonsColumn = null;
        hapticExpandPanel = null;
        hapticPanelExpanded = false;
        settingsOpen = false;
        applyContentBlur(false);
    }

    private void closeThemeSelectorIfOpen() {
        if (rootContainer == null) return;
        View existing = rootContainer.findViewWithTag(TAG_THEME_SELECTOR);
        if (existing != null) rootContainer.removeView(existing);
    }

    // =========================================================
    //  Панель настроек
    // =========================================================
    private void openSettingsPanel() {
        if (settingsOpen || rootContainer == null) return;
        settingsOpen = true;
        hapticPanelExpanded = false;
        applyContentBlur(true);

        final FrameLayout overlay = new FrameLayout(this);
        overlay.setTag(TAG_SETTINGS_OVERLAY);
        overlay.setClickable(true);
        overlay.setFocusable(true);
        overlay.setBackgroundColor(Color.argb(90, 0, 0, 0));
        overlay.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					closeSettingsPanel();
				}
			});

        settingsButtonsColumn = new LinearLayout(this);
        settingsButtonsColumn.setOrientation(LinearLayout.VERTICAL);
        settingsButtonsColumn.setGravity(Gravity.CENTER_HORIZONTAL);
        settingsButtonsColumn.setClickable(true);

        String[] labels = {
			Localization.t("Тема"),
			Localization.t("Язык"),
			Localization.t("Вычисления"),
			Localization.t("Тактильный отклик"),
			Localization.t("Другие наши приложения"),
			Localization.t("О приложении"),
			Localization.t("Добавить виджет лунных фаз"),
			Localization.t("Справочник"),
			Localization.t("Экспериментальные функции")
        };

        final int btnH = dp(52);
        final int gap = dp(10);
        final int startOffset = dp(120);

        for (int i = 0; i < labels.length; i++) {
            final String label = labels[i];
            View btn;
            if (i == 0) btn = createSettingsThemeButton(label, btnH);
            else if (i == 1) btn = createSettingsLanguageButton(label, btnH);
            else if (i == 3) btn = createSettingsHapticButton(label, btnH);
            else if (i == 6) btn = createMoonWidgetButton(label, btnH);
            else if (i == 7) btn = createSettingsReferenceButton(label, btnH);
            else if (i == 8) btn = createSettingsExperimentalButton(label, btnH);
            else btn = createSettingsStubButton(label, btnH);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            if (i > 0) lp.topMargin = gap;
            btn.setLayoutParams(lp);
            btn.setTranslationY(startOffset);
            btn.setAlpha(0f);
            settingsButtonsColumn.addView(btn);
        }

        // === НОВОЕ: колонка настроек теперь в скролле, чтобы всё помещалось ===
        ScrollView settingsScroll = new ScrollView(this);
        settingsScroll.setFillViewport(true);
        settingsScroll.setVerticalScrollBarEnabled(false);
        settingsScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        settingsScroll.addView(settingsButtonsColumn, new ScrollView.LayoutParams(
								   ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        FrameLayout.LayoutParams colLp = new FrameLayout.LayoutParams(dp(290), FrameLayout.LayoutParams.MATCH_PARENT);
        colLp.gravity = Gravity.CENTER;
        overlay.addView(settingsScroll, colLp);

        rootContainer.addView(overlay, matchParentFrameLp());
        settingsOverlayView = overlay;
        bringBottomBarToFront();

        for (int i = 0; i < settingsButtonsColumn.getChildCount(); i++) {
            final View child = settingsButtonsColumn.getChildAt(i);
            child.animate().translationY(0f).alpha(1f).setStartDelay(i * 45).setDuration(320).setListener(null).start();
        }
    }

    private void closeSettingsPanel() {
        if (!settingsOpen || settingsOverlayView == null) return;
        final View overlay = settingsOverlayView;
        final LinearLayout column = settingsButtonsColumn;

        if (column != null) {
            int count = column.getChildCount();
            for (int i = 0; i < count; i++) {
                View child = column.getChildAt(i);
                child.animate().translationY(dp(80)).alpha(0f)
					.setStartDelay((count - 1 - i) * 30).setDuration(220).start();
            }
        }

        overlay.animate().alpha(0f).setDuration(280).setListener(new AnimatorListenerAdapter() {
				@Override
				public void onAnimationEnd(Animator animation) {
					if (rootContainer != null && overlay.getParent() == rootContainer) rootContainer.removeView(overlay);
					settingsOverlayView = null;
					settingsButtonsColumn = null;
					hapticExpandPanel = null;
					hapticPanelExpanded = false;
					settingsOpen = false;
					applyContentBlur(false);
				}
			}).start();
    }

    private void bringBottomBarToFront() {
        if (rootContainer == null) return;
        for (int i = 0; i < rootContainer.getChildCount(); i++) {
            View child = rootContainer.getChildAt(i);
            if (child == null) continue;
            ViewGroup.LayoutParams lp = child.getLayoutParams();
            if (lp instanceof FrameLayout.LayoutParams) {
                FrameLayout.LayoutParams flp = (FrameLayout.LayoutParams) lp;
                if (flp.gravity == Gravity.BOTTOM && flp.height == dp(94)) {
                    child.bringToFront();
                    break;
                }
            }
        }
        if (selectedFunctionPill != null) selectedFunctionPill.bringToFront();
    }

    private void applyContentBlur(boolean enable) {
        if (rootContainer == null) return;
        RenderEffect blur = enable ? RenderEffect.createBlurEffect(22f, 22f, Shader.TileMode.CLAMP) : null;

        for (int i = 0; i < rootContainer.getChildCount(); i++) {
            View child = rootContainer.getChildAt(i);
            if (child == null || child == settingsOverlayView) continue;

            ViewGroup.LayoutParams lp = child.getLayoutParams();
            boolean isBottomBar = false;
            if (lp instanceof FrameLayout.LayoutParams) {
                FrameLayout.LayoutParams flp = (FrameLayout.LayoutParams) lp;
                if (flp.gravity == Gravity.BOTTOM && flp.height == dp(94)) isBottomBar = true;
                if (child == selectedFunctionPill) isBottomBar = true;
            }
            if (isBottomBar) continue;
            child.setRenderEffect(blur);
        }
    }

    private View createSettingsStubButton(String label, int minHeight) {
        TextView tv = new DigitTextView(this);
        tv.setText(label);
        styleText(tv, 16f);
        tv.setGravity(Gravity.CENTER);
        tv.setMinHeight(minHeight);
        tv.setPadding(dp(18), dp(14), dp(18), dp(14));
        tv.setBackground(createRoundedRect(dp(18), COLOR_DARK_PANEL, COLOR_DARK_BORDER));
        applyRipple(tv);
        tv.setClickable(true);
        tv.setFocusable(true);
        tv.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					performAppHaptic(v);
				}
			});
        return tv;
    }

    private View createMoonWidgetButton(String label, int minHeight) {
        TextView tv = new DigitTextView(this);
        tv.setText(label);
        styleText(tv, 16f);
        tv.setGravity(Gravity.CENTER);
        tv.setMinHeight(minHeight);
        tv.setPadding(dp(18), dp(14), dp(18), dp(14));
        tv.setBackground(createRoundedRect(dp(18), COLOR_DARK_PANEL, COLOR_DARK_BORDER));
        applyRipple(tv);
        tv.setClickable(true);
        tv.setFocusable(true);
        tv.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					performAppHaptic(v);
					requestMoonPhaseWidgetPin();
				}
			});
        return tv;
    }

    private void requestMoonPhaseWidgetPin() {
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        if (!manager.isRequestPinAppWidgetSupported()) {
            Toast.makeText(this, "Ваш лаунчер не поддерживает добавление виджетов из приложения.", Toast.LENGTH_LONG).show();
            return;
        }
        ComponentName provider = new ComponentName(this, MoonPhaseWidget.class);
        boolean requested = manager.requestPinAppWidget(provider, null, null);
        if (!requested) Toast.makeText(this, "Не удалось открыть добавление виджета.", Toast.LENGTH_SHORT).show();
    }

    private View createSettingsReferenceButton(String label, int minHeight) {
        TextView tv = new DigitTextView(this);
        tv.setText(label);
        styleText(tv, 16f);
        tv.setGravity(Gravity.CENTER);
        tv.setMinHeight(minHeight);
        tv.setPadding(dp(18), dp(14), dp(18), dp(14));
        tv.setBackground(createRoundedRect(dp(18), COLOR_DARK_PANEL, COLOR_DARK_BORDER));
        applyRipple(tv);
        tv.setClickable(true);
        tv.setFocusable(true);
        tv.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					performAppHaptic(v);
					closeSettingsPanelImmediate();
					openReferenceWindow();
				}
			});
        return tv;
    }

    private void openReferenceWindow() {
        if (rootContainer == null || (referenceWindow != null && referenceWindow.isOpen())) return;
        applyContentBlur(true);
        referenceWindow = new AstrophysicalReferenceWindow(this, rootContainer, appTypeface, new Runnable() {
				@Override
				public void run() {
					referenceWindow = null;
					applyContentBlur(false);
				}
			});
        referenceWindow.show();
    }

    private void closeReferenceWindow() {
        if (referenceWindow != null && referenceWindow.isOpen()) referenceWindow.close();
    }

    private View createSettingsThemeButton(String label, int minHeight) {
        TextView tv = new DigitTextView(this);
        tv.setText(label);
        styleText(tv, 16f);
        tv.setGravity(Gravity.CENTER);
        tv.setMinHeight(minHeight);
        tv.setPadding(dp(18), dp(14), dp(18), dp(14));
        tv.setBackground(createRoundedRect(dp(18), COLOR_DARK_PANEL, COLOR_DARK_BORDER));
        applyRipple(tv);
        tv.setClickable(true);
        tv.setFocusable(true);
        tv.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					performAppHaptic(v);
					openThemeSelector();
				}
			});
        return tv;
    }

    private void openThemeSelector() {
        if (rootContainer == null) return;
        closeThemeSelectorIfOpen();

        final FrameLayout selector = new FrameLayout(this);
        selector.setTag(TAG_THEME_SELECTOR);
        selector.setClickable(true);
        selector.setFocusable(true);
        selector.setBackgroundColor(Color.BLACK);

        final FrameLayout topHalf = new FrameLayout(this);
        ImageView topImg = new ImageView(this);
        topImg.setImageResource(R.drawable.theme_omega_mars);
        topImg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        topHalf.addView(topImg, matchParentFrameLp());

        View topFade = new View(this);
        GradientDrawable topGrad = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
														new int[]{Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(220, 0, 0, 0)});
        topFade.setBackground(topGrad);
        topHalf.addView(topFade, matchParentFrameLp());

        TextView topTitle = new DigitTextView(this);
        topTitle.setText("OMEGA Intellectual");
        styleText(topTitle, 20f);
        topTitle.setGravity(Gravity.CENTER);
        topTitle.setTextColor(COLOR_TEXT_NEAR_WHITE);
        topTitle.setShadowLayer(8f, 0f, 2f, Color.BLACK);

        FrameLayout.LayoutParams topTitleLp = new FrameLayout.LayoutParams(
			FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        topTitleLp.gravity = Gravity.CENTER;
        topHalf.addView(topTitle, topTitleLp);

        topHalf.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					performAppHaptic(v);
					closeThemeSelectorIfOpen();
				}
			});

        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(
			FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        selector.addView(topHalf, topLp);

        rootContainer.addView(selector, matchParentFrameLp());
        selector.bringToFront();
        selector.setAlpha(0f);
        selector.animate().alpha(1f).setDuration(280).start();
    }

    private View createSettingsHapticButton(String label, int minHeight) {
        final LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setBackground(createRoundedRect(dp(18), COLOR_DARK_PANEL, COLOR_DARK_BORDER));
        wrapper.setClipToOutline(true);

        final TextView header = new DigitTextView(this);
        header.setText(label);
        styleText(header, 16f);
        header.setGravity(Gravity.CENTER);
        header.setMinHeight(minHeight);
        int padH = dp(18);
        int padV = dp(14);
        header.setPadding(padH, padV, padH, padV);
        applyRipple(header);
        header.setClickable(true);
        header.setFocusable(true);

        final LinearLayout expand = new LinearLayout(this);
        expand.setOrientation(LinearLayout.HORIZONTAL);
        expand.setGravity(Gravity.CENTER_VERTICAL);
        expand.setPadding(padH, dp(6), padH, dp(14));
        expand.setVisibility(View.GONE);

        final TextView stateLabel = new DigitTextView(this);
        stateLabel.setText(hapticEnabled ? "Вкл" : "Выкл");
        styleText(stateLabel, 14f);
        stateLabel.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        final Switch sw = new Switch(this);
        sw.setChecked(hapticEnabled);
        try {
            sw.getThumbDrawable().setColorFilter(COLOR_ACCENT_PEACH_CLAY, PorterDuff.Mode.SRC_IN);
            sw.getTrackDrawable().setColorFilter(
				hapticEnabled ? Color.parseColor("#80D58B5A") : Color.parseColor("#555555"),
				PorterDuff.Mode.SRC_IN);
        } catch (Throwable ignored) {}

        sw.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
					setHapticEnabled(isChecked);
					stateLabel.setText(isChecked ? "Вкл" : "Выкл");
					try {
						sw.getTrackDrawable().setColorFilter(
                            isChecked ? Color.parseColor("#80D58B5A") : Color.parseColor("#555555"),
                            PorterDuff.Mode.SRC_IN);
					} catch (Throwable ignored) {}
					if (isChecked) performAppHaptic(buttonView);
				}
			});

        expand.addView(stateLabel);
        expand.addView(sw);
        hapticExpandPanel = expand;

        wrapper.addView(header, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        wrapper.addView(expand, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        header.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					performAppHaptic(v);
					toggleHapticExpand(wrapper, expand);
				}
			});
        return wrapper;
    }

    private void toggleHapticExpand(final LinearLayout wrapper, final LinearLayout expand) {
        if (hapticPanelExpanded) {
            expand.animate().alpha(0f).setDuration(180).setListener(new AnimatorListenerAdapter() {
					@Override
					public void onAnimationEnd(Animator animation) {
						expand.setVisibility(View.GONE);
						expand.setAlpha(1f);
					}
				}).start();
            hapticPanelExpanded = false;
        } else {
            expand.setAlpha(0f);
            expand.setVisibility(View.VISIBLE);
            expand.animate().alpha(1f).setDuration(220).setListener(null).start();
            hapticPanelExpanded = true;
        }
    }

    // === НОВОЕ: раздел "Экспериментальные функции" с тумблером кастомной клавиатуры ===
    private View createSettingsExperimentalButton(String label, int minHeight) {
        final LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setBackground(createRoundedRect(dp(18), COLOR_DARK_PANEL, COLOR_DARK_BORDER));
        wrapper.setClipToOutline(true);

        final TextView header = new DigitTextView(this);
        header.setText(label);
        styleText(header, 16f);
        header.setGravity(Gravity.CENTER);
        header.setMinHeight(minHeight);
        final int padH = dp(18);
        int padV = dp(14);
        header.setPadding(padH, padV, padH, padV);
        applyRipple(header);
        header.setClickable(true);
        header.setFocusable(true);

        final LinearLayout expand = new LinearLayout(this);
        expand.setOrientation(LinearLayout.VERTICAL);
        expand.setPadding(padH, dp(6), padH, dp(14));
        expand.setVisibility(View.GONE);

        TextView hint = new DigitTextView(this);
        hint.setText(Localization.t("Функции в активной разработке — включай на свой страх и риск."));
        styleText(hint, 12.5f);
        hint.setPadding(0, 0, 0, dp(10));
        expand.addView(hint, new LinearLayout.LayoutParams(
						   LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView nameLabel = new DigitTextView(this);
        nameLabel.setText(Localization.t("Кастомная клавиатура (заметки)"));
        styleText(nameLabel, 14f);
        nameLabel.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        final Switch sw = new Switch(this);
        sw.setChecked(customKeyboardEnabled);
        try {
            sw.getThumbDrawable().setColorFilter(COLOR_ACCENT_PEACH_CLAY, PorterDuff.Mode.SRC_IN);
            sw.getTrackDrawable().setColorFilter(
				customKeyboardEnabled ? Color.parseColor("#80D58B5A") : Color.parseColor("#555555"),
				PorterDuff.Mode.SRC_IN);
        } catch (Throwable ignored) {}

        sw.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
					setCustomKeyboardEnabled(isChecked);
					try {
						sw.getTrackDrawable().setColorFilter(
                            isChecked ? Color.parseColor("#80D58B5A") : Color.parseColor("#555555"),
                            PorterDuff.Mode.SRC_IN);
					} catch (Throwable ignored) {}
					if (isChecked) performAppHaptic(buttonView);
				}
			});

        row.addView(nameLabel);
        row.addView(sw);
        expand.addView(row, new LinearLayout.LayoutParams(
						   LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        wrapper.addView(header, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        wrapper.addView(expand, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        final boolean[] expanded = new boolean[]{false};
        header.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					performAppHaptic(v);
					if (expanded[0]) {
						expand.animate().alpha(0f).setDuration(180).setListener(new AnimatorListenerAdapter() {
								@Override
								public void onAnimationEnd(Animator animation) {
									expand.setVisibility(View.GONE);
									expand.setAlpha(1f);
								}
							}).start();
						expanded[0] = false;
					} else {
						expand.setAlpha(0f);
						expand.setVisibility(View.VISIBLE);
						expand.animate().alpha(1f).setDuration(220).setListener(null).start();
						expanded[0] = true;
					}
				}
			});
        return wrapper;
    }

    // =========================================================
    //  Блюр фона
    // =========================================================
    private void alignBlurToScreen(final View anchor, final ImageView blurView) {
        anchor.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
				@Override
				public void onGlobalLayout() {
					if (anchor.getWidth() == 0 || anchor.getHeight() == 0) return;
					Drawable d = blurView.getDrawable();
					if (d == null || d.getIntrinsicWidth() <= 0 || d.getIntrinsicHeight() <= 0) return;

					int[] loc = new int[2];
					anchor.getLocationOnScreen(loc);
					int screenW = getResources().getDisplayMetrics().widthPixels;
					int screenH = getResources().getDisplayMetrics().heightPixels;
					float dw = d.getIntrinsicWidth();
					float dh = d.getIntrinsicHeight();
					float scale = Math.max(screenW / dw, screenH / dh);
					float dx = (screenW - dw * scale) / 2f - loc[0];
					float dy = (screenH - dh * scale) / 2f - loc[1];

					Matrix m = new Matrix();
					m.setScale(scale, scale);
					m.postTranslate(dx, dy);
					blurView.setImageMatrix(m);
					anchor.getViewTreeObserver().removeOnGlobalLayoutListener(this);
				}
			});
    }

    // =========================================================
    //  Утилиты
    // =========================================================
    private Bitmap emojiToTintedBitmap(String emoji, float sizePx, int tintColor) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setTextSize(sizePx);
        Rect bounds = new Rect();
        paint.getTextBounds(emoji, 0, emoji.length(), bounds);
        int w = Math.max(1, bounds.width() + dp(6));
        int h = Math.max(1, (int) (sizePx * 1.35f));
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        paint.setColorFilter(new PorterDuffColorFilter(tintColor, PorterDuff.Mode.SRC_IN));
        canvas.drawText(emoji, dp(3), h * 0.75f, paint);
        return bmp;
    }

    private void addFadedEmojiCluster(FrameLayout container, String[] emojis) {
        int[][] offsets = {{-dp(11), -dp(9)}, {dp(11), dp(7)}, {dp(2), -dp(14)}};
        for (int i = 0; i < emojis.length && i < offsets.length; i++) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(emojiToTintedBitmap(emojis[i], dp(15), themeAccentColor()));
            iv.setAlpha(0.18f);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(20), dp(20));
            lp.gravity = Gravity.CENTER;
            lp.leftMargin = offsets[i][0];
            lp.topMargin = offsets[i][1];
            container.addView(iv, 0, lp);
        }
    }

    private void styleText(TextView tv, float sizeSp) {
        tv.setTextColor(COLOR_TEXT_NEAR_WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        if (appTypeface != null) tv.setTypeface(appTypeface);
    }

    private void requestHighRefreshRate() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return;
        try {
            android.view.WindowManager.LayoutParams params = getWindow().getAttributes();
            params.preferredRefreshRate = 120.0f;
            getWindow().setAttributes(params);
        } catch (Throwable ignore) {}
    }

    private void preparePanelNamesParallel() {
        final String[] source = new String[]{
			getString(R.string.panel_velocity),
			getString(R.string.panel_year),
			getString(R.string.panel_habitable_zone),
			getString(R.string.panel_mass),
			getString(R.string.panel_radius),
			getString(R.string.panel_density),
			getString(R.string.panel_gravity),
			getString(R.string.panel_gravity_stability),
			getString(R.string.panel_magnetic_field),
			getString(R.string.panel_esi),
			getString(R.string.panel_astrobio),
			getString(R.string.panel_roche),
			getString(R.string.panel_atmosphere),
			"3D визуализатор",
			"Идеальная круговая орбита"
        };
        final String[] result = new String[source.length];
        final CountDownLatch latch = new CountDownLatch(PerformancePools.UI_THREADS);

        for (int worker = 0; worker < PerformancePools.UI_THREADS; worker++) {
            final int workerId = worker;
            PerformancePools.ui().execute(new Runnable() {
					@Override
					public void run() {
						try {
							for (int i = workerId; i < source.length; i += PerformancePools.UI_THREADS) {
								result[i] = Localization.t(source[i]);
							}
						} finally {
							latch.countDown();
						}
					}
				});
        }

        try {
            latch.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            for (int i = 0; i < source.length; i++) {
                if (result[i] == null) result[i] = Localization.t(source[i]);
            }
        }
        panelNames = result;
    }

    private void initTypography() {
        try {
            appTypeface = Typeface.createFromAsset(getAssets(), "LoraFonts/Lora-Regular.ttf");
        } catch (Throwable ignored) {
            appTypeface = Typeface.SERIF;
        }
    }

    private GradientDrawable createRoundedRect(float radius, int fillColor, int strokeColor) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(radius);
        gd.setColor(fillColor);
        gd.setStroke(dp(1), strokeColor);
        return gd;
    }

    private void applyRipple(final View v) {
        if (v == null) return;
        v.setForeground(null);
        v.setStateListAnimator(null);
        v.setLayerType(View.LAYER_TYPE_NONE, null);
        v.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View view, android.view.MotionEvent event) {
					switch (event.getActionMasked()) {
						case android.view.MotionEvent.ACTION_DOWN:
							view.animate().cancel();
							view.setAlpha(0.86f);
							break;
						case android.view.MotionEvent.ACTION_UP:
						case android.view.MotionEvent.ACTION_CANCEL:
							view.animate().alpha(1f).setDuration(70).start();
							break;
					}
					return false;
				}
			});
    }

    private void configureScrollView(ScrollView scrollView) {
        scrollView.setBackgroundColor(Color.TRANSPARENT);
        scrollView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        scrollView.setVerticalFadingEdgeEnabled(false);
        scrollView.setHorizontalFadingEdgeEnabled(false);
        scrollView.setVerticalScrollBarEnabled(false);
        scrollView.setHorizontalScrollBarEnabled(false);
        scrollView.setFillViewport(true);
        scrollView.setNestedScrollingEnabled(false);
        scrollView.setSmoothScrollingEnabled(true);
        scrollView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
    }

    private static final class SmoothScrollView extends ScrollView {
        SmoothScrollView(Context context) { super(context); }
        @Override protected void dispatchDraw(Canvas canvas) { super.dispatchDraw(canvas); }
        @Override protected void onOverScrolled(int scrollX, int scrollY, boolean clampedX, boolean clampedY) { super.onOverScrolled(scrollX, scrollY, clampedX, clampedY); }
    }

    private FrameLayout.LayoutParams matchParentFrameLp() {
        return new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
    }

    private int dp(float value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }

    private void installLocalizationObserver() {
        if (rootContainer == null) return;
        if (localizationLayoutListener == null) {
            localizationLayoutListener = new ViewTreeObserver.OnGlobalLayoutListener() {
                @Override
                public void onGlobalLayout() {
                    localizeRootIfStructureChanged(false);
                }
            };
        }
        if (!localizationObserverInstalled) {
            ViewTreeObserver observer = rootContainer.getViewTreeObserver();
            if (observer.isAlive()) {
                observer.addOnGlobalLayoutListener(localizationLayoutListener);
                localizationObserverInstalled = true;
            }
        }
        localizeRootIfStructureChanged(true);
    }

    private void localizeRootIfStructureChanged(boolean force) {
        if (rootContainer == null) return;
        int count = rootContainer.getChildCount();
        View top = count > 0 ? rootContainer.getChildAt(count - 1) : null;
        String currentLanguage = Localization.getLanguage();
        if (!force
                && count == lastLocalizedRootChildCount
                && top == lastLocalizedRootTopChild
                && currentLanguage.equals(lastLocalizedLanguage)) {
            return;
        }
        Localization.applyToViewTree(rootContainer);
        lastLocalizedRootChildCount = count;
        lastLocalizedRootTopChild = top;
        lastLocalizedLanguage = currentLanguage;
    }

    private void setLanguage(String lang) {
        language = lang;
        Localization.setLanguage(lang);
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putString(KEY_LANGUAGE, lang).apply();
        closeLanguageSelectorIfOpen();
        closeSettingsPanelImmediate();
        buildUi();
        installLocalizationObserver();
        enterFullscreenMode();
    }

    private void closeLanguageSelectorIfOpen() {
        if (rootContainer == null) return;
        View existing = rootContainer.findViewWithTag("language_selector");
        if (existing != null) rootContainer.removeView(existing);
    }

    private void openLanguageSelector() {
        if (rootContainer == null) return;
        closeLanguageSelectorIfOpen();

        final FrameLayout selector = new FrameLayout(this);
        selector.setTag("language_selector");
        selector.setClickable(true);
        selector.setFocusable(true);
        selector.setBackgroundColor(Color.argb(205, 0, 0, 0));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(20), dp(20), dp(20), dp(20));
        card.setBackground(createRoundedRect(dp(22), COLOR_DARK_PANEL, COLOR_DARK_BORDER));

        TextView title = new DigitTextView(this);
        title.setText("Язык");
        styleText(title, 19f);
        title.setGravity(Gravity.CENTER);
        card.addView(title, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54)));

        String[] langs = {"Русский", "O'zbek", "English"};
        String[] ids = {Localization.LANG_RU, Localization.LANG_UZ, Localization.LANG_EN};

        for (int i = 0; i < langs.length; i++) {
            final String id = ids[i];
            TextView b = new DigitTextView(this);
            b.setText(langs[i]);
            styleText(b, 17f);
            b.setGravity(Gravity.CENTER);
            b.setMinHeight(dp(50));
            b.setPadding(dp(14), dp(10), dp(14), dp(10));
            b.setBackground(createRoundedRect(dp(16), COLOR_DARK_PANEL, COLOR_DARK_BORDER));
            applyRipple(b);

            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(50));
            if (i > 0) blp.topMargin = dp(10);
            card.addView(b, blp);

            b.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						performAppHaptic(v);
						setLanguage(id);
					}
				});
        }

        selector.addView(card, new FrameLayout.LayoutParams(dp(300), dp(250), Gravity.CENTER));
        rootContainer.addView(selector, matchParentFrameLp());

        card.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) { /* consume */ }
			});
        selector.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					closeLanguageSelectorIfOpen();
				}
			});
    }

    private View createSettingsLanguageButton(String label, int minHeight) {
        TextView tv = new DigitTextView(this);
        tv.setText(label);
        styleText(tv, 16f);
        tv.setGravity(Gravity.CENTER);
        tv.setMinHeight(minHeight);
        tv.setPadding(dp(18), dp(14), dp(18), dp(14));
        tv.setBackground(createRoundedRect(dp(18), COLOR_DARK_PANEL, COLOR_DARK_BORDER));
        applyRipple(tv);
        tv.setClickable(true);
        tv.setFocusable(true);
        tv.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					performAppHaptic(v);
					openLanguageSelector();
				}
			});
        return tv;
    }
}
