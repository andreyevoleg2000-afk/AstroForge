package com.astroforge;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Relativity3DEngine
 *
 * Автономный каркас 3D-движка геометрической ОТО.
 * Java 17, Android minSdk 33, без лямбд.
 *
 * Основные принципы:
 * - 80^3 = 512000 геометрических опорных точек.
 * - Сфера симуляции: 27000 световых лет.
 * - Тела искривляют пространство-время, а движение считается по геодезической логике.
 * - Double-double используется как программное повышение точности.
 * - Адаптивная плотность/фокус сетки резко растут при близких пролётах.
 * - Выход за сферу симуляции удаляет тело.
 */
public final class Relativity3DEngine {

    // =========================================================================
    // Константы мира
    // =========================================================================

    public static final int GRID_DIMENSION = 80;
    public static final int GEOMETRIC_POINT_COUNT = GRID_DIMENSION * GRID_DIMENSION * GRID_DIMENSION; // 512000

    public static final double LIGHT_YEAR_METERS = 9_460_730_472_580_800.0;
    public static final double WORLD_RADIUS_LY = 27_000.0;
    public static final double WORLD_RADIUS_METERS = WORLD_RADIUS_LY * LIGHT_YEAR_METERS;

    public static final double SOFTNESS_TENSION = 2.07e-43;

    public static final double SPEED_OF_LIGHT = 299_792_458.0;
    public static final double GRAVITATIONAL_CONSTANT = 6.67430e-11;

    // Сетка вписана в сферу: куб ограничен так, чтобы все 80^3 точек были внутри сферы.
    private static final double GRID_HALF_EXTENT_METERS = WORLD_RADIUS_METERS / Math.sqrt(3.0);
    private static final double GRID_SPACING_METERS =
	(2.0 * GRID_HALF_EXTENT_METERS) / (double) (GRID_DIMENSION - 1);

    private static final double BASE_POINT_DENSITY =
	1.0 / (GRID_SPACING_METERS * GRID_SPACING_METERS * GRID_SPACING_METERS);

    private static final double NUMERIC_SOFTENING_METERS =
	Math.max(1.0e-6, GRID_SPACING_METERS * 1.0e-12);

    private static final double MAX_ADAPTIVE_BOOST = 1.0e18;

    private static final double MIN_STEP_SECONDS = 1.0e-6;
    private static final double MAX_STEP_SECONDS = 3600.0;
    private static final double INTEGRATOR_TOLERANCE = 1.0e-12;

    private static final int DEFORMATION_NODES = 24;

    // Типы материалов.
    public static final int MATERIAL_DUST = 0;
    public static final int MATERIAL_ROCK = 1;
    public static final int MATERIAL_METAL = 2;
    public static final int MATERIAL_PLASMA = 3;

    // =========================================================================
    // Double-double: программная эмуляция повышенной точности
    // =========================================================================

    public static final class DoubleDouble {
        public final double hi;
        public final double lo;

        public static final DoubleDouble ZERO = new DoubleDouble(0.0, 0.0);
        public static final DoubleDouble ONE = new DoubleDouble(1.0, 0.0);

        private DoubleDouble(double hi, double lo) {
            this.hi = hi;
            this.lo = lo;
        }

        public static DoubleDouble of(double value) {
            return new DoubleDouble(value, 0.0);
        }

        public DoubleDouble add(DoubleDouble other) {
            return add(this, other);
        }

        public DoubleDouble subtract(DoubleDouble other) {
            return subtract(this, other);
        }

        public DoubleDouble multiply(DoubleDouble other) {
            return multiply(this, other);
        }

        public DoubleDouble divide(DoubleDouble other) {
            return divide(this, other);
        }

        public DoubleDouble sqrt() {
            return sqrt(this);
        }

        public double toDouble() {
            return hi + lo;
        }

        public static DoubleDouble add(DoubleDouble a, DoubleDouble b) {
            double s = a.hi + b.hi;
            double v = s - a.hi;
            double e = (a.hi - (s - v)) + (b.hi - v);

            double t = a.lo + b.lo;
            double u = t - a.lo;
            double f = (a.lo - (t - u)) + (b.lo - u);

            double lo = e + f;
            double hi = s + lo;

            return new DoubleDouble(hi, lo - (hi - s));
        }

        public static DoubleDouble subtract(DoubleDouble a, DoubleDouble b) {
            return add(a, new DoubleDouble(-b.hi, -b.lo));
        }

        public static DoubleDouble multiply(DoubleDouble a, DoubleDouble b) {
            double p = a.hi * b.hi;
            double e = Math.fma(a.hi, b.hi, -p);
            e += a.hi * b.lo + a.lo * b.hi;

            double hi = p + e;
            return new DoubleDouble(hi, e - (hi - p));
        }

        public static DoubleDouble divide(DoubleDouble a, DoubleDouble b) {
            double bHi = b.hi;
            if (bHi == 0.0) {
                return ZERO;
            }

            double q = a.hi / bHi;
            DoubleDouble product = multiply(b, of(q));
            DoubleDouble remainder = subtract(a, product);
            DoubleDouble correction = of(remainder.toDouble() / bHi);

            return add(of(q), correction);
        }

        public static DoubleDouble sqrt(DoubleDouble x) {
            double v = x.toDouble();
            if (v <= 0.0) {
                return ZERO;
            }

            double r = Math.sqrt(v);
            DoubleDouble rr = multiply(of(r), of(r));
            DoubleDouble diff = subtract(x, rr);
            DoubleDouble denom = of(2.0 * r);
            DoubleDouble correction = divide(diff, denom);

            return add(of(r), correction);
        }
    }

    // =========================================================================
    // Математические структуры
    // =========================================================================

    public static final class Vec3 {
        public double x;
        public double y;
        public double z;

        public Vec3() {
            this.x = 0.0;
            this.y = 0.0;
            this.z = 0.0;
        }

        public Vec3(double x, double y, double z) {
            set(x, y, z);
        }

        public void set(double x, double y, double z) {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        public void set(Vec3 v) {
            if (v == null) {
                return;
            }
            this.x = v.x;
            this.y = v.y;
            this.z = v.z;
        }

        public void scale(double s) {
            x *= s;
            y *= s;
            z *= s;
        }

        public void addScaled(Vec3 v, double s) {
            x += v.x * s;
            y += v.y * s;
            z += v.z * s;
        }

        public double lengthSquared() {
            return x * x + y * y + z * z;
        }

        public double length() {
            return Math.sqrt(lengthSquared());
        }

        public static double distance(Vec3 a, Vec3 b) {
            double dx = a.x - b.x;
            double dy = a.y - b.y;
            double dz = a.z - b.z;
            return Math.sqrt(dx * dx + dy * dy + dz * dz);
        }

        public static double dot(Vec3 a, Vec3 b) {
            return a.x * b.x + a.y * b.y + a.z * b.z;
        }

        public static void cross(Vec3 a, Vec3 b, Vec3 out) {
            double cx = a.y * b.z - a.z * b.y;
            double cy = a.z * b.x - a.x * b.z;
            double cz = a.x * b.y - a.y * b.x;
            out.set(cx, cy, cz);
        }
    }

    public static final class MetricSample {
        public double lapse = 1.0;
        public double spatialScale = 1.0;
        public double localC = SPEED_OF_LIGHT;
        public double timeDilation = 1.0;
        public double curvature = 0.0;
    }

    // =========================================================================
    // Тело
    // =========================================================================

    public static final class Body {
        public final int id;
        public final String name;
        public final int material;

        public boolean alive = true;

        public double massKg;
        public double radiusM;
        public double restDensityKgM3;

        public double stiffness;
        public double damping;

        public final Vec3 position = new Vec3();
        public final Vec3 velocity = new Vec3();
        public final Vec3 acceleration = new Vec3();

        public final Vec3 angularVelocity = new Vec3();

        public final double[] quaternion = new double[]{1.0, 0.0, 0.0, 0.0};
        public final double[] inertia = new double[3];

        public final double[] deformation;
        public final double[] deformationVelocity;

        public double properTimeSeconds;
        public double localTimeRate = 1.0;
        public double localC = SPEED_OF_LIGHT;
        public double tidalStress;

        Body(
			int id,
			String name,
			int material,
			double massKg,
			double radiusM,
			double densityKgM3,
			Vec3 position,
			Vec3 velocity,
			Vec3 angularVelocity
        ) {
            this.id = id;
            this.name = name;
            this.material = material;
            this.massKg = massKg;
            this.radiusM = radiusM;

            this.position.set(position);
            this.velocity.set(velocity);
            this.angularVelocity.set(angularVelocity);

            double radiusSafe = isFinite(radiusM) ? Math.max(1.0e-9, radiusM) : 1.0e-9;
            double volume = (4.0 / 3.0) * Math.PI * radiusSafe * radiusSafe * radiusSafe;

            if (isFinite(densityKgM3) && densityKgM3 > 0.0) {
                this.restDensityKgM3 = densityKgM3;
            } else {
                this.restDensityKgM3 = massKg / Math.max(1.0e-30, volume);
            }

            if (!isFinite(this.restDensityKgM3) || this.restDensityKgM3 <= 0.0) {
                this.restDensityKgM3 = 1000.0;
            }

            double inertiaScalar = 0.4 * Math.max(0.0, massKg) * radiusSafe * radiusSafe;
            if (!isFinite(inertiaScalar) || inertiaScalar <= 0.0) {
                inertiaScalar = 1.0e-30;
            }

            this.inertia[0] = inertiaScalar;
            this.inertia[1] = inertiaScalar;
            this.inertia[2] = inertiaScalar;

            this.deformation = new double[DEFORMATION_NODES];
            this.deformationVelocity = new double[DEFORMATION_NODES];

            this.stiffness = materialStiffness(material, this.restDensityKgM3);
            this.damping = materialDamping(material);
        }
    }

    // =========================================================================
    // Поля движка
    // =========================================================================

    private final double[] pointX;
    private final double[] pointY;
    private final double[] pointZ;

    private final double[] pointDensity;
    private final double[] pointFocus;

    private final boolean[] pointActive;

    private final ArrayList<Body> bodies;

    private double simulationTimeSeconds;
    private double adaptiveDensityBoost;
    private int nextBodyId;

    private final MetricSample metricWork = new MetricSample();

    // =========================================================================
    // Конструктор
    // =========================================================================

    public Relativity3DEngine() {
        pointX = new double[GEOMETRIC_POINT_COUNT];
        pointY = new double[GEOMETRIC_POINT_COUNT];
        pointZ = new double[GEOMETRIC_POINT_COUNT];

        pointDensity = new double[GEOMETRIC_POINT_COUNT];
        pointFocus = new double[GEOMETRIC_POINT_COUNT];

        pointActive = new boolean[GEOMETRIC_POINT_COUNT];

        bodies = new ArrayList<Body>();

        simulationTimeSeconds = 0.0;
        adaptiveDensityBoost = 1.0;
        nextBodyId = 1;

        initializeGeometricContinuum();
    }

    // =========================================================================
    // Публичный API
    // =========================================================================

    public int addBody(
		String name,
		int material,
		double massKg,
		double radiusM,
		double densityKgM3,
		Vec3 position,
		Vec3 velocity,
		Vec3 angularVelocity
    ) {
        Body body = new Body(
			nextBodyId++,
			name == null ? "body" : name,
			material,
			massKg,
			radiusM,
			densityKgM3,
			position,
			velocity,
			angularVelocity
        );

        bodies.add(body);
        return body.id;
    }

    public void step(double dtSeconds) {
        if (dtSeconds <= 0.0 || Double.isNaN(dtSeconds) || Double.isInfinite(dtSeconds)) {
            return;
        }

        double remaining = dtSeconds;
        int guard = 0;

        while (remaining > 0.0 && guard < 10000) {
            double h = Math.min(MAX_STEP_SECONDS, remaining);

            updateAdaptiveDensity();
            integrateAll(h);
            enforceConfirmedPhysics(h);
            updateSoftBodies(h);
            removeOutsideSphere();

            simulationTimeSeconds += h;
            remaining -= h;
            guard++;
        }
    }

    public int getBodyCount() {
        return bodies.size();
    }

    public Body getBodyByIndex(int index) {
        if (index < 0 || index >= bodies.size()) {
            return null;
        }
        return bodies.get(index);
    }

    public Body getBodyById(int id) {
        for (int i = 0; i < bodies.size(); i++) {
            Body body = bodies.get(i);
            if (body.id == id) {
                return body;
            }
        }
        return null;
    }

    public double getSimulationTimeSeconds() {
        return simulationTimeSeconds;
    }

    public double getWorldRadiusMeters() {
        return WORLD_RADIUS_METERS;
    }

    public int getGeometricPointCount() {
        return GEOMETRIC_POINT_COUNT;
    }

    public double getAdaptiveDensityBoost() {
        return adaptiveDensityBoost;
    }

    public double getGeometricPointDensity(int index) {
        if (index < 0 || index >= GEOMETRIC_POINT_COUNT) {
            return 0.0;
        }
        return pointDensity[index];
    }

    public double getGeometricPointFocus(int index) {
        if (index < 0 || index >= GEOMETRIC_POINT_COUNT) {
            return 0.0;
        }
        return pointFocus[index];
    }

    public boolean isGeometricPointActive(int index) {
        if (index < 0 || index >= GEOMETRIC_POINT_COUNT) {
            return false;
        }
        return pointActive[index];
    }

    public boolean isInsideSimulationSphere(double x, double y, double z) {
        double r2 = x * x + y * y + z * z;
        return r2 <= WORLD_RADIUS_METERS * WORLD_RADIUS_METERS;
    }

    // =========================================================================
    // Инициализация геометрического континуума
    // =========================================================================

    private void initializeGeometricContinuum() {
        double start = -GRID_HALF_EXTENT_METERS;
        int index = 0;

        for (int ix = 0; ix < GRID_DIMENSION; ix++) {
            double x = start + GRID_SPACING_METERS * (double) ix;

            for (int iy = 0; iy < GRID_DIMENSION; iy++) {
                double y = start + GRID_SPACING_METERS * (double) iy;

                for (int iz = 0; iz < GRID_DIMENSION; iz++) {
                    double z = start + GRID_SPACING_METERS * (double) iz;

                    pointX[index] = x;
                    pointY[index] = y;
                    pointZ[index] = z;

                    pointActive[index] = isInsideSimulationSphere(x, y, z);
                    pointDensity[index] = BASE_POINT_DENSITY;
                    pointFocus[index] = 1.0;

                    index++;
                }
            }
        }
    }

    // =========================================================================
    // Адаптивная плотность геометрических точек
    // =========================================================================

    private void updateAdaptiveDensity() {
        Arrays.fill(pointDensity, BASE_POINT_DENSITY);
        Arrays.fill(pointFocus, 1.0);

        double closestSeparation = computeClosestSeparation();
        double referenceScale = GRID_SPACING_METERS;

        adaptiveDensityBoost = 1.0;

        if (!Double.isInfinite(closestSeparation) && closestSeparation < referenceScale * 1000.0) {
            double safeSeparation = Math.max(
				closestSeparation,
				1.0e-12 + Math.sqrt(Math.abs(SOFTNESS_TENSION))
            );

            double ratio = referenceScale / safeSeparation;
            adaptiveDensityBoost = 1.0 + ratio * ratio;

            if (!isFinite(adaptiveDensityBoost) || adaptiveDensityBoost < 1.0) {
                adaptiveDensityBoost = 1.0;
            }

            if (adaptiveDensityBoost > MAX_ADAPTIVE_BOOST) {
                adaptiveDensityBoost = MAX_ADAPTIVE_BOOST;
            }
        }

        double spacingVolume = GRID_SPACING_METERS * GRID_SPACING_METERS * GRID_SPACING_METERS;

        for (int bodyIndex = 0; bodyIndex < bodies.size(); bodyIndex++) {
            Body body = bodies.get(bodyIndex);

            if (!body.alive) {
                continue;
            }

            if (!isFiniteVec3(body.position) || !isFinite(body.massKg)) {
                continue;
            }

            double radiusSafe = isFinite(body.radiusM) ? Math.max(0.0, body.radiusM) : 0.0;
            double influenceRadius = Math.max(GRID_SPACING_METERS * 8.0, radiusSafe * 256.0);

            if (!isFinite(influenceRadius) || influenceRadius <= 0.0) {
                influenceRadius = GRID_SPACING_METERS * 8.0;
            }

            int minX = clampIndex(indexFromWorld(body.position.x - influenceRadius));
            int maxX = clampIndex(indexFromWorld(body.position.x + influenceRadius));

            int minY = clampIndex(indexFromWorld(body.position.y - influenceRadius));
            int maxY = clampIndex(indexFromWorld(body.position.y + influenceRadius));

            int minZ = clampIndex(indexFromWorld(body.position.z - influenceRadius));
            int maxZ = clampIndex(indexFromWorld(body.position.z + influenceRadius));

            double soft = physicalSoftening(body);

            for (int ix = minX; ix <= maxX; ix++) {
                for (int iy = minY; iy <= maxY; iy++) {
                    for (int iz = minZ; iz <= maxZ; iz++) {
                        int index = gridIndex(ix, iy, iz);

                        double dx = pointX[index] - body.position.x;
                        double dy = pointY[index] - body.position.y;
                        double dz = pointZ[index] - body.position.z;

                        double dist2 = dx * dx + dy * dy + dz * dz;
                        double denom = dist2 + soft * soft;

                        double inv = 1.0 / Math.max(1.0e-60, denom);
                        double massScale = body.massKg / 1.0e24;

                        double boost = massScale * inv * spacingVolume;
                        boost *= adaptiveDensityBoost;

                        if (!isFinite(boost) || boost < 0.0) {
                            boost = 0.0;
                        }

                        if (boost > MAX_ADAPTIVE_BOOST) {
                            boost = MAX_ADAPTIVE_BOOST;
                        }

                        pointDensity[index] += BASE_POINT_DENSITY * boost;
                        pointFocus[index] += boost;

                        if (!isFinite(pointFocus[index]) || pointFocus[index] < 1.0) {
                            pointFocus[index] = 1.0;
                        }

                        if (pointFocus[index] > MAX_ADAPTIVE_BOOST) {
                            pointFocus[index] = MAX_ADAPTIVE_BOOST;
                        }
                    }
                }
            }
        }
    }

    private double computeClosestSeparation() {
        double min = Double.POSITIVE_INFINITY;
        int n = bodies.size();

        for (int i = 0; i < n; i++) {
            Body a = bodies.get(i);
            if (!a.alive || !isFiniteVec3(a.position)) {
                continue;
            }

            for (int j = i + 1; j < n; j++) {
                Body b = bodies.get(j);
                if (!b.alive || !isFiniteVec3(b.position)) {
                    continue;
                }

                double d = Vec3.distance(a.position, b.position);
                if (d < min) {
                    min = d;
                }
            }
        }

        return min;
    }

    // =========================================================================
    // Метрика пространства-времени
    // =========================================================================

    private void sampleMetric(Vec3 pos, MetricSample out) {
        DoubleDouble potential = DoubleDouble.ZERO;
        DoubleDouble curvature = DoubleDouble.ZERO;
        DoubleDouble g = DoubleDouble.of(GRAVITATIONAL_CONSTANT);

        for (int i = 0; i < bodies.size(); i++) {
            Body source = bodies.get(i);

            if (!source.alive) {
                continue;
            }

            if (!isFiniteVec3(source.position) || !isFinite(source.massKg)) {
                continue;
            }

            double dx = pos.x - source.position.x;
            double dy = pos.y - source.position.y;
            double dz = pos.z - source.position.z;

            double dist2 = dx * dx + dy * dy + dz * dz;
            double soft = physicalSoftening(source);
            double denom = dist2 + soft * soft;

            double r = Math.sqrt(Math.max(1.0e-60, denom));
            double invR = 1.0 / r;
            double invR3 = invR / Math.max(1.0e-60, denom);

            DoubleDouble massDD = DoubleDouble.of(source.massKg);

            DoubleDouble potentialTerm = g.multiply(massDD).multiply(DoubleDouble.of(invR));
            potential = potential.subtract(potentialTerm);

            DoubleDouble curvatureTerm = g.multiply(massDD).multiply(DoubleDouble.of(invR3));
            curvature = curvature.add(curvatureTerm);
        }

        double phi = potential.toDouble();
        double c2 = SPEED_OF_LIGHT * SPEED_OF_LIGHT;
        double phiC2 = phi / c2;

        // Защита от схлопывания метрики в численном коде.
        if (!isFinite(phiC2)) {
            phiC2 = 0.0;
        }

        if (phiC2 < -0.499999999999) {
            phiC2 = -0.499999999999;
        }

        DoubleDouble lapseArgument = DoubleDouble.of(1.0 + 2.0 * phiC2);
        DoubleDouble lapseDD = lapseArgument.sqrt();

        double lapse = Math.max(1.0e-12, lapseDD.toDouble());
        double spatialScale = Math.max(1.0e-12, 1.0 - phiC2);

        if (!isFinite(lapse) || lapse <= 0.0) {
            lapse = 1.0;
        }

        if (!isFinite(spatialScale) || spatialScale <= 0.0) {
            spatialScale = 1.0;
        }

        out.lapse = lapse;
        out.spatialScale = spatialScale;
        out.timeDilation = lapse;
        out.curvature = curvature.toDouble();
        out.localC = SPEED_OF_LIGHT * lapse / spatialScale;

        if (!isFinite(out.localC) || out.localC <= 0.0) {
            out.localC = SPEED_OF_LIGHT;
        }
    }

    // =========================================================================
    // Интегрирование тел
    // =========================================================================

    private void integrateAll(double dt) {
        for (int i = 0; i < bodies.size(); i++) {
            Body body = bodies.get(i);
            if (!body.alive) {
                continue;
            }

            if (!isFiniteVec3(body.position) || !isFiniteVec3(body.velocity)) {
                body.alive = false;
                continue;
            }

            sampleMetric(body.position, metricWork);

            body.localTimeRate = metricWork.timeDilation;
            body.localC = metricWork.localC;
            body.tidalStress = Math.abs(metricWork.curvature) * body.radiusM * body.radiusM;

            if (!isFinite(body.tidalStress)) {
                body.tidalStress = 0.0;
            }

            integrateBodyAdaptive(body, dt);
            updateRotation(body, dt);
        }
    }

    private void integrateBodyAdaptive(Body body, double dt) {
        double remaining = dt;
        double suggested = Math.min(dt, MAX_STEP_SECONDS);

        Vec3 startPos = new Vec3();
        Vec3 startVel = new Vec3();

        Vec3 fullPos = new Vec3();
        Vec3 fullVel = new Vec3();

        Vec3 half1Pos = new Vec3();
        Vec3 half1Vel = new Vec3();

        Vec3 half2Pos = new Vec3();
        Vec3 half2Vel = new Vec3();

        while (remaining > 0.0 && body.alive) {
            double h = Math.min(remaining, Math.max(MIN_STEP_SECONDS, suggested));

            startPos.set(body.position);
            startVel.set(body.velocity);

            rk4Step(body, startPos, startVel, h, fullPos, fullVel);

            rk4Step(body, startPos, startVel, h * 0.5, half1Pos, half1Vel);
            rk4Step(body, half1Pos, half1Vel, h * 0.5, half2Pos, half2Vel);

            double error = estimateIntegrationError(fullPos, fullVel, half2Pos, half2Vel);

            if (error <= INTEGRATOR_TOLERANCE || h <= MIN_STEP_SECONDS) {
                body.position.set(half2Pos);
                body.velocity.set(half2Vel);

                double speed2 = body.velocity.lengthSquared();
                double c = Math.max(1.0, body.localC);
                double beta2 = speed2 / (c * c);

                if (!isFinite(beta2)) {
                    beta2 = 0.0;
                }

                if (beta2 >= 1.0) {
                    beta2 = 1.0 - 1.0e-12;
                }

                if (beta2 < 0.0) {
                    beta2 = 0.0;
                }

                double gamma = 1.0 / Math.sqrt(Math.max(1.0e-30, 1.0 - beta2));

                body.properTimeSeconds += h * body.localTimeRate / gamma;

                if (!isFinite(body.properTimeSeconds)) {
                    body.properTimeSeconds = 0.0;
                }

                remaining -= h;
                suggested = Math.min(MAX_STEP_SECONDS, h * 1.2);
            } else {
                suggested = Math.max(MIN_STEP_SECONDS, h * 0.5);
            }
        }
    }

    private void rk4Step(
		Body body,
		Vec3 p0,
		Vec3 v0,
		double h,
		Vec3 pOut,
		Vec3 vOut
    ) {
        double halfH = h * 0.5;
        double sixthH = h / 6.0;

        Vec3 k1v = new Vec3();
        Vec3 k1a = new Vec3();

        Vec3 pTemp = new Vec3();
        Vec3 vTemp = new Vec3();

        Vec3 k2v = new Vec3();
        Vec3 k2a = new Vec3();

        Vec3 k3v = new Vec3();
        Vec3 k3a = new Vec3();

        Vec3 k4v = new Vec3();
        Vec3 k4a = new Vec3();

        k1v.set(v0);
        computeGeodesicAcceleration(body, p0, v0, k1a);

        pTemp.set(
			p0.x + k1v.x * halfH,
			p0.y + k1v.y * halfH,
			p0.z + k1v.z * halfH
        );

        vTemp.set(
			v0.x + k1a.x * halfH,
			v0.y + k1a.y * halfH,
			v0.z + k1a.z * halfH
        );

        k2v.set(vTemp);
        computeGeodesicAcceleration(body, pTemp, vTemp, k2a);

        pTemp.set(
			p0.x + k2v.x * halfH,
			p0.y + k2v.y * halfH,
			p0.z + k2v.z * halfH
        );

        vTemp.set(
			v0.x + k2a.x * halfH,
			v0.y + k2a.y * halfH,
			v0.z + k2a.z * halfH
        );

        k3v.set(vTemp);
        computeGeodesicAcceleration(body, pTemp, vTemp, k3a);

        pTemp.set(
			p0.x + k3v.x * h,
			p0.y + k3v.y * h,
			p0.z + k3v.z * h
        );

        vTemp.set(
			v0.x + k3a.x * h,
			v0.y + k3a.y * h,
			v0.z + k3a.z * h
        );

        k4v.set(vTemp);
        computeGeodesicAcceleration(body, pTemp, vTemp, k4a);

        pOut.set(
			p0.x + sixthH * (k1v.x + 2.0 * k2v.x + 2.0 * k3v.x + k4v.x),
			p0.y + sixthH * (k1v.y + 2.0 * k2v.y + 2.0 * k3v.y + k4v.y),
			p0.z + sixthH * (k1v.z + 2.0 * k2v.z + 2.0 * k3v.z + k4v.z)
        );

        vOut.set(
			v0.x + sixthH * (k1a.x + 2.0 * k2a.x + 2.0 * k3a.x + k4a.x),
			v0.y + sixthH * (k1a.y + 2.0 * k2a.y + 2.0 * k3a.y + k4a.y),
			v0.z + sixthH * (k1a.z + 2.0 * k2a.z + 2.0 * k3a.z + k4a.z)
        );
    }

    private double estimateIntegrationError(Vec3 p1, Vec3 v1, Vec3 p2, Vec3 v2) {
        double pScale = Math.max(1.0, Math.max(p1.length(), p2.length()));
        double vScale = Math.max(1.0, Math.max(v1.length(), v2.length()));

        double dp = Vec3.distance(p1, p2) / pScale;
        double dv = Vec3.distance(v1, v2) / vScale;

        if (!isFinite(dp)) {
            dp = 0.0;
        }

        if (!isFinite(dv)) {
            dv = 0.0;
        }

        return Math.max(dp, dv);
    }

    private void computeGeodesicAcceleration(
		Body target,
		Vec3 pos,
		Vec3 vel,
		Vec3 out
    ) {
        out.set(0.0, 0.0, 0.0);

        if (target == null) {
            return;
        }

        if (!isFiniteVec3(pos)) {
            return;
        }

        double geometricTimeFactor = target.localTimeRate * target.localTimeRate;
        if (!isFinite(geometricTimeFactor) || geometricTimeFactor <= 0.0) {
            geometricTimeFactor = 1.0;
        }

        DoubleDouble gdd = DoubleDouble.of(GRAVITATIONAL_CONSTANT);

        for (int i = 0; i < bodies.size(); i++) {
            Body source = bodies.get(i);

            if (!source.alive || source == target) {
                continue;
            }

            if (!isFiniteVec3(source.position) || !isFinite(source.massKg)) {
                continue;
            }

            double dx = source.position.x - pos.x;
            double dy = source.position.y - pos.y;
            double dz = source.position.z - pos.z;

            double dist2 = dx * dx + dy * dy + dz * dz;
            double soft = physicalSoftening(source);
            double denom = dist2 + soft * soft;

            double r = Math.sqrt(Math.max(1.0e-60, denom));
            double invR3 = 1.0 / (denom * r);

            if (!isFinite(invR3)) {
                continue;
            }

            DoubleDouble factorDD = gdd
				.multiply(DoubleDouble.of(source.massKg))
				.multiply(DoubleDouble.of(invR3));

            double factor = factorDD.toDouble() * geometricTimeFactor;

            if (!isFinite(factor)) {
                factor = 0.0;
            }

            out.x += dx * factor;
            out.y += dy * factor;
            out.z += dz * factor;
        }

        if (!isFiniteVec3(out)) {
            out.set(0.0, 0.0, 0.0);
        }

        double aLen = out.length();
        double localC = Math.max(1.0, target.localC);
        double maxA = localC / Math.max(MIN_STEP_SECONDS, 1.0e-6);

        if (aLen > maxA) {
            out.scale(maxA / Math.max(1.0e-30, aLen));
        }
    }

    // =========================================================================
    // Законы физики: ограничители и инварианты
    // =========================================================================

    private void enforceConfirmedPhysics(double dt) {
        for (int i = 0; i < bodies.size(); i++) {
            Body body = bodies.get(i);
            if (!body.alive) {
                continue;
            }

            if (
				!isFiniteVec3(body.position) ||
				!isFiniteVec3(body.velocity) ||
				!isFiniteVec3(body.angularVelocity)
				) {
                body.alive = false;
                continue;
            }

            sampleMetric(body.position, metricWork);

            body.localTimeRate = metricWork.timeDilation;
            body.localC = metricWork.localC;
            body.tidalStress = Math.abs(metricWork.curvature) * body.radiusM * body.radiusM;

            if (!isFinite(body.tidalStress)) {
                body.tidalStress = 0.0;
            }

            double maxSpeed = body.localC * (1.0 - 1.0e-12);
            double speed = body.velocity.length();

            if (speed > maxSpeed) {
                body.velocity.scale(maxSpeed / Math.max(1.0e-30, speed));
            }

            double angularSpeed = body.angularVelocity.length();
            double radiusSafe = isFinite(body.radiusM) ? Math.max(1.0e-9, body.radiusM) : 1.0e-9;
            double maxAngularSpeed = maxSpeed / radiusSafe;

            if (angularSpeed > maxAngularSpeed) {
                body.angularVelocity.scale(maxAngularSpeed / Math.max(1.0e-30, angularSpeed));
            }

            normalizeQuaternion(body);
            clampDeformation(body);
        }
    }

    // =========================================================================
    // Мягкие тела, деформация, материал
    // =========================================================================

    private void updateSoftBodies(double dt) {
        for (int i = 0; i < bodies.size(); i++) {
            Body body = bodies.get(i);
            if (!body.alive) {
                continue;
            }

            double stiffness = isFinite(body.stiffness) ? Math.max(1.0e-9, body.stiffness) : 1.0;
            double density = isFinite(body.restDensityKgM3) ? Math.max(1.0, body.restDensityKgM3) : 1000.0;
            double elasticRate = Math.sqrt(Math.max(1.0e-6, stiffness / density));

            if (!isFinite(elasticRate) || elasticRate <= 0.0) {
                elasticRate = 1.0;
            }

            double materialDamping = isFinite(body.damping) ? Math.max(0.0, body.damping) : 1.0;
            double dampingCoeff = Math.min(1.0e6, materialDamping * elasticRate);

            double safeDt = Math.min(dt, 0.05 / Math.max(1.0, elasticRate));
            double minProgressStep = Math.max(1.0e-9, dt / 1000.0);

            double remaining = dt;
            int guard = 0;

            while (remaining > 0.0 && guard < 1000) {
                double h = Math.min(remaining, Math.max(minProgressStep, safeDt));

                double stressDrive = body.tidalStress * 1.0e-30;

                if (!isFinite(stressDrive)) {
                    stressDrive = 0.0;
                }

                if (stressDrive > 1.0) {
                    stressDrive = 1.0;
                }

                if (stressDrive < -1.0) {
                    stressDrive = -1.0;
                }

                for (int n = 0; n < DEFORMATION_NODES; n++) {
                    double shape = irregularShapeFactor(body, n);

                    double drive = stressDrive * shape * elasticRate * 0.1;

                    if (!isFinite(drive)) {
                        drive = 0.0;
                    }

                    if (drive > elasticRate) {
                        drive = elasticRate;
                    }

                    if (drive < -elasticRate) {
                        drive = -elasticRate;
                    }

                    double deformation = body.deformation[n];
                    double deformationVelocity = body.deformationVelocity[n];

                    if (!isFinite(deformation)) {
                        deformation = 0.0;
                        body.deformation[n] = 0.0;
                    }

                    if (!isFinite(deformationVelocity)) {
                        deformationVelocity = 0.0;
                        body.deformationVelocity[n] = 0.0;
                    }

                    double restore = elasticRate * elasticRate * deformation;
                    double damping = dampingCoeff * deformationVelocity;

                    double acc = drive - restore - damping;

                    if (!isFinite(acc)) {
                        acc = 0.0;
                    }

                    body.deformationVelocity[n] += h * acc;
                    body.deformation[n] += h * body.deformationVelocity[n];
                }

                remaining -= h;
                guard++;
            }

            clampDeformation(body);
            updateInertiaFromDeformation(body);
        }
    }

    private void updateInertiaFromDeformation(Body body) {
        double d0 = safeDeformation(body, 0);
        double d1 = safeDeformation(body, 1);
        double d2 = safeDeformation(body, 2);

        double mass = isFinite(body.massKg) ? Math.max(0.0, body.massKg) : 0.0;
        double baseRadius = isFinite(body.radiusM) ? Math.max(1.0e-9, body.radiusM) : 1.0e-9;

        double rx = Math.max(1.0e-9, baseRadius * (1.0 + d0 * 0.25));
        double ry = Math.max(1.0e-9, baseRadius * (1.0 + d1 * 0.25));
        double rz = Math.max(1.0e-9, baseRadius * (1.0 + d2 * 0.25));

        double oldIx = body.inertia[0];
        double oldIy = body.inertia[1];
        double oldIz = body.inertia[2];

        double newIx = 0.2 * mass * (ry * ry + rz * rz);
        double newIy = 0.2 * mass * (rx * rx + rz * rz);
        double newIz = 0.2 * mass * (rx * rx + ry * ry);

        if (!isFinite(newIx) || newIx <= 0.0) {
            newIx = 1.0e-30;
        }

        if (!isFinite(newIy) || newIy <= 0.0) {
            newIy = 1.0e-30;
        }

        if (!isFinite(newIz) || newIz <= 0.0) {
            newIz = 1.0e-30;
        }

        body.inertia[0] = newIx;
        body.inertia[1] = newIy;
        body.inertia[2] = newIz;

        if (oldIx > 1.0e-30 && body.inertia[0] > 1.0e-30) {
            body.angularVelocity.x *= oldIx / body.inertia[0];
        }

        if (oldIy > 1.0e-30 && body.inertia[1] > 1.0e-30) {
            body.angularVelocity.y *= oldIy / body.inertia[1];
        }

        if (oldIz > 1.0e-30 && body.inertia[2] > 1.0e-30) {
            body.angularVelocity.z *= oldIz / body.inertia[2];
        }

        if (!isFiniteVec3(body.angularVelocity)) {
            body.angularVelocity.set(0.0, 0.0, 0.0);
        }
    }

    // =========================================================================
    // Вращение
    // =========================================================================

    private void updateRotation(Body body, double dt) {
        if (!isFiniteVec3(body.angularVelocity)) {
            body.angularVelocity.set(0.0, 0.0, 0.0);
        }

        double wx = body.angularVelocity.x * dt * 0.5;
        double wy = body.angularVelocity.y * dt * 0.5;
        double wz = body.angularVelocity.z * dt * 0.5;

        if (!isFinite(wx)) wx = 0.0;
        if (!isFinite(wy)) wy = 0.0;
        if (!isFinite(wz)) wz = 0.0;

        double q0 = body.quaternion[0];
        double q1 = body.quaternion[1];
        double q2 = body.quaternion[2];
        double q3 = body.quaternion[3];

        if (!isFinite(q0) || !isFinite(q1) || !isFinite(q2) || !isFinite(q3)) {
            q0 = 1.0;
            q1 = 0.0;
            q2 = 0.0;
            q3 = 0.0;
        }

        body.quaternion[0] = q0 - wx * q1 - wy * q2 - wz * q3;
        body.quaternion[1] = q1 + wx * q0 + wy * q3 - wz * q2;
        body.quaternion[2] = q2 - wx * q3 + wy * q0 + wz * q1;
        body.quaternion[3] = q3 + wx * q2 - wy * q1 + wz * q0;

        normalizeQuaternion(body);
    }

    // =========================================================================
    // Граница симуляции
    // =========================================================================

    private void removeOutsideSphere() {
        for (int i = bodies.size() - 1; i >= 0; i--) {
            Body body = bodies.get(i);

            if (!body.alive || body.position.length() > WORLD_RADIUS_METERS) {
                body.alive = false;
                bodies.remove(i);
            }
        }
    }

    // =========================================================================
    // Вспомогательные методы
    // =========================================================================

    private int indexFromWorld(double coordinate) {
        if (!isFinite(coordinate)) {
            return 0;
        }

        return (int) Math.round((coordinate + GRID_HALF_EXTENT_METERS) / GRID_SPACING_METERS);
    }

    private int clampIndex(int index) {
        if (index < 0) {
            return 0;
        }

        if (index >= GRID_DIMENSION) {
            return GRID_DIMENSION - 1;
        }

        return index;
    }

    private int gridIndex(int ix, int iy, int iz) {
        return (ix * GRID_DIMENSION + iy) * GRID_DIMENSION + iz;
    }

    private static double physicalSoftening(Body source) {
        double radiusPart = 0.0;

        if (source != null && isFinite(source.radiusM)) {
            radiusPart = Math.max(0.0, source.radiusM) * 1.0e-6;
        }

        double tensionPart = Math.sqrt(Math.abs(SOFTNESS_TENSION));

        double candidate = radiusPart + tensionPart;

        if (!isFinite(candidate) || candidate < 0.0) {
            candidate = 0.0;
        }

        return Math.max(NUMERIC_SOFTENING_METERS, candidate);
    }

    private static double materialStiffness(int material, double density) {
        double safeDensity = (isFinite(density) && density > 0.0) ? density : 1000.0;

        double base;

        switch (material) {
            case MATERIAL_METAL:
                base = 8.0e10;
                break;

            case MATERIAL_ROCK:
                base = 2.0e10;
                break;

            case MATERIAL_PLASMA:
                base = 1.0e8;
                break;

            case MATERIAL_DUST:
            default:
                base = 1.0e6;
                break;
        }

        double tensionMultiplier = 1.0 + SOFTNESS_TENSION * 1.0e43;

        if (!isFinite(tensionMultiplier) || tensionMultiplier <= 0.0) {
            tensionMultiplier = 1.0;
        }

        return Math.max(1.0e-9, base * (1.0 + safeDensity / 1000.0) * tensionMultiplier);
    }

    private static double materialDamping(int material) {
        switch (material) {
            case MATERIAL_METAL:
                return 0.35;

            case MATERIAL_ROCK:
                return 0.85;

            case MATERIAL_PLASMA:
                return 2.5;

            case MATERIAL_DUST:
            default:
                return 1.0;
        }
    }

    private static double irregularShapeFactor(Body body, int node) {
        double a = Math.sin((double) node * 12.9898 + (double) body.id * 78.233) * 43758.5453;
        a = a - Math.floor(a);

        double b = Math.sin((double) node * 3.1 + (double) body.id * 1.7) * 0.5 + 0.5;

        double result = 0.5 + a * 0.75 + b * 0.25;

        if (!isFinite(result)) {
            return 1.0;
        }

        return result;
    }

    private static double safeDeformation(Body body, int index) {
        if (index < 0 || index >= body.deformation.length) {
            return 0.0;
        }

        double v = body.deformation[index];

        if (!isFinite(v)) {
            return 0.0;
        }

        return v;
    }

    private static void normalizeQuaternion(Body body) {
        double norm = 0.0;

        for (int i = 0; i < 4; i++) {
            double q = body.quaternion[i];

            if (!isFinite(q)) {
                q = 0.0;
                body.quaternion[i] = 0.0;
            }

            norm += q * q;
        }

        norm = Math.sqrt(norm);

        if (!isFinite(norm) || norm < 1.0e-30) {
            body.quaternion[0] = 1.0;
            body.quaternion[1] = 0.0;
            body.quaternion[2] = 0.0;
            body.quaternion[3] = 0.0;
            return;
        }

        for (int i = 0; i < 4; i++) {
            body.quaternion[i] /= norm;
        }
    }

    private static void clampDeformation(Body body) {
        for (int i = 0; i < DEFORMATION_NODES; i++) {
            double v = body.deformation[i];
            double vv = body.deformationVelocity[i];

            if (!isFinite(v)) {
                body.deformation[i] = 0.0;
                body.deformationVelocity[i] = 0.0;
                continue;
            }

            if (!isFinite(vv)) {
                body.deformationVelocity[i] = 0.0;
                vv = 0.0;
            }

            if (v > 0.5) {
                body.deformation[i] = 0.5;
                body.deformationVelocity[i] *= -0.1;
            } else if (v < -0.5) {
                body.deformation[i] = -0.5;
                body.deformationVelocity[i] *= -0.1;
            }
        }
    }

    private static boolean isFinite(double v) {
        return !Double.isNaN(v) && !Double.isInfinite(v);
    }

    private static boolean isFiniteVec3(Vec3 v) {
        if (v == null) {
            return false;
        }

        return isFinite(v.x) && isFinite(v.y) && isFinite(v.z);
    }
}

