package com.astroforge;

/**
 * Ошибка вычислительного движка Magneto.
 */
public final class MagnetoException extends RuntimeException {

    public MagnetoException(String message) {
        super(message);
    }

    public MagnetoException(String message, Throwable cause) {
        super(message, cause);
    }
}
