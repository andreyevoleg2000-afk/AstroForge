package com.astroforge;

import android.util.Log;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * Ранний прогрев горячих Java-методов.
 *
 * ВАЖНО: Android использует ART, а не HotSpot C2. Поэтому этот класс не может
 * приказать ART «скомпилировать метод прямо сейчас». Он лишь создаёт большую
 * реальную нагрузку на целевые методы, чтобы JIT/AOT-компилятор получил шанс
 * сделать их машинно-кодными по своим внутренним правилам.
 */
public final class JitWarmup {
    private static final String TAG = "AstroForgeJIT";

    // 5 000–10 000 по запросу. 8 000 — агрессивный, но ещё разумный дефолт.
    private static final int ITERATIONS = 8_000;

    // Не даём исключению в одном прогреваемом методе сорвать запуск приложения.
    private static volatile long blackhole;

    private JitWarmup() {
    }

    public static void warmUp() {
        long started = System.nanoTime();
        int completed = 0;

        // Нарочно без lambda/method reference: так файл нормально парсится
        // старшими версиями AIDE, которые встречаются на Android.
        try {
            warmPhysicsOrbitalSpeeds();
            completed++;
        } catch (Throwable t) {
            Log.w(TAG, "Orbital speed warmup skipped: " + t.getClass().getSimpleName(), t);
        }

        try {
            warmPhysicsFormatSpeed();
            completed++;
        } catch (Throwable t) {
            Log.w(TAG, "Format speed warmup skipped: " + t.getClass().getSimpleName(), t);
        }

        try {
            warmBodySpeed();
            completed++;
        } catch (Throwable t) {
            Log.w(TAG, "Body speed warmup skipped: " + t.getClass().getSimpleName(), t);
        }

        try {
            warmDoubleDouble();
            completed++;
        } catch (Throwable t) {
            Log.w(TAG, "DoubleDouble warmup skipped: " + t.getClass().getSimpleName(), t);
        }

        long elapsedMs = (System.nanoTime() - started) / 1_000_000L;
        Log.i(TAG, "Startup warmup: " + completed + "/4 jobs, iterations="
                + ITERATIONS + ", elapsed=" + elapsedMs + "ms, vm="
                + String.valueOf(System.getProperty("java.vm.name")));
    }

    private static void warmPhysicsOrbitalSpeeds() {
        try {
            Method method = PhysicsEngine.class.getMethod(
                    "computeOrbitalSpeeds", double.class, double.class);
            if (!Modifier.isStatic(method.getModifiers())) {
                throw new IllegalStateException("Expected static method");
            }

            double checksum = 0.0;
            for (int i = 0; i < ITERATIONS; i++) {
                double mass = 5.972e24 + (i * 1.0e18);
                double distance = 6.371e6 + (i * 10.0);
                PhysicsEngine.OrbitalResult result =
                        (PhysicsEngine.OrbitalResult) invoke(method, mass, distance);
                checksum += result.circularSpeedMs + result.escapeSpeedMs;
            }
            consume(Double.doubleToRawLongBits(checksum));
        } catch (NoSuchMethodException e) {
            throw new IllegalStateException(e);
        }
    }

    private static void warmPhysicsFormatSpeed() {
        try {
            Method method = PhysicsEngine.class.getMethod("formatSpeed", double.class);
            long checksum = 0L;
            for (int i = 0; i < ITERATIONS; i++) {
                String value = (String) invoke(method, 1_000.0 + i * 37.125);
                checksum += value.length();
                checksum += value.hashCode();
            }
            consume(checksum);
        } catch (NoSuchMethodException e) {
            throw new IllegalStateException(e);
        }
    }

    private static void warmBodySpeed() {
        try {
            Method method = PhysicsEngine.Body.class.getMethod("speed");
            PhysicsEngine.Body body = new PhysicsEngine.Body(
                    "warmup",
                    5.972e24,
                    6.371e6,
                    0.0,
                    0.0,
                    7_546.0);

            long checksum = 0L;
            for (int i = 0; i < ITERATIONS; i++) {
                double vx = 1.0 + i * 0.001;
                double vy = 7_546.0 + i * 0.01;
                body.vx = vx;
                body.vy = vy;
                double speed = ((Double) invoke(method, body));
                checksum += Double.doubleToRawLongBits(speed);
            }
            consume(checksum);
        } catch (NoSuchMethodException e) {
            throw new IllegalStateException(e);
        }
    }

    private static void warmDoubleDouble() {
        try {
            Class<?> type = Class.forName("com.astroforge.Relativity3DEngine$DoubleDouble");
            Method of = type.getMethod("of", double.class);
            Method add = type.getMethod("add", type, type);
            Method multiply = type.getMethod("multiply", type, type);

            Object a = invoke(of, 1.0000000001);
            Object b = invoke(of, 2.0000000002);
            long checksum = 0L;

            for (int i = 0; i < ITERATIONS; i++) {
                a = invoke(add, a, b);
                a = invoke(multiply, a, b);
                checksum += System.identityHashCode(a);
            }
            consume(checksum);
        } catch (ClassNotFoundException | NoSuchMethodException e) {
            throw new IllegalStateException(e);
        }
    }

    private static Object invoke(Method method, Object... args) {
        try {
            if (Modifier.isStatic(method.getModifiers())) {
                return method.invoke(null, args);
            }
            if (args.length == 0) {
                throw new IllegalArgumentException("Instance method needs a target: " + method);
            }
            Object target = args[0];
            Object[] actual = new Object[args.length - 1];
            System.arraycopy(args, 1, actual, 0, actual.length);
            return method.invoke(target, actual);
        } catch (IllegalAccessException e) {
            throw new IllegalStateException("Cannot access " + method, e);
        } catch (InvocationTargetException e) {
            Throwable cause = e.getTargetException();
            throw new IllegalStateException("Warmup target failed: " + method, cause);
        }
    }

    private static void consume(long value) {
        blackhole ^= value + 0x9E3779B97F4A7C15L;
    }
}
