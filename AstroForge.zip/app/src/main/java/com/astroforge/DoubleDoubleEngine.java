package com.astroforge;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Arrays;
import java.util.Locale;
import java.util.Set;

public final class DoubleDoubleEngine implements IEngine {

    public static final double G = 6.67430e-11;

    private static final double EPS = 1e-12;
    private static final int MAX_ADAPTIVE_SUBSTEPS = 1000;
    private static final double CLOSE_SUBSTEP_FACTOR = 0.02;
    private static final double VERY_CLOSE_SUBSTEP_FACTOR = 0.005;
    private static final double EXTREME_CLOSE_SUBSTEP_FACTOR = 0.001;

    private final EngineConfig config;
    private final EngineListener listener;
    private final ProgressListener progressListener;
    private final ArrayList<BodySpec> bodies;

    private volatile boolean running = false;
    private volatile boolean stopRequested = false;

    private SimulationReport lastReport;

    private double[] accelAx = new double[0];
    private double[] accelAy = new double[0];
    private double[] accelAz = new double[0];

    private static final class Particle {
        String name;
        double massKg;
        double radiusM;
        double densityKgM3;
        double x;
        double y;
        double z;
        double vx;
        double vy;
        double vz;
        boolean alive = true;

        Particle(BodySpec spec) {
            this.name = spec.name == null || spec.name.length() == 0 ? "Body" : spec.name;
            this.massKg = Math.max(0.0, spec.mass);
            this.x = spec.x;
            this.y = spec.y;
            this.z = spec.z;
            this.vx = spec.vx;
            this.vy = spec.vy;
            this.vz = spec.vz;
        }

        double speed() {
            return Math.sqrt(vx * vx + vy * vy + vz * vz);
        }
    }

    public static final class BodyState {
        public final String name;
        public final double massKg;
        public final double radiusM;
        public final double densityKgM3;
        public final double x;
        public final double y;
        public final double z;
        public final double vx;
        public final double vy;
        public final double vz;
        public final boolean bound;
        public final double semiMajorAxisM;
        public final double eccentricity;
        public final double distanceToCentralM;

        BodyState(
			String name,
			double massKg,
			double radiusM,
			double densityKgM3,
			double x,
			double y,
			double z,
			double vx,
			double vy,
			double vz,
			boolean bound,
			double semiMajorAxisM,
			double eccentricity,
			double distanceToCentralM
        ) {
            this.name = name;
            this.massKg = massKg;
            this.radiusM = radiusM;
            this.densityKgM3 = densityKgM3;
            this.x = x;
            this.y = y;
            this.z = z;
            this.vx = vx;
            this.vy = vy;
            this.vz = vz;
            this.bound = bound;
            this.semiMajorAxisM = semiMajorAxisM;
            this.eccentricity = eccentricity;
            this.distanceToCentralM = distanceToCentralM;
        }

        @Override
        public String toString() {
            return name
                + " | m=" + fmt(massKg) + " кг"
                + ", r=" + fmt(radiusM) + " м"
                + ", d=" + fmt(distanceToCentralM) + " м"
                + ", v=" + fmt(Math.sqrt(vx * vx + vy * vy + vz * vz)) + " м/с"
                + ", e=" + fmt(eccentricity)
                + (bound ? ", связана" : ", улетела");
        }
    }

    public static final class SimulationReport {
        public final ArrayList<String> chronology = new ArrayList<String>();
        public final ArrayList<BodyState> finalBodies = new ArrayList<BodyState>();
        public final ArrayList<SegmentSnapshot> segments = new ArrayList<SegmentSnapshot>();
        public String summary = "";
        public int steps = 0;
        public double simulatedSeconds = 0.0;
        public int collisions = 0;
        public int escapes = 0;
        public double totalEnergyJ = 0.0;
    }

    public static final class SegmentSnapshot {
        public final int index;
        public final double startSeconds;
        public final double endSeconds;
        public final ArrayList<BodyState> bodies = new ArrayList<BodyState>();
        public final ArrayList<String> events = new ArrayList<String>();

        SegmentSnapshot(int index, double startSeconds, double endSeconds,
                        ArrayList<BodyState> states, ArrayList<String> eventList) {
            this.index = index;
            this.startSeconds = startSeconds;
            this.endSeconds = endSeconds;
            if (states != null) {
                bodies.addAll(states);
            }
            if (eventList != null) {
                events.addAll(eventList);
            }
        }
    }

    public DoubleDoubleEngine(EngineConfig config, EngineListener listener) {
        this(config, listener, null);
    }

    public DoubleDoubleEngine(EngineConfig config, EngineListener listener, ProgressListener progressListener) {
        this.config = config == null ? new EngineConfig() : config;
        this.listener = listener;
        this.progressListener = progressListener;
        this.bodies = new ArrayList<BodySpec>();
    }

    public interface ProgressListener {
        void onProgress(double currentSeconds, double totalSeconds);
    }

    @Override
    public void addBody(BodySpec body) {
        if (body != null) {
            bodies.add(body);
        }
    }

    @Override
    public boolean isRunning() {
        return running;
    }

    @Override
    public void start() {
        if (running) {
            return;
        }

        PerformancePools.math().execute(new Runnable() {
				@Override
				public void run() {
					runBlocking();
				}
			});
    }

    @Override
    public void stop() {
        stopRequested = true;
    }

    public SimulationReport getLastReport() {
        return lastReport;
    }

    public SimulationReport runBlocking() {
        if (running) {
            return lastReport;
        }

        running = true;
        stopRequested = false;

        try {
            lastReport = runSimulation();
            if (listener != null && lastReport != null) {
                listener.onFinished(lastReport.summary);
            }
            return lastReport;
        } catch (Throwable t) {
            if (listener != null) {
                listener.onError(t.toString());
            }
            SimulationReport report = new SimulationReport();
            report.summary = "Ошибка: " + t.toString();
            lastReport = report;
            return report;
        } finally {
            running = false;
        }
    }

    private SimulationReport runSimulation() {
        SimulationReport report = new SimulationReport();

        if (bodies.size() == 0) {
            report.summary = "Нет тел для расчёта.";
            if (listener != null) {
                listener.onError("No bodies added.");
            }
            return report;
        }

        ArrayList<Particle> particles = new ArrayList<Particle>();
        for (int i = 0; i < bodies.size(); i++) {
            particles.add(new Particle(bodies.get(i)));
        }

        final int centralIndex = 0;
        Particle central = particles.get(centralIndex);

        final double centralMass = Math.max(EPS, central.massKg);
        final double centralRadius = Math.max(1.0, central.radiusM > 0.0 ? central.radiusM : 1.0);

        for (int i = 0; i < particles.size(); i++) {
            Particle p = particles.get(i);
            if (p.radiusM <= 0.0) {
                p.radiusM = defaultRadiusFromMass(p.massKg);
            }
            if (p.densityKgM3 <= 0.0) {
                p.densityKgM3 = densityFromMassRadius(p.massKg, p.radiusM);
            }
        }

        double maxInitialDistance = 0.0;
        double minPeriod = Double.POSITIVE_INFINITY;
        for (int i = 1; i < particles.size(); i++) {
            Particle p = particles.get(i);
            double dx = p.x - central.x;
            double dy = p.y - central.y;
            double dz = p.z - central.z;
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dist > maxInitialDistance) {
                maxInitialDistance = dist;
            }
            if (dist > 0.0) {
                double period = 2.0 * Math.PI * Math.sqrt((dist * dist * dist) / (G * centralMass));
                if (period > 0.0 && period < minPeriod) {
                    minPeriod = period;
                }
            }
        }

        double duration = config.totalVirtualSeconds > 0.0 ? config.totalVirtualSeconds : deriveDuration(minPeriod);
        double dt = config.dt > 0.0 ? config.dt : deriveDt(minPeriod);
        if (dt > duration) {
            dt = duration;
        }

        double softening = config.softening > 0.0 ? config.softening : 1.0;
        double escapeThreshold = Math.max(maxInitialDistance * 12.0, centralRadius * 200.0);
        if (escapeThreshold <= 0.0) {
            escapeThreshold = 1.0e12;
        }

        report.chronology.add(
            stamp(0.0) + "Старт: " + particles.size() + " тел, dt=" + fmt(dt) + " с, T=" + humanTime(duration)
        );

        for (int i = 0; i < particles.size(); i++) {
            Particle p = particles.get(i);
            report.chronology.add(
                stamp(0.0) + "Тело «" + p.name + "»: m=" + fmt(p.massKg) + " кг, r=" + fmt(p.radiusM) + " м, v0=" + fmt(p.speed()) + " м/с"
            );
        }

        double time = 0.0;
        int steps = 0;
        int collisions = 0;
        int escapes = 0;
        Set<String> closeLogged = new HashSet<String>();
        final double segmentSeconds = 1000.0 * 365.25 * 86400.0;
        double nextSegmentBoundary = segmentSeconds;
        int segmentIndex = 0;
        double segmentStartTime = 0.0;
        ArrayList<String> segmentEvents = new ArrayList<String>();

        while (!stopRequested && time < duration - EPS && particles.size() > 0) {
            int n = particles.size();
            double stepDt = Math.min(dt, duration - time);
            if (time < nextSegmentBoundary && time + stepDt > nextSegmentBoundary) {
                stepDt = nextSegmentBoundary - time;
            }
            if (stepDt <= EPS) {
                stepDt = Math.min(dt, duration - time);
            }

            int adaptiveSubsteps = computeAdaptiveSubsteps(particles, stepDt);
            if (adaptiveSubsteps < 1) {
                adaptiveSubsteps = 1;
            }
            double subDt = stepDt / (double) adaptiveSubsteps;
            if (subDt <= EPS) {
                subDt = stepDt;
                adaptiveSubsteps = 1;
            }

            for (int sub = 0; sub < adaptiveSubsteps && !stopRequested && particles.size() > 0; sub++) {
                int currentN = particles.size();

                integrateSubStep(particles, subDt, softening);

                time += subDt;
                steps++;

                boolean changed = true;
                while (changed) {
                    changed = false;
                    outer:
                    for (int i = 0; i < particles.size(); i++) {
                        Particle a = particles.get(i);
                        if (!a.alive) {
                            continue;
                        }
                        for (int j = i + 1; j < particles.size(); j++) {
                            Particle b = particles.get(j);
                            if (!b.alive) {
                                continue;
                            }

                            double dx = a.x - b.x;
                            double dy = a.y - b.y;
                            double dz = a.z - b.z;
                            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                            double sumR = Math.max(1.0, a.radiusM + b.radiusM);

                            if (dist <= sumR) {
                                String eventText = stamp(time) + "Столкновение: «" + a.name + "» + «" + b.name + "» на r=" + fmt(dist) + " м";
                                report.chronology.add(eventText);
                                segmentEvents.add(eventText);
                                mergeParticles(particles, i, j);
                                closeLogged.clear();
                                collisions++;
                                changed = true;
                                break outer;
                            }

                            String key = pairKey(i, j);
                            double closeThreshold = sumR * 8.0;
                            if (dist <= closeThreshold) {
                                if (!closeLogged.contains(key)) {
                                    closeLogged.add(key);
                                    String eventText = stamp(time) + "Близкое сближение: «" + a.name + "» и «" + b.name + "» на r=" + fmt(dist) + " м";
                                    report.chronology.add(eventText);
                                    segmentEvents.add(eventText);
                                }
                            } else {
                                closeLogged.remove(key);
                            }
                        }
                    }
                }

                if (particles.size() > 1 && particles.size() > 0) {
                    Particle centralNow = particles.get(0);
                    for (int i = particles.size() - 1; i >= 1; i--) {
                        Particle p = particles.get(i);
                        if (!p.alive) {
                            continue;
                        }

                        double dx = p.x - centralNow.x;
                        double dy = p.y - centralNow.y;
                        double dz = p.z - centralNow.z;
                        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                        if (dist <= escapeThreshold) {
                            continue;
                        }

                        double rvx = p.vx - centralNow.vx;
                        double rvy = p.vy - centralNow.vy;
                        double rvz = p.vz - centralNow.vz;
                        double v2 = rvx * rvx + rvy * rvy + rvz * rvz;
                        double radialV = 0.0;
                        if (dist > EPS) {
                            radialV = (dx * rvx + dy * rvy + dz * rvz) / dist;
                        }
                        double mu = G * Math.max(EPS, centralNow.massKg + p.massKg);
                        double specificEnergy = 0.5 * v2 - (mu / Math.max(EPS, dist));

                        if (specificEnergy > 0.0 && radialV > 0.0) {
                            String eventText = stamp(time) + "Побег: «" + p.name + "» покидает систему, r=" + fmt(dist) + " м";
                            report.chronology.add(eventText);
                            segmentEvents.add(eventText);
                            particles.remove(i);
                            closeLogged.clear();
                            escapes++;
                        }
                    }
                }

                if (time >= nextSegmentBoundary - EPS || time >= duration - EPS) {
                    double segmentEnd = Math.min(time, duration);
                    double segmentStart = segmentStartTime;

                    ArrayList<BodyState> states = snapshotStates(particles);
                    report.segments.add(new SegmentSnapshot(
											segmentIndex,
											segmentStart,
											segmentEnd,
											states,
											segmentEvents
										));
                    segmentEvents = new ArrayList<String>();
                    segmentStartTime = segmentEnd;
                    segmentIndex++;

                    while (nextSegmentBoundary <= time + EPS) {
                        nextSegmentBoundary += segmentSeconds;
                    }
                }

                if (listener != null && (steps % 5000 == 0)) {
                    listener.onStatus("Шаг " + steps + ", t=" + humanTime(time) + ", тел=" + particles.size() + ", sub=" + adaptiveSubsteps + "/" + currentN);
                }

                if (progressListener != null && (steps % 1000 == 0)) {
                    progressListener.onProgress(time, duration);
                }
            }
        }

        if (report.segments.size() == 0 || time > report.segments.get(report.segments.size() - 1).endSeconds + EPS) {
            double segmentEnd = time;
            report.segments.add(new SegmentSnapshot(segmentIndex, segmentStartTime, segmentEnd, snapshotStates(particles), segmentEvents));
        }

        report.steps = steps;
        report.simulatedSeconds = time;
        if (progressListener != null) {
            progressListener.onProgress(duration, duration);
        }
        report.collisions = collisions;
        report.escapes = escapes;

        for (int i = 0; i < particles.size(); i++) {
            Particle p = particles.get(i);
            BodyState state = makeBodyState(p, particles.get(0), particles.size() > 1);
            report.finalBodies.add(state);
        }

        DoubleDouble totalEnergy = computeTotalEnergy(particles);
        report.totalEnergyJ = totalEnergy.doubleValue();

        report.summary =
            "Готово: " + steps + " шагов, " + particles.size() + " тел осталось, "
            + collisions + " столкн., " + escapes + " побегов, E=" + fmt(report.totalEnergyJ) + " Дж";

        report.chronology.add(stamp(time) + "Финиш: " + report.summary);

        return report;
    }

    private void ensureAccelerationCapacity(int n) {
        if (n <= 0) {
            return;
        }
        if (accelAx.length >= n && accelAy.length >= n && accelAz.length >= n) {
            return;
        }

        int capacity = n;
        if (accelAx.length > capacity) {
            capacity = accelAx.length;
        }
        if (accelAy.length > capacity) {
            capacity = accelAy.length;
        }
        if (accelAz.length > capacity) {
            capacity = accelAz.length;
        }

        accelAx = new double[capacity];
        accelAy = new double[capacity];
        accelAz = new double[capacity];
    }

    private void computeAccelerations(ArrayList<Particle> particles, double[] ax, double[] ay, double[] az, double softening) {
        int n = particles.size();
        double soft2 = softening * softening;

        for (int i = 0; i < n; i++) {
            Particle a = particles.get(i);
            if (!a.alive) {
                continue;
            }
            for (int j = i + 1; j < n; j++) {
                Particle b = particles.get(j);
                if (!b.alive) {
                    continue;
                }

                double dx = b.x - a.x;
                double dy = b.y - a.y;
                double dz = b.z - a.z;

                double r2 = dx * dx + dy * dy + dz * dz + soft2;
                if (r2 <= 0.0) {
                    continue;
                }

                double r = Math.sqrt(r2);
                double invR3 = 1.0 / (r2 * r);

                double facA = G * b.massKg * invR3;
                double facB = G * a.massKg * invR3;

                ax[i] += dx * facA;
                ay[i] += dy * facA;
                az[i] += dz * facA;

                ax[j] -= dx * facB;
                ay[j] -= dy * facB;
                az[j] -= dz * facB;
            }
        }
    }

    private void mergeParticles(ArrayList<Particle> particles, int i, int j) {
        if (i < 0 || j < 0 || i >= particles.size() || j >= particles.size() || i == j) {
            return;
        }

        Particle a = particles.get(i);
        Particle b = particles.get(j);

        double mass = a.massKg + b.massKg;
        if (mass <= 0.0) {
            mass = 1.0;
        }

        Particle m = new Particle(new BodySpec(
									  a.name + "+" + b.name,
									  mass,
									  (a.x * a.massKg + b.x * b.massKg) / mass,
									  (a.y * a.massKg + b.y * b.massKg) / mass,
									  (a.z * a.massKg + b.z * b.massKg) / mass,
									  (a.vx * a.massKg + b.vx * b.massKg) / mass,
									  (a.vy * a.massKg + b.vy * b.massKg) / mass,
									  (a.vz * a.massKg + b.vz * b.massKg) / mass
								  ));

        m.radiusM = Math.cbrt(Math.max(1.0, a.radiusM * a.radiusM * a.radiusM + b.radiusM * b.radiusM * b.radiusM));
        m.densityKgM3 = densityFromMassRadius(mass, m.radiusM);

        if (j > i) {
            particles.remove(j);
            particles.remove(i);
        } else {
            particles.remove(i);
            particles.remove(j);
        }

        particles.add(i, m);
    }

    private ArrayList<BodyState> snapshotStates(ArrayList<Particle> particles) {
        ArrayList<BodyState> states = new ArrayList<BodyState>();
        if (particles == null || particles.size() == 0) {
            return states;
        }
        Particle central = particles.get(0);
        boolean hasCentral = particles.size() > 1;
        for (int i = 0; i < particles.size(); i++) {
            states.add(makeBodyState(particles.get(i), central, hasCentral));
        }
        return states;
    }

    private BodyState makeBodyState(Particle p, Particle central, boolean hasCentral) {
        double dx = p.x - central.x;
        double dy = p.y - central.y;
        double dz = p.z - central.z;
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (dist <= EPS) {
            return new BodyState(
				p.name,
				p.massKg,
				p.radiusM,
				p.densityKgM3,
				p.x,
				p.y,
				p.z,
				p.vx,
				p.vy,
				p.vz,
				true,
				Double.NaN,
				0.0,
				0.0
            );
        }

        double rvx = p.vx - central.vx;
        double rvy = p.vy - central.vy;
        double rvz = p.vz - central.vz;
        double v2 = rvx * rvx + rvy * rvy + rvz * rvz;

        double mu = G * Math.max(EPS, central.massKg + p.massKg);
        double energy = 0.5 * v2 - mu / Math.max(EPS, dist);

        double semiMajorAxis = Double.NaN;
        double eccentricity = Double.NaN;
        boolean bound = energy < 0.0;

        if (bound) {
            semiMajorAxis = -mu / (2.0 * energy);

            double hx = dy * rvz - dz * rvy;
            double hy = dz * rvx - dx * rvz;
            double hz = dx * rvy - dy * rvx;
            double h2 = hx * hx + hy * hy + hz * hz;

            double e2 = 1.0 + (2.0 * energy * h2) / (mu * mu);
            if (e2 < 0.0) {
                e2 = 0.0;
            }
            eccentricity = Math.sqrt(e2);
        } else {
            eccentricity = 1.0;
        }

        return new BodyState(
			p.name,
			p.massKg,
			p.radiusM,
			p.densityKgM3,
			p.x,
			p.y,
			p.z,
			p.vx,
			p.vy,
			p.vz,
			bound,
			semiMajorAxis,
			eccentricity,
			dist
        );
    }

    private DoubleDouble computeTotalEnergy(ArrayList<Particle> particles) {
        DoubleDouble total = new DoubleDouble(0.0);
        for (int i = 0; i < particles.size(); i++) {
            Particle a = particles.get(i);
            double speed2 = a.vx * a.vx + a.vy * a.vy + a.vz * a.vz;
            total.add(0.5 * a.massKg * speed2);
            for (int j = i + 1; j < particles.size(); j++) {
                Particle b = particles.get(j);
                double dx = b.x - a.x;
                double dy = b.y - a.y;
                double dz = b.z - a.z;
                double r = Math.sqrt(dx * dx + dy * dy + dz * dz);
                total.subtract(G * a.massKg * b.massKg / Math.max(EPS, r));
            }
        }
        return total;
    }

    private double defaultRadiusFromMass(double massKg) {
        if (massKg <= 0.0) {
            return 1.0;
        }
        double density = 5500.0;
        return Math.cbrt((3.0 * massKg) / (4.0 * Math.PI * density));
    }

    private double densityFromMassRadius(double massKg, double radiusM) {
        if (massKg <= 0.0 || radiusM <= 0.0) {
            return 0.0;
        }
        return massKg / ((4.0 / 3.0) * Math.PI * radiusM * radiusM * radiusM);
    }

    private double deriveDuration(double minPeriod) {
        if (Double.isNaN(minPeriod) || minPeriod <= 0.0) {
            return 365.25 * 86400.0 * 10.0;
        }
        return Math.max(365.25 * 86400.0 * 5.0, minPeriod * 6.0);
    }

    private double deriveDt(double minPeriod) {
        if (Double.isNaN(minPeriod) || minPeriod <= 0.0) {
            return 3600.0;
        }
        double dt = minPeriod / 250.0;
        if (dt < 60.0) {
            dt = 60.0;
        }
        if (dt > 86400.0) {
            dt = 86400.0;
        }
        return dt;
    }

    private int computeAdaptiveSubsteps(ArrayList<Particle> particles, double stepDt) {
        if (particles == null || particles.size() < 2 || stepDt <= EPS) {
            return 1;
        }

        double targetDt = stepDt;

        for (int i = 0; i < particles.size(); i++) {
            Particle a = particles.get(i);
            if (!a.alive) {
                continue;
            }
            for (int j = i + 1; j < particles.size(); j++) {
                Particle b = particles.get(j);
                if (!b.alive) {
                    continue;
                }

                double dx = b.x - a.x;
                double dy = b.y - a.y;
                double dz = b.z - a.z;
                double dist2 = dx * dx + dy * dy + dz * dz;
                if (dist2 <= EPS) {
                    targetDt = Math.min(targetDt, stepDt * EXTREME_CLOSE_SUBSTEP_FACTOR);
                    continue;
                }

                double dist = Math.sqrt(dist2);
                double sumR = Math.max(1.0, a.radiusM + b.radiusM);
                double mu = G * Math.max(EPS, a.massKg + b.massKg);
                double dynTime = Math.sqrt((dist * dist * dist) / mu);

                double factor = CLOSE_SUBSTEP_FACTOR;
                if (dist <= sumR * 200.0) {
                    factor = VERY_CLOSE_SUBSTEP_FACTOR;
                }
                if (dist <= sumR * 24.0) {
                    factor = EXTREME_CLOSE_SUBSTEP_FACTOR;
                }

                double candidateDt = dynTime * factor;
                if (dist <= sumR * 8.0) {
                    candidateDt = Math.min(candidateDt, dynTime * EXTREME_CLOSE_SUBSTEP_FACTOR);
                }

                if (candidateDt < targetDt) {
                    targetDt = candidateDt;
                }
            }
        }

        if (!(targetDt > EPS) || Double.isNaN(targetDt) || Double.isInfinite(targetDt)) {
            return 1;
        }

        int substeps = (int) Math.ceil(stepDt / targetDt);
        if (substeps < 1) {
            substeps = 1;
        }
        if (substeps > MAX_ADAPTIVE_SUBSTEPS) {
            substeps = MAX_ADAPTIVE_SUBSTEPS;
        }
        return substeps;
    }

    private void integrateSubStep(ArrayList<Particle> particles, double subDt, double softening) {
        int n = particles.size();
        if (n <= 0 || subDt <= EPS) {
            return;
        }

        ensureAccelerationCapacity(n);
        double[] ax = accelAx;
        double[] ay = accelAy;
        double[] az = accelAz;

        Arrays.fill(ax, 0, n, 0.0);
        Arrays.fill(ay, 0, n, 0.0);
        Arrays.fill(az, 0, n, 0.0);
        computeAccelerations(particles, ax, ay, az, softening);

        double halfDt = subDt * 0.5;
        for (int i = 0; i < n; i++) {
            Particle p = particles.get(i);
            if (!p.alive) {
                continue;
            }

            p.vx += ax[i] * halfDt;
            p.vy += ay[i] * halfDt;
            p.vz += az[i] * halfDt;

            p.x += p.vx * subDt;
            p.y += p.vy * subDt;
            p.z += p.vz * subDt;
        }

        Arrays.fill(ax, 0, n, 0.0);
        Arrays.fill(ay, 0, n, 0.0);
        Arrays.fill(az, 0, n, 0.0);
        computeAccelerations(particles, ax, ay, az, softening);

        for (int i = 0; i < n; i++) {
            Particle p = particles.get(i);
            if (!p.alive) {
                continue;
            }

            p.vx += ax[i] * halfDt;
            p.vy += ay[i] * halfDt;
            p.vz += az[i] * halfDt;
        }
    }

    private String pairKey(int i, int j) {
        if (i < j) {
            return i + ":" + j;
        }
        return j + ":" + i;
    }

    private String stamp(double t) {
        return "[" + humanTime(t) + "] ";
    }

    private String humanTime(double seconds) {
        if (seconds >= 3.15576e7) {
            return fmt(seconds / 3.15576e7) + " лет";
        }
        if (seconds >= 86400.0) {
            return fmt(seconds / 86400.0) + " дн.";
        }
        if (seconds >= 3600.0) {
            return fmt(seconds / 3600.0) + " ч";
        }
        if (seconds >= 60.0) {
            return fmt(seconds / 60.0) + " мин";
        }
        return fmt(seconds) + " с";
    }

    private static String fmt(double value) {
        return String.format(Locale.US, "%.6g", Double.valueOf(value));
    }
}


