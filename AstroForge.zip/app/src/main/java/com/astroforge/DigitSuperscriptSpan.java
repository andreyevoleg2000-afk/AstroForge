package com.astroforge;

import android.text.TextPaint;
import android.text.style.MetricAffectingSpan;

/**
 * Raises a repeated digit run by approximately half of the current digit height.
 * The font size itself is preserved; only the baseline is moved upward.
 */
final class DigitSuperscriptSpan extends MetricAffectingSpan {

    private static int shift(TextPaint paint) {
        android.graphics.Paint.FontMetricsInt fm = paint.getFontMetricsInt();
        int height = fm.descent - fm.ascent;
        return Math.max(1, Math.round(height * 0.5f));
    }

    @Override
    public void updateMeasureState(TextPaint textPaint) {
        textPaint.baselineShift -= shift(textPaint);
    }

    @Override
    public void updateDrawState(TextPaint textPaint) {
        textPaint.baselineShift -= shift(textPaint);
    }
}
