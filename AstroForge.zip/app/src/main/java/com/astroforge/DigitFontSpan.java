package com.astroforge;

import android.graphics.Typeface;
import android.text.TextPaint;
import android.text.style.MetricAffectingSpan;

/**
 * Applies the Quintessential typeface to a span while leaving the rest of the
 * text in its normal AstroForge typeface.
 */
final class DigitFontSpan extends MetricAffectingSpan {

    private final Typeface typeface;

    DigitFontSpan(Typeface typeface) {
        this.typeface = typeface;
    }

    @Override
    public void updateMeasureState(TextPaint textPaint) {
        textPaint.setTypeface(typeface);
    }

    @Override
    public void updateDrawState(TextPaint textPaint) {
        textPaint.setTypeface(typeface);
    }
}
