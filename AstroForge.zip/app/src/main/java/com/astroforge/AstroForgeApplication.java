package com.astroforge;

import android.app.Application;

/**
 * Самая ранняя точка инициализации приложения до MainActivity.
 */
public final class AstroForgeApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

        // Загружаем NDK/native-слой. При проблеме загрузки приложение продолжает
        // работать в прежнем Java-режиме, чтобы запуск и UI не менялись.
        try {
            System.loadLibrary("magneto_core");
        } catch (Throwable ignored) {
        }

        // Инициализируем общий пул производительности. Потоки создаются лениво.
        PerformancePools.ui();
        PerformancePools.math();

        // Намеренно до первого UI: прогреваем горячую математику и строки.
        JitWarmup.warmUp();

        // Ограниченный startup pre-touch. При нехватке native memory он сам пропустится.
        StartupMemoryWarmup.preTouch();
    }
}
