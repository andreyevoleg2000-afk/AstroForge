package com.astroforge;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Build;
import android.text.Spannable;
import android.text.Spanned;
import android.text.style.MetricAffectingSpan;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

/** Small, intentionally local visual helpers for the astrophysics panels. */
final class AstroUiEffects {

    private static final String FONT_ASSET = "fonts/ArchitectsDaughter-Regular.ttf";
    private static Typeface architectsDaughter;

    private AstroUiEffects() {}

    static void applyExplanationTypeface(TextView view, Context context) {
        if (view == null) return;
        CharSequence value = view.getText();
        if (value == null || value.length() == 0) {
            return;
        }
        if (value instanceof Spannable) {
            applyLetterSpans((Spannable) value, context);
        } else {
            Spannable text = new android.text.SpannableString(value);
            applyLetterSpans(text, context);
            view.setText(text, TextView.BufferType.SPANNABLE);
        }
    }

    static void applyUnitTypeface(TextView view, Context context) {
        applyExplanationTypeface(view, context);
    }

    static void applyControlShadow(View view, Context context) {
        if (view == null) return;
        view.setElevation(dp(context, 1.8f));
        view.setTranslationZ(dp(context, 0.45f));
        if (Build.VERSION.SDK_INT >= 28) {
            view.setOutlineSpotShadowColor(0x55000000);
            view.setOutlineAmbientShadowColor(0x40000000);
        }
    }

    static void applyPaperEffect(View parent, Context context) {
        if (!(parent instanceof android.view.ViewGroup)) return;
        ImageView paper = new ImageView(context);
        paper.setImageResource(R.drawable.paper_texture);
        paper.setScaleType(ImageView.ScaleType.FIT_XY);
        paper.setAlpha(0.055f);
        paper.setClickable(false);
        paper.setFocusable(false);
        paper.setEnabled(false);
        android.view.ViewGroup.MarginLayoutParams lp = new android.view.ViewGroup.MarginLayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.MATCH_PARENT);
        ((android.view.ViewGroup) parent).addView(paper, lp);
    }

    private static void applyLetterSpans(Spannable text, Context context) {
        ArchitectsDaughterSpan[] old = text.getSpans(0, text.length(), ArchitectsDaughterSpan.class);
        for (int i = 0; i < old.length; i++) {
            text.removeSpan(old[i]);
        }

        Typeface face = getTypeface(context);
        int start = -1;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            // Architects Daughter in the supplied font file is Latin-only.
            // Restrict spans to glyphs the font actually contains so Russian
            // and mathematical symbols fall back cleanly instead of becoming tofu squares.
            boolean letter = isArchitectsGlyph(c) && Character.isLetter(c);
            if (letter) {
                if (start < 0) start = i;
            } else if (start >= 0) {
                text.setSpan(new ArchitectsDaughterSpan(face), start, i, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                start = -1;
            }
        }
        if (start >= 0) {
            text.setSpan(new ArchitectsDaughterSpan(face), start, text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }

    private static boolean isArchitectsGlyph(char c) {
        return (c >= 0x0041 && c <= 0x005A)
                || (c >= 0x0061 && c <= 0x007A)
                || (c >= 0x00C0 && c <= 0x00FF)
                || (c >= 0x0100 && c <= 0x017F)
                || (c >= 0x02D8 && c <= 0x02DD)
                || (c >= 0x1E80 && c <= 0x1E85);
    }

    private static synchronized Typeface getTypeface(Context context) {
        if (architectsDaughter != null) return architectsDaughter;
        try {
            architectsDaughter = Typeface.createFromAsset(
                    context.getApplicationContext().getAssets(), FONT_ASSET);
        } catch (Throwable ignored) {
            architectsDaughter = Typeface.DEFAULT;
        }
        return architectsDaughter;
    }

    private static int dp(Context context, float value) {
        return (int) (value * context.getResources().getDisplayMetrics().density + 0.5f);
    }

    private static final class ArchitectsDaughterSpan extends MetricAffectingSpan {
        private final Typeface typeface;
        ArchitectsDaughterSpan(Typeface typeface) { this.typeface = typeface; }
        @Override public void updateDrawState(android.text.TextPaint tp) { tp.setTypeface(typeface); }
        @Override public void updateMeasureState(android.text.TextPaint tp) { tp.setTypeface(typeface); }
    }
}
