package com.astroforge;

public class BodySpec {

    public String name;

    public double mass;

    public double x;
    public double y;
    public double z;

    public double vx;
    public double vy;
    public double vz;

    public BodySpec(
            String name,
            double mass,
            double x,
            double y,
            double z,
            double vx,
            double vy,
            double vz
    ) {
        this.name = name;
        this.mass = mass;
        this.x = x;
        this.y = y;
        this.z = z;
        this.vx = vx;
        this.vy = vy;
        this.vz = vz;
    }
}
