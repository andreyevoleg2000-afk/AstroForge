package com.astroforge;

import android.content.Context;
import android.graphics.Color;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

/**
 * Всплывающее окно "Зона обитаемости".
 *
 * Визуально — копия окна "Скорость объекта" (тот же градиент с блюром, та же форма
 * окна и выезжающего списка единиц), но с собственными полями:
 *   - температура звезды (Кельвины / Фаренгейты / Цельсия, с выезжающим списком);
 *   - радиус ИЛИ диаметр звезды (в радиусах/диаметрах Солнца) — поля взаимоисключающие:
 *     если пользователь начинает вводить значение в одно поле, второе автоматически
 *     очищается. Расчёт ведётся строго по тому полю, которое заполнено: ввёл радиус —
 *     считаем и подписываем как радиус, ввёл диаметр — как диаметр;
 *   - класс звезды (O, B, A, F, G, K, M, L, T) — единственное полностью чёрное поле с
 *     тонкой белой окантовкой; влияет ТОЛЬКО на текстовую приписку-предупреждение о
 *     пригодности к жизни (см. HabitableZoneEngine.starClassNote) и никак не меняет
 *     цифры зоны обитаемости;
 *   - большая полуось орбиты планеты (а.е.) и эксцентриситет (0 <= e < 1) — необязательные
 *     поля; нужны, чтобы проверить, не выходит ли планета на эллиптической орбите за
 *     пределы обитаемой зоны (перицентр / апоцентр);
 *   - остальные поля — тёмно-серые, с белой окантовкой.
 *
 * Расчёт зоны обитаемости — по формулам Kopparapu et al. (2013, ApJ 765:131):
 * консервативная зона (Runaway Greenhouse / Maximum Greenhouse) и оптимистичная зона
 * (Recent Venus / Early Mars). Значения температуры просто подставляются в полиномы
 * Kopparapu напрямую — без дополнительных оговорок о диапазоне калибровки.
 *
 * Под результатом выводится стек предупреждений (в указанном порядке):
 *   1) заметка по классу звезды и её влиянию на жизнь;
 *   2) предупреждение о несоответствии температуры и размера звезде главной
 *      последовательности (считаем всё равно по введённым значениям);
 *   3) предупреждение о периодическом перегреве (перицентр ближе внутренней границы);
 *   4) предупреждение о периодическом замерзании (апоцентр дальше внешней границы).
 *
 * Форматирование результата — адаптивное: по умолчанию 3 знака после запятой, но если
 * число настолько мало, что 3 знака обнуляют его (например 0.000215 -> "0.000"), то
 * автоматически показываем 4 значащих цифры, чтобы пользователь видел реальное значение.
 *
 * AIDE-safe: без лямбд, без androidx, diamond с явным типом, все захваченные
 * в анонимный класс локальные переменные — final.
 */
final class HabitableZonePanel {

    private static final int ACCENT_COLOR        = 0xFFD9946B;
    private static final int ACCENT_BORDER_COLOR = Color.parseColor("#CCD9946B");

    // Цвет текстовых предупреждений под результатом (янтарный, чтобы отличать от
    // персиковой заметки про класс звезды).
    private static final int WARNING_TEXT_COLOR = Color.parseColor("#FFD9A0");

    // Обычные поля (температура, радиус, диаметр, орбита) — тёмно-серые с бело-серой окантовкой.
    private static final int FIELD_BG_GREY          = Color.parseColor("#FF1D1D1F");
    private static final int FIELD_BORDER_WHITEGRAY = Color.parseColor("#BDBABABA");

    // Поле "Класс звезды" — единственное полностью чёрное, с тонкой бело-серой окантовкой.
    private static final int CLASS_FIELD_BG     = FIELD_BG_GREY;
    private static final int CLASS_FIELD_BORDER = FIELD_BORDER_WHITEGRAY;

    // Кнопка выезжающего списка (единицы температуры) — чёрная пилюля, бело-серая окантовка.
    private static final int PILL_BG_COLOR          = Color.BLACK;
    private static final int PILL_BORDER_WHITEGRAY  = Color.parseColor("#B8B8B8B8");
    private static final int DROPDOWN_BG_COLOR       = Color.parseColor("#FF1C1C1E");

    private final Context context;
    private final FrameLayout rootContainer;
    private final Typeface typefaceRegular;
    private final Typeface typefaceSemiBold;

    private FrameLayout overlayRoot;
    private FrameLayout dropdownLayer;

    private static HabitableZonePanel activeInstance;

    private EditText temperatureInput;
    private UnitPillState temperatureUnit;
    private EditText radiusInput;
    private EditText diameterInput;
    private EditText starClassInput;
    private EditText semiMajorAxisInput;
    private EditText eccentricityInput;
    private LinearLayout resultContainer;

    // Защита от рекурсии между вотчерами радиуса и диаметра.
    private boolean suppressSizeWatchers = false;

    private HabitableZonePanel(Context context, FrameLayout rootContainer,
                               Typeface typefaceRegular, Typeface typefaceSemiBold) {
        this.context = context;
        this.rootContainer = rootContainer;
        this.typefaceRegular = typefaceRegular;
        this.typefaceSemiBold = typefaceSemiBold;
    }

    static void show(Context context, FrameLayout rootContainer,
                     Typeface typefaceRegular, Typeface typefaceSemiBold) {
        try {
            if (activeInstance != null) {
                activeInstance.close();
            }
        } catch (Throwable ignore) {
            /* очищение старого окна не критично */
        }
        activeInstance = new HabitableZonePanel(context, rootContainer, typefaceRegular, typefaceSemiBold);
        activeInstance.build();
    }

    private int dp(float value) {
        return (int) TypedValue.applyDimension(
			TypedValue.COMPLEX_UNIT_DIP, value, context.getResources().getDisplayMetrics());
    }

    // =========================================================
    //  Построение окна
    // =========================================================
    private void build() {
        overlayRoot = new FrameLayout(context);
        overlayRoot.setBackgroundColor(Color.parseColor("#CC0F0F10"));
        overlayRoot.setClickable(true);
        overlayRoot.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					close();
				}
			});

        final FrameLayout windowFrame = new FrameLayout(context);
        windowFrame.setClickable(true);
        windowFrame.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					/* поглощаем клик */
				}
			});

        GradientDrawable frameBg = new GradientDrawable();
        frameBg.setShape(GradientDrawable.RECTANGLE);
        frameBg.setCornerRadius(dp(28));
        frameBg.setColor(0xF21E1E20);
        frameBg.setStroke(dp(2), ACCENT_COLOR);
        windowFrame.setBackground(frameBg);
        windowFrame.setClipToOutline(true);
        windowFrame.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);

        android.widget.ImageView blurBg = new android.widget.ImageView(context);
        blurBg.setImageResource(R.drawable.background);
        blurBg.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        blurBg.setRenderEffect(RenderEffect.createBlurEffect(dp(44), dp(44), Shader.TileMode.CLAMP));
        blurBg.setAlpha(0.88f);
        windowFrame.addView(blurBg, matchParentFrameLp());

        View tint = new View(context);
        tint.setBackgroundColor(Color.parseColor("#CC232326"));
        windowFrame.addView(tint, matchParentFrameLp());
        AstroUiEffects.applyPaperEffect(windowFrame, context);

        ScrollView scrollView = new ScrollView(context);
        scrollView.setClipToPadding(false);

        LinearLayout content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        content.setPadding(pad, pad, pad, pad);

        content.addView(buildTitle());
        content.addView(spacer(dp(18)));

        content.addView(buildLabel("Температура звезды"));
        content.addView(spacer(dp(6)));
        ValueUnitRow tempRow = buildTemperatureField();
        temperatureInput = tempRow.input;
        temperatureUnit  = tempRow.unitState;
        content.addView(tempRow.row);

        content.addView(spacer(dp(14)));
        content.addView(buildLabel("Радиус звезды (в радиусах Солнца, R☉)"));
        content.addView(spacer(dp(6)));
        radiusInput = buildGreyPlainTextField("Например, 1.0");
        content.addView(radiusInput);

        content.addView(spacer(dp(14)));
        content.addView(buildLabel("Диаметр звезды (в диаметрах Солнца, D☉)"));
        content.addView(spacer(dp(6)));
        diameterInput = buildGreyPlainTextField("Например, 2.0");
        content.addView(diameterInput);

        content.addView(spacer(dp(8)));
        TextView sizeHint = new DigitTextView(context);
        sizeHint.setText("Указывайте только одно из двух полей — радиус или диаметр.");
        sizeHint.setTextColor(Color.parseColor("#99FFFFFF"));
        sizeHint.setTypeface(typefaceRegular);
        sizeHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        content.addView(sizeHint);
        content.addView(spacer(dp(14)));
        linkRadiusDiameterExclusivity();

        content.addView(buildLabel("Класс звезды (O, B, A, F, G, K, M, L, T)"));
        content.addView(spacer(dp(6)));
        starClassInput = buildStarClassField();
        content.addView(starClassInput);

        content.addView(spacer(dp(14)));
        content.addView(buildLabel("Большая полуось орбиты планеты (а.е.)"));
        content.addView(spacer(dp(6)));
        semiMajorAxisInput = buildGreyPlainTextField("Например, 1.0");
        content.addView(semiMajorAxisInput);

        content.addView(spacer(dp(14)));
        content.addView(buildLabel("Эксцентриситет орбиты планеты (0 ≤ e < 1)"));
        content.addView(spacer(dp(6)));
        eccentricityInput = buildGreyPlainTextField("Например, 0.0167");
        content.addView(eccentricityInput);

        content.addView(spacer(dp(8)));
        TextView orbitHint = new DigitTextView(context);
        orbitHint.setText("Необязательно. Нужно, чтобы проверить, не выходит ли планета на "
						  + "эллиптической орбите за пределы обитаемой зоны (перегрев в перицентре / "
						  + "замерзание в апоцентре).");
        orbitHint.setTextColor(Color.parseColor("#99FFFFFF"));
        orbitHint.setTypeface(typefaceRegular);
        orbitHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        content.addView(orbitHint);

        content.addView(spacer(dp(18)));
        content.addView(buildCalculateButton());
        content.addView(spacer(dp(14)));
        content.addView(buildExplanationBlock());
        content.addView(spacer(dp(10)));

        resultContainer = new LinearLayout(context);
        resultContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(resultContainer);

        content.addView(spacer(dp(20)));

        scrollView.addView(content, new ScrollView.LayoutParams(
							   ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        windowFrame.addView(scrollView, matchParentFrameLp());

        FrameLayout.LayoutParams windowLp = new FrameLayout.LayoutParams(
			ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        int screenMargin = dp(18);
        windowLp.setMargins(screenMargin, screenMargin + dp(30), screenMargin, screenMargin + dp(30));
        overlayRoot.addView(windowFrame, windowLp);
        rootContainer.addView(overlayRoot, matchParentFrameLp());

        windowFrame.post(new Runnable() {
            @Override
            public void run() {
                if (overlayRoot != null && overlayRoot.getParent() == rootContainer && windowFrame != null) {
                    WindowOpenAnimation.start(windowFrame, context.getResources().getDisplayMetrics().density);
                }
            }
        });

        dropdownLayer = new FrameLayout(context);
        overlayRoot.addView(dropdownLayer, matchParentFrameLp());
    }

    private void close() {
        if (overlayRoot != null && overlayRoot.getParent() == rootContainer) {
            rootContainer.removeView(overlayRoot);
        }
        if (activeInstance == this) {
            activeInstance = null;
        }
    }

    // =========================================================
    //  Мелкие UI-хелперы (стиль идентичен окну "Скорость объекта")
    // =========================================================
    private View buildTitle() {
        TextView tv = new DigitTextView(context);
        tv.setText("Зона обитаемости");
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        tv.setGravity(Gravity.START | Gravity.TOP);
        return tv;
    }

    private TextView buildLabel(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#DDE3E1DE"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        return tv;
    }

    private View spacer(int heightPx) {
        View v = new View(context);
        v.setLayoutParams(new LinearLayout.LayoutParams(
							  LinearLayout.LayoutParams.MATCH_PARENT, heightPx));
        return v;
    }

    // =========================================================
    //  Поле температуры (с выезжающим списком единиц)
    // =========================================================
    private static final class ValueUnitRow {
        View row;
        EditText input;
        UnitPillState unitState;
    }

    private static final class UnitPillState {
        TextView pillView;
        int selectedIndex = 0;
        String[] labels;
    }

    private ValueUnitRow buildTemperatureField() {
        String[] labels = new String[] {
			HabitableZoneEngine.TemperatureUnit.KELVIN.label,
			HabitableZoneEngine.TemperatureUnit.FAHRENHEIT.label,
			HabitableZoneEngine.TemperatureUnit.CELSIUS.label
        };
        return buildGreyValueUnitRow(labels, "Например, 5778");
    }

    private ValueUnitRow buildGreyValueUnitRow(final String[] unitLabels, String hint) {
        FrameLayout field = new FrameLayout(context);
        field.setBackground(createRoundedRect(dp(16), FIELD_BG_GREY, FIELD_BORDER_WHITEGRAY, dp(1.25f)));
        AstroUiEffects.applyControlShadow(field, context);
        field.setClipToOutline(true);

        final EditText input = new DigitEditText(context);
        input.setHint(hint);
        input.setHintTextColor(Color.parseColor("#88FFFFFF"));
        input.setTextColor(Color.WHITE);
        input.setTypeface(typefaceRegular);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        input.setSingleLine(true);
        input.setBackground(createRoundedRect(dp(16), FIELD_BG_GREY, FIELD_BORDER_WHITEGRAY, dp(1.25f)));
        AstroUiEffects.applyControlShadow(input, context);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL
						   | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setPadding(dp(16), dp(12), dp(140), dp(12));
        field.addView(input, matchParentFrameLp());

        final UnitPillState state = new UnitPillState();
        state.labels = unitLabels;
        state.selectedIndex = 0;

        final TextView pill = new DigitTextView(context);
        pill.setText(unitLabels[0]);
        pill.setTextColor(Color.WHITE);
        pill.setTypeface(typefaceSemiBold);
        pill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        pill.setGravity(Gravity.CENTER);
        pill.setMaxLines(1);
        pill.setEllipsize(android.text.TextUtils.TruncateAt.END);
        pill.setBackground(createRoundedRect(dp(14), PILL_BG_COLOR, PILL_BORDER_WHITEGRAY, dp(1)));
        pill.setPadding(dp(12), dp(8), dp(12), dp(8));
        pill.setClickable(true);
        pill.setFocusable(true);

        FrameLayout.LayoutParams pillLp = new FrameLayout.LayoutParams(
			dp(118), FrameLayout.LayoutParams.WRAP_CONTENT);
        pillLp.gravity = Gravity.CENTER_VERTICAL | Gravity.END;
        pillLp.rightMargin = dp(8);
        field.addView(pill, pillLp);
        pill.setTranslationZ(dp(3f));
        state.pillView = pill;

        pill.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					HapticUtils.perform(v);
					openDropdown(pill, unitLabels, state.selectedIndex, new OnUnitSelected() {
							@Override
							public void onSelected(int newIndex) {
								state.selectedIndex = newIndex;
								pill.setText(unitLabels[newIndex]);
							}
						});
				}
			});

        field.setLayoutParams(new LinearLayout.LayoutParams(
								  LinearLayout.LayoutParams.MATCH_PARENT, dp(50)));

        ValueUnitRow row = new ValueUnitRow();
        row.row = field;
        row.input = input;
        row.unitState = state;
        return row;
    }

    private EditText buildGreyPlainTextField(String hint) {
        EditText input = new DigitEditText(context);
        input.setHint(hint);
        input.setHintTextColor(Color.parseColor("#88FFFFFF"));
        input.setTextColor(Color.WHITE);
        input.setTypeface(typefaceRegular);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL
						   | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setBackground(createRoundedRect(dp(16), FIELD_BG_GREY, FIELD_BORDER_WHITEGRAY, dp(1.25f)));
        AstroUiEffects.applyControlShadow(input, context);
        input.setPadding(dp(16), dp(12), dp(16), dp(12));
        input.setLayoutParams(new LinearLayout.LayoutParams(
								  LinearLayout.LayoutParams.MATCH_PARENT, dp(50)));
        return input;
    }

    /** Единственное полностью чёрное поле, с тонкой белой (1 dp) окантовкой. */
    private EditText buildStarClassField() {
        EditText input = new DigitEditText(context);
        input.setHint("Например, G2V или просто T");
        input.setHintTextColor(Color.parseColor("#88FFFFFF"));
        input.setTextColor(Color.WHITE);
        input.setTypeface(typefaceRegular);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        input.setBackground(createRoundedRect(dp(16), CLASS_FIELD_BG, CLASS_FIELD_BORDER, dp(1)));
        AstroUiEffects.applyControlShadow(input, context);
        input.setPadding(dp(16), dp(12), dp(16), dp(12));
        input.setLayoutParams(new LinearLayout.LayoutParams(
								  LinearLayout.LayoutParams.MATCH_PARENT, dp(50)));
        return input;
    }

    /**
     * Радиус и диаметр — взаимоисключающие поля: как только пользователь начинает
     * вводить значение в одно из них, второе (если там что-то было) автоматически
     * очищается. suppressSizeWatchers защищает от рекурсии между вотчерами.
     */
    private void linkRadiusDiameterExclusivity() {
        radiusInput.addTextChangedListener(new TextWatcher() {
				@Override
				public void beforeTextChanged(CharSequence s, int start, int count, int after) {
					/* не требуется */
				}

				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {
					/* не требуется */
				}

				@Override
				public void afterTextChanged(Editable s) {
					if (suppressSizeWatchers) return;
					if (s.length() > 0 && diameterInput.getText().length() > 0) {
						suppressSizeWatchers = true;
						diameterInput.setText("");
						suppressSizeWatchers = false;
					}
				}
			});

        diameterInput.addTextChangedListener(new TextWatcher() {
				@Override
				public void beforeTextChanged(CharSequence s, int start, int count, int after) {
					/* не требуется */
				}

				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {
					/* не требуется */
				}

				@Override
				public void afterTextChanged(Editable s) {
					if (suppressSizeWatchers) return;
					if (s.length() > 0 && radiusInput.getText().length() > 0) {
						suppressSizeWatchers = true;
						radiusInput.setText("");
						suppressSizeWatchers = false;
					}
				}
			});
    }

    // =========================================================
    //  Dropdown (идентичен по механике и форме окну "Скорость объекта")
    // =========================================================
    private interface OnUnitSelected {
        void onSelected(int index);
    }

    private void openDropdown(final View anchor, final String[] labels, int selectedIndex,
                              final OnUnitSelected callback) {
        dropdownLayer.removeAllViews();

        int[] anchorLoc = new int[2];
        anchor.getLocationOnScreen(anchorLoc);
        int[] rootLoc = new int[2];
        dropdownLayer.getLocationOnScreen(rootLoc);
        int relativeX = anchorLoc[0] - rootLoc[0];
        int relativeY = anchorLoc[1] - rootLoc[1] + anchor.getHeight();

        View scrim = new View(context);
        scrim.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					dropdownLayer.removeAllViews();
				}
			});
        dropdownLayer.addView(scrim, matchParentFrameLp());

        LinearLayout list = new LinearLayout(context);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setBackground(createRoundedRect(dp(14), DROPDOWN_BG_COLOR, ACCENT_BORDER_COLOR, dp(1.25f)));
        list.setClipToOutline(true);
        list.setPadding(dp(6), dp(6), dp(6), dp(6));

        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView item = new DigitTextView(context);
            item.setText(labels[i]);
            item.setTextColor(i == selectedIndex ? ACCENT_COLOR : Color.WHITE);
            item.setTypeface(i == selectedIndex ? typefaceSemiBold : typefaceRegular);
            AstroUiEffects.applyUnitTypeface(item, context);
            item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            item.setPadding(dp(14), dp(10), dp(14), dp(10));
            item.setClickable(true);
            item.setFocusable(true);
            item.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						HapticUtils.perform(v);
						callback.onSelected(idx);
						dropdownLayer.removeAllViews();
					}
				});
            list.addView(item, new LinearLayout.LayoutParams(
							 LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        }

        int available = dropdownLayer.getHeight() - relativeY - dp(8);
        final int maxHeight = available > 0 ? available : 0;

        ScrollView listScroll = new ScrollView(context) {
            @Override
            protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                int hSpec = heightMeasureSpec;
                if (maxHeight > 0) {
                    int mode = View.MeasureSpec.getMode(hSpec);
                    int size = View.MeasureSpec.getSize(hSpec);
                    if (mode == View.MeasureSpec.UNSPECIFIED || size > maxHeight) {
                        hSpec = View.MeasureSpec.makeMeasureSpec(maxHeight, View.MeasureSpec.AT_MOST);
                    }
                }
                super.onMeasure(widthMeasureSpec, hSpec);
            }
        };
        listScroll.addView(list, new ScrollView.LayoutParams(
							   ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        listScroll.setBackground(list.getBackground());
        list.setBackground(null);

        FrameLayout.LayoutParams listLp = new FrameLayout.LayoutParams(
			dp(190), FrameLayout.LayoutParams.WRAP_CONTENT);
        listLp.leftMargin = Math.max(dp(8), relativeX + anchor.getWidth() - dp(190));
        listLp.topMargin = relativeY + dp(4);
        dropdownLayer.addView(listScroll, listLp);
    }

    // =========================================================
    //  Кнопка расчёта (увеличенная, персикового цвета) и результат
    // =========================================================
    private View buildCalculateButton() {
        TextView btn = new DigitTextView(context);
        btn.setText("Рассчитать");
        btn.setTextColor(Color.WHITE);
        btn.setTypeface(typefaceSemiBold);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(0, dp(18), 0, dp(18));
        btn.setBackground(createRoundedRect(dp(22), ACCENT_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        AstroUiEffects.applyControlShadow(btn, context);
        btn.setClickable(true);
        btn.setFocusable(true);
        btn.setLayoutParams(new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        btn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					HapticUtils.perform(v);
					onCalculatePressed();
				}
			});
        return btn;
    }
    private View buildExplanationBlock() {
        LinearLayout block = new LinearLayout(context);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setLayoutParams(new LinearLayout.LayoutParams(
								  LinearLayout.LayoutParams.MATCH_PARENT,
								  LinearLayout.LayoutParams.WRAP_CONTENT
							  ));

        TextView title = new DigitTextView(context);
        title.setText("Как считается зона обитаемости");
        title.setTextColor(Color.WHITE);
        title.setTypeface(typefaceSemiBold);

        AstroUiEffects.applyExplanationTypeface(title, context);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        block.addView(title);

        block.addView(spacer(dp(8)));
        block.addView(buildExplanationLine("1) Переводим температуру в K: T_eff."));
        block.addView(spacer(dp(4)));
        block.addView(buildExplanationLine("2) Если введены радиус или диаметр, приводим их к масштабу звезды: R = k · R☉."));
        block.addView(spacer(dp(4)));
        block.addView(buildExplanationLine("3) Светимость: L/L☉ = (R/R☉)² · (T_eff/T☉)⁴."));
        block.addView(spacer(dp(4)));
        block.addView(buildExplanationLine("4) Поток на границах берём из полиномов Kopparapu: S_eff(T_eff) = S₀ + a·T + b·T² + c·T³ + d·T⁴."));
        block.addView(spacer(dp(4)));
        block.addView(buildExplanationLine("5) Границы в а.е.: a_in = √(L / S_eff,in), a_out = √(L / S_eff,out)."));
        block.addView(spacer(dp(4)));
        block.addView(buildExplanationLine("6) Если задана орбита, проверяем q = a(1 − e) и Q = a(1 + e)."));

        return block;
    }

    private TextView buildExplanationLine(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#CFE3E1DE"));
        tv.setTypeface(typefaceRegular);
        AstroUiEffects.applyExplanationTypeface(tv, context);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        tv.setLineSpacing(dp(2), 1.08f);
        return tv;
    }


    /** Обёрнуто в try/catch(Throwable): любая ошибка не должна ронять окно. */
    private void onCalculatePressed() {
        try {
            resultContainer.removeAllViews();

            Double tempValue = parseDouble(temperatureInput.getText().toString());
            if (tempValue == null) {
                showResultError("Введите корректную температуру звезды (число).");
                return;
            }
            HabitableZoneEngine.TemperatureUnit tUnit =
				HabitableZoneEngine.TemperatureUnit.values()[temperatureUnit.selectedIndex];
            double teffK = tUnit.toKelvin(tempValue);
            if (teffK <= 0) {
                showResultError("Температура звезды получилась ≤ 0 К — проверьте значение и единицы измерения.");
                return;
            }

            Double radiusValue   = parseDouble(radiusInput.getText().toString());
            Double diameterValue = parseDouble(diameterInput.getText().toString());

            // Считаем строго по тому полю, которое заполнено. Численно R в R☉ и D в D☉ —
            // одно и то же масштабирование, поэтому sizeSolar = введённое число, а
            // radiusMeters = sizeSolar * R☉(м). usedDiameter влияет только на подпись/единицы.
            boolean usedDiameter;
            double sizeSolar;
            if (radiusValue != null && radiusValue > 0) {
                usedDiameter = false;
                sizeSolar = radiusValue;
            } else if (diameterValue != null && diameterValue > 0) {
                usedDiameter = true;
                sizeSolar = diameterValue;
            } else {
                showResultError("Укажите радиус или диаметр звезды (одно из двух, положительное число).");
                return;
            }
            double radiusMeters = sizeSolar * HabitableZoneEngine.SUN_RADIUS_M;

            // Орбита планеты (необязательно).
            Double aVal = parseDouble(semiMajorAxisInput.getText().toString());
            Double eVal = parseDouble(eccentricityInput.getText().toString());
            boolean hasA  = aVal != null && aVal > 0;
            boolean hasE  = eVal != null;
            boolean eValid = hasE && eVal >= 0.0 && eVal < 1.0;
            Double peri = null;
            Double apo  = null;
            if (hasA && eValid) {
                peri = aVal * (1.0 - eVal);
                apo  = aVal * (1.0 + eVal);
            }

            HabitableZoneEngine.Result result = HabitableZoneEngine.compute(teffK, radiusMeters);
            showResult(teffK, result, usedDiameter, aVal, eVal, hasA, hasE, eValid, peri, apo);
        } catch (Throwable t) {
            resultContainer.removeAllViews();
            showResultError("Ошибка при расчёте:\n" + stack(t));
        }
    }

    private Double parseDouble(String text) {
        if (text == null) return null;
        String trimmed = text.trim().replace(',', '.');
        if (trimmed.isEmpty()) return null;
        try {
            return Double.parseDouble(trimmed);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void showResultError(String message) {
        TextView tv = new DigitTextView(context);
        tv.setText(message);
        tv.setTextColor(Color.parseColor("#FFB4A0"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        resultContainer.addView(tv);
    }

    private void showResult(double teffK, HabitableZoneEngine.Result result, boolean usedDiameter,
                            Double aVal, Double eVal, boolean hasA, boolean hasE, boolean eValid,
                            Double peri, Double apo) {
        LinearLayout box = resultBox();
        box.addView(resultSectionTitle("Результат"));
        box.addView(spacer(dp(8)));

        // Подпись и единица зависят от того, что вводил пользователь: радиус или диаметр.
        String sizeLabel  = usedDiameter ? "Диаметр звезды" : "Радиус звезды";
        String sizeSuffix = usedDiameter ? "D☉" : "R☉";
        box.addView(resultLine(sizeLabel, fmt3(result.radiusSolar) + " " + sizeSuffix));
        box.addView(spacer(dp(6)));

        box.addView(resultLine("Светимость звезды", fmt3(result.luminosityRatio) + " L☉"));
        box.addView(spacer(dp(10)));

        box.addView(resultLine("Консервативная зона обитаемости",
							   fmt3(result.conservativeInnerAu) + " – " + fmt3(result.conservativeOuterAu) + " а.е."));
        box.addView(spacer(dp(6)));

        box.addView(resultLine("Оптимистичная зона обитаемости",
							   fmt3(result.optimisticInnerAu) + " – " + fmt3(result.optimisticOuterAu) + " а.е."));

        // ---- Стек предупреждений / заметок под числовым результатом ----
        boolean anyNote = false;

        // (1) Заметка по классу звезды — самое первое предупреждение, на расчёт не влияет.
        String classNote = HabitableZoneEngine.starClassNote(starClassInput.getText().toString());
        if (classNote != null) {
            box.addView(spacer(dp(12)));
            box.addView(noteView(classNote, ACCENT_COLOR));
            anyNote = true;
        }

        // (2) Нереалистичная пара "температура <-> размер" для главной последовательности.
        double expectedR = HabitableZoneEngine.expectedRadiusSolarForTeff(teffK);
        boolean realistic = HabitableZoneEngine.isRealisticSizeForTeff(teffK, result.radiusSolar);
        if (!realistic) {
            box.addView(spacer(anyNote ? dp(8) : dp(12)));
            box.addView(noteView(
							"Указанные температура (" + String.format(Locale.US, "%.0f К", teffK)
                            + ") и размер (" + fmt3(result.radiusSolar) + " " + sizeSuffix
                            + ") не согласуются со звездой главной последовательности: для такой "
                            + "температуры типичный радиус ≈ " + fmt3(expectedR)
                            + " R☉. Расчёт выполнен строго по введённым вами значениям.",
							WARNING_TEXT_COLOR));
            anyNote = true;
        }

        // (3)/(4) Проверки эллиптической орбиты относительно консервативной зоны.
        if (hasE && !eValid) {
            box.addView(spacer(anyNote ? dp(8) : dp(12)));
            box.addView(noteView(
							"Эксцентриситет должен быть в диапазоне 0 ≤ e < 1; проверка орбиты пропущена.",
							WARNING_TEXT_COLOR));
            anyNote = true;
        } else if (hasE && !hasA) {
            box.addView(spacer(anyNote ? dp(8) : dp(12)));
            box.addView(noteView(
							"Эксцентриситет учтён не будет: укажите также большую полуось орбиты "
                            + "планеты (а.е.), чтобы проверить выход за пределы обитаемой зоны.",
							WARNING_TEXT_COLOR));
            anyNote = true;
        } else if (hasA && eValid && peri != null && apo != null) {
            String orbitTag = "Орбита планеты (a = " + fmt3(aVal) + " а.е., e = "
				+ String.format(Locale.US, "%.4f", eVal) + "): ";
            // Перегрев: перицентр ближе внутренней границы обитаемой зоны.
            if (peri < result.conservativeInnerAu) {
                box.addView(spacer(anyNote ? dp(8) : dp(12)));
                box.addView(noteView(
								orbitTag + "в перицентре (q = " + fmt3(peri)
                                + " а.е.) планета проходит ближе внутренней границы обитаемой зоны ("
                                + fmt3(result.conservativeInnerAu)
                                + " а.е.) — периодический перегрев поверхности.",
								WARNING_TEXT_COLOR));
                anyNote = true;
            }
            // Замерзание: апоцентр дальше внешней границы обитаемой зоны.
            if (apo > result.conservativeOuterAu) {
                box.addView(spacer(anyNote ? dp(8) : dp(12)));
                box.addView(noteView(
								orbitTag + "в апоцентре (Q = " + fmt3(apo)
                                + " а.е.) планета уходит за внешнюю границу обитаемой зоны ("
                                + fmt3(result.conservativeOuterAu)
                                + " а.е.) — периодическое замерзание.",
								WARNING_TEXT_COLOR));
                anyNote = true;
            }
        }

        resultContainer.addView(box);
    }

    /** Текстовая заметка/предупреждение под результатом. */
    private TextView noteView(String text, int color) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(color);
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        return tv;
    }

    /**
     * Адаптивное форматирование числа для результата.
     *
     * По умолчанию — 3 знака после запятой (чтобы "1.000 R☉", "0.019 а.е." выглядели
     * чисто и единообразно). Но если число ненулевое, а 3 знака схлопывают его в
     * "0.000" (классический кейс: светимость 0.000215 L☉), то переключаемся на вывод
     * 4 значащих цифр, чтобы пользователь видел реальное значение, а не обманчивый ноль.
     */
    private static String fmt3(double v) {
        if (Double.isNaN(v) || Double.isInfinite(v)) {
            return String.valueOf(v);
        }
        String s = String.format(Locale.US, "%.3f", v);
        if (v != 0.0) {
            double rounded = Double.parseDouble(s);
            if (rounded == 0.0) {
                return fmtSig(v, 4);
            }
        }
        return s;
    }

    /** Форматирование с заданным числом значащих цифр (для очень малых величин). */
    private static String fmtSig(double v, int sig) {
        double abs = Math.abs(v);
        int digitsAfter;
        if (abs < 1e-12) {
            digitsAfter = 0;
        } else {
            digitsAfter = sig - 1 - (int) Math.floor(Math.log10(abs));
        }
        if (digitsAfter < 0) digitsAfter = 0;
        if (digitsAfter > 12) digitsAfter = 12;
        return String.format(Locale.US, "%." + digitsAfter + "f", v);
    }

    /** Короткий stack trace для показа в окне (обрезаем, чтобы не раздувать UI). */
    private static String stack(Throwable t) {
        try {
            java.io.StringWriter sw = new java.io.StringWriter();
            t.printStackTrace(new java.io.PrintWriter(sw));
            String s = sw.toString();
            return s.length() > 1500 ? s.substring(0, 1500) + "…" : s;
        } catch (Throwable ignore) {
            return String.valueOf(t);
        }
    }

    // =========================================================
    //  Утилиты
    // =========================================================
    private LinearLayout resultBox() {
        LinearLayout box = new LinearLayout(context);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(createRoundedRect(dp(16), Color.parseColor("#6F6B67"),
											ACCENT_BORDER_COLOR, dp(1.5f)));
        int p = dp(14);
        box.setPadding(p, p, p, p);
        box.setLayoutParams(new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return box;
    }

    private TextView resultSectionTitle(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        return tv;
    }

    private View resultLine(String label, String value) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.VERTICAL);

        TextView labelView = new DigitTextView(context);
        labelView.setText(label);
        labelView.setTextColor(Color.parseColor("#BBFFFFFF"));
        labelView.setTypeface(typefaceRegular);
        labelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        row.addView(labelView);

        TextView valueView = new DigitTextView(context);
        valueView.setText(value);
        valueView.setTextColor(ACCENT_COLOR);
        valueView.setTypeface(typefaceSemiBold);
        valueView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        row.addView(valueView);

        return row;
    }

    private GradientDrawable createRoundedRect(float radius, int fillColor,
                                               int strokeColor, float strokeWidth) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(radius);
        gd.setColor(fillColor);
        gd.setStroke((int) strokeWidth, strokeColor);
        return gd;
    }

    private FrameLayout.LayoutParams matchParentFrameLp() {
        return new FrameLayout.LayoutParams(
			FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
    }

    // =========================================================
    //  ★ Формулы зоны обитаемости (Kopparapu et al. 2013, ApJ 765:131)
    // =========================================================
    static final class HabitableZoneEngine {

        private HabitableZoneEngine() { /* utility */ }

        static final double SUN_RADIUS_M = 6.957e8;
        static final double SUN_TEFF_K   = 5780.0;

        /** Ширина коридора "реалистичности" размера для данной температуры (×N вверх/вниз). */
        private static final double REALISTIC_FACTOR = 3.0;

        /**
         * Опорные точки главной последовательности (Teff, K) -> (R, R☉), отсортированы
         * по возрастанию температуры. Используются для log-log интерполяции/экстраполяции
         * "ожидаемого" радиуса звезды ГП при заданной Teff — чтобы ловить явные
         * несоответствия температуры и размера (расчёт зоны при этом идёт по введённым
         * значениям, см. showResult).
         */
        private static final double[] MS_TEFF = new double[] {
			2000, 2500, 3000, 3500, 4000, 4500, 5000, 5500, 5780,
			6000, 6500, 7000, 7500, 8000, 9000, 10000, 15000, 20000, 30000, 40000, 50000
        };
        private static final double[] MS_R = new double[] {
			0.12, 0.15, 0.20, 0.35, 0.55, 0.70, 0.80, 0.92, 1.00,
			1.10, 1.30, 1.50, 1.70, 1.90, 2.30, 2.80, 5.0, 6.5, 9.0, 12.0, 15.0
        };

        /** Степенной закон (лог-лог) по двум опорным точкам; работает и как экстраполяция. */
        private static double powerLaw(double t1, double r1, double t2, double r2, double t) {
            double lt  = Math.log(t);
            double lt1 = Math.log(t1);
            double lt2 = Math.log(t2);
            double lr1 = Math.log(r1);
            double lr2 = Math.log(r2);
            double lr  = lr1 + (lr2 - lr1) * (lt - lt1) / (lt2 - lt1);
            return Math.exp(lr);
        }

        /** Ожидаемый радиус (в R☉) звезды главной последовательности при заданной Teff. */
        static double expectedRadiusSolarForTeff(double teffK) {
            if (teffK <= 0) return Double.NaN;
            int n = MS_TEFF.length;
            if (teffK <= MS_TEFF[0]) {
                return powerLaw(MS_TEFF[0], MS_R[0], MS_TEFF[1], MS_R[1], teffK);
            }
            if (teffK >= MS_TEFF[n - 1]) {
                return powerLaw(MS_TEFF[n - 2], MS_R[n - 2], MS_TEFF[n - 1], MS_R[n - 1], teffK);
            }
            int i = 1;
            while (i < n - 1 && MS_TEFF[i] < teffK) {
                i++;
            }
            return powerLaw(MS_TEFF[i - 1], MS_R[i - 1], MS_TEFF[i], MS_R[i], teffK);
        }

        /**
         * Реалистичен ли указанный размер для данной температуры в рамках главной
         * последовательности (попадает ли в коридор ×REALISTIC_FACTOR вокруг ожидаемого).
         * Если оценку дать нельзя — считаем реалистичным (не ругаемся зря).
         */
        static boolean isRealisticSizeForTeff(double teffK, double radiusSolar) {
            double expected = expectedRadiusSolarForTeff(teffK);
            if (Double.isNaN(expected) || expected <= 0 || radiusSolar <= 0) {
                return true;
            }
            double ratio = radiusSolar / expected;
            return ratio >= 1.0 / REALISTIC_FACTOR && ratio <= REALISTIC_FACTOR;
        }

        /** Единицы измерения температуры звезды. */
        enum TemperatureUnit {
            KELVIN("Кельвины"),
            FAHRENHEIT("Фаренгейты"),
            CELSIUS("Цельсия");

            final String label;

            TemperatureUnit(String label) {
                this.label = label;
            }

            double toKelvin(double value) {
                switch (this) {
                    case FAHRENHEIT:
                        return (value - 32.0) * 5.0 / 9.0 + 273.15;
                    case CELSIUS:
                        return value + 273.15;
                    default:
                        return value;
                }
            }
        }

        /** Один из калиброванных пределов Kopparapu et al. (2013), таблица 3. */
        private static final class Boundary {
            final double seffSun, a, b, c, d;

            Boundary(double seffSun, double a, double b, double c, double d) {
                this.seffSun = seffSun;
                this.a = a;
                this.b = b;
                this.c = c;
                this.d = d;
            }

            double seff(double teffK) {
                double dT = teffK - SUN_TEFF_K;
                return seffSun + a * dT + b * dT * dT + c * dT * dT * dT + d * dT * dT * dT * dT;
            }
        }

        // Консервативная зона: Runaway Greenhouse (внутр.) / Maximum Greenhouse (внешн.)
        private static final Boundary RUNAWAY_GREENHOUSE =
		new Boundary(1.0512, 1.3242e-4, 1.5418e-8, -7.9895e-12, -1.8328e-15);
        private static final Boundary MAXIMUM_GREENHOUSE =
		new Boundary(0.3438, 5.8942e-5, 1.6558e-9, -3.0045e-12, -5.2983e-16);

        // Оптимистичная зона: Recent Venus (внутр.) / Early Mars (внешн.)
        private static final Boundary RECENT_VENUS =
		new Boundary(1.7753, 1.4316e-4, 2.9875e-9, -7.5702e-12, -1.1635e-15);
        private static final Boundary EARLY_MARS =
		new Boundary(0.3179, 5.4513e-5, 1.5313e-9, -2.7786e-12, -4.8997e-16);

        private static double luminosityRatio(double radiusM, double teffK) {
            double rRatio = radiusM / SUN_RADIUS_M;
            double tRatio = teffK / SUN_TEFF_K;
            return rRatio * rRatio * tRatio * tRatio * tRatio * tRatio;
        }

        private static double distanceAu(double luminosityRatio, double seff) {
            return Math.sqrt(luminosityRatio / seff);
        }

        static final class Result {
            double luminosityRatio;
            double radiusSolar;
            double conservativeInnerAu;
            double conservativeOuterAu;
            double optimisticInnerAu;
            double optimisticOuterAu;
        }

        static Result compute(double teffK, double radiusM) {
            Result r = new Result();
            r.luminosityRatio = luminosityRatio(radiusM, teffK);
            r.radiusSolar = radiusM / SUN_RADIUS_M;
            r.conservativeInnerAu = distanceAu(r.luminosityRatio, RUNAWAY_GREENHOUSE.seff(teffK));
            r.conservativeOuterAu = distanceAu(r.luminosityRatio, MAXIMUM_GREENHOUSE.seff(teffK));
            r.optimisticInnerAu   = distanceAu(r.luminosityRatio, RECENT_VENUS.seff(teffK));
            r.optimisticOuterAu   = distanceAu(r.luminosityRatio, EARLY_MARS.seff(teffK));
            return r;
        }

        /**
         * Текстовая приписка по классу звезды. НЕ участвует в расчёте выше — это
         * только качественный комментарий к результату (см. ТЗ пользователя).
         * Возвращает null, если класс не введён или не распознан.
         * Поддерживаются O, B, A, F, G, K, M, а также L (сверххолодные карлики) и
         * T (коричневые карлики) — последние два влияют только на этот текст.
         */
        static String starClassNote(String rawClassText) {
            if (rawClassText == null) return null;
            String trimmed = rawClassText.trim();
            if (trimmed.isEmpty()) return null;
            char c = Character.toUpperCase(trimmed.charAt(0));
            switch (c) {
                case 'K':
                case 'G':
                case 'F':
                    return "Класс " + c + " — планета в расчётной зоне обитаемости примерно "
						+ "подходит для существования жизни и похожих на земные условий.";
                case 'M':
                    return "Класс M — низкая светимость и высокая активность звезды: риск "
						+ "низкого уровня развития цивилизации или малая вероятность жизни.";
                case 'L':
                    return "Класс L — сверххолодный карлик с крайне низкой светимостью: обитаемая "
						+ "зона очень тесная, вероятен приливный захват и мощные вспышки — "
						+ "малая вероятность сложной жизни.";
                case 'T':
                    return "Класс T — коричневый карлик: светимость ничтожна и падает со временем, "
						+ "обитаемая зона нестабильна и прижата к звезде — вероятность жизни "
						+ "крайне мала.";
                case 'O':
                case 'A':
                case 'B':
                    return "Класс " + c + " — высокий уровень ультрафиолетового излучения, "
						+ "низкая вероятность устойчивого магнитного поля и стабильной "
						+ "атмосферы у планет.";
                default:
                    return null;
            }
        }
    }
}

