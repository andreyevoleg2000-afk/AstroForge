package com.astroforge;

/**
 * Zero-allocation floating-point expansion arithmetic.
 *
 * Число хранится как плоский double[] из 16 элементов.
 * Используется подход Shewchuk / Dekker:
 * - exact two-sum при сложении expansion;
 * - exact two-product через Dekker splitting при умножении.
 *
 * Компоненты expansion идут от меньших по модулю к большим.
 * Нулевые хвосты считаются концом числа.
 */
final class GravityExpansionMath {

    static final int N = 16;

    /**
     * Рабочий буфер должен вмещать произведение 16x16.
     * 1024 с запасом хватает для точных промежуточных expansion.
     */
    private static final int WORK = 1024;

    /**
     * Dekker split constant: 2^27 + 1.
     */
    private static final double SPLIT = 134217729.0;

    static final class Context {
        final double[] work1 = new double[WORK];
        final double[] work2 = new double[WORK];
        final double[] prod2 = new double[2];
    }

    private GravityExpansionMath() {
        // utility
    }

    static void zero(double[] e) {
        for (int i = 0; i < N; i++) {
            e[i] = 0.0;
        }
    }

    static void fromDouble(double value, double[] out) {
        if (!Double.isFinite(value) || value == 0.0) {
            zero(out);
            return;
        }
        out[0] = value;
        for (int i = 1; i < N; i++) {
            out[i] = 0.0;
        }
    }

    static int length(double[] e) {
        int len = 0;
        while (len < N && e[len] != 0.0) {
            len++;
        }
        return len;
    }

    /**
     * Кладёт результат в dst.
     * Если длина expansion больше 16, сохраняем старшие 16 компонент.
     * Младшие отбрасываются.
     */
    static void copyTop(double[] src, int len, double[] dst) {
        if (len <= 0) {
            zero(dst);
            return;
        }

        if (len <= N) {
            for (int i = 0; i < len; i++) {
                dst[i] = src[i];
            }
            for (int i = len; i < N; i++) {
                dst[i] = 0.0;
            }
            return;
        }

        int start = len - N;
        for (int i = 0; i < N; i++) {
            dst[i] = src[start + i];
        }
    }

    /**
     * Точное сложение expansion.
     * out может совпадать с a или b.
     */
    static void add(double[] a, double[] b, double[] out, double[] work1, double[] work2) {
        int alen = length(a);
        int blen = length(b);
        int len = addRaw(a, alen, b, blen, work1, work2);
        copyTop(work1, len, out);
    }

    static int addRaw(
		double[] a,
		int alen,
		double[] b,
		int blen,
		double[] dst,
		double[] tmp
    ) {
        if (alen == 0) {
            if (blen == 0) {
                return 0;
            }
            System.arraycopy(b, 0, dst, 0, blen);
            return blen;
        }

        System.arraycopy(a, 0, dst, 0, alen);
        int len = alen;

        double[] src = dst;
        double[] alt = tmp;

        for (int i = 0; i < blen; i++) {
            double add = b[i];
            if (add == 0.0) {
                continue;
            }

            len = growExpansion(src, len, add, alt);

            double[] swap = src;
            src = alt;
            alt = swap;
        }

        if (src != dst) {
            System.arraycopy(src, 0, dst, 0, len);
        }

        return len;
    }

    /**
     * Shewchuk grow_expansion.
     * Добавляет скаляр b к expansion e, возвращает новый expansion в h.
     */
    static int growExpansion(double[] e, int elen, double b, double[] h) {
        if (b == 0.0) {
            if (e != h) {
                System.arraycopy(e, 0, h, 0, elen);
            }
            return elen;
        }

        double Q = b;
        int hindex = 0;

        for (int i = 0; i < elen; i++) {
            double enow = e[i];

            double x = enow + Q;
            double bv = x - enow;
            double av = x - bv;
            double br = Q - bv;
            double ar = enow - av;
            double hh = ar + br;

            if (hh != 0.0) {
                h[hindex++] = hh;
            }

            Q = x;
        }

        if (Q != 0.0 || hindex == 0) {
            h[hindex++] = Q;
        }

        return hindex;
    }

    /**
     * Точное умножение expansion.
     * out может совпадать с a или b.
     */
    static void multiply(double[] a, double[] b, double[] out, Context ctx) {
        int alen = length(a);
        int blen = length(b);
        int len = multiplyRaw(alen, blen, a, b, ctx.work1, ctx.work2, ctx.prod2);
        copyTop(ctx.work1, len, out);
    }

    static int multiplyRaw(
		int alen,
		int blen,
		double[] a,
		double[] b,
		double[] dst,
		double[] tmp,
		double[] prod2
    ) {
        int accLen = 0;

        double[] acc = dst;
        double[] alt = tmp;

        for (int i = 0; i < alen; i++) {
            double ai = a[i];
            if (ai == 0.0) {
                continue;
            }

            for (int j = 0; j < blen; j++) {
                double bj = b[j];
                if (bj == 0.0) {
                    continue;
                }

                twoProduct(ai, bj, prod2);

                if (prod2[0] != 0.0) {
                    accLen = growExpansion(acc, accLen, prod2[0], alt);

                    double[] swap = acc;
                    acc = alt;
                    alt = swap;
                }

                if (prod2[1] != 0.0) {
                    accLen = growExpansion(acc, accLen, prod2[1], alt);

                    double[] swap = acc;
                    acc = alt;
                    alt = swap;
                }
            }
        }

        if (acc != dst) {
            System.arraycopy(acc, 0, dst, 0, accLen);
        }

        return accLen;
    }

    /**
     * Dekker two-product.
     * out[0] = error, out[1] = main product.
     */
    static void twoProduct(double a, double b, double[] out) {
        double x = a * b;

        if (!Double.isFinite(x)) {
            out[0] = 0.0;
            out[1] = 0.0;
            return;
        }

        double c = SPLIT * a;
        double abig = c - a;
        double ahi = c - abig;
        double alo = a - ahi;

        double d = SPLIT * b;
        double bbig = d - b;
        double bhi = d - bbig;
        double blo = b - bhi;

        double y = alo * blo - (((x - ahi * bhi) - alo * bhi) - ahi * blo);

        out[0] = y;
        out[1] = x;
    }

    static double toDouble(double[] e) {
        int len = length(e);
        double s = 0.0;
        for (int i = 0; i < len; i++) {
            s += e[i];
        }
        return s;
    }

    static String toShortString(double[] e) {
        int len = length(e);
        if (len == 0) {
            return "0";
        }

        StringBuilder sb = new StringBuilder();
        int start = Math.max(0, len - 4);

        for (int i = start; i < len; i++) {
            if (i > start) {
                sb.append(" | ");
            }

            double v = e[i];
            if (!Double.isFinite(v)) {
                v = 0.0;
            }

            sb.append(String.format(java.util.Locale.US, "%.8e", v));
        }

        return sb.toString();
    }
}
