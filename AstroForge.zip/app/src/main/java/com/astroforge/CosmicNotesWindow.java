package com.astroforge;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * Полноэкранный блокнот заметок.
 * Работает только на внутреннем хранилище приложения: getFilesDir().
 * ВАЖНО: код написан без лямбд и прочих новшеств Java 8+ —
 * все обработчики заданы анонимными классами, а переменные,
 * используемые внутри них, объявлены final явно. Благодаря этому
 * файл собирается даже в компиляторах уровня Java 7.
 */
public final class CosmicNotesWindow {

    private CosmicNotesWindow() {
    }

    private static final String OVERLAY_TAG = "cosmic_notes_overlay";
    private static final String PREFS = "cosmic_notes_store";
    private static final String PREF_LAST_NOTE_ID = "last_note_id";
    private static final String DIR_NAME = "cosmic_notes";
    private static final String FILE_EXT = ".json";

    // Ключи общих настроек приложения (те же, что и в MainActivity)
    private static final String PREFS_APP = "astroforge_prefs";
    private static final String KEY_CUSTOM_KEYBOARD = "custom_keyboard_enabled";

    private static final int COLOR_BG = Color.parseColor("#696969");
    private static final int COLOR_PANEL = Color.parseColor("#4E4E4E");
    private static final int COLOR_CARD = Color.parseColor("#5C5C5C");
    private static final int COLOR_CARD_ALT = Color.parseColor("#626262");
    private static final int COLOR_TEXT = Color.parseColor("#F0EFEA");
    private static final int COLOR_SUBTEXT = Color.parseColor("#D8D8D8");
    private static final int COLOR_ACCENT = Color.parseColor("#D58B5A");
    private static final int COLOR_BORDER = Color.parseColor("#8A8A8A");

    /** Включена ли экспериментальная кастомная клавиатура в настройках приложения. */
    private static boolean isCustomKeyboardEnabled(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_APP, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_CUSTOM_KEYBOARD, false);
    }

    public static void showEditor(Activity activity, ViewGroup rootContainer, Typeface typeface) {
        showEditor(activity, rootContainer, typeface, null);
    }

    /**
     * === ИСПРАВЛЕНО: открытие редактора для КОНКРЕТНОЙ заметки (seed),
     * либо продолжение последней (если seed == null).
     */
    public static void showEditor(final Activity activity, final ViewGroup rootContainer,
                                  final Typeface typeface, NoteRecord seed) {
        if (activity == null || rootContainer == null) return;
        removeOverlay(rootContainer);

        final FrameLayout overlay = createOverlay(activity);
        rootContainer.addView(overlay, matchParentLp());

        final LinearLayout sheet = new LinearLayout(activity);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(dp(activity, 18), dp(activity, 18), dp(activity, 18), dp(activity, 18));
        sheet.setBackgroundColor(COLOR_BG);
        sheet.setClickable(true);
        sheet.setFocusable(true);
        overlay.addView(sheet, matchParentLp());

        final boolean customKeyboardEnabled = isCustomKeyboardEnabled(activity);

        // ---------- Шапка ----------
        final LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new DigitTextView(activity);
        title.setText("Космический блокнот");
        styleText(title, typeface, 18f, COLOR_TEXT);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        header.addView(title, titleLp);

        // === НОВОЕ: кнопка выезжания кастомной клавиатуры (только если разрешена в настройках) ===
        final TextView keyboardToggle;
        if (customKeyboardEnabled) {
            keyboardToggle = createHeaderButton(activity, typeface, "⌨");
            header.addView(keyboardToggle, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        } else {
            keyboardToggle = null;
        }

        TextView storageButton = createHeaderButton(activity, typeface, "Склад");
        LinearLayout.LayoutParams storageLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        storageLp.leftMargin = dp(activity, 8);
        header.addView(storageButton, storageLp);
        storageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showShelf(activity, rootContainer, typeface);
            }
        });

        final TextView closeButton = createHeaderButton(activity, typeface, "✕");
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeOverlay(rootContainer);
            }
        });
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        closeLp.leftMargin = dp(activity, 8);
        header.addView(closeButton, closeLp);

        sheet.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView subtitle = new DigitTextView(activity);
        subtitle.setText("Автосохранение включено, всё живёт во внутреннем хранилище приложения.");
        styleText(subtitle, typeface, 12.5f, COLOR_SUBTEXT);
        LinearLayout.LayoutParams subtitleLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        subtitleLp.topMargin = dp(activity, 8);
        sheet.addView(subtitle, subtitleLp);

        // ---------- Поля ----------
        final EditText titleField = new DigitEditText(activity);
        styleEditorField(titleField, typeface, false);
        titleField.setHint("Название заметки");
        titleField.setSingleLine(true);
        titleField.setImeOptions(EditorInfo.IME_ACTION_DONE);
        // === НОВОЕ: нативная клавиатура разрешена, только если кастомная выключена ===
        titleField.setShowSoftInputOnFocus(!customKeyboardEnabled);
        titleField.setTextColor(COLOR_TEXT);
        titleField.setHintTextColor(COLOR_SUBTEXT);
        titleField.setBackground(makeRounded(COLOR_PANEL, COLOR_BORDER, activity));
        LinearLayout.LayoutParams titleFieldLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        titleFieldLp.topMargin = dp(activity, 14);
        sheet.addView(titleField, titleFieldLp);

        final EditText contentField = new DigitEditText(activity);
        styleEditorField(contentField, typeface, true);
        contentField.setHint("Пиши заметку здесь...");
        contentField.setGravity(Gravity.TOP | Gravity.START);
        contentField.setTextColor(COLOR_TEXT);
        contentField.setHintTextColor(COLOR_SUBTEXT);
        contentField.setBackground(makeRounded(COLOR_CARD, COLOR_BORDER, activity));
        contentField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES | InputType.TYPE_TEXT_FLAG_AUTO_CORRECT);
        contentField.setShowSoftInputOnFocus(!customKeyboardEnabled);
        contentField.setImeOptions(EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        contentField.setMinLines(10);
        contentField.setMaxLines(Integer.MAX_VALUE);
        LinearLayout.LayoutParams contentLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        contentLp.topMargin = dp(activity, 12);
        sheet.addView(contentField, contentLp);

        final TextView status = new DigitTextView(activity);
        styleText(status, typeface, 12.5f, COLOR_SUBTEXT);
        status.setText("Готово к редактированию");
        status.setGravity(Gravity.END);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        statusLp.topMargin = dp(activity, 10);
        sheet.addView(status, statusLp);

        // ---------- Заметка: seed (конкретная) или последняя ----------
        NoteRecord note = seed != null ? seed : loadLastOrLatest(activity);
        if (note == null) {
            note = new NoteRecord();
            note.id = UUID.randomUUID().toString();
            note.title = "Новая заметка";
            note.text = "";
            note.updatedAt = System.currentTimeMillis();
            saveRecord(activity, note);
        }
        final NoteRecord currentNote = note;

        final EditText[] activeFieldHolder = new EditText[]{contentField};
        titleField.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    activeFieldHolder[0] = titleField;
                }
            }
        });
        contentField.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    activeFieldHolder[0] = contentField;
                }
            }
        });

        final boolean[] suppress = {true};
        titleField.setText(currentNote.title);
        contentField.setText(currentNote.text);
        suppress[0] = false;
        if (customKeyboardEnabled) {
            status.setText("Сохранено. ⌨ — открыть встроенную клавиатуру");
        } else {
            status.setText("Сохранено");
        }

        final Handler handler = new Handler(Looper.getMainLooper());
        final Runnable[] saveTask = {null};
        TextWatcher watcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (suppress[0]) return;
                scheduleSave();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }

            private void scheduleSave() {
                if (saveTask[0] != null) {
                    handler.removeCallbacks(saveTask[0]);
                }
                saveTask[0] = new Runnable() {
                    @Override
                    public void run() {
                        currentNote.title = safeText(titleField.getText(), "Новая заметка");
                        currentNote.text = safeText(contentField.getText(), "");
                        currentNote.updatedAt = System.currentTimeMillis();
                        saveRecord(activity, currentNote);
                        setLastNoteId(activity, currentNote.id);
                        status.setText("Сохранено • " + currentNote.title);
                    }
                };
                handler.postDelayed(saveTask[0], 180L);
            }
        };
        titleField.addTextChangedListener(watcher);
        contentField.addTextChangedListener(watcher);

        // ---------- Кастомная клавиатура: только если разрешена, и только через кнопку ⌨ ----------
        if (customKeyboardEnabled) {
            final View customKeyboard = CosmicNotesKeyboard.create(
                    activity, typeface, activeFieldHolder, titleField, contentField, status);
            final LinearLayout.LayoutParams keyboardLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0);
            sheet.addView(customKeyboard, keyboardLp);

            final int kbHeight = dp(activity, 286);
            final boolean[] kbVisible = {false};
            keyboardToggle.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    HapticUtils.perform(v);
                    if (kbVisible[0]) {
                        kbVisible[0] = false;
                        animateHeight(customKeyboard, kbHeight, 0, true);
                        status.setText("Клавиатура скрыта");
                    } else {
                        kbVisible[0] = true;
                        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) customKeyboard.getLayoutParams();
                        lp.topMargin = dp(activity, 10);
                        customKeyboard.setLayoutParams(lp);
                        hideSystemKeyboard(activity);
                        animateHeight(customKeyboard, 0, kbHeight, false);
                        status.setText("Кастомная клавиатура открыта");
                    }
                }
            });
        }

        contentField.post(new Runnable() {
            @Override
            public void run() {
                contentField.requestFocus();
            }
        });

        overlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeOverlay(rootContainer);
            }
        });
        sheet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HapticUtils.perform(v);
            }
        });
    }

    /**
     * === НОВОЕ/ИСПРАВЛЕНО: кнопка "+" всегда создаёт НОВУЮ заметку
     * (новый id, новый файл) и открывает редактор именно с ней.
     */
    public static void showEditorWithNewNote(Activity activity, ViewGroup rootContainer, Typeface typeface) {
        if (activity == null || rootContainer == null) return;
        NoteRecord note = new NoteRecord();
        note.id = UUID.randomUUID().toString();
        note.title = "Новая заметка";
        note.text = "";
        note.updatedAt = System.currentTimeMillis();
        saveRecord(activity, note);
        setLastNoteId(activity, note.id);
        showEditor(activity, rootContainer, typeface, note);
    }

    public static void showShelf(final Activity activity, final ViewGroup rootContainer, final Typeface typeface) {
        if (activity == null || rootContainer == null) return;
        removeOverlay(rootContainer);

        final FrameLayout overlay = createOverlay(activity);
        rootContainer.addView(overlay, matchParentLp());

        final LinearLayout sheet = new LinearLayout(activity);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(dp(activity, 18), dp(activity, 18), dp(activity, 18), dp(activity, 18));
        sheet.setBackgroundColor(COLOR_BG);
        sheet.setClickable(true);
        sheet.setFocusable(true);
        overlay.addView(sheet, matchParentLp());

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new DigitTextView(activity);
        title.setText("Склад космических заметок");
        styleText(title, typeface, 18f, COLOR_TEXT);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView newButton = createHeaderButton(activity, typeface, "+");
        newButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // === ИСПРАВЛЕНО: "+" создаёт новую заметку, а не открывает последнюю ===
                showEditorWithNewNote(activity, rootContainer, typeface);
            }
        });

        final TextView closeButton = createHeaderButton(activity, typeface, "✕");
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeOverlay(rootContainer);
            }
        });

        header.addView(newButton);
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        closeLp.leftMargin = dp(activity, 8);
        header.addView(closeButton, closeLp);
        sheet.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView subtitle = new DigitTextView(activity);
        subtitle.setText("Открывай, редактируй и удаляй локальные заметки. Память устройства тут не нужна, и это уже почти чудо.");
        styleText(subtitle, typeface, 12.5f, COLOR_SUBTEXT);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        subLp.topMargin = dp(activity, 8);
        sheet.addView(subtitle, subLp);

        ScrollView scroll = new ScrollView(activity);
        scroll.setFillViewport(true);
        LinearLayout list = new LinearLayout(activity);
        list.setOrientation(LinearLayout.VERTICAL);

        List<NoteRecord> notes = loadAllNotes(activity);
        if (notes.isEmpty()) {
            TextView empty = new DigitTextView(activity);
            empty.setText("Пока тут пусто. Чистый космос, без записей.");
            styleText(empty, typeface, 14f, COLOR_TEXT);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(activity, 16), dp(activity, 40), dp(activity, 16), dp(activity, 16));
            list.addView(empty, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        } else {
            for (int i = 0; i < notes.size(); i++) {
                list.addView(createNoteCard(activity, rootContainer, typeface, notes.get(i)));
            }
        }

        scroll.addView(list, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        scrollLp.topMargin = dp(activity, 12);
        sheet.addView(scroll, scrollLp);

        overlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeOverlay(rootContainer);
            }
        });
        sheet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HapticUtils.perform(v);
            }
        });
        sheet.post(new Runnable() {
            @Override
            public void run() {
                closeButton.requestFocus();
            }
        });
    }

    private static View createNoteCard(final Activity activity, final ViewGroup rootContainer,
                                       final Typeface typeface, final NoteRecord note) {
        LinearLayout card = new LinearLayout(activity);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(activity, 14), dp(activity, 14), dp(activity, 14), dp(activity, 14));
        card.setBackground(makeRounded(note == null ? COLOR_CARD : (note.updatedAt % 2 == 0 ? COLOR_CARD : COLOR_CARD_ALT), COLOR_BORDER, activity));

        TextView title = new DigitTextView(activity);
        title.setText(note.title == null || note.title.trim().isEmpty() ? "Без названия" : note.title.trim());
        styleText(title, typeface, 15.5f, COLOR_TEXT);
        card.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView preview = new DigitTextView(activity);
        preview.setText(previewText(note.text));
        styleText(preview, typeface, 12.8f, COLOR_SUBTEXT);
        LinearLayout.LayoutParams prevLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        prevLp.topMargin = dp(activity, 6);
        card.addView(preview, prevLp);

        TextView meta = new DigitTextView(activity);
        meta.setText(formatTime(note.updatedAt));
        styleText(meta, typeface, 11.8f, COLOR_SUBTEXT);
        LinearLayout.LayoutParams metaLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        metaLp.topMargin = dp(activity, 8);
        card.addView(meta, metaLp);

        LinearLayout actions = new LinearLayout(activity);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.END);

        TextView open = createCardButton(activity, typeface, "Открыть");
        open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Открывается именно ЭТА заметка
                showEditor(activity, rootContainer, typeface, note);
            }
        });

        TextView delete = createCardButton(activity, typeface, "Удалить");
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HapticUtils.perform(v);
                deleteRecord(activity, note.id);
                showShelf(activity, rootContainer, typeface);
            }
        });

        LinearLayout.LayoutParams openLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        actions.addView(open, openLp);
        LinearLayout.LayoutParams deleteLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        deleteLp.leftMargin = dp(activity, 8);
        actions.addView(delete, deleteLp);

        LinearLayout.LayoutParams actLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        actLp.topMargin = dp(activity, 10);
        card.addView(actions, actLp);

        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardLp.bottomMargin = dp(activity, 10);
        card.setLayoutParams(cardLp);
        card.setClickable(true);
        card.setFocusable(true);
        card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showEditor(activity, rootContainer, typeface, note);
            }
        });
        return card;
    }

    private static TextView createHeaderButton(Activity activity, Typeface typeface, String label) {
        TextView button = new DigitTextView(activity);
        button.setText(label);
        styleText(button, typeface, 14f, COLOR_TEXT);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(activity, 14), dp(activity, 10), dp(activity, 14), dp(activity, 10));
        button.setBackground(makeRounded(COLOR_PANEL, COLOR_BORDER, activity));
        button.setClickable(true);
        button.setFocusable(true);
        return button;
    }

    private static TextView createCardButton(Activity activity, Typeface typeface, String label) {
        TextView button = new DigitTextView(activity);
        button.setText(label);
        styleText(button, typeface, 13f, COLOR_ACCENT);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(activity, 12), dp(activity, 8), dp(activity, 12), dp(activity, 8));
        button.setBackground(makeRounded(Color.TRANSPARENT, COLOR_ACCENT, activity));
        button.setClickable(true);
        button.setFocusable(true);
        return button;
    }

    private static void styleText(TextView tv, Typeface typeface, float sizeSp, int color) {
        tv.setTextColor(color);
        tv.setTextSize(sizeSp);
        if (typeface != null) {
            tv.setTypeface(typeface);
        }
    }

    private static void styleEditorField(EditText editText, Typeface typeface, boolean multiline) {
        styleText(editText, typeface, 14.5f, COLOR_TEXT);
        editText.setPadding(dp(editText.getContext(), 14), dp(editText.getContext(), 12), dp(editText.getContext(), 14), dp(editText.getContext(), 12));
        editText.setTextCursorDrawable(null);
        editText.setSingleLine(!multiline);
        editText.setFreezesText(false);
        editText.setHorizontallyScrolling(false);
        editText.setFocusable(true);
        editText.setFocusableInTouchMode(true);
    }

    private static FrameLayout createOverlay(Activity activity) {
        FrameLayout overlay = new FrameLayout(activity);
        overlay.setTag(OVERLAY_TAG);
        overlay.setBackgroundColor(COLOR_BG);
        overlay.setClickable(true);
        overlay.setFocusable(true);
        return overlay;
    }

    private static void closeOverlay(ViewGroup rootContainer) {
        removeOverlay(rootContainer);
    }

    private static void removeOverlay(ViewGroup rootContainer) {
        if (rootContainer == null) return;
        View overlay = rootContainer.findViewWithTag(OVERLAY_TAG);
        if (overlay != null) {
            rootContainer.removeView(overlay);
        }
    }

    private static void hideSystemKeyboard(Activity activity) {
        if (activity == null) return;
        View focused = activity.getCurrentFocus();
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null && focused != null) {
            imm.hideSoftInputFromWindow(focused.getWindowToken(), 0);
        }
    }

    /** Плавная анимация высоты (выезд/уезд клавиатуры). */
    private static void animateHeight(final View view, int from, int to, final boolean zeroMarginOnEnd) {
        final ViewGroup.LayoutParams lp = view.getLayoutParams();
        ValueAnimator animator = ValueAnimator.ofInt(from, to);
        animator.setDuration(240);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                lp.height = ((Integer) animation.getAnimatedValue()).intValue();
                view.setLayoutParams(lp);
            }
        });
        if (zeroMarginOnEnd) {
            animator.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    if (lp instanceof LinearLayout.LayoutParams) {
                        ((LinearLayout.LayoutParams) lp).topMargin = 0;
                    }
                    view.setLayoutParams(lp);
                }
            });
        }
        animator.start();
    }

    private static File notesDir(Context context) {
        File dir = new File(context.getFilesDir(), DIR_NAME);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }

    private static File noteFile(Context context, String id) {
        return new File(notesDir(context), id + FILE_EXT);
    }

    private static void saveRecord(Context context, NoteRecord note) {
        if (context == null || note == null || note.id == null) return;
        try {
            JSONObject json = new JSONObject();
            json.put("id", note.id);
            json.put("title", note.title == null ? "" : note.title);
            json.put("text", note.text == null ? "" : note.text);
            json.put("updatedAt", note.updatedAt);

            FileOutputStream fos = new FileOutputStream(noteFile(context, note.id));
            fos.write(json.toString().getBytes(StandardCharsets.UTF_8));
            fos.flush();
            fos.close();
        } catch (Throwable ignored) {
        }
    }

    private static NoteRecord loadRecord(Context context, File file) {
        if (context == null || file == null || !file.exists()) return null;
        StringBuilder sb = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8));
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            br.close();

            JSONObject json = new JSONObject(sb.toString());
            NoteRecord note = new NoteRecord();
            note.id = json.optString("id", null);
            note.title = json.optString("title", "");
            note.text = json.optString("text", "");
            note.updatedAt = json.optLong("updatedAt", file.lastModified());
            return note;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static List<NoteRecord> loadAllNotes(Context context) {
        List<NoteRecord> notes = new ArrayList<NoteRecord>();
        File[] files = notesDir(context).listFiles();
        if (files == null) return notes;
        for (File file : files) {
            NoteRecord note = loadRecord(context, file);
            if (note != null && note.id != null) {
                notes.add(note);
            }
        }
        Collections.sort(notes, new Comparator<NoteRecord>() {
            @Override
            public int compare(NoteRecord a, NoteRecord b) {
                return Long.compare(b.updatedAt, a.updatedAt);
            }
        });
        return notes;
    }

    private static NoteRecord loadLastOrLatest(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String lastId = prefs.getString(PREF_LAST_NOTE_ID, null);
        if (lastId != null) {
            File file = noteFile(context, lastId);
            NoteRecord note = loadRecord(context, file);
            if (note != null) return note;
        }
        List<NoteRecord> notes = loadAllNotes(context);
        if (!notes.isEmpty()) return notes.get(0);
        return null;
    }

    private static void setLastNoteId(Context context, String id) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        prefs.edit().putString(PREF_LAST_NOTE_ID, id).apply();
    }

    private static void deleteRecord(Context context, String id) {
        if (context == null || id == null) return;
        File file = noteFile(context, id);
        if (file.exists()) {
            file.delete();
        }
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String last = prefs.getString(PREF_LAST_NOTE_ID, null);
        if (id.equals(last)) {
            prefs.edit().remove(PREF_LAST_NOTE_ID).apply();
        }
    }

    private static String previewText(String text) {
        if (text == null) return "";
        String clean = text.replace('\n', ' ').trim();
        if (clean.length() <= 72) return clean;
        return clean.substring(0, 72) + "…";
    }

    private static String safeText(CharSequence text, String fallback) {
        String value = text == null ? "" : text.toString();
        return value.trim().isEmpty() ? fallback : value;
    }

    private static String formatTime(long millis) {
        if (millis <= 0) return "Без даты";
        java.text.SimpleDateFormat fmt = new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault());
        return fmt.format(Long.valueOf(millis));
    }

    private static FrameLayout.LayoutParams matchParentLp() {
        return new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        );
    }

    private static int dp(Context context, float value) {
        return (int) (value * context.getResources().getDisplayMetrics().density + 0.5f);
    }

    private static android.graphics.drawable.GradientDrawable makeRounded(int fillColor, int strokeColor, Context context) {
        android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
        gd.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        gd.setCornerRadius(dp(context, 18));
        gd.setColor(fillColor);
        gd.setStroke(dp(context, 1), strokeColor);
        return gd;
    }

    static final class NoteRecord {
        String id;
        String title;
        String text;
        long updatedAt;
    }
}
