package com.astroforge;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

/** TextView where only digits are rendered with Quintessential. */
final class DigitTextView extends TextView {

    DigitTextView(Context context) {
        super(context);
    }

    DigitTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    DigitTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public void setText(CharSequence text, BufferType type) {
        super.setText(DigitFont.apply(getContext(), text), type);
    }

}
