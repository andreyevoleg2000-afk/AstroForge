package com.astroforge;

import java.io.File;

public class EngineConfig {

    public static final int MODE_SAFE = 0;
    public static final int MODE_ULTRA = 1;

    public int mode = MODE_SAFE;

    // Шаг интегрирования в виртуальных секундах.
    public double dt = 1.0;

    // Сколько виртуального времени считаем.
    public double totalVirtualSeconds = 3600.0;

    // Каждый виртуальный час = 3600 виртуальных секунд.
    public double checkpointVirtualSeconds = 3600.0;

    public boolean writeCheckpoints = true;
    public boolean writeFinal = true;

    // Мягкость для близких сближений, чтобы не ловить сингулярность.
    public double softening = 1e-6;

    // Сколько рабочих CPU-потоков использовать.
    // 0 = авто.
    public int threadCount = 0;

    // Сколько итераций для неявного Gauss-Legendre.
    public int glIterations = 8;

    // В ULTRA-режиме.
    public boolean enableGaussLegendre = true;

    // PN2.5 пока вынесен отдельно.
    // Сейчас лучше держать выключенным, пока не добавим проверенные формулы.
    public boolean enablePN = false;

    public File outputDir = null;

    public String filePrefix = "nbody";
}
