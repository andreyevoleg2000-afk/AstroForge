package com.astroforge;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Окно расчёта гравитационного ускорения.
 *
 * UI сделан по образцу VelocityPanel:
 * - тёмное окно с blur-фоном;
 * - поля ввода;
 * - пилюли единиц с выпадающими списками;
 * - расширенные параметры сворачиваются/разворачиваются;
 * - результат появляется в отдельном боксе.
 *
 * AIDE-safe:
 * - без лямбд;
 * - без androidx;
 * - все final-переменные в анонимных классах соблюдены.
 */
final class GravityAccelerationPanel {

    private static final int ACCENT_COLOR = 0xFFD9946B;
    private static final int ACCENT_BORDER_COLOR = Color.parseColor("#CCD9946B");
    private static final int FIELD_BG_COLOR = Color.parseColor("#F21C1C1E");
    private static final int FIELD_BORDER_COLOR = Color.parseColor("#B3E3E3E3");
    private static final int PILL_BG_COLOR = Color.BLACK;
    private static final int DROPDOWN_BG_COLOR = Color.parseColor("#FF1C1C1E");

    private static final String[] SPEED_LABELS = {
		"м/с",
		"км/с",
		"% c",
		"c"
    };

    private static final String[] SPIN_LABELS = {
		"кг·м²/с",
		"эрг·с",
		"M☉·км²/с"
    };

    private static final String[] CHARGE_LABELS = {
		"Кл",
		"мКл",
		"элементарный заряд"
    };

    private static final String[] LAMBDA_LABELS = {
		"1/м²",
		"1/км²",
		"1/св.год²"
    };

    private final Context context;
    private final FrameLayout rootContainer;
    private final Typeface typefaceRegular;
    private final Typeface typefaceSemiBold;

    private FrameLayout overlayRoot;
    private FrameLayout windowFrame;
    private FrameLayout dropdownLayer;

    private EditText xInput;
    private EditText yInput;
    private EditText zInput;

    private UnitPillState xUnit;
    private UnitPillState yUnit;
    private UnitPillState zUnit;

    private EditText massInput;
    private UnitPillState massUnit;

    private EditText simpleMassInput;
    private UnitPillState simpleMassUnit;
    private EditText simpleRadiusInput;
    private UnitPillState simpleRadiusUnit;

    private EditText observerVxInput;
    private EditText observerVyInput;
    private EditText observerVzInput;

    private UnitPillState observerVxUnit;
    private UnitPillState observerVyUnit;
    private UnitPillState observerVzUnit;

    private boolean advancedMode = false;
    private LinearLayout advancedContainer;
    private LinearLayout standardModeContainer;
    private LinearLayout simplifiedModeContainer;
    private LinearLayout simplifiedResultContainer;
    private boolean simplifiedMode = false;

    private EditText spinInput;
    private UnitPillState spinUnit;

    private EditText sourceVxInput;
    private EditText sourceVyInput;
    private EditText sourceVzInput;

    private UnitPillState sourceVxUnit;
    private UnitPillState sourceVyUnit;
    private UnitPillState sourceVzUnit;

    private EditText chargeInput;
    private UnitPillState chargeUnit;

    private EditText lambdaInput;
    private UnitPillState lambdaUnit;

    private LinearLayout resultContainer;

    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private Runnable progressPoller;
    private CalculationProgressOverlay calculationOverlay;

    private GravityAccelerationPanel(
		Context context,
		FrameLayout rootContainer,
		Typeface typefaceRegular,
		Typeface typefaceSemiBold
    ) {
        this.context = context;
        this.rootContainer = rootContainer;
        this.typefaceRegular = typefaceRegular;
        this.typefaceSemiBold = typefaceSemiBold;
    }

    static void show(
		Context context,
		FrameLayout rootContainer,
		Typeface typefaceRegular,
		Typeface typefaceSemiBold
    ) {
        new GravityAccelerationPanel(
			context,
			rootContainer,
			typefaceRegular,
			typefaceSemiBold
        ).build();
    }

    private int dp(float value) {
        return (int) TypedValue.applyDimension(
			TypedValue.COMPLEX_UNIT_DIP,
			value,
			context.getResources().getDisplayMetrics()
        );
    }

    // =========================================================
    //  Построение окна
    // =========================================================

    private void build() {
        overlayRoot = new FrameLayout(context);
        overlayRoot.setBackgroundColor(Color.parseColor("#CC0F0F10"));
        overlayRoot.setClickable(true);
        overlayRoot.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					close();
				}
			});

        windowFrame = new FrameLayout(context);
        windowFrame.setClickable(true);
        windowFrame.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					// поглощаем клик внутри окна
				}
			});

        GradientDrawable frameBg = new GradientDrawable();
        frameBg.setShape(GradientDrawable.RECTANGLE);
        frameBg.setCornerRadius(dp(28));
        frameBg.setColor(0xF21E1E20);
        frameBg.setStroke(dp(2), ACCENT_COLOR);

        windowFrame.setBackground(frameBg);
        windowFrame.setClipToOutline(true);
        windowFrame.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);

        ImageView blurBg = new ImageView(context);
        blurBg.setImageResource(R.drawable.background);
        blurBg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        blurBg.setRenderEffect(
			RenderEffect.createBlurEffect(dp(44), dp(44), Shader.TileMode.CLAMP)
        );
        blurBg.setAlpha(0.88f);
        windowFrame.addView(blurBg, matchParentFrameLp());

        View tint = new View(context);
        tint.setBackgroundColor(Color.parseColor("#CC232326"));
        windowFrame.addView(tint, matchParentFrameLp());
        AstroUiEffects.applyPaperEffect(windowFrame, context);

        ScrollView scrollView = new ScrollView(context);
        scrollView.setClipToPadding(false);

        LinearLayout content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);

        int pad = dp(20);
        content.setPadding(pad, pad, pad, pad);

        content.addView(buildTitle());
        content.addView(spacer(dp(12)));
        content.addView(buildSimplifiedToggle());
        content.addView(spacer(dp(14)));

        FrameLayout modeFrame = new FrameLayout(context);
        modeFrame.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        standardModeContainer = new LinearLayout(context);
        standardModeContainer.setOrientation(LinearLayout.VERTICAL);

        standardModeContainer.addView(buildLabel("Координата X точки измерения"));
        standardModeContainer.addView(spacer(dp(6)));
        ValueUnitRow xRow = buildDistanceField("X относительно источника");
        xInput = xRow.input;
        xUnit = xRow.unitState;
        standardModeContainer.addView(xRow.row);
        standardModeContainer.addView(spacer(dp(14)));

        standardModeContainer.addView(buildLabel("Координата Y точки измерения"));
        standardModeContainer.addView(spacer(dp(6)));
        ValueUnitRow yRow = buildDistanceField("Y относительно источника");
        yInput = yRow.input;
        yUnit = yRow.unitState;
        standardModeContainer.addView(yRow.row);
        standardModeContainer.addView(spacer(dp(14)));

        standardModeContainer.addView(buildLabel("Координата Z точки измерения"));
        standardModeContainer.addView(spacer(dp(6)));
        ValueUnitRow zRow = buildDistanceField("Z относительно источника");
        zInput = zRow.input;
        zUnit = zRow.unitState;
        standardModeContainer.addView(zRow.row);
        standardModeContainer.addView(spacer(dp(14)));

        standardModeContainer.addView(buildLabel("Масса источника гравитации"));
        standardModeContainer.addView(spacer(dp(6)));
        ValueUnitRow massRow = buildMassField("Введите массу");
        massInput = massRow.input;
        massUnit = massRow.unitState;
        standardModeContainer.addView(massRow.row);
        standardModeContainer.addView(spacer(dp(14)));

        standardModeContainer.addView(buildLabel("Вектор скорости наблюдателя (для покоя оставьте 0)"));
        standardModeContainer.addView(spacer(dp(6)));

        ValueUnitRow vxRow = buildSpeedField("Vx наблюдателя");
        observerVxInput = vxRow.input;
        observerVxUnit = vxRow.unitState;
        standardModeContainer.addView(vxRow.row);
        standardModeContainer.addView(spacer(dp(8)));

        ValueUnitRow vyRow = buildSpeedField("Vy наблюдателя");
        observerVyInput = vyRow.input;
        observerVyUnit = vyRow.unitState;
        standardModeContainer.addView(vyRow.row);
        standardModeContainer.addView(spacer(dp(8)));

        ValueUnitRow vzRow = buildSpeedField("Vz наблюдателя");
        observerVzInput = vzRow.input;
        observerVzUnit = vzRow.unitState;
        standardModeContainer.addView(vzRow.row);

        standardModeContainer.addView(spacer(dp(18)));
        standardModeContainer.addView(buildAdvancedToggleButton());
        standardModeContainer.addView(spacer(dp(4)));
        standardModeContainer.addView(buildExperimentalHint());
        standardModeContainer.addView(spacer(dp(10)));

        advancedContainer = new LinearLayout(context);
        advancedContainer.setOrientation(LinearLayout.VERTICAL);
        advancedContainer.setVisibility(View.GONE);
        buildAdvancedContent(advancedContainer);
        standardModeContainer.addView(advancedContainer);

        standardModeContainer.addView(spacer(dp(18)));
        standardModeContainer.addView(buildCalculateButton());
        standardModeContainer.addView(spacer(dp(14)));
        standardModeContainer.addView(buildExplanationBlock());
        standardModeContainer.addView(spacer(dp(10)));

        resultContainer = new LinearLayout(context);
        resultContainer.setOrientation(LinearLayout.VERTICAL);
        standardModeContainer.addView(resultContainer);
        standardModeContainer.addView(spacer(dp(20)));

        modeFrame.addView(standardModeContainer, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ));

        simplifiedModeContainer = new LinearLayout(context);
        simplifiedModeContainer.setOrientation(LinearLayout.VERTICAL);
        simplifiedModeContainer.setVisibility(View.GONE);

        simplifiedModeContainer.addView(buildLabel("Масса объекта"));
        simplifiedModeContainer.addView(spacer(dp(6)));
        ValueUnitRow simpleMassRow = buildMassField("Введите массу");
        simpleMassInput = simpleMassRow.input;
        simpleMassUnit = simpleMassRow.unitState;
        simplifiedModeContainer.addView(simpleMassRow.row);
        simplifiedModeContainer.addView(spacer(dp(14)));

        simplifiedModeContainer.addView(buildLabel("Радиус объекта"));
        simplifiedModeContainer.addView(spacer(dp(6)));
        ValueUnitRow simpleRadiusRow = buildDistanceField("Введите радиус");
        simpleRadiusInput = simpleRadiusRow.input;
        simpleRadiusUnit = simpleRadiusRow.unitState;
        simplifiedModeContainer.addView(simpleRadiusRow.row);
        simplifiedModeContainer.addView(spacer(dp(18)));

        simplifiedModeContainer.addView(buildCalculateButton());
        simplifiedModeContainer.addView(spacer(dp(14)));
        simplifiedResultContainer = new LinearLayout(context);
        simplifiedResultContainer.setOrientation(LinearLayout.VERTICAL);
        simplifiedModeContainer.addView(simplifiedResultContainer);
        simplifiedModeContainer.addView(spacer(dp(20)));

        modeFrame.addView(simplifiedModeContainer, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ));

        content.addView(modeFrame);
        scrollView.addView(
			content,
			new ScrollView.LayoutParams(
				ScrollView.LayoutParams.MATCH_PARENT,
				ScrollView.LayoutParams.WRAP_CONTENT
			)
        );

        windowFrame.addView(scrollView, matchParentFrameLp());

        FrameLayout.LayoutParams windowLp = new FrameLayout.LayoutParams(
			ViewGroup.LayoutParams.MATCH_PARENT,
			ViewGroup.LayoutParams.MATCH_PARENT
        );

        int screenMargin = dp(18);
        windowLp.setMargins(
			screenMargin,
			screenMargin + dp(30),
			screenMargin,
			screenMargin + dp(30)
        );

        overlayRoot.addView(windowFrame, windowLp);

        dropdownLayer = new FrameLayout(context);
        dropdownLayer.setClipChildren(false);
        dropdownLayer.setClipToPadding(false);
        dropdownLayer.setElevation(dp(1000));
        overlayRoot.addView(dropdownLayer, matchParentFrameLp());
        dropdownLayer.bringToFront();

        rootContainer.addView(overlayRoot, matchParentFrameLp());

        windowFrame.post(new Runnable() {
            @Override
            public void run() {
                if (overlayRoot != null && overlayRoot.getParent() == rootContainer && windowFrame != null) {
                    WindowOpenAnimation.start(windowFrame, context.getResources().getDisplayMetrics().density);
                }
            }
        });

        restoreLastResultIfNeeded();
    }

    private void close() {
        stopProgressPolling();

        if (dropdownLayer != null) {
            dropdownLayer.removeAllViews();
        }

        if (overlayRoot != null) {
            overlayRoot.animate().cancel();

            if (windowFrame != null) {
                windowFrame.animate().cancel();
            }

            if (overlayRoot.getParent() == rootContainer) {
                rootContainer.removeView(overlayRoot);
            }
        }

        overlayRoot = null;
        windowFrame = null;
        dropdownLayer = null;
    }

    // =========================================================
    //  UI-хелперы
    // =========================================================

    private View buildTitle() {
        TextView tv = new DigitTextView(context);
        tv.setText("Гравитационное ускорение");
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        tv.setGravity(Gravity.START | Gravity.TOP);
        return tv;
    }

    private TextView buildLabel(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#DDE3E1DE"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        return tv;
    }

    private View spacer(int heightPx) {
        View v = new View(context);
        v.setLayoutParams(new LinearLayout.LayoutParams(
							  LinearLayout.LayoutParams.MATCH_PARENT,
							  heightPx
						  ));
        return v;
    }

    private View buildSimplifiedToggle() {
        final LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(8), dp(10), dp(8));
        row.setBackground(createRoundedRect(dp(16), Color.parseColor("#331C1C1E"), Color.parseColor("#55E3E3E3"), dp(1)));

        TextView label = new DigitTextView(context);
        label.setText("Упрощённый расчёт");
        label.setTextColor(Color.WHITE);
        label.setTypeface(typefaceRegular);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        label.setGravity(Gravity.CENTER_VERTICAL);

        final TextView state = new DigitTextView(context);
        state.setText("ВЫКЛ");
        state.setTextColor(Color.parseColor("#B8FFFFFF"));
        state.setTypeface(typefaceSemiBold);
        state.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        state.setGravity(Gravity.CENTER);
        state.setPadding(dp(12), dp(7), dp(12), dp(7));
        state.setBackground(createRoundedRect(dp(14), Color.BLACK, Color.parseColor("#44E3E3E3"), dp(1)));

        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(0, dp(42), 1f);
        LinearLayout.LayoutParams stateLp = new LinearLayout.LayoutParams(dp(88), dp(38));
        row.addView(label, labelLp);
        row.addView(state, stateLp);

        row.setClickable(true);
        row.setFocusable(true);
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HapticUtils.perform(v);
                simplifiedMode = !simplifiedMode;
                standardModeContainer.setVisibility(simplifiedMode ? View.GONE : View.VISIBLE);
                simplifiedModeContainer.setVisibility(simplifiedMode ? View.VISIBLE : View.GONE);
                state.setText(simplifiedMode ? "ВКЛ" : "ВЫКЛ");
                state.setTextColor(simplifiedMode ? ACCENT_COLOR : Color.parseColor("#B8FFFFFF"));
            }
        });
        return row;
    }

    private View buildAdvancedToggleButton() {
        final TextView btn = new DigitTextView(context);
        btn.setText("+  Необязательные релятивистские параметры");
        btn.setTextColor(Color.parseColor("#DDE3E1DE"));
        btn.setTypeface(typefaceRegular);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(dp(16), dp(12), dp(16), dp(12));

        GradientDrawable dashed = new GradientDrawable();
        dashed.setShape(GradientDrawable.RECTANGLE);
        dashed.setCornerRadius(dp(16));
        dashed.setColor(Color.TRANSPARENT);
        dashed.setStroke(dp(1.5f), Color.parseColor("#AAE3E3E3"), dp(8), dp(5));

        btn.setBackground(dashed);
        btn.setClickable(true);
        btn.setFocusable(true);
        btn.setLayoutParams(new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT,
								LinearLayout.LayoutParams.WRAP_CONTENT
							));

        btn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					HapticUtils.perform(v);

					advancedMode = !advancedMode;
					advancedContainer.setVisibility(advancedMode ? View.VISIBLE : View.GONE);

					btn.setText(advancedMode
								? "−  Скрыть релятивистские параметры"
								: "+  Необязательные релятивистские параметры");
				}
			});

        return btn;
    }

    private View buildExperimentalHint() {
        TextView notice = new DigitTextView(context);
        notice.setText("Экспериментальная функция: 1 год, dt = 1 с, expansion-арифметика");
        notice.setTextColor(Color.parseColor("#FFF29B3B"));
        notice.setTypeface(typefaceRegular);
        notice.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        notice.setPadding(dp(4), dp(0), dp(4), dp(0));
        notice.setLayoutParams(new LinearLayout.LayoutParams(
								   LinearLayout.LayoutParams.MATCH_PARENT,
								   LinearLayout.LayoutParams.WRAP_CONTENT
							   ));
        return notice;
    }

    private void buildAdvancedContent(LinearLayout container) {
        container.addView(buildLabel("Угловой момент (спин) источника"));
        container.addView(spacer(dp(6)));

        ValueUnitRow spinRow = buildSpinField();
        spinInput = spinRow.input;
        spinUnit = spinRow.unitState;
        container.addView(spinRow.row);
        container.addView(spacer(dp(14)));

        container.addView(buildLabel("Скорость источника X"));
        container.addView(spacer(dp(6)));
        ValueUnitRow svxRow = buildSpeedField("SVx источника");
        sourceVxInput = svxRow.input;
        sourceVxUnit = svxRow.unitState;
        container.addView(svxRow.row);
        container.addView(spacer(dp(8)));

        container.addView(buildLabel("Скорость источника Y"));
        container.addView(spacer(dp(6)));
        ValueUnitRow svyRow = buildSpeedField("SVy источника");
        sourceVyInput = svyRow.input;
        sourceVyUnit = svyRow.unitState;
        container.addView(svyRow.row);
        container.addView(spacer(dp(8)));

        container.addView(buildLabel("Скорость источника Z"));
        container.addView(spacer(dp(6)));
        ValueUnitRow svzRow = buildSpeedField("SVz источника");
        sourceVzInput = svzRow.input;
        sourceVzUnit = svzRow.unitState;
        container.addView(svzRow.row);
        container.addView(spacer(dp(14)));

        container.addView(buildLabel("Электрический заряд источника"));
        container.addView(spacer(dp(6)));
        ValueUnitRow chargeRow = buildChargeField();
        chargeInput = chargeRow.input;
        chargeUnit = chargeRow.unitState;
        container.addView(chargeRow.row);
        container.addView(spacer(dp(14)));

        container.addView(buildLabel("Космологическая постоянная Λ"));
        container.addView(spacer(dp(6)));
        ValueUnitRow lambdaRow = buildLambdaField();
        lambdaInput = lambdaRow.input;
        lambdaUnit = lambdaRow.unitState;
        container.addView(lambdaRow.row);
    }

    private View buildCalculateButton() {
        TextView btn = new DigitTextView(context);
        btn.setText("Рассчитать");
        btn.setTextColor(Color.WHITE);
        btn.setTypeface(typefaceSemiBold);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(0, dp(14), 0, dp(14));
        btn.setBackground(createRoundedRect(dp(18), ACCENT_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        AstroUiEffects.applyControlShadow(btn, context);
        btn.setClickable(true);
        btn.setFocusable(true);
        btn.setLayoutParams(new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT,
								LinearLayout.LayoutParams.WRAP_CONTENT
							));

        btn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					HapticUtils.perform(v);
					onCalculatePressed();
				}
			});

        return btn;
    }

    private View buildExplanationBlock() {
        LinearLayout block = new LinearLayout(context);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setLayoutParams(new LinearLayout.LayoutParams(
								  LinearLayout.LayoutParams.MATCH_PARENT,
								  LinearLayout.LayoutParams.WRAP_CONTENT
							  ));

        TextView title = new DigitTextView(context);
        title.setText("Как считается собственное ускорение");
        title.setTextColor(Color.WHITE);
        title.setTypeface(typefaceSemiBold);

        AstroUiEffects.applyExplanationTypeface(title, context);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        block.addView(title);

        block.addView(spacer(dp(8)));

        block.addView(buildExplanationLine(
						  "1) 3+1 lapse: α = sqrt(f), где f = 1 - 2GM/(c²r) + GQ²/(4πɛ0c⁴r²) - Λr²/3."
					  ));
        block.addView(spacer(dp(4)));

        block.addView(buildExplanationLine(
						  "2) Собственное ускорение статического наблюдателя: a = |градиент поля| / α."
					  ));
        block.addView(spacer(dp(4)));

        block.addView(buildExplanationLine(
						  "3) Спин источника добавляет поправку Лензе-Тирринга: 1 + 2GJ/(c³r²)·cos(широты)."
					  ));
        block.addView(spacer(dp(4)));

        block.addView(buildExplanationLine(
						  "4) Скорость наблюдателя даёт гамма-фактор проекции 4-ускорения."
					  ));
        block.addView(spacer(dp(4)));

        block.addView(buildExplanationLine(
						  "5) Симуляция идёт 1 год с dt = 1 с. Сумма накапливается в 16-компонентном expansion, среднее считается точным expansion-умножением."
					  ));

        return block;
    }

    private TextView buildExplanationLine(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#CFE3E1DE"));
        tv.setTypeface(typefaceRegular);
        AstroUiEffects.applyExplanationTypeface(tv, context);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        tv.setLineSpacing(dp(2), 1.08f);
        return tv;
    }

    // =========================================================
    //  Поля с единицами
    // =========================================================

    private static final class ValueUnitRow {
        View row;
        EditText input;
        UnitPillState unitState;
    }

    private static final class UnitPillState {
        TextView pillView;
        int selectedIndex = 0;
        String[] labels;
    }

    private ValueUnitRow buildDistanceField(String hint) {
        PhysicsEngine.DistanceUnit[] values = PhysicsEngine.DistanceUnit.values();
        String[] labels = new String[values.length];

        for (int i = 0; i < values.length; i++) {
            labels[i] = values[i].label;
        }

        return buildValueUnitRow(labels, hint);
    }

    private ValueUnitRow buildMassField(String hint) {
        PhysicsEngine.MassUnit[] values = PhysicsEngine.MassUnit.values();
        String[] labels = new String[values.length];

        for (int i = 0; i < values.length; i++) {
            labels[i] = values[i].label;
        }

        return buildValueUnitRow(labels, hint);
    }

    private ValueUnitRow buildSpeedField(String hint) {
        return buildValueUnitRow(SPEED_LABELS, hint);
    }

    private ValueUnitRow buildSpinField() {
        return buildValueUnitRow(SPIN_LABELS, "Необязательно");
    }

    private ValueUnitRow buildChargeField() {
        return buildValueUnitRow(CHARGE_LABELS, "Необязательно");
    }

    private ValueUnitRow buildLambdaField() {
        return buildValueUnitRow(LAMBDA_LABELS, "Необязательно");
    }

    private ValueUnitRow buildValueUnitRow(final String[] unitLabels, String hint) {
        FrameLayout field = new FrameLayout(context);
        field.setBackground(createRoundedRect(dp(16), FIELD_BG_COLOR, FIELD_BORDER_COLOR, dp(1.25f)));
        AstroUiEffects.applyControlShadow(field, context);
        field.setClipToOutline(true);

        final EditText input = new DigitEditText(context);
        input.setHint(hint);
        input.setHintTextColor(Color.parseColor("#77FFFFFF"));
        input.setTextColor(Color.WHITE);
        input.setTypeface(typefaceRegular);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        input.setSingleLine(true);
        input.setBackground(null);
        AstroUiEffects.applyControlShadow(input, context);
        input.setInputType(
			InputType.TYPE_CLASS_NUMBER
			| InputType.TYPE_NUMBER_FLAG_DECIMAL
			| InputType.TYPE_NUMBER_FLAG_SIGNED
        );
        input.setPadding(dp(16), dp(12), dp(140), dp(12));

        field.addView(input, matchParentFrameLp());

        final UnitPillState state = new UnitPillState();
        state.labels = unitLabels;
        state.selectedIndex = 0;

        final TextView pill = new DigitTextView(context);
        pill.setText(unitLabels[0]);
        pill.setTextColor(Color.WHITE);
        pill.setTypeface(typefaceSemiBold);
        pill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        pill.setGravity(Gravity.CENTER);
        pill.setMaxLines(1);
        pill.setEllipsize(android.text.TextUtils.TruncateAt.END);
        pill.setBackground(createRoundedRect(dp(14), PILL_BG_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        pill.setPadding(dp(12), dp(8), dp(12), dp(8));
        pill.setClickable(true);
        pill.setFocusable(true);

        FrameLayout.LayoutParams pillLp = new FrameLayout.LayoutParams(
			dp(128),
			FrameLayout.LayoutParams.WRAP_CONTENT
        );
        pillLp.gravity = Gravity.CENTER_VERTICAL | Gravity.END;
        pillLp.rightMargin = dp(8);

        field.addView(pill, pillLp);
        pill.setTranslationZ(dp(3f));

        state.pillView = pill;

        pill.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					HapticUtils.perform(v);

					openDropdown(
                        pill,
                        unitLabels,
                        state.selectedIndex,
                        new OnUnitSelected() {
                            @Override
                            public void onSelected(int newIndex) {
                                state.selectedIndex = newIndex;
                                pill.setText(unitLabels[newIndex]);
                            }
                        }
					);
				}
			});

        field.setLayoutParams(new LinearLayout.LayoutParams(
								  LinearLayout.LayoutParams.MATCH_PARENT,
								  dp(50)
							  ));

        ValueUnitRow row = new ValueUnitRow();
        row.row = field;
        row.input = input;
        row.unitState = state;

        return row;
    }

    // =========================================================
    //  Dropdown
    // =========================================================

    private interface OnUnitSelected {
        void onSelected(int index);
    }

    private void openDropdown(
		final View anchor,
		final String[] labels,
		int selectedIndex,
		final OnUnitSelected callback
    ) {
        dropdownLayer.removeAllViews();
        dropdownLayer.bringToFront();

        int[] anchorLoc = new int[2];
        anchor.getLocationOnScreen(anchorLoc);

        int[] rootLoc = new int[2];
        dropdownLayer.getLocationOnScreen(rootLoc);

        int relativeX = anchorLoc[0] - rootLoc[0];
        int relativeY = anchorLoc[1] - rootLoc[1];
        int anchorBottom = relativeY + anchor.getHeight();

        Rect visibleFrame = new Rect();
        rootContainer.getWindowVisibleDisplayFrame(visibleFrame);

        int visibleTop = visibleFrame.top - rootLoc[1];
        int visibleBottom = visibleFrame.bottom - rootLoc[1];

        View scrim = new View(context);
        scrim.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					dropdownLayer.removeAllViews();
				}
			});

        dropdownLayer.addView(scrim, matchParentFrameLp());

        LinearLayout list = new LinearLayout(context);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setBackground(createRoundedRect(dp(14), DROPDOWN_BG_COLOR, ACCENT_BORDER_COLOR, dp(1.25f)));
        list.setClipToOutline(true);
        list.setPadding(dp(6), dp(6), dp(6), dp(6));

        for (int i = 0; i < labels.length; i++) {
            final int idx = i;

            TextView item = new DigitTextView(context);
            item.setText(labels[i]);
            item.setTextColor(i == selectedIndex ? ACCENT_COLOR : Color.WHITE);
            item.setTypeface(i == selectedIndex ? typefaceSemiBold : typefaceRegular);
            AstroUiEffects.applyUnitTypeface(item, context);
            item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            item.setPadding(dp(14), dp(10), dp(14), dp(10));
            item.setClickable(true);
            item.setFocusable(true);

            item.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						HapticUtils.perform(v);
						callback.onSelected(idx);
						dropdownLayer.removeAllViews();
					}
				});

            list.addView(item, new LinearLayout.LayoutParams(
							 LinearLayout.LayoutParams.MATCH_PARENT,
							 LinearLayout.LayoutParams.WRAP_CONTENT
						 ));
        }

        int estimatedHeight = dp(12) + (labels.length * dp(40));
        int spaceBelow = visibleBottom - anchorBottom - dp(8);
        int spaceAbove = relativeY - visibleTop - dp(8);

        if (spaceBelow < 0) {
            spaceBelow = 0;
        }

        if (spaceAbove < 0) {
            spaceAbove = 0;
        }

        boolean showAbove = spaceBelow < estimatedHeight && spaceAbove > spaceBelow;

        final int maxHeight = Math.max(
			0,
			Math.min(estimatedHeight, showAbove ? spaceAbove : spaceBelow)
        );

        ScrollView listScroll = new ScrollView(context) {
            @Override
            protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                int hSpec = heightMeasureSpec;

                if (maxHeight > 0) {
                    int mode = View.MeasureSpec.getMode(hSpec);
                    int size = View.MeasureSpec.getSize(hSpec);

                    if (mode == View.MeasureSpec.UNSPECIFIED || size > maxHeight) {
                        hSpec = View.MeasureSpec.makeMeasureSpec(maxHeight, View.MeasureSpec.AT_MOST);
                    }
                }

                super.onMeasure(widthMeasureSpec, hSpec);
            }
        };

        listScroll.addView(list, new ScrollView.LayoutParams(
							   ScrollView.LayoutParams.MATCH_PARENT,
							   ScrollView.LayoutParams.WRAP_CONTENT
						   ));

        listScroll.setBackground(list.getBackground());
        list.setBackground(null);

        listScroll.setVerticalScrollBarEnabled(false);
        listScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        int listWidth = dp(220);

        FrameLayout.LayoutParams listLp = new FrameLayout.LayoutParams(
			listWidth,
			FrameLayout.LayoutParams.WRAP_CONTENT
        );

        listLp.leftMargin = Math.max(dp(8), relativeX + anchor.getWidth() - listWidth);

        if (showAbove) {
            listLp.topMargin = Math.max(visibleTop + dp(8), relativeY - maxHeight - dp(4));
        } else {
            listLp.topMargin = anchorBottom + dp(4);
        }

        dropdownLayer.addView(listScroll, listLp);
        listScroll.bringToFront();
    }

    // =========================================================
    //  Расчёт
    // =========================================================

    private void onSimplifiedCalculatePressed() {
        simplifiedResultContainer.removeAllViews();

        Double mass = parseRequired(simpleMassInput, "массу объекта");
        if (mass == null) return;
        if (mass <= 0.0) {
            showSimplifiedResultError("Масса объекта должна быть положительной.");
            return;
        }

        Double radius = parseRequired(simpleRadiusInput, "радиус объекта");
        if (radius == null) return;
        if (radius <= 0.0) {
            showSimplifiedResultError("Радиус объекта должен быть положительным.");
            return;
        }

        double massKg = PhysicsEngine.MassUnit.values()[simpleMassUnit.selectedIndex].toKg(mass);
        double radiusM = PhysicsEngine.DistanceUnit.values()[simpleRadiusUnit.selectedIndex].toMeters(radius);
        double g = PhysicsEngine.G * massKg / (radiusM * radiusM);

        LinearLayout box = resultBox();
        box.addView(resultSectionTitle("Результат"));
        box.addView(spacer(dp(6)));

        TextView value = new DigitTextView(context);
        value.setText(formatGravityValue(g));
        value.setTextColor(Color.parseColor("#E8FFFFFF"));
        value.setTypeface(typefaceSemiBold);
        value.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        value.setLineSpacing(dp(2), 1.1f);
        box.addView(value);

        TextView formula = new DigitTextView(context);
        formula.setText("g = GM / R²");
        formula.setTextColor(Color.parseColor("#CFE3E1DE"));
        formula.setTypeface(typefaceRegular);
        formula.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        box.addView(spacer(dp(6)));
        box.addView(formula);

        simplifiedResultContainer.addView(box);
    }

    private String formatGravityValue(double g) {
        if (Double.isNaN(g) || Double.isInfinite(g)) {
            return "Не удалось получить конечное значение.";
        }
        return String.format(java.util.Locale.US, "%.9f м/с²", g);
    }

    private void showSimplifiedResultError(String message) {
        TextView tv = new DigitTextView(context);
        tv.setText(message);
        tv.setTextColor(Color.parseColor("#FFB4A0"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        simplifiedResultContainer.addView(tv);
    }

    private void onCalculatePressed() {
        try {
            resultContainer.removeAllViews();

            if (GravityResultStore.state == GravityResultStore.RUNNING) {
                showRunningBlock();
                return;
            }

            GravityRelativityEngine.Params params = collectParams();
            if (params == null) {
                return;
            }

            GravityResultStore.reset();
            GravityResultStore.state = GravityResultStore.RUNNING;
            GravityResultStore.progress = 0;

            startThread(params);
            showRunningBlock();

        } catch (Throwable t) {
            resultContainer.removeAllViews();
            showResultError("Ошибка при подготовке расчёта:\n" + t);
        }
    }

    private GravityRelativityEngine.Params collectParams() {
        Double x = parseOptional(xInput, "координату X");
        if (x == null) {
            return null;
        }

        Double y = parseOptional(yInput, "координату Y");
        if (y == null) {
            return null;
        }

        Double z = parseOptional(zInput, "координату Z");
        if (z == null) {
            return null;
        }

        Double mass = parseRequired(massInput, "массу источника");
        if (mass == null) {
            return null;
        }

        if (mass <= 0.0) {
            showResultError("Масса источника должна быть положительной.");
            return null;
        }

        Double ovx = parseOptional(observerVxInput, "Vx наблюдателя");
        if (ovx == null) {
            return null;
        }

        Double ovy = parseOptional(observerVyInput, "Vy наблюдателя");
        if (ovy == null) {
            return null;
        }

        Double ovz = parseOptional(observerVzInput, "Vz наблюдателя");
        if (ovz == null) {
            return null;
        }

        GravityRelativityEngine.Params p = new GravityRelativityEngine.Params();

        p.x = PhysicsEngine.DistanceUnit.values()[xUnit.selectedIndex].toMeters(x);
        p.y = PhysicsEngine.DistanceUnit.values()[yUnit.selectedIndex].toMeters(y);
        p.z = PhysicsEngine.DistanceUnit.values()[zUnit.selectedIndex].toMeters(z);

        p.massKg = PhysicsEngine.MassUnit.values()[massUnit.selectedIndex].toKg(mass);

        p.observerVx = speedToMs(observerVxUnit.selectedIndex, ovx);
        p.observerVy = speedToMs(observerVyUnit.selectedIndex, ovy);
        p.observerVz = speedToMs(observerVzUnit.selectedIndex, ovz);

        if (advancedMode) {
            Double spin = parseOptional(spinInput, "спин");
            if (spin == null) {
                return null;
            }

            Double svx = parseOptional(sourceVxInput, "SVx источника");
            if (svx == null) {
                return null;
            }

            Double svy = parseOptional(sourceVyInput, "SVy источника");
            if (svy == null) {
                return null;
            }

            Double svz = parseOptional(sourceVzInput, "SVz источника");
            if (svz == null) {
                return null;
            }

            Double charge = parseOptional(chargeInput, "заряд");
            if (charge == null) {
                return null;
            }

            Double lambda = parseOptional(lambdaInput, "Λ");
            if (lambda == null) {
                return null;
            }

            p.spin = spinToSi(spinUnit.selectedIndex, spin);

            p.sourceVx = speedToMs(sourceVxUnit.selectedIndex, svx);
            p.sourceVy = speedToMs(sourceVyUnit.selectedIndex, svy);
            p.sourceVz = speedToMs(sourceVzUnit.selectedIndex, svz);

            p.chargeC = chargeToSi(chargeUnit.selectedIndex, charge);
            p.lambda = lambdaToSi(lambdaUnit.selectedIndex, lambda);
        }

        if (p.x == 0.0 && p.y == 0.0 && p.z == 0.0) {
            showResultError("Координаты точки измерения не могут все быть нулём относительно источника.");
            return null;
        }

        return p;
    }

    private void startThread(final GravityRelativityEngine.Params params) {
        PerformancePools.math().execute(new Runnable() {
				@Override
				public void run() {
					try {
						String result = GravityRelativityEngine.compute(params);

						if (GravityResultStore.state == GravityResultStore.RUNNING) {
							GravityResultStore.result = result;
							GravityResultStore.state = GravityResultStore.DONE;
						}
					} catch (Throwable t) {
						if (GravityResultStore.state == GravityResultStore.RUNNING) {
							GravityResultStore.error = "Ошибка расчёта:\n" + t;
							GravityResultStore.state = GravityResultStore.ERROR;
						}
					}
				}
			});
    }

    private Double parseRequired(EditText input, String name) {
        String text = input.getText().toString().trim();

        if (text.isEmpty()) {
            showResultError("Введите " + name + ".");
            return null;
        }

        Double v = parseDouble(text);
        if (v == null) {
            showResultError("Не удалось прочитать " + name + ".");
            return null;
        }

        return v;
    }

    private Double parseOptional(EditText input, String name) {
        String text = input.getText().toString().trim();

        if (text.isEmpty()) {
            return 0.0;
        }

        Double v = parseDouble(text);
        if (v == null) {
            showResultError("Не удалось прочитать " + name + ".");
            return null;
        }

        return v;
    }

    private Double parseDouble(String text) {
        if (text == null) {
            return null;
        }

        String trimmed = text.trim().replace(',', '.');

        if (trimmed.isEmpty()) {
            return null;
        }

        try {
            return Double.parseDouble(trimmed);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private double speedToMs(int index, double v) {
        switch (index) {
            case 0:
                return v;
            case 1:
                return v * 1000.0;
            case 2:
                return v * 299792458.0 / 100.0;
            case 3:
                return v * 299792458.0;
            default:
                return v;
        }
    }

    private double spinToSi(int index, double v) {
        switch (index) {
            case 0:
                return v;
            case 1:
                return v * 1.0e-7;
            case 2:
                return v * 1.98847e30 * 1.0e6;
            default:
                return v;
        }
    }

    private double chargeToSi(int index, double v) {
        switch (index) {
            case 0:
                return v;
            case 1:
                return v * 1.0e-3;
            case 2:
                return v * 1.602176634e-19;
            default:
                return v;
        }
    }

    private double lambdaToSi(int index, double v) {
        switch (index) {
            case 0:
                return v;
            case 1:
                return v * 1.0e-6;
            case 2:
                double ly = 9.4607304725808e15;
                return v / (ly * ly);
            default:
                return v;
        }
    }

    // =========================================================
    //  Результат
    // =========================================================

    private void restoreLastResultIfNeeded() {
        int st = GravityResultStore.state;

        if (st == GravityResultStore.RUNNING) {
            showRunningBlock();
        } else if (st == GravityResultStore.DONE) {
            showStaticResult(GravityResultStore.result);
        } else if (st == GravityResultStore.ERROR) {
            showStaticError(GravityResultStore.error);
        }
    }

    private void showRunningBlock() {
        final LinearLayout box = resultBox();
        final TextView title = resultSectionTitle("Расчёт выполняется…");

        final TextView progressText = new DigitTextView(context);
        progressText.setText(GravityResultStore.progress + " %");
        progressText.setTextColor(Color.parseColor("#CCFFFFFF"));
        progressText.setTypeface(typefaceRegular);
        progressText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);

        box.addView(title);
        box.addView(spacer(dp(6)));
        box.addView(progressText);

        resultContainer.addView(box);

        if (calculationOverlay == null) {
            calculationOverlay = new CalculationProgressOverlay(context, rootContainer);
            calculationOverlay.begin("Релятивистское ускорение", ACCENT_COLOR);
        }
        if (calculationOverlay != null) {
            calculationOverlay.update(GravityResultStore.progress, (GravityResultStore.progress / 100.0) * GravityRelativityEngine.YEAR_SECONDS, "Интегрирование годового интервала");
        }

        startProgressPolling(box, title, progressText);
    }

    private void startProgressPolling(
		final LinearLayout box,
		final TextView title,
		final TextView progressText
    ) {
        stopProgressPolling();

        progressPoller = new Runnable() {
            @Override
            public void run() {
                try {
                    if (overlayRoot == null || box == null) {
                        return;
                    }

                    int st = GravityResultStore.state;

                    if (st == GravityResultStore.RUNNING) {
                        if (progressText != null) {
                            progressText.setText(GravityResultStore.progress + " %");
                        }
                        if (calculationOverlay != null) {
                            calculationOverlay.update(GravityResultStore.progress, (GravityResultStore.progress / 100.0) * GravityRelativityEngine.YEAR_SECONDS, "Интегрирование годового интервала");
                        }

                        uiHandler.postDelayed(this, 250);
                    } else if (st == GravityResultStore.DONE) {
                        renderDone(box, title, progressText);
                    } else if (st == GravityResultStore.ERROR) {
                        renderError(box, title, progressText);
                    }
                } catch (Throwable ignore) {
                    // polling не должен ронять UI
                }
            }
        };

        uiHandler.postDelayed(progressPoller, 200);
    }

    private void stopProgressPolling() {
        if (progressPoller != null) {
            try {
                uiHandler.removeCallbacks(progressPoller);
            } catch (Throwable ignore) {
                // не критично
            }

            progressPoller = null;
        }
    }

    private void renderDone(LinearLayout box, TextView title, TextView progressText) {
        if (box == null) {
            return;
        }

        if (Boolean.TRUE.equals(box.getTag())) {
            return;
        }

        box.setTag(Boolean.TRUE);
        stopProgressPolling();
        if (calculationOverlay != null) {
            calculationOverlay.update(100, GravityRelativityEngine.YEAR_SECONDS, "Расчёт завершён");
            calculationOverlay.finish();
            calculationOverlay = null;
        }

        if (title != null) {
            title.setText("Результат");
        }

        if (progressText != null) {
            box.removeView(progressText);
        }

        TextView tv = new DigitTextView(context);
        tv.setText(GravityResultStore.result != null ? GravityResultStore.result : "");
        tv.setTextColor(Color.parseColor("#E8FFFFFF"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tv.setLineSpacing(dp(2), 1.1f);

        box.addView(tv);
    }

    private void renderError(LinearLayout box, TextView title, TextView progressText) {
        if (box == null) {
            return;
        }

        if (Boolean.TRUE.equals(box.getTag())) {
            return;
        }

        box.setTag(Boolean.TRUE);
        stopProgressPolling();
        if (calculationOverlay != null) {
            calculationOverlay.fail("Ошибка расчёта");
            calculationOverlay = null;
        }

        if (title != null) {
            title.setText("Ошибка расчёта");
        }

        if (progressText != null) {
            box.removeView(progressText);
        }

        TextView err = new DigitTextView(context);
        err.setText(GravityResultStore.error != null ? GravityResultStore.error : "Не удалось выполнить расчёт.");
        err.setTextColor(Color.parseColor("#FFB4A0"));
        err.setTypeface(typefaceRegular);
        err.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);

        box.addView(err);
    }

    private void showStaticResult(String result) {
        LinearLayout box = resultBox();

        TextView title = resultSectionTitle("Результат");
        box.addView(title);
        box.addView(spacer(dp(6)));

        TextView tv = new DigitTextView(context);
        tv.setText(result != null ? result : "");
        tv.setTextColor(Color.parseColor("#E8FFFFFF"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tv.setLineSpacing(dp(2), 1.1f);

        box.addView(tv);
        resultContainer.addView(box);
    }

    private void showStaticError(String error) {
        LinearLayout box = resultBox();

        TextView title = resultSectionTitle("Ошибка расчёта");
        box.addView(title);
        box.addView(spacer(dp(6)));

        TextView tv = new DigitTextView(context);
        tv.setText(error != null ? error : "Не удалось выполнить расчёт.");
        tv.setTextColor(Color.parseColor("#FFB4A0"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);

        box.addView(tv);
        resultContainer.addView(box);
    }

    private void showResultError(String message) {
        TextView tv = new DigitTextView(context);
        tv.setText(message);
        tv.setTextColor(Color.parseColor("#FFB4A0"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);

        resultContainer.addView(tv);
    }

    private LinearLayout resultBox() {
        LinearLayout box = new LinearLayout(context);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(createRoundedRect(
							  dp(16),
							  Color.parseColor("#6F6B67"),
							  Color.parseColor("#CCFFFFFF"),
							  dp(1.5f)
						  ));

        int p = dp(14);
        box.setPadding(p, p, p, p);
        box.setLayoutParams(new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT,
								LinearLayout.LayoutParams.WRAP_CONTENT
							));

        return box;
    }

    private TextView resultSectionTitle(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        return tv;
    }

    // =========================================================
    //  Утилиты
    // =========================================================

    private GradientDrawable createRoundedRect(
		float radius,
		int fillColor,
		int strokeColor,
		float strokeWidth
    ) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(radius);
        gd.setColor(fillColor);
        gd.setStroke((int) strokeWidth, strokeColor);
        return gd;
    }

    private FrameLayout.LayoutParams matchParentFrameLp() {
        return new FrameLayout.LayoutParams(
			FrameLayout.LayoutParams.MATCH_PARENT,
			FrameLayout.LayoutParams.MATCH_PARENT
        );
    }
}
