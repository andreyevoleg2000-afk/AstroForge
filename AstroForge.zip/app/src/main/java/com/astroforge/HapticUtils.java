package com.astroforge;

import android.content.Context;
import android.view.HapticFeedbackConstants;
import android.view.View;

/**
 * Centralized Android-native tactile feedback for button presses.
 *
 * No direct Vibrator/VibrationEffect calls are used here. The platform
 * decides how the haptic is rendered on the device and respects the
 * user's system haptic-feedback settings.
 */
final class HapticUtils {

    private static final String PREFS_NAME = "astroforge_prefs";
    private static final String KEY_HAPTIC = "haptic_enabled";

    private HapticUtils() {
    }

    static void perform(View view) {
        if (view == null || !isEnabled(view.getContext())) {
            return;
        }

        // CONFIRM is the native Android semantic for a positive user action
        // and is noticeably more distinct than VIRTUAL_KEY on modern devices.
        boolean performed = false;

        try {
            performed = view.performHapticFeedback(
                    HapticFeedbackConstants.CONFIRM
            );
        } catch (Throwable ignored) {
            // Fall through to the broad compatibility feedback below.
        }

        if (!performed) {
            try {
                view.performHapticFeedback(
                        HapticFeedbackConstants.VIRTUAL_KEY
                );
            } catch (Throwable ignored) {
                // Nothing else to do.
            }
        }
    }

    private static boolean isEnabled(Context context) {
        if (context == null) {
            return true;
        }

        return context.getSharedPreferences(
                PREFS_NAME,
                Context.MODE_PRIVATE
        ).getBoolean(KEY_HAPTIC, true);
    }
}
