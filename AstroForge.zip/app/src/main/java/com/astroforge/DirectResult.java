package com.astroforge;

/**
 * Результат прямого расчёта магнитного поля.
 */
public final class DirectResult {

    public final double coreFieldTesla;
    public final double surfaceFieldTesla;
    public final double dipoleMomentAm2;
    public final double dipoleFractionUsed;
    public final double energyFluxUsedWm2;
    public final double magneticEnergyDensityJm3;
    public final double magneticPressurePa;

    public DirectResult(
		double coreFieldTesla,
		double surfaceFieldTesla,
		double dipoleMomentAm2,
		double dipoleFractionUsed,
		double energyFluxUsedWm2,
		double magneticEnergyDensityJm3,
		double magneticPressurePa
    ) {
        this.coreFieldTesla = coreFieldTesla;
        this.surfaceFieldTesla = surfaceFieldTesla;
        this.dipoleMomentAm2 = dipoleMomentAm2;
        this.dipoleFractionUsed = dipoleFractionUsed;
        this.energyFluxUsedWm2 = energyFluxUsedWm2;
        this.magneticEnergyDensityJm3 = magneticEnergyDensityJm3;
        this.magneticPressurePa = magneticPressurePa;
    }

    public double surfaceFieldGauss() {
        return surfaceFieldTesla * 1.0e4;
    }

    public double surfaceFieldMicroTesla() {
        return surfaceFieldTesla * 1.0e6;
    }

    public double surfaceFieldNanoTesla() {
        return surfaceFieldTesla * 1.0e9;
    }
}
