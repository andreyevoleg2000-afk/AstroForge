package com.astroforge;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

/**
 * Всплывающее окно "Год на объекте".
 *
 * Считает длительность одного оборота тела вокруг родительского тела (орбитальный
 * период) по третьему закону Кеплера: T = 2π * sqrt(a^3 / (G*M)), где a — расстояние
 * до тела (принимается как большая полуось орбиты), M — масса родительского тела.
 *
 * Эксцентриситет орбиты — необязательное поле, без выезжающего списка. Сам период
 * от него не зависит (в этом суть третьего закона Кеплера), но если эксцентриситет
 * введён и корректен (0 ≤ e &lt; 1), дополнительно считаются перигелий/афелий и
 * орбитальные скорости в этих точках — этот блок результата показывается только
 * тогда, когда поле реально заполнено, как и было озвучено в задаче.
 *
 * Стиль, палитра и структура окна полностью повторяют окно "Скорость объекта"
 * (VelocityPanel) — тот же градиент/блюр рамки, тот же тёмно-серый цвет полей ввода
 * и те же выезжающие списки единиц измерения (масса — как в VelocityPanel, расстояние —
 * оттуда же, но с единицами расстояния вместо размеров объектов).
 *
 * AIDE-safe: без лямбд, без androidx, diamond с явным типом, все захваченные
 * в анонимный класс локальные переменные — final.
 */
final class YearOnObjectPanel {

    private static final int ACCENT_COLOR        = 0xFFD9946B;
    private static final int ACCENT_BORDER_COLOR = Color.parseColor("#CCD9946B");
    private static final int FIELD_BG_COLOR      = Color.parseColor("#F21C1C1E");
    private static final int FIELD_BORDER_COLOR  = Color.parseColor("#B3E3E3E3");
    private static final int PILL_BG_COLOR       = Color.BLACK;
    private static final int DROPDOWN_BG_COLOR   = Color.parseColor("#FF1C1C1E");

    private final Context context;
    private final FrameLayout rootContainer;
    private final Typeface typefaceRegular;
    private final Typeface typefaceSemiBold;

    private FrameLayout overlayRoot;
    private FrameLayout dropdownLayer;

    private EditText parentMassInput;
    private UnitPillState parentMassUnit;

    private EditText distanceInput;
    private UnitPillState distanceUnit;

    private EditText eccentricityInput;

    private LinearLayout resultContainer;

    private YearOnObjectPanel(Context context,
                              FrameLayout rootContainer,
                              Typeface typefaceRegular,
                              Typeface typefaceSemiBold) {
        this.context = context;
        this.rootContainer = rootContainer;
        this.typefaceRegular = typefaceRegular;
        this.typefaceSemiBold = typefaceSemiBold;
    }

    static void show(Context context,
                     FrameLayout rootContainer,
                     Typeface typefaceRegular,
                     Typeface typefaceSemiBold) {
        new YearOnObjectPanel(context, rootContainer, typefaceRegular, typefaceSemiBold).build();
    }

    private int dp(float value) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                value,
                context.getResources().getDisplayMetrics()
        );
    }

    // =========================================================
    //  Построение окна
    // =========================================================

    private void build() {
        overlayRoot = new FrameLayout(context);
        overlayRoot.setBackgroundColor(Color.parseColor("#CC0F0F10"));
        overlayRoot.setClickable(true);
        overlayRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                close();
            }
        });

        final FrameLayout windowFrame = new FrameLayout(context);
        windowFrame.setClickable(true);
        windowFrame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /* поглощаем клик */
            }
        });

        GradientDrawable frameBg = new GradientDrawable();
        frameBg.setShape(GradientDrawable.RECTANGLE);
        frameBg.setCornerRadius(dp(28));
        frameBg.setColor(0xF21E1E20);
        frameBg.setStroke(dp(2), ACCENT_COLOR);
        windowFrame.setBackground(frameBg);
        windowFrame.setClipToOutline(true);
        windowFrame.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);

        android.widget.ImageView blurBg = new android.widget.ImageView(context);
        blurBg.setImageResource(R.drawable.background);
        blurBg.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        blurBg.setRenderEffect(RenderEffect.createBlurEffect(dp(44), dp(44), Shader.TileMode.CLAMP));
        blurBg.setAlpha(0.88f);
        windowFrame.addView(blurBg, matchParentFrameLp());

        View tint = new View(context);
        tint.setBackgroundColor(Color.parseColor("#CC232326"));
        windowFrame.addView(tint, matchParentFrameLp());
        AstroUiEffects.applyPaperEffect(windowFrame, context);

        ScrollView scrollView = new ScrollView(context);
        scrollView.setClipToPadding(false);

        LinearLayout content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);

        int pad = dp(20);
        content.setPadding(pad, pad, pad, pad);

        content.addView(buildTitle());
        content.addView(spacer(dp(18)));

        content.addView(buildLabel("Масса родительского тела"));
        content.addView(spacer(dp(6)));
        ValueUnitRow massRow = buildMassField();
        parentMassInput = massRow.input;
        parentMassUnit  = massRow.unitState;
        content.addView(massRow.row);

        content.addView(spacer(dp(14)));

        content.addView(buildLabel("Расстояние до тела"));
        content.addView(spacer(dp(6)));
        ValueUnitRow distRow = buildDistanceField();
        distanceInput = distRow.input;
        distanceUnit  = distRow.unitState;
        content.addView(distRow.row);

        content.addView(spacer(dp(14)));

        content.addView(buildLabel("Эксцентриситет орбиты (необязательно)"));
        content.addView(spacer(dp(6)));
        eccentricityInput = buildEccentricityField();
        content.addView(eccentricityInput);

        content.addView(spacer(dp(18)));
        content.addView(buildCalculateButton());
        content.addView(spacer(dp(16)));

        resultContainer = new LinearLayout(context);
        resultContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(resultContainer);

        content.addView(spacer(dp(20)));

        scrollView.addView(content, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT
        ));

        windowFrame.addView(scrollView, matchParentFrameLp());

        FrameLayout.LayoutParams windowLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        );

        int screenMargin = dp(18);
        windowLp.setMargins(
                screenMargin,
                screenMargin + dp(30),
                screenMargin,
                screenMargin + dp(30)
        );

        overlayRoot.addView(windowFrame, windowLp);
        rootContainer.addView(overlayRoot, matchParentFrameLp());

        windowFrame.post(new Runnable() {
            @Override
            public void run() {
                if (overlayRoot != null && overlayRoot.getParent() == rootContainer && windowFrame != null) {
                    WindowOpenAnimation.start(windowFrame, context.getResources().getDisplayMetrics().density);
                }
            }
        });

        dropdownLayer = new FrameLayout(context);
        dropdownLayer.setClipChildren(false);
        dropdownLayer.setClipToPadding(false);
        dropdownLayer.setElevation(dp(1000));
        overlayRoot.addView(dropdownLayer, matchParentFrameLp());
        dropdownLayer.bringToFront();
    }

    private void close() {
        if (overlayRoot != null && overlayRoot.getParent() == rootContainer) {
            rootContainer.removeView(overlayRoot);
        }
    }

    // =========================================================
    //  Мелкие UI-хелперы
    // =========================================================

    private View buildTitle() {
        TextView tv = new DigitTextView(context);
        tv.setText("Год на объекте");
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        tv.setGravity(Gravity.START | Gravity.TOP);
        return tv;
    }

    private TextView buildLabel(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#DDE3E1DE"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        return tv;
    }

    private View spacer(int heightPx) {
        View v = new View(context);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                heightPx
        ));
        return v;
    }

    // =========================================================
    //  Поля с единицами
    // =========================================================

    private static final class ValueUnitRow {
        View row;
        EditText input;
        UnitPillState unitState;
    }

    private static final class UnitPillState {
        TextView pillView;
        int selectedIndex = 0;
        String[] labels;
    }

    private ValueUnitRow buildMassField() {
        String[] labels = new String[PhysicsEngine.MassUnit.values().length];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = PhysicsEngine.MassUnit.values()[i].label;
        }
        return buildValueUnitRow(labels, "Введите массу");
    }

    private ValueUnitRow buildDistanceField() {
        String[] labels = new String[PhysicsEngine.DistanceUnit.values().length];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = PhysicsEngine.DistanceUnit.values()[i].label;
        }
        return buildValueUnitRow(labels, "Введите расстояние");
    }

    private ValueUnitRow buildValueUnitRow(final String[] unitLabels, String hint) {
        FrameLayout field = new FrameLayout(context);
        field.setBackground(createRoundedRect(dp(16), FIELD_BG_COLOR, FIELD_BORDER_COLOR, dp(1.25f)));
        AstroUiEffects.applyControlShadow(field, context);
        field.setClipToOutline(true);

        final EditText input = new DigitEditText(context);
        input.setHint(hint);
        input.setHintTextColor(Color.parseColor("#77FFFFFF"));
        input.setTextColor(Color.WHITE);
        input.setTypeface(typefaceRegular);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        input.setSingleLine(true);
        input.setBackground(null);
        AstroUiEffects.applyControlShadow(input, context);
        input.setInputType(InputType.TYPE_CLASS_NUMBER
                | InputType.TYPE_NUMBER_FLAG_DECIMAL
                | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setPadding(dp(16), dp(12), dp(120), dp(12));
        field.addView(input, matchParentFrameLp());

        final UnitPillState state = new UnitPillState();
        state.labels = unitLabels;
        state.selectedIndex = 0;

        final TextView pill = new DigitTextView(context);
        pill.setText(unitLabels[0]);
        pill.setTextColor(Color.WHITE);
        pill.setTypeface(typefaceSemiBold);
        pill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        pill.setGravity(Gravity.CENTER);
        pill.setMaxLines(1);
        pill.setEllipsize(android.text.TextUtils.TruncateAt.END);
        pill.setBackground(createRoundedRect(dp(14), PILL_BG_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        pill.setPadding(dp(12), dp(8), dp(12), dp(8));
        pill.setClickable(true);
        pill.setFocusable(true);

        FrameLayout.LayoutParams pillLp = new FrameLayout.LayoutParams(
                dp(104),
                FrameLayout.LayoutParams.WRAP_CONTENT
        );
        pillLp.gravity = Gravity.CENTER_VERTICAL | Gravity.END;
        pillLp.rightMargin = dp(8);
        field.addView(pill, pillLp);
        pill.setTranslationZ(dp(3f));

        state.pillView = pill;

        pill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HapticUtils.perform(v);
                openDropdown(pill, unitLabels, state.selectedIndex, new OnUnitSelected() {
                    @Override
                    public void onSelected(int newIndex) {
                        state.selectedIndex = newIndex;
                        pill.setText(unitLabels[newIndex]);
                    }
                });
            }
        });

        field.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(50)
        ));

        ValueUnitRow row = new ValueUnitRow();
        row.row = field;
        row.input = input;
        row.unitState = state;
        return row;
    }

    /**
     * Поле эксцентриситета: тот же тёмно-серый прямоугольник, что и у остальных полей,
     * но без пилюли единиц измерения — значение безразмерное (0 ≤ e &lt; 1) и
     * учитывается только тогда, когда реально введено.
     */
    private EditText buildEccentricityField() {
        EditText input = new DigitEditText(context);
        input.setHint("Необязательно, от 0 до 0.99");
        input.setHintTextColor(Color.parseColor("#77FFFFFF"));
        input.setTextColor(Color.WHITE);
        input.setTypeface(typefaceRegular);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        input.setSingleLine(true);
        input.setBackground(createRoundedRect(dp(16), FIELD_BG_COLOR, FIELD_BORDER_COLOR, dp(1.25f)));
        AstroUiEffects.applyControlShadow(input, context);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setPadding(dp(16), dp(12), dp(16), dp(12));
        input.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(50)
        ));
        return input;
    }

    // =========================================================
    //  Dropdown
    // =========================================================

    private interface OnUnitSelected {
        void onSelected(int index);
    }

    private void openDropdown(final View anchor,
                              final String[] labels,
                              int selectedIndex,
                              final OnUnitSelected callback) {
        dropdownLayer.removeAllViews();
        dropdownLayer.bringToFront();

        int[] anchorLoc = new int[2];
        anchor.getLocationOnScreen(anchorLoc);

        int[] rootLoc = new int[2];
        dropdownLayer.getLocationOnScreen(rootLoc);

        int relativeX = anchorLoc[0] - rootLoc[0];
        int relativeY = anchorLoc[1] - rootLoc[1];
        int anchorBottom = relativeY + anchor.getHeight();

        Rect visibleFrame = new Rect();
        rootContainer.getWindowVisibleDisplayFrame(visibleFrame);

        int visibleTop = visibleFrame.top - rootLoc[1];
        int visibleBottom = visibleFrame.bottom - rootLoc[1];

        View scrim = new View(context);
        scrim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dropdownLayer.removeAllViews();
            }
        });
        dropdownLayer.addView(scrim, matchParentFrameLp());

        LinearLayout list = new LinearLayout(context);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setBackground(createRoundedRect(dp(14), DROPDOWN_BG_COLOR, ACCENT_BORDER_COLOR, dp(1.25f)));
        list.setClipToOutline(true);
        list.setPadding(dp(6), dp(6), dp(6), dp(6));

        for (int i = 0; i < labels.length; i++) {
            final int idx = i;

            TextView item = new DigitTextView(context);
            item.setText(labels[i]);
            item.setTextColor(i == selectedIndex ? ACCENT_COLOR : Color.WHITE);
            item.setTypeface(i == selectedIndex ? typefaceSemiBold : typefaceRegular);
            AstroUiEffects.applyUnitTypeface(item, context);
            item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            item.setPadding(dp(14), dp(10), dp(14), dp(10));
            item.setClickable(true);
            item.setFocusable(true);

            item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    HapticUtils.perform(v);
                    callback.onSelected(idx);
                    dropdownLayer.removeAllViews();
                }
            });

            list.addView(item, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            ));
        }

        int estimatedHeight = dp(12) + (labels.length * dp(40));
        int spaceBelow = visibleBottom - anchorBottom - dp(8);
        int spaceAbove = relativeY - visibleTop - dp(8);

        if (spaceBelow < 0) spaceBelow = 0;
        if (spaceAbove < 0) spaceAbove = 0;

        boolean showAbove = spaceBelow < estimatedHeight && spaceAbove > spaceBelow;

        final int maxHeight = Math.max(
                0,
                Math.min(estimatedHeight, showAbove ? spaceAbove : spaceBelow)
        );

        ScrollView listScroll = new ScrollView(context) {
            @Override
            protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                int hSpec = heightMeasureSpec;

                if (maxHeight > 0) {
                    int mode = View.MeasureSpec.getMode(hSpec);
                    int size = View.MeasureSpec.getSize(hSpec);

                    if (mode == View.MeasureSpec.UNSPECIFIED || size > maxHeight) {
                        hSpec = View.MeasureSpec.makeMeasureSpec(maxHeight, View.MeasureSpec.AT_MOST);
                    }
                }

                super.onMeasure(widthMeasureSpec, hSpec);
            }
        };

        listScroll.addView(list, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT
        ));

        listScroll.setBackground(list.getBackground());
        list.setBackground(null);
        listScroll.setVerticalScrollBarEnabled(false);
        listScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        FrameLayout.LayoutParams listLp = new FrameLayout.LayoutParams(
                dp(180),
                FrameLayout.LayoutParams.WRAP_CONTENT
        );

        listLp.leftMargin = Math.max(dp(8), relativeX + anchor.getWidth() - dp(180));

        if (showAbove) {
            listLp.topMargin = Math.max(visibleTop + dp(8), relativeY - maxHeight - dp(4));
        } else {
            listLp.topMargin = anchorBottom + dp(4);
        }

        dropdownLayer.addView(listScroll, listLp);
        listScroll.bringToFront();
    }

    // =========================================================
    //  Кнопка расчёта и результат
    // =========================================================

    private View buildCalculateButton() {
        TextView btn = new DigitTextView(context);
        btn.setText("Рассчитать");
        btn.setTextColor(Color.WHITE);
        btn.setTypeface(typefaceSemiBold);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(0, dp(14), 0, dp(14));
        btn.setBackground(createRoundedRect(dp(18), ACCENT_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        AstroUiEffects.applyControlShadow(btn, context);
        btn.setClickable(true);
        btn.setFocusable(true);
        btn.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HapticUtils.perform(v);
                onCalculatePressed();
            }
        });

        return btn;
    }

    /** Обёрнуто в try/catch(Throwable): любая ошибка больше не роняет приложение. */
    private void onCalculatePressed() {
        try {
            resultContainer.removeAllViews();

            Double parentMassValue = parseDouble(parentMassInput.getText().toString());
            Double distanceValue   = parseDouble(distanceInput.getText().toString());

            if (parentMassValue == null || distanceValue == null
                    || parentMassValue <= 0 || distanceValue <= 0) {
                showResultError("Введите корректную массу и расстояние (положительные числа).");
                return;
            }

            double parentMassKg =
                    PhysicsEngine.MassUnit.values()[parentMassUnit.selectedIndex].toKg(parentMassValue);

            double distanceM =
                    PhysicsEngine.DistanceUnit.values()[distanceUnit.selectedIndex].toMeters(distanceValue);

            // Третий закон Кеплера: T = 2π * sqrt(a^3 / (G*M)). Расстояние принимается
            // как большая полуось орбиты — сам период от эксцентриситета не зависит.
            double periodSeconds =
                    2.0 * Math.PI * Math.sqrt(Math.pow(distanceM, 3) / (PhysicsEngine.G * parentMassKg));

            String eccText = eccentricityInput.getText().toString();
            Double eccValue = parseDouble(eccText);
            boolean eccWasEntered = eccValue != null;
            boolean eccValid = eccWasEntered && eccValue >= 0.0 && eccValue < 1.0;

            double periapsisM = 0, apoapsisM = 0, periSpeedMs = 0, apoSpeedMs = 0;

            if (eccValid) {
                double a = distanceM;
                double e = eccValue;
                periapsisM  = a * (1.0 - e);
                apoapsisM   = a * (1.0 + e);
                periSpeedMs = Math.sqrt(PhysicsEngine.G * parentMassKg * (2.0 / periapsisM - 1.0 / a));
                apoSpeedMs  = Math.sqrt(PhysicsEngine.G * parentMassKg * (2.0 / apoapsisM  - 1.0 / a));
            }

            showYearResult(periodSeconds, eccValid, periapsisM, apoapsisM, periSpeedMs, apoSpeedMs);

            if (eccWasEntered && !eccValid) {
                showEccentricityWarning();
            }
        } catch (Throwable t) {
            resultContainer.removeAllViews();
            showResultError("Ошибка при расчёте:\n" + stack(t));
        }
    }

    private Double parseDouble(String text) {
        if (text == null) return null;

        String trimmed = text.trim().replace(',', '.');
        if (trimmed.isEmpty()) return null;

        try {
            return Double.parseDouble(trimmed);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void showResultError(String message) {
        TextView tv = new DigitTextView(context);
        tv.setText(message);
        tv.setTextColor(Color.parseColor("#FFB4A0"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        resultContainer.addView(tv);
    }

    private void showEccentricityWarning() {
        TextView tv = new DigitTextView(context);
        tv.setText("Эксцентриситет должен быть числом от 0 до 0.99 — год выше показан без его учёта.");
        tv.setTextColor(Color.parseColor("#FFF29B3B"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        resultContainer.addView(spacer(dp(8)));
        resultContainer.addView(tv);
    }

    private void showYearResult(double periodSeconds,
                                boolean hasEccentricity,
                                double periapsisM,
                                double apoapsisM,
                                double periSpeedMs,
                                double apoSpeedMs) {
        LinearLayout box = resultBox();

        box.addView(resultSectionTitle("Результат"));
        box.addView(spacer(dp(8)));

        box.addView(resultLine(
                "Длительность года (период обращения)",
                formatPeriod(periodSeconds)
        ));

        box.addView(spacer(dp(6)));

        box.addView(resultLine(
                "В земных годах",
                String.format(Locale.US, "%.6f", periodSeconds / PhysicsEngine.TimeUnit.YEAR.seconds)
        ));

        resultContainer.addView(box);

        if (hasEccentricity) {
            resultContainer.addView(spacer(dp(12)));

            LinearLayout eccBox = resultBox();

            eccBox.addView(resultSectionTitle("С учётом эксцентриситета орбиты"));
            eccBox.addView(spacer(dp(8)));

            eccBox.addView(resultLine("Перигелий (мин. расстояние до тела)", formatDistance(periapsisM)));
            eccBox.addView(spacer(dp(6)));
            eccBox.addView(resultLine("Афелий (макс. расстояние до тела)", formatDistance(apoapsisM)));
            eccBox.addView(spacer(dp(6)));
            eccBox.addView(resultLine("Скорость в перигелии", PhysicsEngine.formatSpeed(periSpeedMs)));
            eccBox.addView(spacer(dp(6)));
            eccBox.addView(resultLine("Скорость в афелии", PhysicsEngine.formatSpeed(apoSpeedMs)));

            resultContainer.addView(eccBox);
        }
    }

    /** Читаемое представление периода: годы для длинных орбит, сутки/часы/секунды для коротких. */
    private String formatPeriod(double seconds) {
        double yearSeconds = PhysicsEngine.TimeUnit.YEAR.seconds;
        double daySeconds  = PhysicsEngine.TimeUnit.DAY.seconds;
        double hourSeconds = PhysicsEngine.TimeUnit.HOUR.seconds;

        if (seconds >= yearSeconds * 0.5) {
            return String.format(Locale.US, "%.4f лет (земных)", seconds / yearSeconds);
        }

        if (seconds >= daySeconds) {
            return String.format(Locale.US, "%.2f суток", seconds / daySeconds);
        }

        if (seconds >= hourSeconds) {
            return String.format(Locale.US, "%.2f ч.", seconds / hourSeconds);
        }

        return String.format(Locale.US, "%.1f с", seconds);
    }

    /** Читаемое представление расстояния: а.е. для больших дистанций, иначе км/м. */
    private String formatDistance(double meters) {
        double au = meters / 1.495978707e11;

        if (Math.abs(au) >= 0.01) {
            return String.format(Locale.US, "%.4f а.е.", au);
        }

        double km = meters / 1000.0;
        if (Math.abs(km) >= 1.0) {
            return String.format(Locale.US, "%.3e км", km);
        }

        return String.format(Locale.US, "%.3e м", meters);
    }

    // =========================================================
    //  Утилиты
    // =========================================================

    private LinearLayout resultBox() {
        LinearLayout box = new LinearLayout(context);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(createRoundedRect(
                dp(16),
                Color.parseColor("#6F6B67"),
                Color.parseColor("#CCFFFFFF"),
                dp(1.5f)
        ));

        int p = dp(14);
        box.setPadding(p, p, p, p);
        box.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        return box;
    }

    private TextView resultSectionTitle(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        return tv;
    }

    private View resultLine(String label, String value) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.VERTICAL);

        TextView labelView = new DigitTextView(context);
        labelView.setText(label);
        labelView.setTextColor(Color.parseColor("#BBFFFFFF"));
        labelView.setTypeface(typefaceRegular);
        labelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        row.addView(labelView);

        TextView valueView = new DigitTextView(context);
        valueView.setText(value);
        valueView.setTextColor(ACCENT_COLOR);
        valueView.setTypeface(typefaceSemiBold);
        valueView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        row.addView(valueView);

        return row;
    }

    private GradientDrawable createRoundedRect(float radius,
                                               int fillColor,
                                               int strokeColor,
                                               float strokeWidth) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(radius);
        gd.setColor(fillColor);
        gd.setStroke((int) strokeWidth, strokeColor);
        return gd;
    }

    private FrameLayout.LayoutParams matchParentFrameLp() {
        return new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        );
    }

    /** Короткий stack trace для показа в окне. */
    private static String stack(Throwable t) {
        try {
            java.io.StringWriter sw = new java.io.StringWriter();
            t.printStackTrace(new java.io.PrintWriter(sw));
            String s = sw.toString();
            return s.length() > 1500 ? s.substring(0, 1500) + "…" : s;
        } catch (Throwable ignore) {
            return String.valueOf(t);
        }
    }
}

