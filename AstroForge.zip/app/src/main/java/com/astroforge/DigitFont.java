package com.astroforge;

import android.content.Context;
import android.graphics.Typeface;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;

/**
 * Typography helper: only ASCII digits 0-9 use Quintessential.
 * All letters, punctuation, symbols and spaces keep the existing typeface.
 */
final class DigitFont {

    private static final String ASSET_PATH = "fonts/Quintessential-Regular.ttf";
    private static Typeface quintessential;

    private DigitFont() {
    }

    static CharSequence apply(Context context, CharSequence source) {
        if (source == null || source.length() == 0) {
            return source;
        }

        SpannableString out = new SpannableString(source);
        applyToSpannable(context, out);
        return out;
    }

    static void applyToSpannable(Context context, Spannable text) {
        if (text == null || text.length() == 0) {
            return;
        }

        Typeface face = getTypeface(context);

        DigitFontSpan[] oldFontSpans = text.getSpans(
                0,
                text.length(),
                DigitFontSpan.class
        );

        for (int i = 0; i < oldFontSpans.length; i++) {
            text.removeSpan(oldFontSpans[i]);
        }

        DigitSuperscriptSpan[] oldRaisedSpans = text.getSpans(
                0,
                text.length(),
                DigitSuperscriptSpan.class
        );

        for (int i = 0; i < oldRaisedSpans.length; i++) {
            text.removeSpan(oldRaisedSpans[i]);
        }

        int start = -1;

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            boolean digit = c >= '0' && c <= '9';

            if (digit) {
                if (start < 0) {
                    start = i;
                }
            } else if (start >= 0) {
                applyDigitRun(text, face, start, i);
                start = -1;
            }
        }

        if (start >= 0) {
            applyDigitRun(text, face, start, text.length());
        }
    }


    /**
     * Applies Quintessential to a digit run. If the second digit and the
     * following digits repeat the first one, all repeated digits are raised
     * by roughly half of the digit height while keeping the same font size.
     * Examples: 111 -> 1 with 11 raised; 2222 -> 2 with 222 raised.
     */
    private static void applyDigitRun(Spannable text, Typeface face, int start, int end) {
        text.setSpan(
                new DigitFontSpan(face),
                start,
                end,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        );

        int runLength = end - start;
        if (runLength < 2) {
            return;
        }

        char first = text.charAt(start);
        for (int i = start + 1; i < end; i++) {
            if (text.charAt(i) != first) {
                return;
            }
        }

        text.setSpan(
                new DigitSuperscriptSpan(),
                start + 1,
                end,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        );
    }

    private static synchronized Typeface getTypeface(Context context) {
        if (quintessential != null) {
            return quintessential;
        }

        try {
            quintessential = Typeface.createFromAsset(
                    context.getApplicationContext().getAssets(),
                    ASSET_PATH
            );
        } catch (Throwable ignored) {
            quintessential = Typeface.DEFAULT;
        }

        return quintessential;
    }
}
