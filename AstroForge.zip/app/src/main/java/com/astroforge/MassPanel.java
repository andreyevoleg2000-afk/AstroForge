package com.astroforge;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

/**
 * Всплывающее окно "Масса объекта".
 *
 * Стилистика полностью повторяет VelocityPanel ("Скорость объекта"): тот же
 * градиентный фон окна, размытая подложка, тёмно-серые поля ввода с обводкой
 * и выезжающим списком единиц измерения (пилюля справа в поле).
 *
 * Расчёт: объект считается однородным шаром. По радиусу и плотности находится
 * объём шара, а затем масса по формуле M = ρ · V.
 * Единицы плотности (кг/м³, г/см³) локальные для этого окна и не
 * зависят от PhysicsEngine — конвертация в кг/м³ делается прямо здесь.
 *
 * AIDE-safe: без лямбд, без androidx, diamond с явным типом, все захваченные
 * в анонимный класс локальные переменные — final.
 */
final class MassPanel {

    private static final int ACCENT_COLOR        = 0xFFD9946B;
    private static final int ACCENT_BORDER_COLOR = Color.parseColor("#CCD9946B");
    private static final int FIELD_BG_COLOR      = Color.parseColor("#F21C1C1E");
    private static final int FIELD_BORDER_COLOR  = Color.parseColor("#B3E3E3E3");
    private static final int PILL_BG_COLOR       = Color.BLACK;
    private static final int DROPDOWN_BG_COLOR   = Color.parseColor("#FF1C1C1E");

    private final Context context;
    private final FrameLayout rootContainer;
    private final Typeface typefaceRegular;
    private final Typeface typefaceSemiBold;

    private FrameLayout overlayRoot;
    private FrameLayout dropdownLayer;

    private EditText radiusInput;
    private UnitPillState radiusUnit;

    private EditText densityInput;
    private UnitPillState densityUnit;

    private LinearLayout resultContainer;

    private MassPanel(Context context,
					  FrameLayout rootContainer,
					  Typeface typefaceRegular,
					  Typeface typefaceSemiBold) {
        this.context = context;
        this.rootContainer = rootContainer;
        this.typefaceRegular = typefaceRegular;
        this.typefaceSemiBold = typefaceSemiBold;
    }

    static void show(Context context,
                     FrameLayout rootContainer,
                     Typeface typefaceRegular,
                     Typeface typefaceSemiBold) {
        if (context == null || rootContainer == null) {
            return;
        }

        new MassPanel(context, rootContainer, typefaceRegular, typefaceSemiBold).build();
    }

    private int dp(float value) {
        return (int) TypedValue.applyDimension(
			TypedValue.COMPLEX_UNIT_DIP,
			value,
			context.getResources().getDisplayMetrics()
        );
    }

    // =========================================================
    //  Построение окна
    // =========================================================

    private void build() {
        overlayRoot = new FrameLayout(context);
        overlayRoot.setBackgroundColor(Color.parseColor("#CC0F0F10"));
        overlayRoot.setClickable(true);
        overlayRoot.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					close();
				}
			});

        final FrameLayout windowFrame = new FrameLayout(context);
        windowFrame.setClickable(true);
        windowFrame.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					/* поглощаем клик */
				}
			});

        GradientDrawable frameBg = new GradientDrawable();
        frameBg.setShape(GradientDrawable.RECTANGLE);
        frameBg.setCornerRadius(dp(28));
        frameBg.setColor(0xF21E1E20);
        frameBg.setStroke(dp(2), ACCENT_COLOR);
        windowFrame.setBackground(frameBg);
        windowFrame.setClipToOutline(true);
        windowFrame.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);

        android.widget.ImageView blurBg = new android.widget.ImageView(context);
        blurBg.setImageResource(R.drawable.background);
        blurBg.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        blurBg.setRenderEffect(RenderEffect.createBlurEffect(dp(44), dp(44), Shader.TileMode.CLAMP));
        blurBg.setAlpha(0.88f);
        windowFrame.addView(blurBg, matchParentFrameLp());

        View tint = new View(context);
        tint.setBackgroundColor(Color.parseColor("#CC232326"));
        windowFrame.addView(tint, matchParentFrameLp());
        AstroUiEffects.applyPaperEffect(windowFrame, context);

        ScrollView scrollView = new ScrollView(context);
        scrollView.setClipToPadding(false);

        LinearLayout content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);

        int pad = dp(20);
        content.setPadding(pad, pad, pad, pad);

        content.addView(buildTitle());
        content.addView(spacer(dp(18)));

        content.addView(buildLabel("Радиус объекта"));
        content.addView(spacer(dp(6)));
        ValueUnitRow radiusRow = buildRadiusField();
        radiusInput = radiusRow.input;
        radiusUnit = radiusRow.unitState;
        content.addView(radiusRow.row);

        content.addView(spacer(dp(14)));

        content.addView(buildLabel("Плотность объекта"));
        content.addView(spacer(dp(6)));
        ValueUnitRow densityRow = buildDensityField();
        densityInput = densityRow.input;
        densityUnit  = densityRow.unitState;
        content.addView(densityRow.row);

        content.addView(spacer(dp(18)));
        content.addView(buildCalculateButton());
        content.addView(spacer(dp(16)));

        resultContainer = new LinearLayout(context);
        resultContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(resultContainer);

        content.addView(spacer(dp(16)));
        content.addView(buildExplanationBlock());
        content.addView(spacer(dp(20)));

        scrollView.addView(content, new ScrollView.LayoutParams(
							   ScrollView.LayoutParams.MATCH_PARENT,
							   ScrollView.LayoutParams.WRAP_CONTENT
						   ));

        windowFrame.addView(scrollView, matchParentFrameLp());

        FrameLayout.LayoutParams windowLp = new FrameLayout.LayoutParams(
			ViewGroup.LayoutParams.MATCH_PARENT,
			ViewGroup.LayoutParams.MATCH_PARENT
        );

        int screenMargin = dp(18);
        windowLp.setMargins(
			screenMargin,
			screenMargin + dp(30),
			screenMargin,
			screenMargin + dp(30)
        );

        overlayRoot.addView(windowFrame, windowLp);
        rootContainer.addView(overlayRoot, matchParentFrameLp());

        windowFrame.post(new Runnable() {
            @Override
            public void run() {
                if (overlayRoot != null && overlayRoot.getParent() == rootContainer && windowFrame != null) {
                    WindowOpenAnimation.start(windowFrame, context.getResources().getDisplayMetrics().density);
                }
            }
        });

        dropdownLayer = new FrameLayout(context);
        dropdownLayer.setClipChildren(false);
        dropdownLayer.setClipToPadding(false);
        dropdownLayer.setElevation(dp(1000));
        overlayRoot.addView(dropdownLayer, matchParentFrameLp());
        dropdownLayer.bringToFront();
    }

    private void close() {
        if (overlayRoot != null && overlayRoot.getParent() == rootContainer) {
            rootContainer.removeView(overlayRoot);
        }
    }

    // =========================================================
    //  Мелкие UI-хелперы
    // =========================================================

    private View buildTitle() {
        TextView tv = new DigitTextView(context);
        tv.setText("Масса объекта");
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        tv.setGravity(Gravity.START | Gravity.TOP);
        return tv;
    }

    private TextView buildLabel(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#DDE3E1DE"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        return tv;
    }

    private View spacer(int heightPx) {
        View v = new View(context);
        v.setLayoutParams(new LinearLayout.LayoutParams(
							  LinearLayout.LayoutParams.MATCH_PARENT,
							  heightPx
						  ));
        return v;
    }

    // =========================================================
    //  Единицы измерения радиуса и плотности
    // =========================================================

    private enum RadiusUnit {
        M("м", 1.0),
        KM("км", 1000.0);

        final String label;
        final double toMetersFactor;

        RadiusUnit(String label, double toMetersFactor) {
            this.label = label;
            this.toMetersFactor = toMetersFactor;
        }

        double toMeters(double value) {
            return value * toMetersFactor;
        }
    }

    private enum DensityUnit {
        KG_M3("кг/м³", 1.0),
        G_CM3("г/см³", 1000.0);

        final String label;
        final double toKgM3Factor;

        DensityUnit(String label, double toKgM3Factor) {
            this.label = label;
            this.toKgM3Factor = toKgM3Factor;
        }

        double toKgPerM3(double value) {
            return value * toKgM3Factor;
        }
    }

    // =========================================================
    //  Поля с единицами
    // =========================================================

    private static final class ValueUnitRow {
        View row;
        EditText input;
        UnitPillState unitState;
    }

    private static final class UnitPillState {
        TextView pillView;
        int selectedIndex = 0;
        String[] labels;
    }

    private ValueUnitRow buildRadiusField() {
        String[] labels = new String[RadiusUnit.values().length];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = RadiusUnit.values()[i].label;
        }
        return buildValueUnitRow(labels, "Введите радиус");
    }

    private ValueUnitRow buildDensityField() {
        DensityUnit[] units = DensityUnit.values();
        String[] labels = new String[units.length];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = units[i].label;
        }
        return buildValueUnitRow(labels, "Введите плотность");
    }

    private ValueUnitRow buildValueUnitRow(final String[] unitLabels, String hint) {
        FrameLayout field = new FrameLayout(context);
        field.setBackground(createRoundedRect(dp(16), FIELD_BG_COLOR, FIELD_BORDER_COLOR, dp(1.25f)));
        AstroUiEffects.applyControlShadow(field, context);
        field.setClipToOutline(true);

        final EditText input = new DigitEditText(context);
        input.setHint(hint);
        input.setHintTextColor(Color.parseColor("#77FFFFFF"));
        input.setTextColor(Color.WHITE);
        input.setTypeface(typefaceRegular);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        input.setSingleLine(true);
        input.setBackground(null);
        AstroUiEffects.applyControlShadow(input, context);
        input.setInputType(InputType.TYPE_CLASS_NUMBER
						   | InputType.TYPE_NUMBER_FLAG_DECIMAL
						   | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setPadding(dp(16), dp(12), dp(120), dp(12));
        field.addView(input, matchParentFrameLp());

        final UnitPillState state = new UnitPillState();
        state.labels = unitLabels;
        state.selectedIndex = 0;

        final TextView pill = new DigitTextView(context);
        pill.setText(unitLabels[0]);
        pill.setTextColor(Color.WHITE);
        pill.setTypeface(typefaceSemiBold);
        pill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        pill.setGravity(Gravity.CENTER);
        pill.setMaxLines(1);
        pill.setEllipsize(android.text.TextUtils.TruncateAt.END);
        pill.setBackground(createRoundedRect(dp(14), PILL_BG_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        pill.setPadding(dp(12), dp(8), dp(12), dp(8));
        pill.setClickable(true);
        pill.setFocusable(true);

        FrameLayout.LayoutParams pillLp = new FrameLayout.LayoutParams(
			dp(104),
			FrameLayout.LayoutParams.WRAP_CONTENT
        );
        pillLp.gravity = Gravity.CENTER_VERTICAL | Gravity.END;
        pillLp.rightMargin = dp(8);
        field.addView(pill, pillLp);
        pill.setTranslationZ(dp(3f));

        state.pillView = pill;

        pill.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					HapticUtils.perform(v);
					openDropdown(pill, unitLabels, state.selectedIndex, new OnUnitSelected() {
							@Override
							public void onSelected(int newIndex) {
								state.selectedIndex = newIndex;
								pill.setText(unitLabels[newIndex]);
							}
						});
				}
			});

        field.setLayoutParams(new LinearLayout.LayoutParams(
								  LinearLayout.LayoutParams.MATCH_PARENT,
								  dp(50)
							  ));

        ValueUnitRow row = new ValueUnitRow();
        row.row = field;
        row.input = input;
        row.unitState = state;
        return row;
    }

    // =========================================================
    //  Dropdown
    // =========================================================

    private interface OnUnitSelected {
        void onSelected(int index);
    }

    private void openDropdown(final View anchor,
                              final String[] labels,
                              int selectedIndex,
                              final OnUnitSelected callback) {
        dropdownLayer.removeAllViews();
        dropdownLayer.bringToFront();

        int[] anchorLoc = new int[2];
        anchor.getLocationOnScreen(anchorLoc);

        int[] rootLoc = new int[2];
        dropdownLayer.getLocationOnScreen(rootLoc);

        int relativeX = anchorLoc[0] - rootLoc[0];
        int relativeY = anchorLoc[1] - rootLoc[1];
        int anchorBottom = relativeY + anchor.getHeight();

        Rect visibleFrame = new Rect();
        rootContainer.getWindowVisibleDisplayFrame(visibleFrame);

        int visibleTop = visibleFrame.top - rootLoc[1];
        int visibleBottom = visibleFrame.bottom - rootLoc[1];

        View scrim = new View(context);
        scrim.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					dropdownLayer.removeAllViews();
				}
			});
        dropdownLayer.addView(scrim, matchParentFrameLp());

        LinearLayout list = new LinearLayout(context);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setBackground(createRoundedRect(dp(14), DROPDOWN_BG_COLOR, ACCENT_BORDER_COLOR, dp(1.25f)));
        list.setClipToOutline(true);
        list.setPadding(dp(6), dp(6), dp(6), dp(6));

        for (int i = 0; i < labels.length; i++) {
            final int idx = i;

            TextView item = new DigitTextView(context);
            item.setText(labels[i]);
            item.setTextColor(i == selectedIndex ? ACCENT_COLOR : Color.WHITE);
            item.setTypeface(i == selectedIndex ? typefaceSemiBold : typefaceRegular);
            AstroUiEffects.applyUnitTypeface(item, context);
            item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            item.setPadding(dp(14), dp(10), dp(14), dp(10));
            item.setClickable(true);
            item.setFocusable(true);

            item.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						HapticUtils.perform(v);
						callback.onSelected(idx);
						dropdownLayer.removeAllViews();
					}
				});

            list.addView(item, new LinearLayout.LayoutParams(
							 LinearLayout.LayoutParams.MATCH_PARENT,
							 LinearLayout.LayoutParams.WRAP_CONTENT
						 ));
        }

        int estimatedHeight = dp(12) + (labels.length * dp(40));
        int spaceBelow = visibleBottom - anchorBottom - dp(8);
        int spaceAbove = relativeY - visibleTop - dp(8);

        if (spaceBelow < 0) spaceBelow = 0;
        if (spaceAbove < 0) spaceAbove = 0;

        boolean showAbove = spaceBelow < estimatedHeight && spaceAbove > spaceBelow;

        final int maxHeight = Math.max(
			0,
			Math.min(estimatedHeight, showAbove ? spaceAbove : spaceBelow)
        );

        ScrollView listScroll = new ScrollView(context) {
            @Override
            protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                int hSpec = heightMeasureSpec;

                if (maxHeight > 0) {
                    int mode = View.MeasureSpec.getMode(hSpec);
                    int size = View.MeasureSpec.getSize(hSpec);

                    if (mode == View.MeasureSpec.UNSPECIFIED || size > maxHeight) {
                        hSpec = View.MeasureSpec.makeMeasureSpec(maxHeight, View.MeasureSpec.AT_MOST);
                    }
                }

                super.onMeasure(widthMeasureSpec, hSpec);
            }
        };

        listScroll.addView(list, new ScrollView.LayoutParams(
							   ScrollView.LayoutParams.MATCH_PARENT,
							   ScrollView.LayoutParams.WRAP_CONTENT
						   ));

        listScroll.setBackground(list.getBackground());
        list.setBackground(null);
        listScroll.setVerticalScrollBarEnabled(false);
        listScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        FrameLayout.LayoutParams listLp = new FrameLayout.LayoutParams(
			dp(180),
			FrameLayout.LayoutParams.WRAP_CONTENT
        );

        listLp.leftMargin = Math.max(dp(8), relativeX + anchor.getWidth() - dp(180));

        if (showAbove) {
            listLp.topMargin = Math.max(visibleTop + dp(8), relativeY - maxHeight - dp(4));
        } else {
            listLp.topMargin = anchorBottom + dp(4);
        }

        dropdownLayer.addView(listScroll, listLp);
        listScroll.bringToFront();
    }

    // =========================================================
    //  Кнопка расчёта и результат
    // =========================================================

    private View buildCalculateButton() {
        TextView btn = new DigitTextView(context);
        btn.setText("Рассчитать");
        btn.setTextColor(Color.WHITE);
        btn.setTypeface(typefaceSemiBold);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(0, dp(14), 0, dp(14));
        btn.setBackground(createRoundedRect(dp(18), ACCENT_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        AstroUiEffects.applyControlShadow(btn, context);
        btn.setClickable(true);
        btn.setFocusable(true);
        btn.setLayoutParams(new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT,
								LinearLayout.LayoutParams.WRAP_CONTENT
							));

        btn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					HapticUtils.perform(v);
					onCalculatePressed();
				}
			});

        return btn;
    }

    /** Обёрнуто в try/catch(Throwable): любая ошибка больше не роняет приложение. */
    private void onCalculatePressed() {
        try {
            resultContainer.removeAllViews();

            Double radiusValue  = parseDouble(radiusInput.getText().toString());
            Double densityValue = parseDouble(densityInput.getText().toString());

            if (radiusValue == null || densityValue == null
				|| radiusValue <= 0 || densityValue <= 0) {
                showResultError("Введите корректные радиус и плотность (положительные числа).");
                return;
            }

            double radiusM =
				RadiusUnit.values()[radiusUnit.selectedIndex].toMeters(radiusValue);

            double densityKgM3 =
				DensityUnit.values()[densityUnit.selectedIndex].toKgPerM3(densityValue);

            double volumeM3 = (4.0 / 3.0) * Math.PI * radiusM * radiusM * radiusM;
            double massKg   = densityKgM3 * volumeM3;

            showSimpleResult(massKg);
        } catch (Throwable t) {
            resultContainer.removeAllViews();
            showResultError("Ошибка при расчёте:\n" + stack(t));
        }
    }

    private Double parseDouble(String text) {
        if (text == null) return null;

        String trimmed = text.trim().replace(',', '.');
        if (trimmed.isEmpty()) return null;

        try {
            return Double.parseDouble(trimmed);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void showResultError(String message) {
        TextView tv = new DigitTextView(context);
        tv.setText(message);
        tv.setTextColor(Color.parseColor("#FFB4A0"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        resultContainer.addView(tv);
    }

    private void showSimpleResult(double massKg) {
        LinearLayout box = resultBox();

        box.addView(resultSectionTitle("Результат"));
        box.addView(spacer(dp(8)));

        box.addView(resultLine("Масса объекта", formatMass(massKg)));

        resultContainer.addView(box);
    }

    private View buildExplanationBlock() {
        LinearLayout block = new LinearLayout(context);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setPadding(0, 0, 0, 0);
        block.setBackgroundColor(Color.TRANSPARENT);

        TextView title = new DigitTextView(context);
        title.setText("Как считается масса");
        title.setTextColor(Color.parseColor("#F2FFFFFF"));
        title.setTypeface(typefaceSemiBold);

        AstroUiEffects.applyExplanationTypeface(title, context);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        block.addView(title);

        block.addView(spacer(dp(10)));

        block.addView(explanationLine("1) Переводим радиус в метры:", "r_м = r × k_r"));
        block.addView(spacer(dp(6)));

        block.addView(explanationLine("2) Переводим плотность в кг/м³:", "ρ_кг/м³ = ρ × k_ρ"));
        block.addView(spacer(dp(6)));

        block.addView(explanationLine("3) Находим объём шара:", "V = 4/3 · π · r³"));
        block.addView(spacer(dp(2)));

        TextView formula2 = new DigitTextView(context);
        formula2.setText("M = ρ · V");
        formula2.setTextColor(Color.parseColor("#FFD9946B"));
        formula2.setTypeface(typefaceSemiBold);

        AstroUiEffects.applyExplanationTypeface(formula2, context);
        formula2.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        block.addView(formula2);

        block.addView(spacer(dp(6)));

        block.addView(explanationLine("4) Получаем массу объекта:", "M = ρ × 4/3 · π · r³"));
        block.addView(spacer(dp(8)));

        TextView note = new DigitTextView(context);
        note.setText("Здесь объект считается однородным шаром. Сначала берётся объём, потом он умножается на плотность. Как обычно, физика не спрашивает, удобно тебе или нет.");
        note.setTextColor(Color.parseColor("#B8E3E1DE"));
        note.setTypeface(typefaceRegular);
        AstroUiEffects.applyExplanationTypeface(note, context);
        note.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        note.setLineSpacing(0f, 1.15f);
        block.addView(note);

        return block;
    }

    private View explanationLine(String label, String formula) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.VERTICAL);

        TextView labelView = new DigitTextView(context);
        labelView.setText(label);
        labelView.setTextColor(Color.parseColor("#DCE3E1DE"));
        labelView.setTypeface(typefaceRegular);
        AstroUiEffects.applyExplanationTypeface(labelView, context);
        labelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        labelView.setLineSpacing(0f, 1.08f);
        row.addView(labelView);

        TextView formulaView = new DigitTextView(context);
        formulaView.setText(formula);
        formulaView.setTextColor(Color.WHITE);
        formulaView.setTypeface(typefaceSemiBold);
        AstroUiEffects.applyExplanationTypeface(formulaView, context);
        formulaView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        formulaView.setLineSpacing(0f, 1.08f);
        row.addView(formulaView);

        return row;
    }

    /** Простое форматирование длины: метры для мелких значений, километры для крупных. */
    private String formatLength(double meters) {
        double km = meters / 1000.0;

        if (Math.abs(km) >= 1.0) {
            if (Math.abs(km) >= 1000000.0) {
                return String.format(Locale.US, "%.4e км", km);
            }
            return String.format(Locale.US, "%,.2f км", km).replace(',', ' ');
        }

        return String.format(Locale.US, "%.2f м", meters);
    }

    /** Простое форматирование массы: кг для обычных значений, научная запись для огромных. */
    private String formatMass(double kilograms) {
        if (Math.abs(kilograms) >= 1000000000.0 || Math.abs(kilograms) < 0.001) {
            return String.format(Locale.US, "%.4e кг", kilograms);
        }

        return String.format(Locale.US, "%,.2f кг", kilograms).replace(',', ' ');
    }

    private String stack(Throwable t) {
        StringBuilder sb = new StringBuilder();
        sb.append(t.toString());
        StackTraceElement[] trace = t.getStackTrace();
        int limit = Math.min(trace.length, 4);
        for (int i = 0; i < limit; i++) {
            sb.append("\n  at ").append(trace[i]);
        }
        return sb.toString();
    }

    // =========================================================
    //  Утилиты
    // =========================================================

    private LinearLayout resultBox() {
        LinearLayout box = new LinearLayout(context);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(createRoundedRect(
							  dp(16),
							  Color.parseColor("#6F6B67"),
							  Color.parseColor("#CCFFFFFF"),
							  dp(1.5f)
						  ));

        int p = dp(14);
        box.setPadding(p, p, p, p);
        box.setLayoutParams(new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT,
								LinearLayout.LayoutParams.WRAP_CONTENT
							));

        return box;
    }

    private TextView resultSectionTitle(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        return tv;
    }

    private View resultLine(String label, String value) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.VERTICAL);

        TextView labelView = new DigitTextView(context);
        labelView.setText(label);
        labelView.setTextColor(Color.parseColor("#BBFFFFFF"));
        labelView.setTypeface(typefaceRegular);
        labelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        row.addView(labelView);

        TextView valueView = new DigitTextView(context);
        valueView.setText(value);
        valueView.setTextColor(ACCENT_COLOR);
        valueView.setTypeface(typefaceSemiBold);
        valueView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        row.addView(valueView);

        return row;
    }

    private GradientDrawable createRoundedRect(float radius,
                                               int fillColor,
                                               int strokeColor,
                                               float strokeWidth) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(radius);
        gd.setColor(fillColor);
        gd.setStroke((int) strokeWidth, strokeColor);
        return gd;
    }

    private FrameLayout.LayoutParams matchParentFrameLp() {
        return new FrameLayout.LayoutParams(
			FrameLayout.LayoutParams.MATCH_PARENT,
			FrameLayout.LayoutParams.MATCH_PARENT
        );
    }
}






