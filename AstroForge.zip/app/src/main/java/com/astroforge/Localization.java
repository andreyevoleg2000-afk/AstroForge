package com.astroforge;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.HashMap;
import java.util.Map;

/**
 * AstroForge application localization.
 *
 * Russian is the source language and is intentionally kept unchanged.
 * Uzbek and English translations are applied to every visible TextView/EditText
 * whose original Russian text is present in the catalog. The view-tree pass also
 * handles text that appears later during calculations or animations.
 */
public final class Localization {
    public static final String LANG_RU = "ru";
    public static final String LANG_UZ = "uz";
    public static final String LANG_EN = "en";

    private static String language = LANG_RU;
    private static final Map<String, String[]> MAP = new HashMap<>();
    private static final Map<String, String> SOURCE_BY_TRANSLATION = new HashMap<>();

    static {
        add("Режим ИИ", "Sun'iy intellekt rejimi", "AI Mode");
        add("Космические заметки", "Kosmik qaydlar", "Cosmic Notes");
        add("Калькулятор", "Kalkulyator", "Calculator");
        add("Генератор планет", "Sayyoralar generatori", "Planet Generator");
        add("Настройки", "Sozlamalar", "Settings");

        add("Тема", "Mavzu", "Theme");
        add("Язык", "Til", "Language");
        add("Вычисления", "Hisob-kitoblar", "Calculations");
        add("Тактильный отклик", "Tegishli haptik javob", "Haptic Feedback");
        add("Другие наши приложения", "Boshqa ilovalarimiz", "Our Other Apps");
        add("О приложении", "Ilova haqida", "About the App");
        add("Добавить виджет лунных фаз", "Oy fazalari vidjetini qo‘shish", "Add Moon Phases Widget");
        add("Справочник", "Ma’lumotnoma", "Reference");
        add("OMEGA Intellectual", "OMEGA Intellectual", "OMEGA Intellectual");

        add("Скорость объекта", "Obyekt tezligi", "Object Velocity");
        add("Год на объекте", "Obyektdagi yil", "Year on Object");
        add("Зона обитаемости", "Yashashga yaroqli zona", "Habitable Zone");
        add("Масса", "Massa", "Mass");
        add("Радиус", "Radius", "Radius");
        add("Плотность", "Zichlik", "Density");
        add("Расчет гравитации", "Gravitatsiyani hisoblash", "Gravity Calculation");
        add("Стабильность гравитации", "Gravitatsiya barqarorligi", "Gravity Stability");
        add("Магнитное поле", "Magnit maydoni", "Magnetic Field");
        add("ESI анализ", "ESI tahlili", "ESI Analysis");
        add("Астробиологический анализ", "Astrobiologik tahlil", "Astrobiological Analysis");
        add("Предел Роша", "Roche chegarasi", "Roche Limit");
        add("Расчет атмосферы", "Atmosferani hisoblash", "Atmosphere Calculation");
        add("3D визуализатор", "3D vizualizator", "3D Visualizer");
        add("Идеальная круговая орбита", "Ideal aylana orbitasi", "Ideal Circular Orbit");

        add("Рассчитать", "Hisoblash", "Calculate");
        add("Результат", "Natija", "Result");
        add("Назад", "Orqaga", "Back");
        add("Закрыть", "Yopish", "Close");
        add("Добавить тело", "Jism qo‘shish", "Add Body");
        add("Экспериментальная функция", "Eksperimental funksiya", "Experimental Feature");
        add("Пожалуйста, подождите", "Iltimos, kuting", "Please wait");
        add("Ошибка расчёта", "Hisoblash xatosi", "Calculation Error");
        add("Ошибка ввода", "Kiritish xatosi", "Input Error");
        add("Неизвестная ошибка", "Noma’lum xato", "Unknown error");
        add("Как считается скорость", "Tezlik qanday hisoblanadi", "How Velocity Is Calculated");
        add("Как считается зона обитаемости", "Yashashga yaroqli zona qanday hisoblanadi", "How the Habitable Zone Is Calculated");
        add("Как считается магнитное поле", "Magnit maydoni qanday hisoblanadi", "How the Magnetic Field Is Calculated");
        add("Хронология изменения скоростей", "Tezlik o‘zgarishlari xronologiyasi", "Velocity Change Timeline");
        add("Выборка точек:", "Nuqtalar tanlovi:", "Sampled Points:");
        add("Средняя скорость по эпохам:", "Davrlar bo‘yicha o‘rtacha tezlik:", "Average Velocity by Epochs:");
        add("Точность орбит", "Orbital aniqlik", "Orbital Accuracy");
        add("Расчёт выполняется…", "Hisoblash bajarilmoqda…", "Calculation in progress…");
        add("Симуляция выполняется…", "Simulyatsiya bajarilmoqda…", "Simulation in progress…");

        add("Масса родительского тела", "Markaziy jism massasi", "Parent Body Mass");
        add("Расстояние до родительского тела", "Markaziy jismgacha masofa", "Distance to Parent Body");
        add("Масса второго тела (необязательно, для парного вращения)", "Ikkinchi jism massasi (ixtiyoriy, juft aylanish uchun)", "Second Body Mass (optional, for paired rotation)");
        add("Название родительского тела", "Markaziy jism nomi", "Parent Body Name");
        add("Название орбитального тела", "Orbital jism nomi", "Orbital Body Name");
        add("Масса объекта", "Obyekt massasi", "Object Mass");
        add("Радиус объекта", "Obyekt radiusi", "Object Radius");
        add("Радиус ядра / динамо-области", "Yadro / dinamo sohasi radiusi", "Core / Dynamo Region Radius");
        add("Радиус ядра", "Yadro radiusi", "Core Radius");
        add("Плотность проводящей среды", "O‘tkazuvchi muhit zichligi", "Conducting Medium Density");
        add("Конвективный тепловой поток", "Konvektiv issiqlik oqimi", "Convective Heat Flux");
        add("Период вращения (необязательно)", "Aylanish davri (ixtiyoriy)", "Rotation Period (optional)");
        add("Доля дипольности, 0..1", "Dipollik ulushi, 0..1", "Dipole Fraction, 0..1");
        add("Калибровочный коэффициент", "Kalibrlash koeffitsiyenti", "Calibration Factor");
        add("Режим расчёта", "Hisoblash rejimi", "Calculation Mode");
        add("Параметры объекта", "Obyekt parametrlari", "Object Parameters");
        add("Параметры симуляции", "Simulyatsiya parametrlari", "Simulation Parameters");
        add("Длительность симуляции", "Simulyatsiya davomiyligi", "Simulation Duration");
        add("Количество точек", "Nuqtalar soni", "Number of Points");
        add("Seed генератора событий", "Hodisalar generatori seed qiymati", "Event Generator Seed");
        add("Минимальный тепловой поток", "Minimal issiqlik oqimi", "Minimum Heat Flux");
        add("Время охлаждения", "Sovish vaqti", "Cooling Time");
        add("Частота событий в год", "Yiliga hodisalar chastotasi", "Events per Year");
        add("Минимальное время ожидания событий", "Hodisalar orasidagi minimal kutish vaqti", "Minimum Event Waiting Time");
        add("Максимальное время ожидания событий", "Hodisalar orasidagi maksimal kutish vaqti", "Maximum Event Waiting Time");

        add("Введите массу", "Massani kiriting", "Enter mass");
        add("Введите расстояние", "Masofani kiriting", "Enter distance");
        add("Введите радиус", "Radiusni kiriting", "Enter radius");
        add("Введите радиус ядра", "Yadro radiusini kiriting", "Enter core radius");
        add("Введите плотность", "Zichlikni kiriting", "Enter density");
        add("Введите тепловой поток", "Issiqlik oqimini kiriting", "Enter heat flux");
        add("Необязательно", "Ixtiyoriy", "Optional");
        add("До родителя", "Markaziy jismgacha", "To Parent");
        add("Промежуток времени", "Vaqt oralig‘i", "Time Interval");
        add("Название тела", "Jism nomi", "Body Name");
        add("Дополнительные тела", "Qo‘shimcha jismlar", "Additional Bodies");

        add("Например, Земля", "Masalan, Yer", "e.g. Earth");
        add("Например, спутник", "Masalan, yo‘ldosh", "e.g. Satellite");
        add("Например, 24", "Masalan, 24", "e.g. 24");
        add("Например, 1.0", "Masalan, 1.0", "e.g. 1.0");
        add("Например, 0.0167", "Masalan, 0.0167", "e.g. 0.0167");
        add("Например, 5778", "Masalan, 5778", "e.g. 5778");
        add("Например, 1000000", "Masalan, 1000000", "e.g. 1000000");
        add("По умолчанию 1.0", "Standart qiymat: 1.0", "Default: 1.0");
        add("По умолчанию 200", "Standart qiymat: 200", "Default: 200");
        add("По умолчанию 42", "Standart qiymat: 42", "Default: 42");
        add("По умолчанию 0", "Standart qiymat: 0", "Default: 0");
        add("По умолчанию годы / 10", "Standart: yillar / 10", "Default: years / 10");
        add("По умолчанию 1e-6", "Standart qiymat: 1e-6", "Default: 1e-6");
        add("По умолчанию 1.2", "Standart qiymat: 1.2", "Default: 1.2");
        add("По умолчанию 1 год", "Standart: 1 yil", "Default: 1 year");
        add("По умолчанию по длительности", "Standart: davomiylikka teng", "Default: duration");

        add("Расширенный расчёт (n-body)", "Kengaytirilgan hisoblash (n-body)", "Advanced Calculation (n-body)");
        add("Скрыть расширенный расчёт", "Kengaytirilgan hisoblashni yashirish", "Hide Advanced Calculation");
        add("Режим: симуляция по годам", "Rejim: yillar bo‘yicha simulyatsiya", "Mode: year-by-year simulation");
        add("Режим: быстрый расчёт", "Rejim: tezkor hisoblash", "Mode: fast calculation");
        add("События инверсий: вкл", "Inversiya hodisalari: yoqilgan", "Inversion Events: On");
        add("События инверсий: выкл", "Inversiya hodisalari: o‘chirilgan", "Inversion Events: Off");

        add("Первая космическая скорость (круговая орбита)", "Birinchi kosmik tezlik (aylana orbitasi)", "First Cosmic Velocity (circular orbit)");
        add("Вторая космическая скорость (скорость убегания)", "Ikkinchi kosmik tezlik (qochish tezligi)", "Second Cosmic Velocity (escape velocity)");
        add("Светимость звезды", "Yulduz yorqinligi", "Stellar Luminosity");
        add("Консервативная зона обитаемости", "Konservativ yashashga yaroqli zona", "Conservative Habitable Zone");
        add("Оптимистичная зона обитаемости", "Optimistik yashashga yaroqli zona", "Optimistic Habitable Zone");
        add("Диаметр звезды", "Yulduz diametri", "Star Diameter");
        add("Радиус звезды", "Yulduz radiusi", "Star Radius");
        add("Класс звезды (O, B, A, F, G, K, M, L, T)", "Yulduz sinfi (O, B, A, F, G, K, M, L, T)", "Star Class (O, B, A, F, G, K, M, L, T)");
        add("Большая полуось орбиты планеты (а.е.)", "Sayyora orbitasining katta yarim o‘qi (a.b.)", "Planet Orbit Semi-major Axis (AU)");
        add("Эксцентриситет орбиты планеты (0 ≤ e < 1)", "Sayyora orbitasi ekssentrisiteti (0 ≤ e < 1)", "Planet Orbit Eccentricity (0 ≤ e < 1)");

        add("Справочник", "Ma’lumotnoma", "Reference");
        add("Величина", "Kattalik", "Quantity");
        add("Обозначение", "Belgisi", "Symbol");
        add("Значение", "Qiymati", "Value");
        add("Граница", "Chegara", "Boundary");
        add("Смысл", "Ma’nosi", "Meaning");
        add("Параметр", "Parametr", "Parameter");
        add("Эталон", "Etalon", "Reference");
        add("Вес w", "Vazn w", "Weight w");
        add("Класс", "Sinf", "Class");
        add("Пример", "Misol", "Example");
        add("Модуль", "Modul", "Module");
        add("Базовая модель", "Asosiy model", "Base Model");
        add("Что выводить пользователю", "Foydalanuvchiga nima ko‘rsatiladi", "What to show to the user");

        // Common diagnostics and notifications
        add("Ваш лаунчер не поддерживает добавление виджетов из приложения.",
            "Launcher ilova ichidan vidjet qo‘shishni qo‘llab-quvvatlamaydi.",
            "Your launcher does not support adding widgets from the app.");
        add("Не удалось открыть добавление виджета.",
            "Vidjet qo‘shish oynasini ochib bo‘lmadi.",
            "Could not open widget setup.");
        add("Не удалось выполнить расчёт.", "Hisoblashni bajarib bo‘lmadi.", "Could not perform the calculation.");
        add("Не удалось открыть справочник", "Ma’lumotnomani ochib bo‘lmadi", "Could not open the reference.");
    }

    private Localization() {}

    private static void add(String ru, String uz, String en) {
        MAP.put(ru, new String[]{ru, uz, en});
        if (uz != null && !uz.equals(ru)) SOURCE_BY_TRANSLATION.putIfAbsent(uz, ru);
        if (en != null && !en.equals(ru)) SOURCE_BY_TRANSLATION.putIfAbsent(en, ru);
    }

    public static void setLanguage(String value) {
        if (LANG_UZ.equals(value) || LANG_EN.equals(value)) {
            language = value;
        } else {
            language = LANG_RU;
        }
    }

    public static String getLanguage() {
        return language;
    }

    public static String t(String value) {
        if (value == null) return null;
        String source = MAP.containsKey(value) ? value : SOURCE_BY_TRANSLATION.get(value);
        if (source == null) return value; // non-catalog text stays untouched
        String[] values = MAP.get(source);
        if (values == null) return value;
        if (LANG_RU.equals(language)) return values[0];
        return LANG_UZ.equals(language) ? values[1] : values[2];
    }

    public static void applyToViewTree(View root) {
        if (root == null || LANG_RU.equals(language)) return;
        apply(root);
    }

    private static void apply(View view) {
        if (view instanceof TextView) {
            TextView tv = (TextView) view;
            CharSequence text = tv.getText();
            if (text != null) {
                String value = text.toString();
                String translated = t(value);
                if (!value.equals(translated)) tv.setText(translated);
            }
            CharSequence hint = tv.getHint();
            if (hint != null) {
                String value = hint.toString();
                String translated = t(value);
                if (!value.equals(translated)) tv.setHint(translated);
            }
            CharSequence desc = tv.getContentDescription();
            if (desc != null) {
                String value = desc.toString();
                String translated = t(value);
                if (!value.equals(translated)) tv.setContentDescription(translated);
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                apply(group.getChildAt(i));
            }
        }
    }
}
