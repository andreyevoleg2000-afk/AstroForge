package com.astroforge;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

/**
 * ESI (Earth Similarity Index) — индекс схожести с Землёй.
 * Сравниваем радиус, плотность, температуру поверхности и массу
 * с земными значениями и считаем классический ESI.
 *
 * Макет, градиент, поля, дропдауны и анимации — 1:1 как в VelocityPanel.
 */
final class EsiPanel {

    private static final int ACCENT_COLOR        = 0xFFD9946B;
    private static final int ACCENT_BORDER_COLOR = Color.parseColor("#CCD9946B");
    private static final int FIELD_BG_COLOR      = Color.parseColor("#F21C1C1E");
    private static final int FIELD_BORDER_COLOR  = Color.parseColor("#B3E3E3E3");
    private static final int PILL_BG_COLOR       = Color.BLACK;
    private static final int DROPDOWN_BG_COLOR   = Color.parseColor("#FF1C1C1E");

    // Земные константы (SI)
    private static final double EARTH_RADIUS_M   = 6.371e6;
    private static final double EARTH_MASS_KG    = 5.972e24;
    private static final double EARTH_DENSITY    = 5514.0;          // кг/м³
    private static final double EARTH_TEMP_K     = 288.0;           // средняя поверхностная
    private static final double EARTH_ESCAPE_MS  = 11186.0;

    private final Context context;
    private final FrameLayout rootContainer;
    private final Typeface typefaceRegular;
    private final Typeface typefaceSemiBold;

    private FrameLayout overlayRoot;
    private FrameLayout windowFrame;
    private FrameLayout dropdownLayer;

    private PixelFillOverlay pixelFillOverlay;
    private ValueAnimator openAnimator;
    private ValueAnimator closeAnimator;
    private boolean isClosing = false;

    private static final int CLOSE_DIRECTION_CENTER = 0;
    private static final int CLOSE_DIRECTION_LEFT   = -1;
    private static final int CLOSE_DIRECTION_RIGHT  = 1;

    private boolean swipeClosing = false;
    private boolean swipeFromLeftEdge = false;
    private float swipeStartX = 0f;
    private float swipeStartY = 0f;
    private float swipeLastDx = 0f;
    private float swipeLastDy = 0f;

    private static final long OPEN_ANIM_DURATION_MS  = 360L;
    private static final long CLOSE_ANIM_DURATION_MS = 220L;

    // --- поля ---
    private EditText massInput;
    private UnitPillState massUnit;

    private EditText radiusInput;
    private UnitPillState radiusUnit;

    private EditText densityInput;
    private UnitPillState densityUnit;

    private EditText tempInput;
    private UnitPillState tempUnit;

    private EditText starClassInput;          // просто текст + пилюля со списком
    private UnitPillState starClassState;

    private LinearLayout resultContainer;

    private EsiPanel(Context context,
                     FrameLayout rootContainer,
                     Typeface typefaceRegular,
                     Typeface typefaceSemiBold) {
        this.context = context;
        this.rootContainer = rootContainer;
        this.typefaceRegular = typefaceRegular;
        this.typefaceSemiBold = typefaceSemiBold;
    }

    static void show(Context context,
                     FrameLayout rootContainer,
                     Typeface typefaceRegular,
                     Typeface typefaceSemiBold) {
        new EsiPanel(context, rootContainer, typefaceRegular, typefaceSemiBold).build();
    }

    private int dp(float value) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            context.getResources().getDisplayMetrics()
        );
    }

    // =========================================================
    //  Построение окна (копия стиля VelocityPanel)
    // =========================================================

    private void build() {
        overlayRoot = new FrameLayout(context);
        overlayRoot.setBackgroundColor(Color.parseColor("#CC0F0F10"));
        overlayRoot.setClickable(true);
        overlayRoot.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) { close(); }
			});

        windowFrame = new FrameLayout(context);
        windowFrame.setClickable(true);
        windowFrame.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) { /* absorb */ }
			});

        overlayRoot.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					return handleEdgeSwipe(event);
				}
			});

        GradientDrawable frameBg = new GradientDrawable();
        frameBg.setShape(GradientDrawable.RECTANGLE);
        frameBg.setCornerRadius(dp(28));
        frameBg.setColor(0xF21E1E20);
        frameBg.setStroke(dp(2), ACCENT_COLOR);
        windowFrame.setBackground(frameBg);
        windowFrame.setClipToOutline(true);
        windowFrame.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);

        android.widget.ImageView blurBg = new android.widget.ImageView(context);
        blurBg.setImageResource(R.drawable.background);
        blurBg.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        blurBg.setRenderEffect(RenderEffect.createBlurEffect(dp(44), dp(44), Shader.TileMode.CLAMP));
        blurBg.setAlpha(0.88f);
        windowFrame.addView(blurBg, matchParentFrameLp());

        View tint = new View(context);
        tint.setBackgroundColor(Color.parseColor("#CC232326"));
        windowFrame.addView(tint, matchParentFrameLp());
        AstroUiEffects.applyPaperEffect(windowFrame, context);

        ScrollView scrollView = new ScrollView(context);
        scrollView.setClipToPadding(false);

        LinearLayout content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        content.setPadding(pad, pad, pad, pad);

        content.addView(buildTitle());
        content.addView(spacer(dp(18)));

        // Масса
        content.addView(buildLabel("Масса планеты"));
        content.addView(spacer(dp(6)));
        ValueUnitRow massRow = buildMassField();
        massInput = massRow.input;
        massUnit  = massRow.unitState;
        content.addView(massRow.row);

        content.addView(spacer(dp(14)));

        // Радиус
        content.addView(buildLabel("Радиус планеты"));
        content.addView(spacer(dp(6)));
        ValueUnitRow radiusRow = buildRadiusField();
        radiusInput = radiusRow.input;
        radiusUnit  = radiusRow.unitState;
        content.addView(radiusRow.row);

        content.addView(spacer(dp(14)));

        // Плотность (авто-коррекция)
        content.addView(buildLabel("Плотность (при несоответствии массе/радиусу заменяется автоматически)"));
        content.addView(spacer(dp(6)));
        ValueUnitRow densityRow = buildDensityField();
        densityInput = densityRow.input;
        densityUnit  = densityRow.unitState;
        content.addView(densityRow.row);

        content.addView(spacer(dp(14)));

        // Температура
        content.addView(buildLabel("Средняя температура поверхности"));
        content.addView(spacer(dp(6)));
        ValueUnitRow tempRow = buildTempField();
        tempInput = tempRow.input;
        tempUnit  = tempRow.unitState;
        content.addView(tempRow.row);

        content.addView(spacer(dp(14)));

        // Класс звезды
        content.addView(buildLabel("Спектральный класс родительской звезды"));
        content.addView(spacer(dp(6)));
        ValueUnitRow starRow = buildStarClassField();
        starClassInput = starRow.input;
        starClassState = starRow.unitState;
        content.addView(starRow.row);

        content.addView(spacer(dp(22)));
        content.addView(buildCalculateButton());
        content.addView(spacer(dp(16)));
        content.addView(buildExplanationBlock());
        content.addView(spacer(dp(12)));

        resultContainer = new LinearLayout(context);
        resultContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(resultContainer);

        content.addView(spacer(dp(20)));

        scrollView.addView(content, new ScrollView.LayoutParams(
							   ScrollView.LayoutParams.MATCH_PARENT,
							   ScrollView.LayoutParams.WRAP_CONTENT
						   ));

        windowFrame.addView(scrollView, matchParentFrameLp());
        attachPixelFillOverlay();

        FrameLayout.LayoutParams windowLp = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        );
        int screenMargin = dp(18);
        windowLp.setMargins(screenMargin, screenMargin + dp(30), screenMargin, screenMargin + dp(30));

        overlayRoot.addView(windowFrame, windowLp);
        rootContainer.addView(overlayRoot, matchParentFrameLp());

        windowFrame.post(new Runnable() {
				@Override public void run() {
					if (overlayRoot != null && overlayRoot.getParent() == rootContainer) {
						startOpenAnimation();
					}
				}
			});

        dropdownLayer = new FrameLayout(context);
        dropdownLayer.setClipChildren(false);
        dropdownLayer.setClipToPadding(false);
        dropdownLayer.setElevation(dp(1000));
        overlayRoot.addView(dropdownLayer, matchParentFrameLp());
        dropdownLayer.bringToFront();
    }

    private void close() {
        beginClose(CLOSE_DIRECTION_CENTER);
    }

    private void beginClose(int direction) {
        if (isClosing) return;
        if (overlayRoot == null || overlayRoot.getParent() != rootContainer) return;
        isClosing = true;
        swipeClosing = false;
        startCloseAnimation(direction);
    }

    // ---------- анимации открытия/закрытия (копия VelocityPanel) ----------

    private void startOpenAnimation() {
        if (windowFrame == null) return;
        if (openAnimator != null) { openAnimator.cancel(); openAnimator = null; }
        if (closeAnimator != null) { closeAnimator.cancel(); closeAnimator = null; }

        swipeClosing = false;
        swipeFromLeftEdge = false;

        windowFrame.setPivotX(windowFrame.getWidth() * 0.5f);
        windowFrame.setPivotY(windowFrame.getHeight() * 0.5f);
        windowFrame.setScaleX(0.965f);
        windowFrame.setScaleY(0.965f);
        windowFrame.setTranslationX(0f);
        windowFrame.setTranslationY(dp(10));

        if (pixelFillOverlay != null) {
            pixelFillOverlay.setVisibility(View.VISIBLE);
            pixelFillOverlay.setProgress(0f);
            pixelFillOverlay.setAlpha(1f);
        }

        openAnimator = ValueAnimator.ofFloat(0f, 1f);
        openAnimator.setDuration(OPEN_ANIM_DURATION_MS);
        openAnimator.setInterpolator(new DecelerateInterpolator(1.8f));
        openAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
				@Override
				public void onAnimationUpdate(ValueAnimator animation) {
					float p = ((Float) animation.getAnimatedValue()).floatValue();
					if (windowFrame != null) {
						windowFrame.setScaleX(0.965f + (0.035f * p));
						windowFrame.setScaleY(0.965f + (0.035f * p));
						windowFrame.setTranslationX(0f);
						windowFrame.setTranslationY(dp(10) * (1f - p));
					}
					if (pixelFillOverlay != null) {
						pixelFillOverlay.setProgress(p);
						if (p >= 1f) pixelFillOverlay.setVisibility(View.GONE);
					}
				}
			});
        openAnimator.start();
    }

    private void startCloseAnimation(final int direction) {
        if (windowFrame == null || overlayRoot == null) {
            performImmediateClose();
            return;
        }
        if (openAnimator != null) { openAnimator.cancel(); openAnimator = null; }
        if (closeAnimator != null) { closeAnimator.cancel(); closeAnimator = null; }

        final float endScale = 0.72f;
        final float endOffsetX;
        if (direction == CLOSE_DIRECTION_LEFT) {
            endOffsetX = -Math.max(dp(96), windowFrame.getWidth() * 0.22f);
        } else if (direction == CLOSE_DIRECTION_RIGHT) {
            endOffsetX = Math.max(dp(96), windowFrame.getWidth() * 0.22f);
        } else {
            endOffsetX = 0f;
        }
        final float endOffsetY = Math.max(dp(90), windowFrame.getHeight() * 0.18f);

        if (direction == CLOSE_DIRECTION_LEFT) {
            windowFrame.setPivotX(0f);
            windowFrame.setPivotY(windowFrame.getHeight());
        } else if (direction == CLOSE_DIRECTION_RIGHT) {
            windowFrame.setPivotX(windowFrame.getWidth());
            windowFrame.setPivotY(windowFrame.getHeight());
        } else {
            windowFrame.setPivotX(windowFrame.getWidth() * 0.5f);
            windowFrame.setPivotY(windowFrame.getHeight() * 0.5f);
        }

        if (pixelFillOverlay != null) {
            pixelFillOverlay.setVisibility(View.VISIBLE);
            pixelFillOverlay.setProgress(1f);
            pixelFillOverlay.setAlpha(1f);
        }

        closeAnimator = ValueAnimator.ofFloat(1f, 0f);
        closeAnimator.setDuration(CLOSE_ANIM_DURATION_MS);
        closeAnimator.setInterpolator(new AccelerateInterpolator(1.6f));
        closeAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
				@Override
				public void onAnimationUpdate(ValueAnimator animation) {
					float p = ((Float) animation.getAnimatedValue()).floatValue();
					float fraction = 1f - p;
					if (windowFrame != null) {
						float scale = 1f - ((1f - endScale) * fraction);
						windowFrame.setScaleX(scale);
						windowFrame.setScaleY(scale);
						windowFrame.setTranslationX(endOffsetX * fraction);
						windowFrame.setTranslationY(endOffsetY * fraction);
					}
					if (pixelFillOverlay != null) {
						pixelFillOverlay.setProgress(p);
					}
				}
			});
        closeAnimator.addListener(new android.animation.Animator.AnimatorListener() {
				@Override public void onAnimationStart(android.animation.Animator animation) {}
				@Override public void onAnimationEnd(android.animation.Animator animation) { performImmediateClose(); }
				@Override public void onAnimationCancel(android.animation.Animator animation) { performImmediateClose(); }
				@Override public void onAnimationRepeat(android.animation.Animator animation) {}
			});
        closeAnimator.start();
    }

    private boolean handleEdgeSwipe(MotionEvent event) {
        if (overlayRoot == null || windowFrame == null || overlayRoot.getParent() != rootContainer) return false;

        int action = event.getActionMasked();
        int edge = dp(28);

        switch (action) {
            case MotionEvent.ACTION_DOWN: {
					float x = event.getX();
					float y = event.getY();
					int w = overlayRoot.getWidth();
					if (w <= 0) return false;

					boolean fromLeft = x <= edge;
					boolean fromRight = x >= (w - edge);
					if (!fromLeft && !fromRight) return false;

					swipeClosing = true;
					swipeFromLeftEdge = fromLeft;
					swipeStartX = x;
					swipeStartY = y;
					swipeLastDx = 0f;
					swipeLastDy = 0f;
					return true;
				}
            case MotionEvent.ACTION_MOVE: {
					if (!swipeClosing) return false;
					swipeLastDx = event.getX() - swipeStartX;
					swipeLastDy = event.getY() - swipeStartY;

					float drag = swipeFromLeftEdge ? swipeLastDx : -swipeLastDx;
					if (drag < 0f) drag = 0f;

					float progress = Math.min(1f, drag / (float) dp(220));
					float scale = 1f - (0.28f * progress);
					float tx = (swipeFromLeftEdge ? -1f : 1f) * Math.max(dp(24), windowFrame.getWidth() * 0.22f) * progress;
					float ty = Math.max(dp(18), windowFrame.getHeight() * 0.18f) * progress;

					if (swipeFromLeftEdge) windowFrame.setPivotX(0f);
					else windowFrame.setPivotX(windowFrame.getWidth());
					windowFrame.setPivotY(windowFrame.getHeight());
					windowFrame.setScaleX(scale);
					windowFrame.setScaleY(scale);
					windowFrame.setTranslationX(tx);
					windowFrame.setTranslationY(ty);
					return true;
				}
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
					if (!swipeClosing) return false;
					float drag = swipeFromLeftEdge ? swipeLastDx : -swipeLastDx;
					boolean shouldClose = drag >= dp(84) || Math.abs(swipeLastDx) >= dp(84);
					if (shouldClose) {
						beginClose(swipeFromLeftEdge ? CLOSE_DIRECTION_LEFT : CLOSE_DIRECTION_RIGHT);
					} else {
						cancelSwipeGesture();
					}
					return true;
				}
            default:
                return swipeClosing;
        }
    }

    private void cancelSwipeGesture() {
        swipeClosing = false;
        if (windowFrame == null) return;
        windowFrame.setPivotX(windowFrame.getWidth() * 0.5f);
        windowFrame.setPivotY(windowFrame.getHeight() * 0.5f);
        windowFrame.animate()
            .scaleX(1f).scaleY(1f)
            .translationX(0f).translationY(0f)
            .setDuration(180L)
            .setInterpolator(new DecelerateInterpolator(1.6f))
            .start();
    }

    private void performImmediateClose() {
        if (overlayRoot != null && overlayRoot.getParent() == rootContainer) {
            rootContainer.removeView(overlayRoot);
        }
        if (openAnimator != null) { openAnimator.cancel(); openAnimator = null; }
        if (closeAnimator != null) {
            closeAnimator.removeAllListeners();
            closeAnimator.cancel();
            closeAnimator = null;
        }
        if (pixelFillOverlay != null) {
            pixelFillOverlay.setProgress(1f);
            pixelFillOverlay.setVisibility(View.GONE);
        }
        overlayRoot = null;
        windowFrame = null;
        pixelFillOverlay = null;
        isClosing = false;
        swipeClosing = false;
    }

    private void attachPixelFillOverlay() {
        if (windowFrame == null) return;
        pixelFillOverlay = new PixelFillOverlay(context);
        pixelFillOverlay.setVisibility(View.VISIBLE);
        windowFrame.addView(pixelFillOverlay, matchParentFrameLp());
        pixelFillOverlay.bringToFront();
    }

    private final class PixelFillOverlay extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Rect rect = new Rect();
        private float progress = 0f;
        private int cachedW = -1, cachedH = -1, tilePx = 1, cols = 0, rows = 0;
        private float[] thresholds = new float[0];

        PixelFillOverlay(Context context) {
            super(context);
            paint.setStyle(Paint.Style.FILL);
            setWillNotDraw(false);
            setClickable(false);
            setFocusable(false);
            setBackgroundColor(Color.TRANSPARENT);
        }

        void setProgress(float p) {
            if (p < 0f) p = 0f;
            if (p > 1f) p = 1f;
            if (progress == p) return;
            progress = p;
            invalidate();
        }

        private void ensureGeometry(int w, int h) {
            if (w == cachedW && h == cachedH && thresholds.length == cols * rows) return;
            cachedW = w; cachedH = h;
            int base = Math.min(w, h) / 18;
            tilePx = Math.max(dp(20), base);
            if (tilePx <= 0) tilePx = dp(20);
            cols = Math.max(1, (int) Math.ceil((double) w / (double) tilePx));
            rows = Math.max(1, (int) Math.ceil((double) h / (double) tilePx));
            thresholds = new float[cols * rows];
            float cx = w * 0.5f, cy = h * 0.5f;
            float maxDist = (float) Math.sqrt(cx * cx + cy * cy);
            if (maxDist <= 0f) maxDist = 1f;
            int index = 0;
            for (int row = 0; row < rows; row++) {
                float y = (row * tilePx) + (tilePx * 0.5f);
                for (int col = 0; col < cols; col++) {
                    float x = (col * tilePx) + (tilePx * 0.5f);
                    float dx = x - cx, dy = y - cy;
                    float norm = (float) Math.sqrt(dx * dx + dy * dy) / maxDist;
                    if (norm < 0f) norm = 0f;
                    if (norm > 1f) norm = 1f;
                    thresholds[index++] = norm;
                }
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            ensureGeometry(w, h);

            final int baseAlpha = 220;
            final int fillColor = 0xF21E1E20;
            final int accentColor = 0xFFD9946B;
            int fillR = Color.red(fillColor), fillG = Color.green(fillColor), fillB = Color.blue(fillColor);
            int accentR = Color.red(accentColor), accentG = Color.green(accentColor), accentB = Color.blue(accentColor);

            int index = 0;
            for (int row = 0; row < rows; row++) {
                int top = row * tilePx;
                int bottom = Math.min(h, top + tilePx);
                for (int col = 0; col < cols; col++) {
                    int left = col * tilePx;
                    int right = Math.min(w, left + tilePx);
                    float threshold = thresholds[index++];
                    float local = progress - threshold;
                    float alpha01;
                    if (local <= 0f) alpha01 = 1f;
                    else if (local >= 0.16f) alpha01 = 0f;
                    else {
                        float t = local / 0.16f;
                        alpha01 = 1f - (t * t * (3f - 2f * t));
                    }
                    if (alpha01 <= 0.01f) continue;
                    int alpha = (int) (baseAlpha * alpha01);
                    if (((row + col) & 7) == 0) {
                        paint.setColor(Color.argb(alpha, accentR, accentG, accentB));
                    } else if (((row + col) & 3) == 0) {
                        paint.setColor(Color.argb(alpha, 52, 46, 44));
                    } else {
                        paint.setColor(Color.argb(alpha, fillR, fillG, fillB));
                    }
                    rect.set(left, top, right, bottom);
                    canvas.drawRect(rect, paint);
                }
            }
        }
    }

    // =========================================================
    //  UI-хелперы
    // =========================================================

    private View buildTitle() {
        TextView tv = new DigitTextView(context);
        tv.setText("Индекс схожести с Землёй (ESI)");
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        tv.setGravity(Gravity.START | Gravity.TOP);
        return tv;
    }

    private TextView buildLabel(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#DDE3E1DE"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        return tv;
    }

    private View spacer(int heightPx) {
        View v = new View(context);
        v.setLayoutParams(new LinearLayout.LayoutParams(
							  LinearLayout.LayoutParams.MATCH_PARENT, heightPx));
        return v;
    }

    // =========================================================
    //  Поля + единицы
    // =========================================================

    private static final class ValueUnitRow {
        View row;
        EditText input;
        UnitPillState unitState;
    }

    private static final class UnitPillState {
        TextView pillView;
        int selectedIndex = 0;
        String[] labels;
    }

    private ValueUnitRow buildMassField() {
        String[] labels = new String[PhysicsEngine.MassUnit.values().length];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = PhysicsEngine.MassUnit.values()[i].label;
        }
        return buildValueUnitRow(labels, "Масса планеты");
    }

    private ValueUnitRow buildRadiusField() {
        // используем DistanceUnit (м, км, R⊕ и т.д.)
        String[] labels = new String[PhysicsEngine.DistanceUnit.values().length];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = PhysicsEngine.DistanceUnit.values()[i].label;
        }
        return buildValueUnitRow(labels, "Радиус");
    }

    private ValueUnitRow buildDensityField() {
        String[] labels = {"кг/м³", "г/см³", "ρ⊕"};
        return buildValueUnitRow(labels, "Плотность");
    }

    private ValueUnitRow buildTempField() {
        String[] labels = {"K", "°C", "°F"};
        return buildValueUnitRow(labels, "Температура");
    }

    private ValueUnitRow buildStarClassField() {
        String[] labels = {"O", "B", "A", "F", "G", "K", "M", "L", "T", "Y"};
        ValueUnitRow row = buildValueUnitRow(labels, "G (Солнце)");
        // по умолчанию G
        row.unitState.selectedIndex = 4;
        row.unitState.pillView.setText("G");
        return row;
    }

    private ValueUnitRow buildValueUnitRow(final String[] unitLabels, String hint) {
        FrameLayout field = new FrameLayout(context);
        field.setBackground(createRoundedRect(dp(16), FIELD_BG_COLOR, FIELD_BORDER_COLOR, dp(1.25f)));
        AstroUiEffects.applyControlShadow(field, context);
        field.setClipToOutline(true);

        final EditText input = new DigitEditText(context);
        input.setHint(hint);
        input.setHintTextColor(Color.parseColor("#77FFFFFF"));
        input.setTextColor(Color.WHITE);
        input.setTypeface(typefaceRegular);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        input.setSingleLine(true);
        input.setBackground(null);
        AstroUiEffects.applyControlShadow(input, context);
        input.setInputType(InputType.TYPE_CLASS_NUMBER
						   | InputType.TYPE_NUMBER_FLAG_DECIMAL
						   | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setPadding(dp(16), dp(12), dp(120), dp(12));
        field.addView(input, matchParentFrameLp());

        final UnitPillState state = new UnitPillState();
        state.labels = unitLabels;
        state.selectedIndex = 0;

        final TextView pill = new DigitTextView(context);
        pill.setText(unitLabels[0]);
        pill.setTextColor(Color.WHITE);
        pill.setTypeface(typefaceSemiBold);
        pill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        pill.setGravity(Gravity.CENTER);
        pill.setMaxLines(1);
        pill.setEllipsize(android.text.TextUtils.TruncateAt.END);
        pill.setBackground(createRoundedRect(dp(14), PILL_BG_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        pill.setPadding(dp(12), dp(8), dp(12), dp(8));
        pill.setClickable(true);
        pill.setFocusable(true);

        FrameLayout.LayoutParams pillLp = new FrameLayout.LayoutParams(dp(104), FrameLayout.LayoutParams.WRAP_CONTENT);
        pillLp.gravity = Gravity.CENTER_VERTICAL | Gravity.END;
        pillLp.rightMargin = dp(8);
        field.addView(pill, pillLp);
        pill.setTranslationZ(dp(3f));

        state.pillView = pill;

        pill.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					HapticUtils.perform(v);
					openDropdown(pill, unitLabels, state.selectedIndex, new OnUnitSelected() {
							@Override
							public void onSelected(int newIndex) {
								state.selectedIndex = newIndex;
								pill.setText(unitLabels[newIndex]);
							}
						});
				}
			});

        field.setLayoutParams(new LinearLayout.LayoutParams(
								  LinearLayout.LayoutParams.MATCH_PARENT, dp(50)));

        ValueUnitRow row = new ValueUnitRow();
        row.row = field;
        row.input = input;
        row.unitState = state;
        return row;
    }

    // =========================================================
    //  Dropdown
    // =========================================================

    private interface OnUnitSelected {
        void onSelected(int index);
    }

    private void openDropdown(final View anchor,
                              final String[] labels,
                              int selectedIndex,
                              final OnUnitSelected callback) {
        dropdownLayer.removeAllViews();
        dropdownLayer.bringToFront();

        int[] anchorLoc = new int[2];
        anchor.getLocationOnScreen(anchorLoc);
        int[] rootLoc = new int[2];
        dropdownLayer.getLocationOnScreen(rootLoc);

        int relativeX = anchorLoc[0] - rootLoc[0];
        int relativeY = anchorLoc[1] - rootLoc[1];
        int anchorBottom = relativeY + anchor.getHeight();

        Rect visibleFrame = new Rect();
        rootContainer.getWindowVisibleDisplayFrame(visibleFrame);
        int visibleTop = visibleFrame.top - rootLoc[1];
        int visibleBottom = visibleFrame.bottom - rootLoc[1];

        View scrim = new View(context);
        scrim.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) { dropdownLayer.removeAllViews(); }
			});
        dropdownLayer.addView(scrim, matchParentFrameLp());

        LinearLayout list = new LinearLayout(context);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setBackground(createRoundedRect(dp(14), DROPDOWN_BG_COLOR, ACCENT_BORDER_COLOR, dp(1.25f)));
        list.setClipToOutline(true);
        list.setPadding(dp(6), dp(6), dp(6), dp(6));

        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView item = new DigitTextView(context);
            item.setText(labels[i]);
            item.setTextColor(i == selectedIndex ? ACCENT_COLOR : Color.WHITE);
            item.setTypeface(i == selectedIndex ? typefaceSemiBold : typefaceRegular);
            AstroUiEffects.applyUnitTypeface(item, context);
            item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            item.setPadding(dp(14), dp(10), dp(14), dp(10));
            item.setClickable(true);
            item.setFocusable(true);
            item.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						HapticUtils.perform(v);
						callback.onSelected(idx);
						dropdownLayer.removeAllViews();
					}
				});
            list.addView(item, new LinearLayout.LayoutParams(
							 LinearLayout.LayoutParams.MATCH_PARENT,
							 LinearLayout.LayoutParams.WRAP_CONTENT));
        }

        int estimatedHeight = dp(12) + (labels.length * dp(40));
        int spaceBelow = visibleBottom - anchorBottom - dp(8);
        int spaceAbove = relativeY - visibleTop - dp(8);
        if (spaceBelow < 0) spaceBelow = 0;
        if (spaceAbove < 0) spaceAbove = 0;
        boolean showAbove = spaceBelow < estimatedHeight && spaceAbove > spaceBelow;
        final int maxHeight = Math.max(0, Math.min(estimatedHeight, showAbove ? spaceAbove : spaceBelow));

        ScrollView listScroll = new ScrollView(context) {
            @Override
            protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                int hSpec = heightMeasureSpec;
                if (maxHeight > 0) {
                    int mode = View.MeasureSpec.getMode(hSpec);
                    int size = View.MeasureSpec.getSize(hSpec);
                    if (mode == View.MeasureSpec.UNSPECIFIED || size > maxHeight) {
                        hSpec = View.MeasureSpec.makeMeasureSpec(maxHeight, View.MeasureSpec.AT_MOST);
                    }
                }
                super.onMeasure(widthMeasureSpec, hSpec);
            }
        };
        listScroll.addView(list, new ScrollView.LayoutParams(
							   ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        listScroll.setBackground(list.getBackground());
        list.setBackground(null);
        listScroll.setVerticalScrollBarEnabled(false);
        listScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        FrameLayout.LayoutParams listLp = new FrameLayout.LayoutParams(dp(180), FrameLayout.LayoutParams.WRAP_CONTENT);
        listLp.leftMargin = Math.max(dp(8), relativeX + anchor.getWidth() - dp(180));
        if (showAbove) {
            listLp.topMargin = Math.max(visibleTop + dp(8), relativeY - maxHeight - dp(4));
        } else {
            listLp.topMargin = anchorBottom + dp(4);
        }
        dropdownLayer.addView(listScroll, listLp);
        listScroll.bringToFront();
    }

    // =========================================================
    //  Кнопка и объяснение
    // =========================================================

    private View buildCalculateButton() {
        TextView btn = new DigitTextView(context);
        btn.setText("Рассчитать ESI");
        btn.setTextColor(Color.WHITE);
        btn.setTypeface(typefaceSemiBold);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(0, dp(14), 0, dp(14));
        btn.setBackground(createRoundedRect(dp(18), ACCENT_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        btn.setClickable(true);
        btn.setFocusable(true);
        btn.setLayoutParams(new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        btn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					HapticUtils.perform(v);
					onCalculatePressed();
				}
			});
        return btn;
    }

    private View buildExplanationBlock() {
        LinearLayout block = new LinearLayout(context);
        block.setOrientation(LinearLayout.VERTICAL);

        TextView title = new DigitTextView(context);
        title.setText("Как считается ESI");
        title.setTextColor(Color.WHITE);
        title.setTypeface(typefaceSemiBold);

        AstroUiEffects.applyExplanationTypeface(title, context);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        block.addView(title);
        block.addView(spacer(dp(8)));

        block.addView(buildExplanationLine("1) Приводим всё к SI (кг, м, K, кг/м³)."));
        block.addView(spacer(dp(4)));
        block.addView(buildExplanationLine("2) Если плотность не совпадает с M и R — заменяем на ρ = M / (4/3 π R³)."));
        block.addView(spacer(dp(4)));
        block.addView(buildExplanationLine("3) Считаем частичные индексы:"));
        block.addView(spacer(dp(2)));
        block.addView(buildExplanationLine("   ESI_x = [1 − |(x − x⊕)/(x + x⊕)| ]^w"));
        block.addView(spacer(dp(4)));
        block.addView(buildExplanationLine("4) Полный ESI = (ESI_R · ESI_ρ · ESI_ve · ESI_T)^0.25"));
        block.addView(spacer(dp(4)));
        block.addView(buildExplanationLine("5) Класс звезды влияет на оценку «пригодности» (G/K/M — лучше)."));

        return block;
    }

    private TextView buildExplanationLine(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#CFE3E1DE"));
        tv.setTypeface(typefaceRegular);
        AstroUiEffects.applyExplanationTypeface(tv, context);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        tv.setLineSpacing(dp(2), 1.08f);
        return tv;
    }

    // =========================================================
    //  Расчёт
    // =========================================================

    private void onCalculatePressed() {
        try {
            resultContainer.removeAllViews();

            Double massVal = parseDouble(massInput.getText().toString());
            Double radiusVal = parseDouble(radiusInput.getText().toString());
            Double densityVal = parseDouble(densityInput.getText().toString());
            Double tempVal = parseDouble(tempInput.getText().toString());

            if (massVal == null || massVal <= 0) {
                showResultError("Введите корректную массу планеты.");
                return;
            }
            if (radiusVal == null || radiusVal <= 0) {
                showResultError("Введите корректный радиус планеты.");
                return;
            }
            if (tempVal == null) {
                showResultError("Введите температуру поверхности.");
                return;
            }

            // --- в SI ---
            double massKg = PhysicsEngine.MassUnit.values()[massUnit.selectedIndex].toKg(massVal);
            double radiusM = PhysicsEngine.DistanceUnit.values()[radiusUnit.selectedIndex].toMeters(radiusVal);

            // плотность
            double densitySi;
            if (densityVal != null && densityVal > 0) {
                densitySi = densityToSi(densityVal, densityUnit.selectedIndex);
            } else {
                densitySi = massKg / ((4.0 / 3.0) * Math.PI * radiusM * radiusM * radiusM);
            }

            // авто-коррекция плотности
            double expectedDensity = massKg / ((4.0 / 3.0) * Math.PI * radiusM * radiusM * radiusM);
            double relDiff = Math.abs(densitySi - expectedDensity) / expectedDensity;
            boolean densityCorrected = false;
            if (relDiff > 0.08) {          // > 8 % — считаем ошибкой
                densitySi = expectedDensity;
                densityCorrected = true;
                // обновляем поле
                densityInput.setText(String.format(Locale.US, "%.1f", densitySi));
                densityUnit.selectedIndex = 0;
                densityUnit.pillView.setText("кг/м³");
            }

            // температура в K
            double tempK = tempToKelvin(tempVal, tempUnit.selectedIndex);

            // скорость убегания
            double escapeMs = Math.sqrt(2.0 * PhysicsEngine.G * massKg / radiusM);

            // --- частичные ESI ---
            double esiR  = partialEsi(radiusM, EARTH_RADIUS_M, 0.57);
            double esiRho = partialEsi(densitySi, EARTH_DENSITY, 1.07);
            double esiVe = partialEsi(escapeMs, EARTH_ESCAPE_MS, 0.70);
            double esiT  = partialEsi(tempK, EARTH_TEMP_K, 5.58);

            double esi = Math.pow(esiR * esiRho * esiVe * esiT, 0.25);

            // бонус/штраф за класс звезды
            String starClass = starClassState.labels[starClassState.selectedIndex];
            double starFactor = starClassFactor(starClass);
            double esiFinal = Math.min(1.0, esi * starFactor);

            showResult(esiFinal, esiR, esiRho, esiVe, esiT,
                       densityCorrected, densitySi, escapeMs, tempK, starClass);
        } catch (Throwable t) {
            resultContainer.removeAllViews();
            showResultError("Ошибка:\n" + stack(t));
        }
    }

    private double partialEsi(double x, double x0, double weight) {
        if (x <= 0 || x0 <= 0) return 0.0;
        double ratio = Math.abs((x - x0) / (x + x0));
        return Math.pow(1.0 - ratio, weight);
    }

    private double densityToSi(double value, int unitIndex) {
        switch (unitIndex) {
            case 0: return value;                    // кг/м³
            case 1: return value * 1000.0;           // г/см³ → кг/м³
            case 2: return value * EARTH_DENSITY;    // ρ⊕
            default: return value;
        }
    }

    private double tempToKelvin(double value, int unitIndex) {
        switch (unitIndex) {
            case 0: return value;                    // K
            case 1: return value + 273.15;           // °C
            case 2: return (value - 32.0) * 5.0 / 9.0 + 273.15; // °F
            default: return value;
        }
    }

    private double starClassFactor(String cls) {
        // G и K — идеально, M — чуть хуже (вспышки), O/B — слишком горячие
        if ("G".equals(cls) || "K".equals(cls)) return 1.00;
        if ("F".equals(cls) || "M".equals(cls)) return 0.96;
        if ("A".equals(cls)) return 0.90;
        if ("B".equals(cls) || "O".equals(cls)) return 0.82;
        if ("L".equals(cls) || "T".equals(cls) || "Y".equals(cls)) return 0.75;
        return 0.92;
    }

    private void showResult(double esi, double esiR, double esiRho, double esiVe, double esiT,
                            boolean densityCorrected, double densitySi, double escapeMs,
                            double tempK, String starClass) {
        LinearLayout box = resultBox();

        box.addView(resultSectionTitle("Результат ESI"));
        box.addView(spacer(dp(10)));

        // главный показатель
        TextView big = new DigitTextView(context);
        big.setText(String.format(Locale.US, "%.1f %%", esi * 100.0));
        big.setTextColor(ACCENT_COLOR);
        big.setTypeface(typefaceSemiBold);
        big.setTextSize(TypedValue.COMPLEX_UNIT_SP, 32);
        big.setGravity(Gravity.CENTER);
        box.addView(big);

        TextView verdict = new DigitTextView(context);
        verdict.setText(esiVerdict(esi));
        verdict.setTextColor(Color.parseColor("#DDE3E1DE"));
        verdict.setTypeface(typefaceRegular);
        verdict.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        verdict.setGravity(Gravity.CENTER);
        box.addView(verdict);

        box.addView(spacer(dp(14)));

        box.addView(resultLine("ESI по радиусу", String.format(Locale.US, "%.3f", esiR)));
        box.addView(spacer(dp(4)));
        box.addView(resultLine("ESI по плотности", String.format(Locale.US, "%.3f", esiRho)));
        box.addView(spacer(dp(4)));
        box.addView(resultLine("ESI по скорости убегания", String.format(Locale.US, "%.3f", esiVe)));
        box.addView(spacer(dp(4)));
        box.addView(resultLine("ESI по температуре", String.format(Locale.US, "%.3f", esiT)));
        box.addView(spacer(dp(8)));
        box.addView(resultLine("Класс звезды", starClass + "  (фактор " + String.format(Locale.US, "%.2f", starClassFactor(starClass)) + ")"));

        if (densityCorrected) {
            box.addView(spacer(dp(10)));
            TextView note = new DigitTextView(context);
            note.setText("⚠ Плотность была несовместима с массой и радиусом и автоматически заменена на " +
                         String.format(Locale.US, "%.0f кг/м³", densitySi));
            note.setTextColor(Color.parseColor("#FFF29B3B"));
            note.setTypeface(typefaceRegular);
            note.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            box.addView(note);
        }

        box.addView(spacer(dp(8)));
        box.addView(resultLine("Скорость убегания", PhysicsEngine.formatSpeed(escapeMs)));
        box.addView(spacer(dp(4)));
        box.addView(resultLine("Температура (K)", String.format(Locale.US, "%.1f K", tempK)));

        resultContainer.addView(box);
    }

    private String esiVerdict(double esi) {
        if (esi >= 0.90) return "Почти Земля. Можно начинать продавать билеты.";
        if (esi >= 0.80) return "Очень похожа. Хороший кандидат.";
        if (esi >= 0.70) return "Приличная схожесть. Есть шансы.";
        if (esi >= 0.50) return "Средняя. Жить можно, но с оговорками.";
        if (esi >= 0.30) return "Слабо. Скорее Марс, чем Земля.";
        return "Совсем не Земля. Лучше искать дальше.";
    }

    private void showResultError(String message) {
        TextView tv = new DigitTextView(context);
        tv.setText(message);
        tv.setTextColor(Color.parseColor("#FFB4A0"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        resultContainer.addView(tv);
    }

    private Double parseDouble(String text) {
        if (text == null) return null;
        String trimmed = text.trim().replace(',', '.');
        if (trimmed.isEmpty()) return null;
        try { return Double.parseDouble(trimmed); }
        catch (NumberFormatException e) { return null; }
    }

    private static String stack(Throwable t) {
        try {
            java.io.StringWriter sw = new java.io.StringWriter();
            t.printStackTrace(new java.io.PrintWriter(sw));
            String s = sw.toString();
            return s.length() > 1200 ? s.substring(0, 1200) + "…" : s;
        } catch (Throwable ignore) {
            return String.valueOf(t);
        }
    }

    // =========================================================
    //  Утилиты результата
    // =========================================================

    private LinearLayout resultBox() {
        LinearLayout box = new LinearLayout(context);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(createRoundedRect(dp(16), Color.parseColor("#6F6B67"), Color.parseColor("#CCFFFFFF"), dp(1.5f)));
        int p = dp(14);
        box.setPadding(p, p, p, p);
        box.setLayoutParams(new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return box;
    }

    private TextView resultSectionTitle(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        return tv;
    }

    private View resultLine(String label, String value) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.VERTICAL);
        TextView labelView = new DigitTextView(context);
        labelView.setText(label);
        labelView.setTextColor(Color.parseColor("#BBFFFFFF"));
        labelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        row.addView(labelView);
        TextView valueView = new DigitTextView(context);
        valueView.setText(value);
        valueView.setTextColor(ACCENT_COLOR);
        valueView.setTypeface(typefaceSemiBold);
        valueView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        row.addView(valueView);
        return row;
    }

    private GradientDrawable createRoundedRect(float radius, int fillColor, int strokeColor, float strokeWidth) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(radius);
        gd.setColor(fillColor);
        gd.setStroke((int) strokeWidth, strokeColor);
        return gd;
    }

    private FrameLayout.LayoutParams matchParentFrameLp() {
        return new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        );
    }
}
