package com.astroforge;

import android.content.Context;
import android.graphics.Color;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.SeekBar;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

/**
 * Окно расчёта идеальной круговой орбиты.
 *
 * Базовая модель:
 *   v = sqrt(G * M / r)
 *   T = 2*pi*r/v
 *
 * Поля массы и расстояния реализованы нативными SeekBar с логарифмической
 * шкалой, а единицы выбираются выезжающим PopupWindow.
 * Для реалистичных астрономических диапазонов значения показываются с
 * сохранением физического значения в СИ.
 *
 * AIDE-safe: без lambda/var/records/AndroidX.
 */
final class OrbitalPanel {

    private static final double G = PhysicsEngine.G;
    private static final double TWO_PI = 2.0 * Math.PI;

    private static final int ACCENT_COLOR = 0xFFD9946B;
    private static final int TEXT_MAIN = Color.parseColor("#F0E7E0");
    private static final int TEXT_SECONDARY = Color.parseColor("#D7CBC2");
    private static final int GLASS_TINT = Color.parseColor("#AA201B1A");
    private static final int GLASS_BORDER = Color.parseColor("#66F0D1BE");
    private static final int FIELD_TINT = Color.parseColor("#B51C1816");
    private static final int RESULT_TINT = Color.parseColor("#B52A211D");
    private static final int DROPDOWN_BG = Color.parseColor("#F226211E");

    private final Context context;
    private final FrameLayout rootContainer;
    private final Typeface regular;
    private final Typeface semiBold;

    private FrameLayout overlayRoot;
    private FrameLayout dropdownLayer;

    private SeekBar massSeek;
    private SeekBar distanceSeek;
    private TextView massValue;
    private TextView distanceValue;
    private TextView massUnitPill;
    private TextView distanceUnitPill;

    private int massUnitIndex = 5;     // Земля
    private int distanceUnitIndex = 3; // а.е.

    // SI-состояние — сохраняется при смене единиц.
    private double massKg = 5.972e24;
    private double distanceM = 1.496e11;

    private LinearLayout resultContainer;
    private PopupWindow activePopup;

    private OrbitalPanel(Context context,
                         FrameLayout rootContainer,
                         Typeface regular,
                         Typeface semiBold) {
        this.context = context;
        this.rootContainer = rootContainer;
        this.regular = regular;
        this.semiBold = semiBold;
    }

    static void show(Context context,
                     FrameLayout rootContainer,
                     Typeface regular,
                     Typeface semiBold) {
        if (context == null || rootContainer == null) {
            return;
        }
        new OrbitalPanel(context, rootContainer, regular, semiBold).build();
    }

    private int dp(float value) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            context.getResources().getDisplayMetrics()
        );
    }

    private void build() {
        overlayRoot = new FrameLayout(context);
        overlayRoot.setBackgroundColor(Color.parseColor("#990A0908"));
        overlayRoot.setClickable(true);
        overlayRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                close();
            }
        });

        final FrameLayout windowFrame = new FrameLayout(context);
        windowFrame.setClickable(true);
        windowFrame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ничего не делаем: клик внутри окна не закрывает его.
            }
        });

        GradientDrawable frameBg = new GradientDrawable();
        frameBg.setColor(Color.parseColor("#E51E1A18"));
        frameBg.setCornerRadius(dp(28));
        frameBg.setStroke(dp(2), ACCENT_COLOR);
        windowFrame.setBackground(frameBg);
        windowFrame.setClipToOutline(true);
        windowFrame.setOutlineProvider(ViewOutlineProviderCompat.rounded(dp(28)));

        android.widget.ImageView bg = new android.widget.ImageView(context);
        bg.setImageResource(R.drawable.orbital_mars);
        bg.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        if (Build.VERSION.SDK_INT >= 31) {
            bg.setRenderEffect(RenderEffect.createBlurEffect(dp(22), dp(22), Shader.TileMode.CLAMP));
        }
        bg.setAlpha(0.72f);
        windowFrame.addView(bg, matchParentFrameLp());

        View tint = new View(context);
        tint.setBackgroundColor(Color.parseColor("#B52A211D"));
        windowFrame.addView(tint, matchParentFrameLp());
        AstroUiEffects.applyPaperEffect(windowFrame, context);

        ScrollView scroll = new ScrollView(context);
        scroll.setClipToPadding(false);
        scroll.setFillViewport(true);

        LinearLayout content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(18), dp(18), dp(24));

        content.addView(buildTitle());
        content.addView(spacer(dp(5)));
        content.addView(buildSubtitle("Нативный расчёт идеальной круговой орбиты"));
        content.addView(spacer(dp(18)));

        FrameLayout massPanel = buildSliderPanel("Масса родительского тела", true);
        content.addView(massPanel);
        content.addView(spacer(dp(12)));

        FrameLayout distancePanel = buildSliderPanel("Расстояние до родительского тела", false);
        content.addView(distancePanel);
        content.addView(spacer(dp(16)));

        content.addView(buildCalculateButton());
        content.addView(spacer(dp(14)));

        resultContainer = new LinearLayout(context);
        resultContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(resultContainer);

        content.addView(spacer(dp(12)));
        content.addView(buildExplanationBlock());

        scroll.addView(content, new ScrollView.LayoutParams(
            ScrollView.LayoutParams.MATCH_PARENT,
            ScrollView.LayoutParams.WRAP_CONTENT
        ));
        windowFrame.addView(scroll, matchParentFrameLp());

        FrameLayout.LayoutParams windowLp = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        );
        int margin = dp(16);
        windowLp.setMargins(margin, margin + dp(26), margin, margin + dp(26));
        overlayRoot.addView(windowFrame, windowLp);

        rootContainer.addView(overlayRoot, matchParentFrameLp());

        windowFrame.post(new Runnable() {
            @Override
            public void run() {
                if (overlayRoot != null && overlayRoot.getParent() == rootContainer && windowFrame != null) {
                    WindowOpenAnimation.start(windowFrame, context.getResources().getDisplayMetrics().density);
                }
            }
        });

        dropdownLayer = new FrameLayout(context);
        dropdownLayer.setClipChildren(false);
        dropdownLayer.setClipToPadding(false);
        dropdownLayer.setElevation(dp(2000));
        overlayRoot.addView(dropdownLayer, matchParentFrameLp());

        updateMassUi(false);
        updateDistanceUi(false);
    }

    private TextView buildTitle() {
        TextView tv = new DigitTextView(context);
        tv.setText("Идеальная круговая орбита");
        tv.setTextColor(TEXT_MAIN);
        tv.setTypeface(semiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        return tv;
    }

    private TextView buildSubtitle(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(TEXT_SECONDARY);
        tv.setTypeface(regular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        return tv;
    }

    private FrameLayout buildSliderPanel(String title, boolean mass) {
        final FrameLayout card = buildGlassCard();

        LinearLayout inner = new LinearLayout(context);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(14), dp(12), dp(14), dp(12));

        TextView label = new DigitTextView(context);
        label.setText(title);
        label.setTextColor(TEXT_MAIN);
        label.setTypeface(semiBold);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        inner.addView(label);
        inner.addView(spacer(dp(8)));

        FrameLayout readout = new FrameLayout(context);
        readout.setBackground(glassBackground(FIELD_TINT, GLASS_BORDER, dp(16), dp(1)));

        TextView value = new DigitTextView(context);
        value.setTextColor(Color.WHITE);
        value.setTypeface(semiBold);
        value.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        value.setGravity(Gravity.CENTER_VERTICAL);
        value.setPadding(dp(12), 0, dp(58), 0);

        final TextView pill = new DigitTextView(context);
        pill.setTextColor(Color.WHITE);
        pill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        pill.setTypeface(semiBold);
        pill.setGravity(Gravity.CENTER);
        pill.setPadding(dp(10), 0, dp(10), 0);
        pill.setBackground(glassBackground(Color.parseColor("#EE161311"), ACCENT_COLOR, dp(14), dp(1)));
        pill.setClickable(true);
        pill.setFocusable(true);

        if (mass) {
            massValue = value;
            massUnitPill = pill;
        } else {
            distanceValue = value;
            distanceUnitPill = pill;
        }

        readout.addView(value, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            dp(48)
        ));
        FrameLayout.LayoutParams pillLp = new FrameLayout.LayoutParams(dp(72), dp(36));
        pillLp.gravity = Gravity.END | Gravity.CENTER_VERTICAL;
        pillLp.rightMargin = dp(6);
        readout.addView(pill, pillLp);
        inner.addView(readout, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(48)
        ));

        SeekBar seek = new SeekBar(context);
        seek.setMax(1000);
        seek.setPadding(dp(2), 0, dp(2), 0);

        if (mass) {
            massSeek = seek;
            seek.setProgress(500);
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                    massKg = massFromProgress(progress, massUnitIndex);
                    updateMassUi(false);
                }
                @Override public void onStartTrackingTouch(SeekBar bar) { }
                @Override public void onStopTrackingTouch(SeekBar bar) { }
            });

            pill.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showUnitPopup(true, pill);
                }
            });
        } else {
            distanceSeek = seek;
            seek.setProgress(620);
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                    distanceM = distanceFromProgress(progress, distanceUnitIndex);
                    updateDistanceUi(false);
                }
                @Override public void onStartTrackingTouch(SeekBar bar) { }
                @Override public void onStopTrackingTouch(SeekBar bar) { }
            });

            pill.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showUnitPopup(false, pill);
                }
            });
        }

        inner.addView(seek, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(42)
        ));

        TextView hint = new DigitTextView(context);
        hint.setText(mass ? "Проведите по шкале — диапазон логарифмический" :
                             "Проведите по шкале — удобно для астрономических расстояний");
        hint.setTextColor(Color.parseColor("#C6B8AF"));
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        inner.addView(hint);

        card.addView(inner, matchParentFrameLp());
        return card;
    }

    private FrameLayout buildGlassCard() {
        FrameLayout card = new FrameLayout(context);
        GradientDrawable bg = glassBackground(GLASS_TINT, GLASS_BORDER, dp(20), dp(1));
        card.setBackground(bg);
        card.setClipToOutline(true);
        if (Build.VERSION.SDK_INT >= 31) {
            // Лёгкое сглаживание самого стеклянного содержимого поверх фоновой картинки.
            card.setRenderEffect(RenderEffect.createBlurEffect(0.45f, 0.45f, Shader.TileMode.CLAMP));
        }

        android.widget.ImageView blurLayer = new android.widget.ImageView(context);
        blurLayer.setImageResource(R.drawable.orbital_mars);
        blurLayer.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        blurLayer.setAlpha(0.62f);
        if (Build.VERSION.SDK_INT >= 31) {
            blurLayer.setRenderEffect(RenderEffect.createBlurEffect(dp(16), dp(16), Shader.TileMode.CLAMP));
        }
        card.addView(blurLayer, matchParentFrameLp());

        View tint = new View(context);
        tint.setBackgroundColor(Color.parseColor("#A11B1714"));
        card.addView(tint, matchParentFrameLp());
        return card;
    }

    private GradientDrawable glassBackground(int fill, int stroke, int radius, int strokeWidth) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(radius);
        d.setStroke(strokeWidth, stroke);
        return d;
    }

    private View buildCalculateButton() {
        TextView button = new DigitTextView(context);
        button.setText("Рассчитать орбиту");
        button.setTextColor(Color.WHITE);
        button.setTypeface(semiBold);
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        button.setGravity(Gravity.CENTER);
        button.setBackground(glassBackground(Color.parseColor("#D16E4630"), ACCENT_COLOR, dp(18), dp(2)));
        button.setPadding(dp(14), dp(14), dp(14), dp(14));
        button.setClickable(true);
        button.setFocusable(true);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculate();
            }
        });
        return button;
    }

    private View buildExplanationBlock() {
        FrameLayout card = buildGlassCard();

        LinearLayout inner = new LinearLayout(context);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(14), dp(12), dp(14), dp(12));

        TextView title = new DigitTextView(context);
        title.setText("Как считается");
        title.setTextColor(TEXT_MAIN);
        title.setTypeface(semiBold);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        inner.addView(title);
        inner.addView(spacer(dp(6)));

        TextView text = new DigitTextView(context);
        text.setText("Для идеальной круговой орбиты используется ньютоновская формула " +
                     "v = √(GM/r), где G — гравитационная постоянная, M — масса " +
                     "родительского тела, а r — расстояние до его центра. Период " +
                     "оборота затем находится как T = 2πr/v. Массой спутника в этой " +
                     "упрощённой модели пренебрегаем.");
        text.setTextColor(TEXT_SECONDARY);
        text.setTypeface(regular);
        AstroUiEffects.applyExplanationTypeface(text, context);
        text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        text.setLineSpacing(0f, 1.15f);
        inner.addView(text);

        card.addView(inner, matchParentFrameLp());
        return card;
    }

    private void calculate() {
        if (massKg <= 0.0 || distanceM <= 0.0) {
            return;
        }

        PhysicsEngine.OrbitalResult speeds = PhysicsEngine.computeOrbitalSpeeds(massKg, distanceM);
        double v = speeds.circularSpeedMs;
        double periodSeconds = TWO_PI * distanceM / v;

        resultContainer.removeAllViews();
        resultContainer.addView(buildResultCard("Орбитальная скорость", formatSpeed(v), "м/с"));
        resultContainer.addView(spacer(dp(10)));
        resultContainer.addView(buildResultCard("Период обращения", formatTime(periodSeconds), ""));
        resultContainer.addView(spacer(dp(10)));

        TextView note = new DigitTextView(context);
        note.setText("Расчёт выполнен для идеальной круговой орбиты без сопротивления среды и возмущений.");
        note.setTextColor(Color.parseColor("#D6C6BC"));
        note.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        resultContainer.addView(note);
    }

    private FrameLayout buildResultCard(String title, String value, String unit) {
        FrameLayout card = new FrameLayout(context);
        card.setBackground(glassBackground(RESULT_TINT, Color.parseColor("#88D9946B"), dp(18), dp(1)));

        LinearLayout inner = new LinearLayout(context);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(14), dp(11), dp(14), dp(11));

        TextView label = new DigitTextView(context);
        label.setText(title);
        label.setTextColor(TEXT_SECONDARY);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        inner.addView(label);
        inner.addView(spacer(dp(3)));

        TextView valueTv = new DigitTextView(context);
        valueTv.setText(unit.length() == 0 ? value : value + " " + unit);
        valueTv.setTextColor(Color.WHITE);
        valueTv.setTypeface(semiBold);
        valueTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        inner.addView(valueTv);

        card.addView(inner, matchParentFrameLp());
        return card;
    }

    private void showUnitPopup(final boolean mass, final TextView anchor) {
        if (activePopup != null) {
            activePopup.dismiss();
            activePopup = null;
        }

        final String[] labels = mass ? massLabels() : distanceLabels();
        LinearLayout list = new LinearLayout(context);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(6), dp(6), dp(6), dp(6));
        list.setBackground(glassBackground(DROPDOWN_BG, ACCENT_COLOR, dp(18), dp(1)));

        for (int i = 0; i < labels.length; i++) {
            final int index = i;
            TextView item = new DigitTextView(context);
            item.setText(labels[i]);
            item.setTextColor(Color.WHITE);
            item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(dp(13), 0, dp(13), 0);
            item.setMinHeight(dp(42));
            item.setClickable(true);
            item.setBackground(glassBackground(
                index == (mass ? massUnitIndex : distanceUnitIndex)
                    ? Color.parseColor("#5A4A3F") : Color.TRANSPARENT,
                Color.TRANSPARENT,
                dp(12),
                0
            ));
            item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mass) {
                        massUnitIndex = index;
                        updateMassSeekForUnit();
                        updateMassUi(false);
                    } else {
                        distanceUnitIndex = index;
                        updateDistanceSeekForUnit();
                        updateDistanceUi(false);
                    }
                    if (activePopup != null) {
                        activePopup.dismiss();
                        activePopup = null;
                    }
                }
            });
            list.addView(item);
        }

        activePopup = new PopupWindow(
            list,
            dp(190),
            ViewGroup.LayoutParams.WRAP_CONTENT,
            true
        );
        activePopup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        activePopup.setOutsideTouchable(true);
        activePopup.setElevation(dp(14));

        int[] location = new int[2];
        anchor.getLocationOnScreen(location);
        int x = Math.max(dp(8), location[0] + anchor.getWidth() - dp(190));
        int y = location[1] + anchor.getHeight() + dp(5);
        activePopup.showAtLocation(anchor, Gravity.TOP | Gravity.START, x, y);
    }

    private void updateMassSeekForUnit() {
        int p = progressForMass(massKg, massUnitIndex);
        massSeek.setProgress(p);
    }

    private void updateDistanceSeekForUnit() {
        int p = progressForDistance(distanceM, distanceUnitIndex);
        distanceSeek.setProgress(p);
    }

    private void updateMassUi(boolean dummy) {
        double display = massKg / massFactors()[massUnitIndex];
        massUnitPill.setText(massLabels()[massUnitIndex]);
        massValue.setText(formatValue(display));
    }

    private void updateDistanceUi(boolean dummy) {
        double display = distanceM / distanceFactors()[distanceUnitIndex];
        distanceUnitPill.setText(distanceLabels()[distanceUnitIndex]);
        distanceValue.setText(formatValue(display));
    }

    private String[] massLabels() {
        return new String[]{"кг", "т", "Церера", "Плутон", "Луна", "Земля", "Нептун", "Юпитер", "Солнце"};
    }

    private double[] massFactors() {
        return new double[]{
            1.0, 1.0e3, 9.3835e20, 1.303e22, 7.342e22,
            5.972e24, 1.024e26, 1.898e27, 1.989e30
        };
    }

    private String[] distanceLabels() {
        return new String[]{"м", "км", "R Земли", "а.е.", "св. год"};
    }

    private double[] distanceFactors() {
        return new double[]{1.0, 1.0e3, 6.371e6, 1.496e11, 9.461e15};
    }

    private double massFromProgress(int progress, int unitIndex) {
        double minExp = massMinExp(unitIndex);
        double maxExp = massMaxExp(unitIndex);
        double value = Math.pow(10.0, minExp + (maxExp - minExp) * progress / 1000.0);
        return value * massFactors()[unitIndex];
    }

    private double distanceFromProgress(int progress, int unitIndex) {
        double minExp = distanceMinExp(unitIndex);
        double maxExp = distanceMaxExp(unitIndex);
        double value = Math.pow(10.0, minExp + (maxExp - minExp) * progress / 1000.0);
        return value * distanceFactors()[unitIndex];
    }

    private int progressForMass(double kg, int unitIndex) {
        double value = kg / massFactors()[unitIndex];
        double exp = Math.log10(Math.max(value, Math.pow(10.0, massMinExp(unitIndex))));
        double min = massMinExp(unitIndex);
        double max = massMaxExp(unitIndex);
        return clamp((int) Math.round((exp - min) * 1000.0 / (max - min)), 0, 1000);
    }

    private int progressForDistance(double meters, int unitIndex) {
        double value = meters / distanceFactors()[unitIndex];
        double exp = Math.log10(Math.max(value, Math.pow(10.0, distanceMinExp(unitIndex))));
        double min = distanceMinExp(unitIndex);
        double max = distanceMaxExp(unitIndex);
        return clamp((int) Math.round((exp - min) * 1000.0 / (max - min)), 0, 1000);
    }

    private double massMinExp(int unit) {
        switch (unit) {
            case 0: return 10.0;
            case 1: return 7.0;
            case 2: return -8.0;
            case 3: return -8.0;
            case 4: return -6.0;
            case 5: return -6.0;
            case 6: return -8.0;
            case 7: return -10.0;
            default: return -10.0;
        }
    }

    private double massMaxExp(int unit) {
        switch (unit) {
            case 0: return 32.0;
            case 1: return 29.0;
            case 2: return 12.0;
            case 3: return 10.0;
            case 4: return 9.0;
            case 5: return 7.0;
            case 6: return 6.0;
            case 7: return 5.0;
            default: return 3.0;
        }
    }

    private double distanceMinExp(int unit) {
        switch (unit) {
            case 0: return 6.0;
            case 1: return 3.0;
            case 2: return -1.0;
            case 3: return -4.0;
            default: return -10.0;
        }
    }

    private double distanceMaxExp(int unit) {
        switch (unit) {
            case 0: return 14.0;
            case 1: return 11.0;
            case 2: return 7.0;
            case 3: return 3.0;
            default: return 2.0;
        }
    }

    private int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    private String formatValue(double value) {
        if (value == 0.0) return "0";
        double a = Math.abs(value);
        if (a >= 0.01 && a < 1000000.0) {
            return String.format(Locale.US, "%.4g", value).replace('E', 'e');
        }
        return String.format(Locale.US, "%.4e", value).replace('E', 'e');
    }

    private String formatSpeed(double ms) {
        if (ms >= 1000.0) {
            return String.format(Locale.US, "%.4f км/с", ms / 1000.0);
        }
        return String.format(Locale.US, "%.4f м/с", ms);
    }

    private String formatTime(double seconds) {
        double days = seconds / 86400.0;
        if (days >= 365.25) {
            return String.format(Locale.US, "%.4f лет", days / 365.25);
        }
        if (days >= 1.0) {
            return String.format(Locale.US, "%.4f дн.", days);
        }
        double hours = seconds / 3600.0;
        if (hours >= 1.0) {
            return String.format(Locale.US, "%.4f ч", hours);
        }
        return String.format(Locale.US, "%.4f с", seconds);
    }

    private View spacer(int h) {
        View v = new View(context);
        v.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            h
        ));
        return v;
    }

    private FrameLayout.LayoutParams matchParentFrameLp() {
        return new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        );
    }

    private void close() {
        if (activePopup != null) {
            activePopup.dismiss();
            activePopup = null;
        }
        if (overlayRoot != null && overlayRoot.getParent() == rootContainer) {
            rootContainer.removeView(overlayRoot);
        }
    }

    /** Минимальная совместимая реализация OutlineProvider без AndroidX. */
    private static final class ViewOutlineProviderCompat extends android.view.ViewOutlineProvider {
        private final int radius;

        private ViewOutlineProviderCompat(int radius) {
            this.radius = radius;
        }

        static ViewOutlineProviderCompat rounded(int radius) {
            return new ViewOutlineProviderCompat(radius);
        }

        @Override
        public void getOutline(View view, android.graphics.Outline outline) {
            outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
        }
    }
}
