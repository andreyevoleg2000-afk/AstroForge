package com.astroforge;

public class BlackBoxEngineAdapter implements IEngine {

    private final DoubleDoubleEngine engine;

    public BlackBoxEngineAdapter(EngineConfig config, EngineListener listener) {
        this.engine = new DoubleDoubleEngine(config, listener);
    }

    public DoubleDoubleEngine getEngine() {
        return engine;
    }

    @Override
    public void addBody(BodySpec body) {
        engine.addBody(body);
    }

    @Override
    public void start() {
        engine.start();
    }

    @Override
    public void stop() {
        engine.stop();
    }

    @Override
    public boolean isRunning() {
        return engine.isRunning();
    }
}
