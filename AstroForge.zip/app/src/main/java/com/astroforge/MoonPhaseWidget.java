package com.astroforge;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.Bundle;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Native AstroForge home-screen widget for lunar phases.
 * Minimum size: 4 x 2 cells. Horizontal resizing is allowed.
 */
public class MoonPhaseWidget extends AppWidgetProvider {

    private static final double SYNODIC_MONTH_DAYS = 29.530588853;
    // 2000-01-06 18:14 UTC, a known New Moon reference.
    private static final long REFERENCE_NEW_MOON_MS = 947182440000L;

    private static final String ACTION_DAILY_UPDATE =
            "com.astroforge.action.MOON_PHASE_DAILY_UPDATE";
    private static final int DAILY_UPDATE_REQUEST_CODE = 9031;

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId);
        }
        scheduleDailyUpdate(context);
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        scheduleDailyUpdate(context);
    }

    @Override
    public void onDisabled(Context context) {
        cancelDailyUpdate(context);
        super.onDisabled(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);

        String action = intent.getAction();
        if (ACTION_DAILY_UPDATE.equals(action)) {
            updateAllWidgets(context);
            scheduleDailyUpdate(context);
        } else if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_TIME_CHANGED.equals(action)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(action)
                || Intent.ACTION_DATE_CHANGED.equals(action)) {
            updateAllWidgets(context);
            scheduleDailyUpdate(context);
        }
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context,
                                          AppWidgetManager appWidgetManager,
                                          int appWidgetId,
                                          Bundle newOptions) {
        updateWidget(context, appWidgetManager, appWidgetId);
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions);
    }

    private static void updateAllWidgets(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName provider = new ComponentName(context, MoonPhaseWidget.class);
        int[] ids = manager.getAppWidgetIds(provider);
        for (int id : ids) {
            updateWidget(context, manager, id);
        }
    }

    private static void updateWidget(Context context,
                                     AppWidgetManager manager,
                                     int widgetId) {
        final LunarData lunar = calculateLunarData(System.currentTimeMillis());
        final RemoteViews views = new RemoteViews(
                context.getPackageName(), R.layout.widget_moon_phase);

        views.setImageViewBitmap(
                R.id.widget_moon_image,
                createMoonBitmap(320, lunar.phaseFraction));
        views.setTextViewText(R.id.widget_phase_name, lunar.phaseName);
        views.setTextViewText(
                R.id.widget_illumination,
                String.format(Locale.getDefault(),
                        "Освещённость %d%%",
                        Math.round(lunar.illumination * 100.0)));
        views.setTextViewText(R.id.widget_date, lunar.dateText);

        Intent launchIntent = new Intent(context, MainActivity.class);
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                0,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, pendingIntent);

        manager.updateAppWidget(widgetId, views);
    }

    /** Schedule one update at the next local midnight. */
    private static void scheduleDailyUpdate(Context context) {
        AlarmManager alarmManager =
                (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            return;
        }

        Intent intent = new Intent(context, MoonPhaseWidget.class);
        intent.setAction(ACTION_DAILY_UPDATE);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                DAILY_UPDATE_REQUEST_CODE,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Calendar nextMidnight = Calendar.getInstance();
        nextMidnight.add(Calendar.DAY_OF_YEAR, 1);
        nextMidnight.set(Calendar.HOUR_OF_DAY, 0);
        nextMidnight.set(Calendar.MINUTE, 0);
        nextMidnight.set(Calendar.SECOND, 0);
        nextMidnight.set(Calendar.MILLISECOND, 0);

        long triggerAtMillis = nextMidnight.getTimeInMillis();
        // A one-shot alarm is rescheduled after every delivery, so timezone/date
        // changes and reboots cannot leave the widget on an old daily schedule.
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC, triggerAtMillis, pendingIntent);
        } else {
            alarmManager.set(AlarmManager.RTC, triggerAtMillis, pendingIntent);
        }
    }

    private static void cancelDailyUpdate(Context context) {
        AlarmManager alarmManager =
                (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            return;
        }

        Intent intent = new Intent(context, MoonPhaseWidget.class);
        intent.setAction(ACTION_DAILY_UPDATE);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                DAILY_UPDATE_REQUEST_CODE,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        alarmManager.cancel(pendingIntent);
    }

    private static LunarData calculateLunarData(long nowMs) {
        double days = (nowMs - REFERENCE_NEW_MOON_MS) / 86400000.0;
        double age = days % SYNODIC_MONTH_DAYS;
        if (age < 0) {
            age += SYNODIC_MONTH_DAYS;
        }

        double fraction = age / SYNODIC_MONTH_DAYS;
        // 0 at New Moon, 0.5 at Full Moon.
        double illumination = 0.5 * (1.0 - Math.cos(2.0 * Math.PI * fraction));

        String phaseName;
        if (fraction < 0.0625 || fraction >= 0.9375) {
            phaseName = "Новолуние";
        } else if (fraction < 0.1875) {
            phaseName = "Растущий серп";
        } else if (fraction < 0.3125) {
            phaseName = "Первая четверть";
        } else if (fraction < 0.4375) {
            phaseName = "Растущая Луна";
        } else if (fraction < 0.5625) {
            phaseName = "Полнолуние";
        } else if (fraction < 0.6875) {
            phaseName = "Убывающая Луна";
        } else if (fraction < 0.8125) {
            phaseName = "Последняя четверть";
        } else {
            phaseName = "Убывающий серп";
        }

        SimpleDateFormat sdf = new SimpleDateFormat("d MMMM yyyy", new Locale("ru"));
        sdf.setTimeZone(TimeZone.getDefault());

        return new LunarData(
                fraction,
                illumination,
                phaseName,
                sdf.format(new Date(nowMs)));
    }

    /**
     * Draw a more realistic Moon using deterministic maria/crater texture plus
     * a spherical light model for the current phase. The texture is generated
     * locally so the widget does not need a large bitmap resource.
     */
    private static Bitmap createMoonBitmap(int size, double phaseFraction) {
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        final float center = size / 2f;
        final float radius = size * 0.405f;
        final int pixelCount = size * size;

        Paint clear = new Paint(Paint.ANTI_ALIAS_FLAG);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(Color.TRANSPARENT, android.graphics.PorterDuff.Mode.CLEAR);

        // Large-scale lunar surface albedo. Dark maria are deliberately broad,
        // irregular and low contrast so they remain believable at widget size.
        final double[][] maria = new double[][]{
                {-0.18, -0.36, 0.24, 0.16, 0.16},
                { 0.08, -0.12, 0.30, 0.18, 0.14},
                {-0.34,  0.08, 0.20, 0.15, 0.08},
                { 0.26,  0.18, 0.27, 0.19, 0.12},
                {-0.08,  0.34, 0.24, 0.13, 0.10},
                { 0.38, -0.30, 0.15, 0.11, 0.07},
                {-0.40, -0.24, 0.13, 0.09, 0.07}
        };

        int[] pixels = new int[pixelCount];
        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                double nx = (x - center) / radius;
                double ny = (y - center) / radius;
                double rr = nx * nx + ny * ny;
                int index = y * size + x;
                if (rr > 1.0) {
                    pixels[index] = Color.TRANSPARENT;
                    continue;
                }

                double coarse = fbm(nx * 2.3, ny * 2.3, 4);
                double fine = fbm(nx * 12.0, ny * 12.0, 3);
                double albedo = 0.79 + (coarse - 0.5) * 0.16 + (fine - 0.5) * 0.035;

                for (double[] m : maria) {
                    double dx = (nx - m[0]) / m[2];
                    double dy = (ny - m[1]) / m[3];
                    double d = dx * dx + dy * dy;
                    if (d < 1.0) {
                        double edge = 1.0 - smoothStep(0.72, 1.0, d);
                        double localNoise = 0.92 + 0.08 * fbm(nx * 7.0 + m[0] * 4.0,
                                ny * 7.0 + m[1] * 4.0, 2);
                        albedo -= m[4] * edge * localNoise;
                    }
                }

                albedo = Math.max(0.53, Math.min(0.90, albedo));
                int gray = (int) Math.round(albedo * 255.0);
                pixels[index] = Color.argb(255, gray, gray, gray);
            }
        }

        // A large set of deterministic craters. Drawing the craters into the
        // albedo first means the phase light naturally shades their interiors.
        Paint crater = new Paint(Paint.ANTI_ALIAS_FLAG);
        for (int i = 0; i < 115; i++) {
            double angle = i * 2.399963229728653 + 0.17;
            double radial = Math.sqrt((i + 0.7) / 115.7) * 0.86;
            float cx = center + (float) Math.cos(angle) * (float) (radius * radial);
            float cy = center + (float) Math.sin(angle) * (float) (radius * radial);
            float craterRadius = radius * (0.006f + (float) hash01(i * 17 + 9) * 0.028f);

            crater.setStyle(Paint.Style.FILL);
            crater.setColor(Color.argb(24 + (int) (hash01(i * 31 + 5) * 22), 24, 24, 24));
            canvas.drawCircle(cx, cy, craterRadius, crater);

            crater.setStyle(Paint.Style.STROKE);
            crater.setStrokeWidth(Math.max(1f, craterRadius * 0.18f));
            crater.setColor(Color.argb(22, 255, 255, 255));
            canvas.drawCircle(cx - craterRadius * 0.10f,
                    cy - craterRadius * 0.10f,
                    craterRadius * 0.82f,
                    crater);
        }

        bitmap.setPixels(pixels, 0, size, 0, 0, size, size);
        // Repaint crater layer on top of the base pixels.
        canvas = new Canvas(bitmap);
        for (int i = 0; i < 115; i++) {
            double angle = i * 2.399963229728653 + 0.17;
            double radial = Math.sqrt((i + 0.7) / 115.7) * 0.86;
            float cx = center + (float) Math.cos(angle) * (float) (radius * radial);
            float cy = center + (float) Math.sin(angle) * (float) (radius * radial);
            float craterRadius = radius * (0.006f + (float) hash01(i * 17 + 9) * 0.028f);
            crater.setStyle(Paint.Style.FILL);
            crater.setColor(Color.argb(20 + (int) (hash01(i * 31 + 5) * 25), 22, 22, 22));
            canvas.drawCircle(cx, cy, craterRadius, crater);
            crater.setStyle(Paint.Style.STROKE);
            crater.setStrokeWidth(Math.max(1f, craterRadius * 0.18f));
            crater.setColor(Color.argb(18, 255, 255, 255));
            canvas.drawCircle(cx - craterRadius * 0.10f, cy - craterRadius * 0.10f,
                    craterRadius * 0.82f, crater);
        }

        bitmap.getPixels(pixels, 0, size, 0, 0, size, size);

        double theta = 2.0 * Math.PI * phaseFraction;
        double sunX = Math.sin(theta);
        double sunY = 0.08;
        double sunZ = -Math.cos(theta);
        double sunLength = Math.sqrt(sunX * sunX + sunY * sunY + sunZ * sunZ);
        sunX /= sunLength;
        sunY /= sunLength;
        sunZ /= sunLength;

        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                int index = y * size + x;
                int alpha = Color.alpha(pixels[index]);
                if (alpha == 0) {
                    continue;
                }

                double nx = (x - center) / radius;
                double ny = (y - center) / radius;
                double rr = nx * nx + ny * ny;
                if (rr > 1.0) {
                    pixels[index] = Color.TRANSPARENT;
                    continue;
                }

                double nz = Math.sqrt(Math.max(0.0, 1.0 - rr));
                double light = nx * sunX + ny * sunY + nz * sunZ;
                double diffuse = Math.max(0.0, light);

                // Slight earthshine on the night side; nearly invisible except
                // around a crescent, which gives the Moon better spherical depth.
                double earthshine = 0.035 + 0.020 * (1.0 - nz);
                double intensity = earthshine + Math.pow(diffuse, 0.92) * 0.98;
                intensity = Math.max(0.0, Math.min(1.0, intensity));

                // Limb darkening for a more photographic sphere.
                double limb = Math.pow(Math.max(0.0, nz), 0.18);
                intensity *= 0.78 + 0.22 * limb;

                int base = pixels[index];
                int r = Color.red(base);
                int g = Color.green(base);
                int b = Color.blue(base);

                // Tiny warm-gray bias approximates the Moon's neutral, dusty tone.
                int outR = clamp((int) Math.round(r * intensity * 1.01));
                int outG = clamp((int) Math.round(g * intensity));
                int outB = clamp((int) Math.round(b * intensity * 0.99));

                // Smooth anti-aliased edge instead of a hard pixel circle.
                double edge = 1.0 - smoothStep(0.965, 1.0, rr);
                pixels[index] = Color.argb((int) Math.round(255.0 * edge), outR, outG, outB);
            }
        }
        bitmap.setPixels(pixels, 0, size, 0, 0, size, size);

        Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
        rim.setStyle(Paint.Style.STROKE);
        rim.setStrokeWidth(Math.max(1f, size * 0.006f));
        rim.setColor(Color.argb(80, 255, 255, 255));
        canvas = new Canvas(bitmap);
        canvas.drawCircle(center, center, radius, rim);

        return bitmap;
    }

    private static int clamp(int value) {
        return Math.max(0, Math.min(255, value));
    }

    private static double hash01(int n) {
        long x = n * 0x9E3779B97F4A7C15L + 0xBF58476D1CE4E5B9L;
        x = (x ^ (x >>> 30)) * 0xBF58476D1CE4E5B9L;
        x = (x ^ (x >>> 27)) * 0x94D049BB133111EBL;
        x ^= (x >>> 31);
        return (x & 0x7fffffffffffffffL) / (double) Long.MAX_VALUE;
    }

    private static double noise2(double x, double y) {
        int xi = (int) Math.floor(x);
        int yi = (int) Math.floor(y);
        double xf = x - xi;
        double yf = y - yi;
        double u = xf * xf * (3.0 - 2.0 * xf);
        double v = yf * yf * (3.0 - 2.0 * yf);
        double a = hashGrid(xi, yi);
        double b = hashGrid(xi + 1, yi);
        double c = hashGrid(xi, yi + 1);
        double d = hashGrid(xi + 1, yi + 1);
        return lerp(lerp(a, b, u), lerp(c, d, u), v);
    }

    private static double hashGrid(int x, int y) {
        int n = x * 374761393 + y * 668265263;
        n = (n ^ (n >>> 13)) * 1274126177;
        n ^= (n >>> 16);
        return (n & 0x7fffffff) / 2147483647.0;
    }

    private static double fbm(double x, double y, int octaves) {
        double value = 0.0;
        double amplitude = 0.5;
        double frequency = 1.0;
        double norm = 0.0;
        for (int i = 0; i < octaves; i++) {
            value += noise2(x * frequency, y * frequency) * amplitude;
            norm += amplitude;
            frequency *= 2.0;
            amplitude *= 0.5;
        }
        return value / norm;
    }

    private static double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }

    private static double smoothStep(double edge0, double edge1, double x) {
        double t = Math.max(0.0, Math.min(1.0, (x - edge0) / (edge1 - edge0)));
        return t * t * (3.0 - 2.0 * t);
    }

    private static final class LunarData {
        final double phaseFraction;
        final double illumination;
        final String phaseName;
        final String dateText;

        LunarData(double phaseFraction, double illumination,
                  String phaseName, String dateText) {
            this.phaseFraction = phaseFraction;
            this.illumination = illumination;
            this.phaseName = phaseName;
            this.dateText = dateText;
        }
    }
}

