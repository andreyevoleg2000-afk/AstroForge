package com.astroforge;

import android.animation.ValueAnimator;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Всплывающее окно "Скорость объекта".
 *
 * Расширенный расчёт крутится в отдельном foreground-сервисе NBodySimulationService:
 * - не блокирует UI и не ловит ANR;
 * - не умирает при сворачивании/закрытии окна (пока висит уведомление);
 * - при повторном открытии окна подхватывает текущий прогресс/результат из ResultStore.
 *
 * Рендер результата (renderNBodyResult) умеет показывать индикатор точности орбит и
 * на сверхдлинных промежутках (качество "низкая") рисовать среднюю орбитальную скорость
 * вместо мгновенной — чтобы не было "бзыков"-алиасинга.
 *
 * AIDE-safe: без лямбд, без androidx, diamond с явным типом, все захваченные
 * в анонимный класс локальные переменные — final.
 */
final class VelocityPanel {

    private static final int ACCENT_COLOR        = 0xFFD9946B;
    private static final int ACCENT_BORDER_COLOR = Color.parseColor("#CCD9946B");
    private static final int FIELD_BG_COLOR      = Color.parseColor("#F21C1C1E");
    private static final int FIELD_BORDER_COLOR  = Color.parseColor("#B3E3E3E3");
    private static final int PILL_BG_COLOR       = Color.BLACK;
    private static final int DROPDOWN_BG_COLOR   = Color.parseColor("#FF1C1C1E");

    /** Графитовый цвет для кнопок-панелек на ГЛАВНОМ экране (не в этом окне). */
    static final int PANEL_BG_COLOR = Color.parseColor("#2E2E31");

    /** Потолок шагов интегрирования, чтобы телефон не умирал на гигантских промежутках. */
    private static final int MAX_STEPS = 600000;

    private static final String ACTION_PROGRESS = NBodySimulationService.ACTION_PROGRESS;
    private static final String ACTION_DONE     = NBodySimulationService.ACTION_DONE;
    private static final String ACTION_ERROR    = NBodySimulationService.ACTION_ERROR;

    private final Context context;
    private final FrameLayout rootContainer;
    private final Typeface typefaceRegular;
    private final Typeface typefaceSemiBold;

    private FrameLayout overlayRoot;
    private FrameLayout windowFrame;
    private FrameLayout dropdownLayer;

    private PixelFillOverlay pixelFillOverlay;
    private ValueAnimator openAnimator;
    private ValueAnimator closeAnimator;
    private boolean isClosing = false;

    private static final int CLOSE_DIRECTION_CENTER = 0;
    private static final int CLOSE_DIRECTION_LEFT = -1;
    private static final int CLOSE_DIRECTION_RIGHT = 1;

    private boolean swipeClosing = false;
    private boolean swipeFromLeftEdge = false;
    private float swipeStartX = 0f;
    private float swipeStartY = 0f;
    private float swipeLastDx = 0f;
    private float swipeLastDy = 0f;

    private static final long OPEN_ANIM_DURATION_MS = 360L;
    private static final long CLOSE_ANIM_DURATION_MS = 220L;

    private EditText parentMassInput;
    private UnitPillState parentMassUnit;

    private EditText distanceInput;
    private UnitPillState distanceUnit;

    private EditText secondMassInput;
    private UnitPillState secondMassUnit;

    private EditText parentNameInput;
    private EditText orbitalNameInput;

    private boolean advancedMode = false;
    private LinearLayout advancedContainer;

    private final List<ExtraBodyRow> extraBodyRows = new ArrayList<ExtraBodyRow>();

    private EditText timeSpanInput;
    private UnitPillState timeSpanUnit;

    private LinearLayout resultContainer;

    private android.content.BroadcastReceiver simReceiver;
    private CalculationProgressOverlay calculationOverlay;
    private double calculationTotalSeconds = 0.0;

    private final android.os.Handler uiHandler =
	new android.os.Handler(android.os.Looper.getMainLooper());

    private Runnable progressPoller;

    private VelocityPanel(Context context,
                          FrameLayout rootContainer,
                          Typeface typefaceRegular,
                          Typeface typefaceSemiBold) {
        this.context = context;
        this.rootContainer = rootContainer;
        this.typefaceRegular = typefaceRegular;
        this.typefaceSemiBold = typefaceSemiBold;
    }

    static void show(Context context,
                     FrameLayout rootContainer,
                     Typeface typefaceRegular,
                     Typeface typefaceSemiBold) {
        new VelocityPanel(context, rootContainer, typefaceRegular, typefaceSemiBold).build();
    }

    private int dp(float value) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            context.getResources().getDisplayMetrics()
        );
    }

    // =========================================================
    //  Построение окна
    // =========================================================

    private void build() {
        overlayRoot = new FrameLayout(context);
        overlayRoot.setBackgroundColor(Color.parseColor("#CC0F0F10"));
        overlayRoot.setClickable(true);
        overlayRoot.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    close();
                }
            });

        windowFrame = new FrameLayout(context);
        windowFrame.setClickable(true);
        windowFrame.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    /* поглощаем клик */
                }
            });

        overlayRoot.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    return handleEdgeSwipe(event);
                }
            });

        GradientDrawable frameBg = new GradientDrawable();
        frameBg.setShape(GradientDrawable.RECTANGLE);
        frameBg.setCornerRadius(dp(28));
        frameBg.setColor(0xF21E1E20);
        frameBg.setStroke(dp(2), ACCENT_COLOR);
        windowFrame.setBackground(frameBg);
        windowFrame.setClipToOutline(true);
        windowFrame.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);

        android.widget.ImageView blurBg = new android.widget.ImageView(context);
        blurBg.setImageResource(R.drawable.background);
        blurBg.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        blurBg.setRenderEffect(RenderEffect.createBlurEffect(dp(44), dp(44), Shader.TileMode.CLAMP));
        blurBg.setAlpha(0.88f);
        windowFrame.addView(blurBg, matchParentFrameLp());

        View tint = new View(context);
        tint.setBackgroundColor(Color.parseColor("#CC232326"));
        windowFrame.addView(tint, matchParentFrameLp());
        AstroUiEffects.applyPaperEffect(windowFrame, context);

        ScrollView scrollView = new ScrollView(context);
        scrollView.setClipToPadding(false);

        LinearLayout content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);

        int pad = dp(20);
        content.setPadding(pad, pad, pad, pad);

        content.addView(buildTitle());
        content.addView(spacer(dp(18)));

        content.addView(buildLabel("Масса родительского тела"));
        content.addView(spacer(dp(6)));
        ValueUnitRow parentMassRow = buildMassField();
        parentMassInput = parentMassRow.input;
        parentMassUnit  = parentMassRow.unitState;
        content.addView(parentMassRow.row);

        content.addView(spacer(dp(14)));

        content.addView(buildLabel("Расстояние до родительского тела"));
        content.addView(spacer(dp(6)));
        ValueUnitRow distanceRow = buildDistanceField();
        distanceInput = distanceRow.input;
        distanceUnit  = distanceRow.unitState;
        content.addView(distanceRow.row);

        content.addView(spacer(dp(14)));

        content.addView(buildLabel("Масса второго тела (необязательно, для парного вращения)"));
        content.addView(spacer(dp(6)));
        ValueUnitRow secondMassRow = buildMassFieldSecondary();
        secondMassInput = secondMassRow.input;
        secondMassUnit  = secondMassRow.unitState;
        content.addView(secondMassRow.row);

        content.addView(spacer(dp(14)));

        content.addView(buildLabel("Название родительского тела"));
        content.addView(spacer(dp(6)));
        parentNameInput = buildPlainTextField("Например, Земля");
        content.addView(parentNameInput);

        content.addView(spacer(dp(14)));

        content.addView(buildLabel("Название орбитального тела"));
        content.addView(spacer(dp(6)));
        orbitalNameInput = buildPlainTextField("Например, спутник");
        content.addView(orbitalNameInput);

        content.addView(spacer(dp(18)));

        content.addView(buildAdvancedToggleButton());
        content.addView(spacer(dp(4)));
        content.addView(buildExperimentalHint());
        content.addView(spacer(dp(10)));

        advancedContainer = new LinearLayout(context);
        advancedContainer.setOrientation(LinearLayout.VERTICAL);
        advancedContainer.setVisibility(View.GONE);
        buildAdvancedContent(advancedContainer);
        content.addView(advancedContainer);

        content.addView(spacer(dp(18)));
        content.addView(buildCalculateButton());
        content.addView(spacer(dp(14)));
        content.addView(buildExplanationBlock());
        content.addView(spacer(dp(10)));

        resultContainer = new LinearLayout(context);
        resultContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(resultContainer);

        content.addView(spacer(dp(20)));

        scrollView.addView(content, new ScrollView.LayoutParams(
                               ScrollView.LayoutParams.MATCH_PARENT,
                               ScrollView.LayoutParams.WRAP_CONTENT
                           ));

        windowFrame.addView(scrollView, matchParentFrameLp());
        attachPixelFillOverlay();

        FrameLayout.LayoutParams windowLp = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        );

        int screenMargin = dp(18);
        windowLp.setMargins(
            screenMargin,
            screenMargin + dp(30),
            screenMargin,
            screenMargin + dp(30)
        );

        overlayRoot.addView(windowFrame, windowLp);
        rootContainer.addView(overlayRoot, matchParentFrameLp());

        windowFrame.post(new Runnable() {
                @Override
                public void run() {
                    if (overlayRoot != null && overlayRoot.getParent() == rootContainer) {
                        startOpenAnimation();
                    }
                }
            });

        dropdownLayer = new FrameLayout(context);
        dropdownLayer.setClipChildren(false);
        dropdownLayer.setClipToPadding(false);
        dropdownLayer.setElevation(dp(1000));
        overlayRoot.addView(dropdownLayer, matchParentFrameLp());
        dropdownLayer.bringToFront();

        restoreLastResultIfNeeded();
    }

    private void close() {
        beginClose(CLOSE_DIRECTION_CENTER);
    }

    private void beginClose(int direction) {
        stopProgressPolling();
        unregisterSimReceiver();

        if (isClosing) {
            return;
        }

        if (overlayRoot == null || overlayRoot.getParent() != rootContainer) {
            return;
        }

        isClosing = true;
        swipeClosing = false;
        startCloseAnimation(direction);
    }


    private void startOpenAnimation() {
        if (windowFrame == null) return;

        if (openAnimator != null) {
            openAnimator.cancel();
            openAnimator = null;
        }
        if (closeAnimator != null) {
            closeAnimator.cancel();
            closeAnimator = null;
        }

        swipeClosing = false;
        swipeFromLeftEdge = false;

        windowFrame.setPivotX(windowFrame.getWidth() * 0.5f);
        windowFrame.setPivotY(windowFrame.getHeight() * 0.5f);
        windowFrame.setScaleX(0.965f);
        windowFrame.setScaleY(0.965f);
        windowFrame.setTranslationX(0f);
        windowFrame.setTranslationY(dp(10));

        if (pixelFillOverlay != null) {
            pixelFillOverlay.setVisibility(View.VISIBLE);
            pixelFillOverlay.setProgress(0f);
            pixelFillOverlay.setAlpha(1f);
        }

        openAnimator = ValueAnimator.ofFloat(0f, 1f);
        openAnimator.setDuration(OPEN_ANIM_DURATION_MS);
        openAnimator.setInterpolator(new DecelerateInterpolator(1.8f));
        openAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator animation) {
                    float p = ((Float) animation.getAnimatedValue()).floatValue();
                    if (windowFrame != null) {
                        windowFrame.setScaleX(0.965f + (0.035f * p));
                        windowFrame.setScaleY(0.965f + (0.035f * p));
                        windowFrame.setTranslationX(0f);
                        windowFrame.setTranslationY(dp(10) * (1f - p));
                    }
                    if (pixelFillOverlay != null) {
                        pixelFillOverlay.setProgress(p);
                        if (p >= 1f) {
                            pixelFillOverlay.setVisibility(View.GONE);
                        }
                    }
                }
            });
        openAnimator.start();
    }

    private void startCloseAnimation(final int direction) {
        if (windowFrame == null || overlayRoot == null) {
            performImmediateClose();
            return;
        }

        if (openAnimator != null) {
            openAnimator.cancel();
            openAnimator = null;
        }
        if (closeAnimator != null) {
            closeAnimator.cancel();
            closeAnimator = null;
        }

        final float endScale = 0.72f;
        final float endOffsetX;
        if (direction == CLOSE_DIRECTION_LEFT) {
            endOffsetX = -Math.max(dp(96), windowFrame.getWidth() * 0.22f);
        } else if (direction == CLOSE_DIRECTION_RIGHT) {
            endOffsetX = Math.max(dp(96), windowFrame.getWidth() * 0.22f);
        } else {
            endOffsetX = 0f;
        }
        final float endOffsetY = Math.max(dp(90), windowFrame.getHeight() * 0.18f);

        if (direction == CLOSE_DIRECTION_LEFT) {
            windowFrame.setPivotX(0f);
            windowFrame.setPivotY(windowFrame.getHeight());
        } else if (direction == CLOSE_DIRECTION_RIGHT) {
            windowFrame.setPivotX(windowFrame.getWidth());
            windowFrame.setPivotY(windowFrame.getHeight());
        } else {
            windowFrame.setPivotX(windowFrame.getWidth() * 0.5f);
            windowFrame.setPivotY(windowFrame.getHeight() * 0.5f);
        }

        if (pixelFillOverlay != null) {
            pixelFillOverlay.setVisibility(View.VISIBLE);
            pixelFillOverlay.setProgress(1f);
            pixelFillOverlay.setAlpha(1f);
        }

        closeAnimator = ValueAnimator.ofFloat(1f, 0f);
        closeAnimator.setDuration(CLOSE_ANIM_DURATION_MS);
        closeAnimator.setInterpolator(new AccelerateInterpolator(1.6f));
        closeAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator animation) {
                    float p = ((Float) animation.getAnimatedValue()).floatValue();
                    float fraction = 1f - p;
                    if (windowFrame != null) {
                        float scale = 1f - ((1f - endScale) * fraction);
                        windowFrame.setScaleX(scale);
                        windowFrame.setScaleY(scale);
                        windowFrame.setTranslationX(endOffsetX * fraction);
                        windowFrame.setTranslationY(endOffsetY * fraction);
                    }
                    if (pixelFillOverlay != null) {
                        pixelFillOverlay.setProgress(p);
                    }
                }
            });
        closeAnimator.addListener(new android.animation.Animator.AnimatorListener() {
                @Override
                public void onAnimationStart(android.animation.Animator animation) { }

                @Override
                public void onAnimationEnd(android.animation.Animator animation) {
                    performImmediateClose();
                }

                @Override
                public void onAnimationCancel(android.animation.Animator animation) {
                    performImmediateClose();
                }

                @Override
                public void onAnimationRepeat(android.animation.Animator animation) { }
            });
        closeAnimator.start();
    }

    private boolean handleEdgeSwipe(MotionEvent event) {
        if (overlayRoot == null || windowFrame == null || overlayRoot.getParent() != rootContainer) {
            return false;
        }

        int action = event.getActionMasked();
        int edge = dp(28);

        switch (action) {
            case MotionEvent.ACTION_DOWN: {
                    float x = event.getX();
                    float y = event.getY();
                    int w = overlayRoot.getWidth();
                    if (w <= 0) {
                        return false;
                    }

                    boolean fromLeft = x <= edge;
                    boolean fromRight = x >= (w - edge);
                    if (!fromLeft && !fromRight) {
                        return false;
                    }

                    swipeClosing = true;
                    swipeFromLeftEdge = fromLeft;
                    swipeStartX = x;
                    swipeStartY = y;
                    swipeLastDx = 0f;
                    swipeLastDy = 0f;
                    return true;
                }

            case MotionEvent.ACTION_MOVE: {
                    if (!swipeClosing) {
                        return false;
                    }

                    swipeLastDx = event.getX() - swipeStartX;
                    swipeLastDy = event.getY() - swipeStartY;

                    float drag = swipeFromLeftEdge ? swipeLastDx : -swipeLastDx;
                    if (drag < 0f) {
                        drag = 0f;
                    }

                    float progress = Math.min(1f, drag / (float) dp(220));
                    float scale = 1f - (0.28f * progress);
                    float tx = (swipeFromLeftEdge ? -1f : 1f) * Math.max(dp(24), windowFrame.getWidth() * 0.22f) * progress;
                    float ty = Math.max(dp(18), windowFrame.getHeight() * 0.18f) * progress;

                    if (swipeFromLeftEdge) {
                        windowFrame.setPivotX(0f);
                    } else {
                        windowFrame.setPivotX(windowFrame.getWidth());
                    }
                    windowFrame.setPivotY(windowFrame.getHeight());
                    windowFrame.setScaleX(scale);
                    windowFrame.setScaleY(scale);
                    windowFrame.setTranslationX(tx);
                    windowFrame.setTranslationY(ty);

                    return true;
                }

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                    if (!swipeClosing) {
                        return false;
                    }

                    float drag = swipeFromLeftEdge ? swipeLastDx : -swipeLastDx;
                    boolean shouldClose = drag >= dp(84) || Math.abs(swipeLastDx) >= dp(84);

                    if (shouldClose) {
                        beginClose(swipeFromLeftEdge ? CLOSE_DIRECTION_LEFT : CLOSE_DIRECTION_RIGHT);
                    } else {
                        cancelSwipeGesture();
                    }
                    return true;
                }

            default:
                return swipeClosing;
        }
    }

    private void cancelSwipeGesture() {
        swipeClosing = false;
        if (windowFrame == null) {
            return;
        }

        windowFrame.setPivotX(windowFrame.getWidth() * 0.5f);
        windowFrame.setPivotY(windowFrame.getHeight() * 0.5f);
        windowFrame.animate()
            .scaleX(1f)
            .scaleY(1f)
            .translationX(0f)
            .translationY(0f)
            .setDuration(180L)
            .setInterpolator(new DecelerateInterpolator(1.6f))
            .start();
    }

    private void performImmediateClose() {
        if (overlayRoot != null && overlayRoot.getParent() == rootContainer) {
            rootContainer.removeView(overlayRoot);
        }

        if (openAnimator != null) {
            openAnimator.cancel();
            openAnimator = null;
        }
        if (closeAnimator != null) {
            closeAnimator.removeAllListeners();
            closeAnimator.cancel();
            closeAnimator = null;
        }

        if (pixelFillOverlay != null) {
            pixelFillOverlay.setProgress(1f);
            pixelFillOverlay.setVisibility(View.GONE);
        }

        overlayRoot = null;
        windowFrame = null;
        pixelFillOverlay = null;
        isClosing = false;
        swipeClosing = false;
        swipeFromLeftEdge = false;
        swipeStartX = 0f;
        swipeStartY = 0f;
        swipeLastDx = 0f;
        swipeLastDy = 0f;
    }

    private void attachPixelFillOverlay() {
        if (windowFrame == null) return;

        pixelFillOverlay = new PixelFillOverlay(context);
        pixelFillOverlay.setVisibility(View.VISIBLE);
        windowFrame.addView(pixelFillOverlay, matchParentFrameLp());
        pixelFillOverlay.bringToFront();
    }

    private final class PixelFillOverlay extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Rect rect = new Rect();
        private float progress = 0f;
        private int cachedW = -1;
        private int cachedH = -1;
        private int tilePx = 1;
        private int cols = 0;
        private int rows = 0;
        private float[] thresholds = new float[0];

        PixelFillOverlay(Context context) {
            super(context);
            paint.setStyle(Paint.Style.FILL);
            setWillNotDraw(false);
            setClickable(false);
            setFocusable(false);
            setBackgroundColor(Color.TRANSPARENT);
        }

        void setProgress(float p) {
            if (p < 0f) p = 0f;
            if (p > 1f) p = 1f;
            if (progress == p) return;
            progress = p;
            invalidate();
        }

        private void ensureGeometry(int w, int h) {
            if (w == cachedW && h == cachedH && thresholds.length == cols * rows) {
                return;
            }

            cachedW = w;
            cachedH = h;

            int base = Math.min(w, h) / 18;
            tilePx = Math.max(dp(20), base);
            if (tilePx <= 0) tilePx = dp(20);

            cols = Math.max(1, (int) Math.ceil((double) w / (double) tilePx));
            rows = Math.max(1, (int) Math.ceil((double) h / (double) tilePx));
            thresholds = new float[cols * rows];

            float cx = w * 0.5f;
            float cy = h * 0.5f;
            float maxDist = (float) Math.sqrt((cx * cx) + (cy * cy));
            if (maxDist <= 0f) maxDist = 1f;

            int index = 0;
            for (int row = 0; row < rows; row++) {
                float y = (row * tilePx) + (tilePx * 0.5f);
                for (int col = 0; col < cols; col++) {
                    float x = (col * tilePx) + (tilePx * 0.5f);
                    float dx = x - cx;
                    float dy = y - cy;
                    float norm = (float) Math.sqrt((dx * dx) + (dy * dy)) / maxDist;
                    if (norm < 0f) norm = 0f;
                    if (norm > 1f) norm = 1f;
                    thresholds[index++] = norm;
                }
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;

            ensureGeometry(w, h);

            // Держим блоки тяжёлыми только в начале, затем быстро "тают" и не жрут FPS.
            final int baseAlpha = 220;
            final int fillColor = 0xF21E1E20;
            final int accentColor = 0xFFD9946B;

            int fillR = Color.red(fillColor);
            int fillG = Color.green(fillColor);
            int fillB = Color.blue(fillColor);
            int accentR = Color.red(accentColor);
            int accentG = Color.green(accentColor);
            int accentB = Color.blue(accentColor);

            int index = 0;
            for (int row = 0; row < rows; row++) {
                int top = row * tilePx;
                int bottom = Math.min(h, top + tilePx);

                for (int col = 0; col < cols; col++) {
                    int left = col * tilePx;
                    int right = Math.min(w, left + tilePx);

                    float threshold = thresholds[index++];
                    float local = progress - threshold;

                    float alpha01;
                    if (local <= 0f) {
                        alpha01 = 1f;
                    } else if (local >= 0.16f) {
                        alpha01 = 0f;
                    } else {
                        float t = local / 0.16f;
                        alpha01 = 1f - (t * t * (3f - 2f * t));
                    }

                    if (alpha01 <= 0.01f) {
                        continue;
                    }

                    int alpha = (int) (baseAlpha * alpha01);
                    if (((row + col) & 7) == 0) {
                        paint.setColor(Color.argb(alpha, accentR, accentG, accentB));
                    } else if (((row + col) & 3) == 0) {
                        paint.setColor(Color.argb(alpha, 52, 46, 44));
                    } else {
                        paint.setColor(Color.argb(alpha, fillR, fillG, fillB));
                    }

                    rect.set(left, top, right, bottom);
                    canvas.drawRect(rect, paint);
                }
            }
        }
    }

    // =========================================================
    //  Мелкие UI-хелперы
    // =========================================================

    private View buildTitle() {
        TextView tv = new DigitTextView(context);
        tv.setText("Скорость объекта");
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        tv.setGravity(Gravity.START | Gravity.TOP);
        return tv;
    }

    private TextView buildLabel(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#DDE3E1DE"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        return tv;
    }

    private View spacer(int heightPx) {
        View v = new View(context);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                              LinearLayout.LayoutParams.MATCH_PARENT,
                              heightPx
                          ));
        return v;
    }

    // =========================================================
    //  Поля с единицами
    // =========================================================

    private static final class ValueUnitRow {
        View row;
        EditText input;
        UnitPillState unitState;
    }

    private static final class UnitPillState {
        TextView pillView;
        int selectedIndex = 0;
        String[] labels;
    }

    private ValueUnitRow buildMassField() {
        String[] labels = new String[PhysicsEngine.MassUnit.values().length];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = PhysicsEngine.MassUnit.values()[i].label;
        }
        return buildValueUnitRow(labels, "Введите массу");
    }

    private ValueUnitRow buildMassFieldSecondary() {
        String[] labels = new String[PhysicsEngine.MassUnit.values().length];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = PhysicsEngine.MassUnit.values()[i].label;
        }
        return buildValueUnitRow(labels, "Необязательно");
    }

    private ValueUnitRow buildDistanceField() {
        String[] labels = new String[PhysicsEngine.DistanceUnit.values().length];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = PhysicsEngine.DistanceUnit.values()[i].label;
        }
        return buildValueUnitRow(labels, "Введите расстояние");
    }

    private ValueUnitRow buildExtraDistanceField() {
        String[] labels = new String[PhysicsEngine.DistanceUnit.values().length];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = PhysicsEngine.DistanceUnit.values()[i].label;
        }
        return buildValueUnitRow(labels, "До родителя");
    }

    private ValueUnitRow buildTimeField() {
        String[] labels = new String[PhysicsEngine.TimeUnit.values().length];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = PhysicsEngine.TimeUnit.values()[i].label;
        }
        return buildValueUnitRow(labels, "Промежуток времени");
    }

    private ValueUnitRow buildValueUnitRow(final String[] unitLabels, String hint) {
        FrameLayout field = new FrameLayout(context);
        field.setBackground(createRoundedRect(dp(16), FIELD_BG_COLOR, FIELD_BORDER_COLOR, dp(1.25f)));
        AstroUiEffects.applyControlShadow(field, context);
        field.setClipToOutline(true);

        final EditText input = new DigitEditText(context);
        input.setHint(hint);
        input.setHintTextColor(Color.parseColor("#77FFFFFF"));
        input.setTextColor(Color.WHITE);
        input.setTypeface(typefaceRegular);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        input.setSingleLine(true);
        input.setBackground(null);
        AstroUiEffects.applyControlShadow(input, context);
        input.setInputType(InputType.TYPE_CLASS_NUMBER
                           | InputType.TYPE_NUMBER_FLAG_DECIMAL
                           | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setPadding(dp(16), dp(12), dp(120), dp(12));
        field.addView(input, matchParentFrameLp());

        final UnitPillState state = new UnitPillState();
        state.labels = unitLabels;
        state.selectedIndex = 0;

        final TextView pill = new DigitTextView(context);
        pill.setText(unitLabels[0]);
        pill.setTextColor(Color.WHITE);
        pill.setTypeface(typefaceSemiBold);
        pill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        pill.setGravity(Gravity.CENTER);
        pill.setMaxLines(1);
        pill.setEllipsize(android.text.TextUtils.TruncateAt.END);
        pill.setBackground(createRoundedRect(dp(14), PILL_BG_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        pill.setPadding(dp(12), dp(8), dp(12), dp(8));
        pill.setClickable(true);
        pill.setFocusable(true);

        FrameLayout.LayoutParams pillLp = new FrameLayout.LayoutParams(
            dp(104),
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        pillLp.gravity = Gravity.CENTER_VERTICAL | Gravity.END;
        pillLp.rightMargin = dp(8);
        field.addView(pill, pillLp);
        pill.setTranslationZ(dp(3f));

        state.pillView = pill;

        pill.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    HapticUtils.perform(v);
                    openDropdown(pill, unitLabels, state.selectedIndex, new OnUnitSelected() {
                            @Override
                            public void onSelected(int newIndex) {
                                state.selectedIndex = newIndex;
                                pill.setText(unitLabels[newIndex]);
                            }
                        });
                }
            });

        field.setLayoutParams(new LinearLayout.LayoutParams(
                                  LinearLayout.LayoutParams.MATCH_PARENT,
                                  dp(50)
                              ));

        ValueUnitRow row = new ValueUnitRow();
        row.row = field;
        row.input = input;
        row.unitState = state;
        return row;
    }

    private EditText buildPlainTextField(String hint) {
        EditText input = new DigitEditText(context);
        input.setHint(hint);
        input.setHintTextColor(Color.parseColor("#77FFFFFF"));
        input.setTextColor(Color.WHITE);
        input.setTypeface(typefaceRegular);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        input.setSingleLine(true);
        input.setBackground(createRoundedRect(dp(16), FIELD_BG_COLOR, FIELD_BORDER_COLOR, dp(1.25f)));
        AstroUiEffects.applyControlShadow(input, context);
        input.setPadding(dp(16), dp(12), dp(16), dp(12));
        input.setLayoutParams(new LinearLayout.LayoutParams(
                                  LinearLayout.LayoutParams.MATCH_PARENT,
                                  dp(50)
                              ));
        return input;
    }

    // =========================================================
    //  Dropdown
    // =========================================================

    private interface OnUnitSelected {
        void onSelected(int index);
    }

    private void openDropdown(final View anchor,
                              final String[] labels,
                              int selectedIndex,
                              final OnUnitSelected callback) {
        dropdownLayer.removeAllViews();
        dropdownLayer.bringToFront();

        int[] anchorLoc = new int[2];
        anchor.getLocationOnScreen(anchorLoc);

        int[] rootLoc = new int[2];
        dropdownLayer.getLocationOnScreen(rootLoc);

        int relativeX = anchorLoc[0] - rootLoc[0];
        int relativeY = anchorLoc[1] - rootLoc[1];
        int anchorBottom = relativeY + anchor.getHeight();

        Rect visibleFrame = new Rect();
        rootContainer.getWindowVisibleDisplayFrame(visibleFrame);

        int visibleTop = visibleFrame.top - rootLoc[1];
        int visibleBottom = visibleFrame.bottom - rootLoc[1];

        View scrim = new View(context);
        scrim.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dropdownLayer.removeAllViews();
                }
            });
        dropdownLayer.addView(scrim, matchParentFrameLp());

        LinearLayout list = new LinearLayout(context);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setBackground(createRoundedRect(dp(14), DROPDOWN_BG_COLOR, ACCENT_BORDER_COLOR, dp(1.25f)));
        list.setClipToOutline(true);
        list.setPadding(dp(6), dp(6), dp(6), dp(6));

        for (int i = 0; i < labels.length; i++) {
            final int idx = i;

            TextView item = new DigitTextView(context);
            item.setText(labels[i]);
            item.setTextColor(i == selectedIndex ? ACCENT_COLOR : Color.WHITE);
            item.setTypeface(i == selectedIndex ? typefaceSemiBold : typefaceRegular);
            AstroUiEffects.applyUnitTypeface(item, context);
            item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            item.setPadding(dp(14), dp(10), dp(14), dp(10));
            item.setClickable(true);
            item.setFocusable(true);

            item.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        HapticUtils.perform(v);
                        callback.onSelected(idx);
                        dropdownLayer.removeAllViews();
                    }
                });

            list.addView(item, new LinearLayout.LayoutParams(
                             LinearLayout.LayoutParams.MATCH_PARENT,
                             LinearLayout.LayoutParams.WRAP_CONTENT
                         ));
        }

        int estimatedHeight = dp(12) + (labels.length * dp(40));
        int spaceBelow = visibleBottom - anchorBottom - dp(8);
        int spaceAbove = relativeY - visibleTop - dp(8);

        if (spaceBelow < 0) spaceBelow = 0;
        if (spaceAbove < 0) spaceAbove = 0;

        boolean showAbove = spaceBelow < estimatedHeight && spaceAbove > spaceBelow;

        final int maxHeight = Math.max(
            0,
            Math.min(estimatedHeight, showAbove ? spaceAbove : spaceBelow)
        );

        ScrollView listScroll = new ScrollView(context) {
            @Override
            protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                int hSpec = heightMeasureSpec;

                if (maxHeight > 0) {
                    int mode = View.MeasureSpec.getMode(hSpec);
                    int size = View.MeasureSpec.getSize(hSpec);

                    if (mode == View.MeasureSpec.UNSPECIFIED || size > maxHeight) {
                        hSpec = View.MeasureSpec.makeMeasureSpec(maxHeight, View.MeasureSpec.AT_MOST);
                    }
                }

                super.onMeasure(widthMeasureSpec, hSpec);
            }
        };

        listScroll.addView(list, new ScrollView.LayoutParams(
                               ScrollView.LayoutParams.MATCH_PARENT,
                               ScrollView.LayoutParams.WRAP_CONTENT
                           ));

        listScroll.setBackground(list.getBackground());
        list.setBackground(null);
        listScroll.setVerticalScrollBarEnabled(false);
        listScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        FrameLayout.LayoutParams listLp = new FrameLayout.LayoutParams(
            dp(180),
            FrameLayout.LayoutParams.WRAP_CONTENT
        );

        listLp.leftMargin = Math.max(dp(8), relativeX + anchor.getWidth() - dp(180));

        if (showAbove) {
            listLp.topMargin = Math.max(visibleTop + dp(8), relativeY - maxHeight - dp(4));
        } else {
            listLp.topMargin = anchorBottom + dp(4);
        }

        dropdownLayer.addView(listScroll, listLp);
        listScroll.bringToFront();
    }

    // =========================================================
    //  Расширенный расчёт
    // =========================================================

    private View buildAdvancedToggleButton() {
        final TextView btn = new DigitTextView(context);
        btn.setText("+  Расширенный расчёт (n-body)");
        btn.setTextColor(Color.parseColor("#DDE3E1DE"));
        btn.setTypeface(typefaceRegular);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(dp(16), dp(12), dp(16), dp(12));

        GradientDrawable dashed = new GradientDrawable();
        dashed.setShape(GradientDrawable.RECTANGLE);
        dashed.setCornerRadius(dp(16));
        dashed.setColor(Color.TRANSPARENT);
        dashed.setStroke(dp(1.5f), Color.parseColor("#AAE3E3E3"), dp(8), dp(5));
        btn.setBackground(dashed);

        btn.setClickable(true);
        btn.setFocusable(true);
        btn.setLayoutParams(new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                            ));

        btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    HapticUtils.perform(v);
                    advancedMode = !advancedMode;
                    advancedContainer.setVisibility(advancedMode ? View.VISIBLE : View.GONE);
                    btn.setText(advancedMode
                                ? "−  Скрыть расширенный расчёт"
                                : "+  Расширенный расчёт (n-body)");
                }
            });

        return btn;
    }

    private View buildExperimentalHint() {
        TextView notice = new DigitTextView(context);
        notice.setText("Экспериментальная функция");
        notice.setTextColor(Color.parseColor("#FFF29B3B"));
        notice.setTypeface(typefaceRegular);
        notice.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        notice.setPadding(dp(4), dp(0), dp(4), dp(0));
        notice.setLayoutParams(new LinearLayout.LayoutParams(
                                   LinearLayout.LayoutParams.MATCH_PARENT,
                                   LinearLayout.LayoutParams.WRAP_CONTENT
                               ));
        return notice;
    }

    private void buildAdvancedContent(LinearLayout container) {
        container.addView(buildLabel("Промежуток времени симуляции"));
        container.addView(spacer(dp(6)));

        ValueUnitRow timeRow = buildTimeField();
        timeSpanInput = timeRow.input;
        timeSpanUnit  = timeRow.unitState;
        container.addView(timeRow.row);

        container.addView(spacer(dp(14)));

        container.addView(buildLabel("Дополнительные тела"));
        container.addView(spacer(dp(6)));

        final LinearLayout extraBodiesList = new LinearLayout(context);
        extraBodiesList.setOrientation(LinearLayout.VERTICAL);
        container.addView(extraBodiesList);

        container.addView(spacer(dp(8)));

        TextView addBodyBtn = new DigitTextView(context);
        addBodyBtn.setText("+  Добавить тело");
        addBodyBtn.setTextColor(Color.parseColor("#DDE3E1DE"));
        addBodyBtn.setTypeface(typefaceRegular);
        addBodyBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        addBodyBtn.setGravity(Gravity.CENTER);
        addBodyBtn.setPadding(dp(14), dp(10), dp(14), dp(10));

        GradientDrawable dashedSmall = new GradientDrawable();
        dashedSmall.setShape(GradientDrawable.RECTANGLE);
        dashedSmall.setCornerRadius(dp(14));
        dashedSmall.setColor(Color.TRANSPARENT);
        dashedSmall.setStroke(dp(1.25f), Color.parseColor("#88E3E3E3"), dp(7), dp(4));
        addBodyBtn.setBackground(dashedSmall);

        addBodyBtn.setClickable(true);
        addBodyBtn.setFocusable(true);
        addBodyBtn.setLayoutParams(new LinearLayout.LayoutParams(
                                       LinearLayout.LayoutParams.MATCH_PARENT,
                                       LinearLayout.LayoutParams.WRAP_CONTENT
                                   ));

        addBodyBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    HapticUtils.perform(v);
                    addExtraBodyRow(extraBodiesList);
                }
            });

        container.addView(addBodyBtn);

        addExtraBodyRow(extraBodiesList);
    }

    private static final class ExtraBodyRow {
        EditText nameInput;
        EditText massInput;
        UnitPillState massUnit;
        EditText distanceInput;
        UnitPillState distanceUnit;
        View rowView;
    }

    private void addExtraBodyRow(LinearLayout parent) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setLayoutParams(new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                            ));
        ((LinearLayout.LayoutParams) row.getLayoutParams()).bottomMargin = dp(10);

        EditText nameInput = buildPlainTextField("Название тела");
        row.addView(nameInput);
        row.addView(spacer(dp(6)));

        ValueUnitRow massRow = buildMassField();
        row.addView(massRow.row);
        row.addView(spacer(dp(10)));

        row.addView(buildLabel("Расстояние до родительского тела"));
        row.addView(spacer(dp(6)));

        ValueUnitRow distanceRow = buildExtraDistanceField();
        row.addView(distanceRow.row);

        parent.addView(row);

        ExtraBodyRow extra = new ExtraBodyRow();
        extra.nameInput = nameInput;
        extra.massInput = massRow.input;
        extra.massUnit  = massRow.unitState;
        extra.distanceInput = distanceRow.input;
        extra.distanceUnit  = distanceRow.unitState;
        extra.rowView = row;

        extraBodyRows.add(extra);
    }

    // =========================================================
    //  Кнопка расчёта и результат
    // =========================================================

    private View buildCalculateButton() {
        TextView btn = new DigitTextView(context);
        btn.setText("Рассчитать");
        btn.setTextColor(Color.WHITE);
        btn.setTypeface(typefaceSemiBold);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(0, dp(14), 0, dp(14));
        btn.setBackground(createRoundedRect(dp(18), ACCENT_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        AstroUiEffects.applyControlShadow(btn, context);
        btn.setClickable(true);
        btn.setFocusable(true);
        btn.setLayoutParams(new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                            ));

        btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    HapticUtils.perform(v);
                    onCalculatePressed();
                }
            });

        return btn;
    }

    private View buildExplanationBlock() {
        LinearLayout block = new LinearLayout(context);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setLayoutParams(new LinearLayout.LayoutParams(
                                  LinearLayout.LayoutParams.MATCH_PARENT,
                                  LinearLayout.LayoutParams.WRAP_CONTENT
                              ));

        TextView title = new DigitTextView(context);
        title.setText("Как считается скорость");
        title.setTextColor(Color.WHITE);
        title.setTypeface(typefaceSemiBold);

        AstroUiEffects.applyExplanationTypeface(title, context);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        block.addView(title);

        block.addView(spacer(dp(8)));
        block.addView(buildExplanationLine("1) Приводим массу M и расстояние r к SI."));
        block.addView(spacer(dp(4)));
        block.addView(buildExplanationLine("2) Гравитационный параметр: μ = G · M."));
        block.addView(spacer(dp(4)));
        block.addView(buildExplanationLine("3) Круговая скорость: v₁ = √(μ / r) = √(G · M / r)."));
        block.addView(spacer(dp(4)));
        block.addView(buildExplanationLine("4) Скорость убегания: v₂ = √(2μ / r) = √2 · v₁."));
        block.addView(spacer(dp(4)));
        block.addView(buildExplanationLine("5) В расширенном режиме стартуем примерно с v₁, а дальше тела двигаются шагами Δt под взаимным притяжением: aᵢ = Σ G·m·(r − r) / |r − rᵢ|³."));

        return block;
    }

    private TextView buildExplanationLine(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#CFE3E1DE"));
        tv.setTypeface(typefaceRegular);
        AstroUiEffects.applyExplanationTypeface(tv, context);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        tv.setLineSpacing(dp(2), 1.08f);
        return tv;
    }


    /** Обёрнуто в try/catch(Throwable): любая ошибка больше не роняет приложение. */
    private void onCalculatePressed() {
        try {
            resultContainer.removeAllViews();
            unregisterSimReceiver();

            Double parentMassValue = parseDouble(parentMassInput.getText().toString());
            Double distanceValue   = parseDouble(distanceInput.getText().toString());

            if (parentMassValue == null || parentMassValue <= 0) {
                showResultError("Введите корректную массу родительского тела (положительное число).");
                return;
            }

            if (distanceValue == null || distanceValue <= 0) {
                showResultError("Введите корректное расстояние (положительное число).");
                return;
            }

            double parentMassKg =
                PhysicsEngine.MassUnit.values()[parentMassUnit.selectedIndex].toKg(parentMassValue);

            double distanceM =
                PhysicsEngine.DistanceUnit.values()[distanceUnit.selectedIndex].toMeters(distanceValue);

            if (!advancedMode) {
                PhysicsEngine.OrbitalResult result =
                    PhysicsEngine.computeOrbitalSpeeds(parentMassKg, distanceM);
                showSimpleResult(result);
            } else {
                startAdvancedCalculation(parentMassKg, distanceM);
            }
        } catch (Throwable t) {
            resultContainer.removeAllViews();
            showResultError("Ошибка при расчёте:\n" + stack(t));
        }
    }

    private Double parseDouble(String text) {
        if (text == null) return null;

        String trimmed = text.trim().replace(',', '.');
        if (trimmed.isEmpty()) return null;

        try {
            return Double.parseDouble(trimmed);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void showResultError(String message) {
        TextView tv = new DigitTextView(context);
        tv.setText(message);
        tv.setTextColor(Color.parseColor("#FFB4A0"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        resultContainer.addView(tv);
    }

    private void showSimpleResult(PhysicsEngine.OrbitalResult result) {
        LinearLayout box = resultBox();

        box.addView(resultSectionTitle("Результат"));
        box.addView(spacer(dp(8)));

        box.addView(resultLine(
                        "Первая космическая скорость (круговая орбита)",
                        PhysicsEngine.formatSpeed(result.circularSpeedMs)
                    ));

        box.addView(spacer(dp(6)));

        box.addView(resultLine(
                        "Вторая космическая скорость (скорость убегания)",
                        PhysicsEngine.formatSpeed(result.escapeSpeedMs)
                    ));

        resultContainer.addView(box);
    }

    // =========================================================
    //  Расширенный расчёт — через foreground-сервис
    // =========================================================

    private void startAdvancedCalculation(double parentMassKg, double distanceM) {
        Double timeValue = (timeSpanInput != null)
            ? parseDouble(timeSpanInput.getText().toString())
            : null;

        if (timeValue == null || timeValue <= 0) {
            showResultError("Введите положительный промежуток времени для симуляции.");
            return;
        }

        // Предохранитель от двойного клика: если расчёт уже идёт — не плодим второй
        // поток, а просто подключаемся смотреть его прогресс.
        if (ResultStore.state == ResultStore.STATE_RUNNING) {
            resultContainer.removeAllViews();
            showRunningBlock();
            return;
        }

        try {
            double totalTimeSeconds =
                PhysicsEngine.TimeUnit.values()[timeSpanUnit.selectedIndex].toSeconds(timeValue);

            // 60 шагов/сутки, но не больше потолка и не меньше 60.
            double secondsPerDay = 86400.0;
            double totalDays     = totalTimeSeconds / secondsPerDay;

            long rawSteps = (long) Math.ceil(60.0 * totalDays);
            if (rawSteps > MAX_STEPS) rawSteps = MAX_STEPS;
            if (rawSteps < 60L)       rawSteps = 60L;

            int totalSteps = (int) rawSteps;

            List<PhysicsEngine.Body> bodies = new ArrayList<PhysicsEngine.Body>();

            String parentName  = nonEmptyOr(parentNameInput.getText().toString(), "Родительское тело");
            String orbitalName = nonEmptyOr(orbitalNameInput.getText().toString(), "Орбитальное тело");

            bodies.add(new PhysicsEngine.Body(parentName, parentMassKg, 0, 0, 0, 0));

            double circularSpeed = Math.sqrt(PhysicsEngine.G * parentMassKg / distanceM);
            bodies.add(new PhysicsEngine.Body(
                           orbitalName,
                           1000.0,
                           distanceM,
                           0,
                           0,
                           circularSpeed
                       ));

            int idx = 1;

            for (ExtraBodyRow extra : extraBodyRows) {
                Double massValue = parseDouble(extra.massInput.getText().toString());
                Double extraDist = parseDouble(extra.distanceInput.getText().toString());

                if (massValue == null || massValue <= 0
                    || extraDist == null || extraDist <= 0) {
                    continue;
                }

                double massKg =
                    PhysicsEngine.MassUnit.values()[extra.massUnit.selectedIndex].toKg(massValue);

                double r =
                    PhysicsEngine.DistanceUnit.values()[extra.distanceUnit.selectedIndex].toMeters(extraDist);

                String name = nonEmptyOr(extra.nameInput.getText().toString(), "Тело " + (idx + 1));

                double angle = idx * (Math.PI / 3.0);

                double bx = r * Math.cos(angle);
                double by = r * Math.sin(angle);

                double speed = Math.sqrt(PhysicsEngine.G * parentMassKg / r);

                double bvx = -speed * Math.sin(angle);
                double bvy =  speed * Math.cos(angle);

                bodies.add(new PhysicsEngine.Body(name, massKg, bx, by, bvx, bvy));
                idx++;
            }

            final LinearLayout box = resultBox();
            final TextView title = resultSectionTitle("Расчёт выполняется…");

            box.addView(title);

            final TextView progressText = new DigitTextView(context);
            progressText.setText("0 %");
            progressText.setTextColor(Color.parseColor("#CCFFFFFF"));
            progressText.setTypeface(typefaceRegular);
            progressText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);

            box.addView(spacer(dp(6)));
            box.addView(progressText);

            resultContainer.addView(box);

            calculationTotalSeconds = totalTimeSeconds;
            calculationOverlay = new CalculationProgressOverlay(context, rootContainer);
            calculationOverlay.begin("Орбитальная симуляция", ACCENT_COLOR, false);

            attachReceiver(box, title, progressText);
            ensureNotificationPermission();

            NBodySimulationService.launch(context, totalTimeSeconds, totalSteps, bodies);
        } catch (Throwable t) {
            unregisterSimReceiver();
            if (calculationOverlay != null) {
                calculationOverlay.fail("Не удалось запустить расчёт");
                calculationOverlay = null;
            }
            resultContainer.removeAllViews();
            showResultError("Не удалось запустить расчёт:\n" + stack(t));
        }
    }

    private void attachReceiver(final LinearLayout box,
                                final TextView title,
                                final TextView progressText) {
        unregisterSimReceiver();

        simReceiver = new android.content.BroadcastReceiver() {
            @Override
            public void onReceive(Context c, android.content.Intent intent) {
                try {
                    String action = intent.getAction();
                    if (action == null) return;

                    if (ACTION_PROGRESS.equals(action)) {
                        int pct = intent.getIntExtra(NBodySimulationService.EXTRA_PERCENT, 0);
                        ResultStore.progressPercent = pct;

                        if (progressText != null) {
                            progressText.setText(pct + " %");
                        }
                        if (calculationOverlay != null) {
                            calculationOverlay.update(pct, calculationTotalSeconds * pct / 100.0, "Орбитальная симуляция");
                        }
                    } else if (ACTION_DONE.equals(action)) {
                        if (calculationOverlay != null) {
                            calculationOverlay.update(100, calculationTotalSeconds, "Расчёт завершён");
                            calculationOverlay.finish();
                            calculationOverlay = null;
                        }
                        renderAdvancedDone(box, title, progressText);
                    } else if (ACTION_ERROR.equals(action)) {
                        String message = intent.getStringExtra(NBodySimulationService.EXTRA_MESSAGE);
                        if (calculationOverlay != null) {
                            calculationOverlay.fail("Ошибка расчёта");
                            calculationOverlay = null;
                        }
                        renderAdvancedError(box, title, progressText, message);
                    }
                } catch (Throwable ignore) {
                    /* приёмник не должен ронять UI ни при каких обстоятельствах */
                }
            }
        };

        android.content.IntentFilter f = new android.content.IntentFilter();
        f.addAction(ACTION_PROGRESS);
        f.addAction(ACTION_DONE);
        f.addAction(ACTION_ERROR);

        safeRegisterReceiver(simReceiver, f);

        startProgressPolling(box, title, progressText);
    }

    /** Безопасная регистрация: на Android 13+ передаём RECEIVER_NOT_EXPORTED. */
    private void safeRegisterReceiver(android.content.BroadcastReceiver r,
                                      android.content.IntentFilter f) {
        if (Build.VERSION.SDK_INT >= 33) {
            context.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            context.registerReceiver(r, f);
        }
    }

    private void unregisterSimReceiver() {
        stopProgressPolling();

        if (simReceiver != null) {
            try {
                context.unregisterReceiver(simReceiver);
            } catch (Exception ignore) {
                /* приёмник мог быть уже снят — не страшно */
            }
            simReceiver = null;
        }
    }

    private void startProgressPolling(final LinearLayout box,
                                      final TextView title,
                                      final TextView progressText) {
        stopProgressPolling();

        progressPoller = new Runnable() {
            @Override
            public void run() {
                try {
                    int state = ResultStore.state;

                    if (state == ResultStore.STATE_RUNNING) {
                        if (progressText != null) {
                            progressText.setText(ResultStore.progressPercent + " %");
                        }
                        uiHandler.postDelayed(this, 250);
                    } else if (state == ResultStore.STATE_DONE) {
                        renderAdvancedDone(box, title, progressText);
                    } else if (state == ResultStore.STATE_ERROR) {
                        renderAdvancedError(box, title, progressText, ResultStore.errorMessage);
                    }
                } catch (Throwable ignore) {
                    /* polling не должен ронять UI */
                }
            }
        };

        uiHandler.postDelayed(progressPoller, 250);
    }

    private void stopProgressPolling() {
        if (progressPoller != null) {
            try {
                uiHandler.removeCallbacks(progressPoller);
            } catch (Throwable ignore) {
                /* не критично */
            }
            progressPoller = null;
        }
    }

    private void renderAdvancedDone(LinearLayout box,
                                    TextView title,
                                    TextView progressText) {
        try {
            if (box == null) return;

            // Защита от двойного рендера (broadcast + polling).
            if (Boolean.TRUE.equals(box.getTag())) return;
            box.setTag(Boolean.TRUE);

            stopProgressPolling();

            if (title != null) {
                title.setText("Хронология изменения скоростей");
            }

            if (progressText != null) {
                box.removeView(progressText);
            }

            if (ResultStore.resultBodies != null) {
                PhysicsEngine.SimulationResult r =
                    new PhysicsEngine.SimulationResult(ResultStore.resultBodies);
                renderNBodyResult(box, r);
            }

            cancelNotification();
        } catch (Throwable ignore) {
            /* UI не должен падать */
        }
    }

    private void renderAdvancedError(LinearLayout box,
                                     TextView title,
                                     TextView progressText,
                                     String message) {
        try {
            if (box == null) return;

            // Защита от двойного рендера (broadcast + polling).
            if (Boolean.TRUE.equals(box.getTag())) return;
            box.setTag(Boolean.TRUE);

            stopProgressPolling();

            if (title != null) {
                title.setText("Ошибка расчёта");
            }

            if (progressText != null) {
                box.removeView(progressText);
            }

            TextView err = new DigitTextView(context);
            err.setText(message != null ? message : "Не удалось выполнить расчёт.");
            err.setTextColor(Color.parseColor("#FFB4A0"));
            err.setTypeface(typefaceRegular);
            err.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);

            box.addView(err);

            cancelNotification();
        } catch (Throwable ignore) {
            /* UI не должен падать */
        }
    }

    private void cancelNotification() {
        try {
            NotificationManager nm =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                nm.cancel(NBodySimulationService.NOTIF_ID);
            }
        } catch (Throwable ignore) {
            /* не критично */
        }
    }

    private void restoreLastResultIfNeeded() {
        int st = ResultStore.state;
        if (st == ResultStore.STATE_IDLE) return;

        if (st == ResultStore.STATE_RUNNING) {
            showRunningBlock();
        } else if (st == ResultStore.STATE_DONE && ResultStore.resultBodies != null) {
            final LinearLayout box = resultBox();
            final TextView title = resultSectionTitle("Хронология изменения скоростей");

            box.addView(title);
            resultContainer.addView(box);

            PhysicsEngine.SimulationResult r =
                new PhysicsEngine.SimulationResult(ResultStore.resultBodies);

            renderNBodyResult(box, r);
        } else if (st == ResultStore.STATE_ERROR) {
            final LinearLayout box = resultBox();
            final TextView title = resultSectionTitle("Ошибка расчёта");

            box.addView(title);
            box.addView(spacer(dp(6)));

            TextView err = new DigitTextView(context);
            err.setText(ResultStore.errorMessage != null
                        ? ResultStore.errorMessage
                        : "Не удалось выполнить расчёт.");
            err.setTextColor(Color.parseColor("#FFB4A0"));
            err.setTypeface(typefaceRegular);
            err.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);

            box.addView(err);
            resultContainer.addView(box);
        }
    }

    /** Блок "расчёт уже идёт" + подписка на прогресс. */
    private void showRunningBlock() {
        final LinearLayout box = resultBox();
        final TextView title = resultSectionTitle("Расчёт выполняется…");

        box.addView(title);

        final TextView progressText = new DigitTextView(context);
        progressText.setText(ResultStore.progressPercent + " %");
        progressText.setTextColor(Color.parseColor("#CCFFFFFF"));
        progressText.setTypeface(typefaceRegular);
        progressText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);

        box.addView(spacer(dp(6)));
        box.addView(progressText);

        resultContainer.addView(box);

        attachReceiver(box, title, progressText);
    }

    private void ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (context instanceof android.app.Activity) {
                android.app.Activity act = (android.app.Activity) context;

                if (act.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                    != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    act.requestPermissions(
                        new String[]{ android.Manifest.permission.POST_NOTIFICATIONS },
                        1337
                    );
                }
            }
        }
    }

    private String nonEmptyOr(String value, String fallback) {
        if (value == null) return fallback;
        String t = value.trim();
        return t.isEmpty() ? fallback : t;
    }

    /** Короткий stack trace для показа в окне. */
    private static String stack(Throwable t) {
        try {
            java.io.StringWriter sw = new java.io.StringWriter();
            t.printStackTrace(new java.io.PrintWriter(sw));
            String s = sw.toString();
            return s.length() > 1500 ? s.substring(0, 1500) + "…" : s;
        } catch (Throwable ignore) {
            return String.valueOf(t);
        }
    }

    // =========================================================
    //  Отображение результатов n-body
    // =========================================================

    private void renderNBodyResult(LinearLayout box, PhysicsEngine.SimulationResult result) {
        // На сверхдлинных промежутках качество падает до "низкая" — тогда мгновенная
        // скорость осциллирует быстрее, чем можно показать по точкам (алиасинг = "бзыки"),
        // и мы рисуем среднюю орбитальную скорость (3-я колонка истории) вместо неё.
        final boolean useChar = PhysicsEngine.lastQuality != null
            && PhysicsEngine.lastQuality.indexOf("низкая") >= 0;

        box.addView(resultLine(
                        "Точность орбит",
                        PhysicsEngine.lastQuality != null ? PhysicsEngine.lastQuality : "-"
                    ));

        if (useChar) {
            TextView hint = new DigitTextView(context);
            hint.setText("На таком промежутке показана средняя орбитальная скорость: "
                         + "мгновенная осциллирует гораздо быстрее, чем можно отобразить по точкам, "
                         + "поэтому её график выглядел бы как шум.");
            hint.setTextColor(Color.parseColor("#99FFFFFF"));
            hint.setTypeface(typefaceRegular);
            hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            box.addView(hint);
        }

        box.addView(spacer(dp(6)));

        for (PhysicsEngine.Body body : result.bodies) {
            LinearLayout bodyBlock = new LinearLayout(context);
            bodyBlock.setOrientation(LinearLayout.VERTICAL);
            bodyBlock.setBackground(createRoundedRect(
                                        dp(14),
                                        Color.parseColor("#332E2E30"),
                                        Color.parseColor("#55FFFFFF"),
                                        dp(1)
                                    ));

            int bp = dp(12);
            bodyBlock.setPadding(bp, bp, bp, bp);

            LinearLayout.LayoutParams blockLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            );
            blockLp.topMargin = dp(10);
            bodyBlock.setLayoutParams(blockLp);

            // Какую колонку истории брать: 1 = мгновенная, 2 = средняя характеристическая.
            final int colBody = useChar
                ? (!body.history.isEmpty() && body.history.get(0).length > 2 ? 2 : 1)
                : 1;

            TextView name = new DigitTextView(context);
            name.setText(body.name + (body.alive ? "" : "  (выбыло)"));
            name.setTextColor(body.alive ? Color.WHITE : Color.parseColor("#AAFFFFFF"));
            name.setTypeface(typefaceSemiBold);
            name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            bodyBlock.addView(name);

            bodyBlock.addView(spacer(dp(4)));

            TextView massLine = new DigitTextView(context);
            massLine.setText(String.format(Locale.US, "Масса: %.4e кг", body.massKg));
            massLine.setTextColor(Color.parseColor("#CCFFFFFF"));
            massLine.setTypeface(typefaceRegular);
            massLine.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            bodyBlock.addView(massLine);

            TextView initSpeedLine = new DigitTextView(context);
            initSpeedLine.setText("Начальная скорость (1-я космическая): "
                                  + PhysicsEngine.formatSpeed(body.initialSpeedMs));
            initSpeedLine.setTextColor(Color.parseColor("#CCFFFFFF"));
            initSpeedLine.setTypeface(typefaceRegular);
            initSpeedLine.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            bodyBlock.addView(initSpeedLine);

            if (!body.history.isEmpty()) {
                double[] last = body.history.get(body.history.size() - 1);
                int lastCol = (last.length > colBody) ? colBody : 1;

                TextView finalSpeedLine = new DigitTextView(context);
                finalSpeedLine.setText((useChar ? "Средняя скорость: " : "Итоговая скорость: ")
                                       + PhysicsEngine.formatSpeed(last[lastCol]));
                finalSpeedLine.setTextColor(ACCENT_COLOR);
                finalSpeedLine.setTypeface(typefaceSemiBold);
                finalSpeedLine.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
                bodyBlock.addView(finalSpeedLine);
            }

            bodyBlock.addView(spacer(dp(6)));

            TextView historyTitle = new DigitTextView(context);
            historyTitle.setText(useChar ? "Средняя скорость по эпохам:" : "Хронология скорости:");
            historyTitle.setTextColor(Color.parseColor("#AAFFFFFF"));
            historyTitle.setTypeface(typefaceRegular);
            historyTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            bodyBlock.addView(historyTitle);

            int maxEntries = 12;
            List<double[]> hist = body.history;
            int step = Math.max(1, hist.size() / maxEntries);

            for (int i = 0; i < hist.size(); i += step) {
                double[] entry = hist.get(i);
                int entryCol = (entry.length > colBody) ? colBody : 1;

                TextView line = new DigitTextView(context);
                line.setText(String.format(
                                 Locale.US,
                                 "  t = %s  →  %s",
                                 formatTime(entry[0]),
                                 PhysicsEngine.formatSpeed(entry[entryCol])
                             ));
                line.setTextColor(Color.parseColor("#BBFFFFFF"));
                line.setTypeface(typefaceRegular);
                line.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);

                bodyBlock.addView(line);
            }

            box.addView(bodyBlock);
        }
    }

    private String formatTime(double seconds) {
        if (seconds >= PhysicsEngine.TimeUnit.YEAR.seconds) {
            return String.format(Locale.US, "%.2f лет", seconds / PhysicsEngine.TimeUnit.YEAR.seconds);
        }

        if (seconds >= PhysicsEngine.TimeUnit.DAY.seconds) {
            return String.format(Locale.US, "%.2f дн.", seconds / PhysicsEngine.TimeUnit.DAY.seconds);
        }

        if (seconds >= PhysicsEngine.TimeUnit.HOUR.seconds) {
            return String.format(Locale.US, "%.2f ч.", seconds / PhysicsEngine.TimeUnit.HOUR.seconds);
        }

        return String.format(Locale.US, "%.1f с", seconds);
    }

    // =========================================================
    //  Утилиты
    // =========================================================

    private LinearLayout resultBox() {
        LinearLayout box = new LinearLayout(context);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(createRoundedRect(
                              dp(16),
                              Color.parseColor("#6F6B67"),
                              Color.parseColor("#CCFFFFFF"),
                              dp(1.5f)
                          ));

        int p = dp(14);
        box.setPadding(p, p, p, p);
        box.setLayoutParams(new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                            ));

        return box;
    }

    private TextView resultSectionTitle(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        return tv;
    }

    private View resultLine(String label, String value) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.VERTICAL);

        TextView labelView = new DigitTextView(context);
        labelView.setText(label);
        labelView.setTextColor(Color.parseColor("#BBFFFFFF"));
        labelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        row.addView(labelView);

        TextView valueView = new DigitTextView(context);
        valueView.setText(value);
        valueView.setTextColor(ACCENT_COLOR);
        valueView.setTypeface(typefaceSemiBold);
        valueView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        row.addView(valueView);

        return row;
    }

    private GradientDrawable createRoundedRect(float radius,
                                               int fillColor,
                                               int strokeColor,
                                               float strokeWidth) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(radius);
        gd.setColor(fillColor);
        gd.setStroke((int) strokeWidth, strokeColor);
        return gd;
    }

    private FrameLayout.LayoutParams matchParentFrameLp() {
        return new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        );
    }

    // =========================================================
    //  ХРАНИЛИЩЕ
    // =========================================================

    static final class ResultStore {
        static final int STATE_IDLE    = 0;
        static final int STATE_RUNNING = 1;
        static final int STATE_DONE    = 2;
        static final int STATE_ERROR   = 3;

        static volatile int    state           = STATE_IDLE;
        static volatile int    progressPercent = 0;
        static volatile String errorMessage    = null;
        static volatile List<PhysicsEngine.Body> resultBodies = null;

        private ResultStore() {
            /* utility */
        }

        static void reset() {
            state = STATE_IDLE;
            progressPercent = 0;
            errorMessage = null;
            resultBodies = null;
        }
    }
}
