package com.astroforge;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

/**
 * Foreground-сервис расчёта n-body (top-level public-класс).
 *
 * Согласован с VelocityPanel (без вложенного сервиса) и с манифестом,
 * где объявлен android:name=".NBodySimulationService".
 *
 * - broadcast'ы прогресса/готовности/ошибки шлются АДРЕСНО (setPackage);
 * - foreground service стартует с типом dataSync (нужно на targetSdk 34+);
 * - чистые EXTRA_* без пробелов;
 * - ResultStore переводится в IDLE при отмене, чтобы UI не залипал в RUNNING.
 *
 * AIDE-safe: без лямбд, без androidx, diamond с явным типом.
 */
public final class NBodySimulationService extends Service {

    public static final String ACTION_START = "com.astroforge.NBody.START";

    public static final String EXTRA_TOTAL_SECONDS = "totalSeconds";
    public static final String EXTRA_STEPS         = "steps";
    public static final String EXTRA_NAMES         = "names";
    public static final String EXTRA_MASSES        = "masses";
    public static final String EXTRA_X             = "xs";
    public static final String EXTRA_Y             = "ys";
    public static final String EXTRA_VX            = "vxs";
    public static final String EXTRA_VY            = "vys";

    public static final String ACTION_PROGRESS = "com.astroforge.NBody.PROGRESS";
    public static final String ACTION_DONE     = "com.astroforge.NBody.DONE";
    public static final String ACTION_ERROR    = "com.astroforge.NBody.ERROR";

    public static final String EXTRA_PERCENT = "percent";
    public static final String EXTRA_MESSAGE = "message";

    private static final String CHANNEL_ID   = "astroforge_nbody";
    private static final String CHANNEL_NAME = "Расчёт симуляции";

    public static final int NOTIF_ID = 1337;

    private NotificationManager notifManager;
    private Future<?> workerTask;
    private volatile boolean cancelled = false;

    @Override
    public void onCreate() {
        super.onCreate();

        try {
            notifManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            createChannel();
        } catch (Throwable t) {
            VelocityPanel.ResultStore.state = VelocityPanel.ResultStore.STATE_ERROR;
            VelocityPanel.ResultStore.errorMessage = "onCreate: " + stack(t);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            if (intent == null || !ACTION_START.equals(intent.getAction())) {
                stopSelf();
                return START_NOT_STICKY;
            }

            startForegroundTyped("Запуск расчёта…", 0);

            final double totalSeconds = intent.getDoubleExtra(EXTRA_TOTAL_SECONDS, 0.0);
            final int    steps        = intent.getIntExtra(EXTRA_STEPS, 60);
            final List<PhysicsEngine.Body> bodies = readBodies(intent);

            VelocityPanel.ResultStore.reset();
            VelocityPanel.ResultStore.state = VelocityPanel.ResultStore.STATE_RUNNING;
            VelocityPanel.ResultStore.progressPercent = 0;

            cancelled = false;

            try {
                sendProgress(0);
            } catch (Throwable ignore) {
                /* не критично */
            }

            workerTask = PerformancePools.math().submit(new Runnable() {
					@Override
					public void run() {
						try {
							PhysicsEngine.SimulationResult result = PhysicsEngine.simulate(
                                bodies,
                                totalSeconds,
                                steps,
                                new PhysicsEngine.ProgressCallback() {
                                    @Override
                                    public void onProgress(final int cur, final int total) {
                                        if (cancelled) return;

                                        final int pct = (int) (100.0 * cur / total);

                                        VelocityPanel.ResultStore.progressPercent = pct;

                                        updateNotification("Симуляция… " + pct + "%", pct);
                                        sendProgress(pct);
                                    }
                                },
                                new PhysicsEngine.CancelToken() {
                                    @Override
                                    public boolean isCancelled() {
                                        return cancelled;
                                    }
                                }
							);

							if (!cancelled) {
								VelocityPanel.ResultStore.resultBodies = result.bodies;
								VelocityPanel.ResultStore.state = VelocityPanel.ResultStore.STATE_DONE;
								VelocityPanel.ResultStore.progressPercent = 100;

								updateNotification("Готово", 100);
								sendDone();
							} else {
								VelocityPanel.ResultStore.state = VelocityPanel.ResultStore.STATE_IDLE;
								VelocityPanel.ResultStore.progressPercent = 0;
							}
						} catch (Throwable e) {
							VelocityPanel.ResultStore.state = VelocityPanel.ResultStore.STATE_ERROR;
							VelocityPanel.ResultStore.errorMessage = stack(e);

							updateNotification("Ошибка расчёта", 0);
							sendError(stack(e));
						} finally {
							stopSelf();
						}
					}
				});

            return START_NOT_STICKY;
        } catch (Throwable t) {
            VelocityPanel.ResultStore.state = VelocityPanel.ResultStore.STATE_ERROR;
            VelocityPanel.ResultStore.errorMessage = stack(t);

            try {
                sendError(stack(t));
            } catch (Throwable ignore) {
                /* не критично */
            }

            try {
                stopSelf();
            } catch (Throwable ignore) {
                /* не критично */
            }

            return START_NOT_STICKY;
        }
    }

    @Override
    public void onDestroy() {
        cancelled = true;

        if (workerTask != null) {
            try {
                workerTask.cancel(true);
            } catch (Throwable ignore) {
                /* не критично */
            }
        }

        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void startForegroundTyped(String text, int percent) {
        Notification notification = buildNotification(text, percent);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
				NOTIF_ID,
				notification,
				android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            );
        } else {
            startForeground(NOTIF_ID, notification);
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
				CHANNEL_ID,
				CHANNEL_NAME,
				NotificationManager.IMPORTANCE_LOW
            );

            ch.setDescription("Прогресс расчёта орбитальной симуляции");
            ch.setShowBadge(false);

            notifManager.createNotificationChannel(ch);
        }
    }

    private Notification buildNotification(String text, int percent) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());

        PendingIntent pi = null;
        if (launch != null) {
            pi = PendingIntent.getActivity(
				this,
				0,
				launch,
				PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
        }

        Notification.Builder b = new Notification.Builder(this, CHANNEL_ID)
			.setContentTitle("AstroForge")
			.setContentText(text)
			.setSmallIcon(android.R.drawable.ic_menu_compass)
			.setOngoing(true)
			.setProgress(100, percent, percent <= 0);

        if (pi != null) {
            b.setContentIntent(pi);
        }

        return b.build();
    }

    private void updateNotification(final String text, final int percent) {
        try {
            notifManager.notify(NOTIF_ID, buildNotification(text, percent));
        } catch (Throwable ignore) {
            /* уведомление не критично для работы расчёта */
        }
    }

    private void sendProgress(int pct) {
        try {
            Intent i = new Intent(ACTION_PROGRESS);
            i.setPackage(getPackageName());
            i.putExtra(EXTRA_PERCENT, pct);
            sendBroadcast(i);
        } catch (Throwable ignore) {
            /* не критично */
        }
    }

    private void sendDone() {
        try {
            Intent i = new Intent(ACTION_DONE);
            i.setPackage(getPackageName());
            sendBroadcast(i);
        } catch (Throwable ignore) {
            /* не критично */
        }
    }

    private void sendError(String msg) {
        try {
            Intent i = new Intent(ACTION_ERROR);
            i.setPackage(getPackageName());
            i.putExtra(EXTRA_MESSAGE, msg);
            sendBroadcast(i);
        } catch (Throwable ignore) {
            /* не критично */
        }
    }

    private List<PhysicsEngine.Body> readBodies(Intent intent) {
        String[] names  = intent.getStringArrayExtra(EXTRA_NAMES);
        double[] masses = intent.getDoubleArrayExtra(EXTRA_MASSES);
        double[] xs     = intent.getDoubleArrayExtra(EXTRA_X);
        double[] ys     = intent.getDoubleArrayExtra(EXTRA_Y);
        double[] vxs    = intent.getDoubleArrayExtra(EXTRA_VX);
        double[] vys    = intent.getDoubleArrayExtra(EXTRA_VY);

        List<PhysicsEngine.Body> list = new ArrayList<PhysicsEngine.Body>();

        if (names == null || masses == null || xs == null
			|| ys == null || vxs == null || vys == null) {
            return list;
        }

        int n = names.length;
        n = Math.min(n, masses.length);
        n = Math.min(n, xs.length);
        n = Math.min(n, ys.length);
        n = Math.min(n, vxs.length);
        n = Math.min(n, vys.length);

        for (int i = 0; i < n; i++) {
            String name = names[i] != null ? names[i] : "Тело " + (i + 1);

            list.add(new PhysicsEngine.Body(
						 name,
						 masses[i],
						 xs[i],
						 ys[i],
						 vxs[i],
						 vys[i]
					 ));
        }

        return list;
    }

    public static void launch(Context ctx,
                              double totalSeconds,
                              int steps,
                              List<PhysicsEngine.Body> bodies) {
        Intent i = new Intent(ctx, NBodySimulationService.class);
        i.setAction(ACTION_START);

        i.putExtra(EXTRA_TOTAL_SECONDS, totalSeconds);
        i.putExtra(EXTRA_STEPS, steps);

        int n = bodies.size();

        String[] names  = new String[n];
        double[] masses = new double[n];
        double[] xs     = new double[n];
        double[] ys     = new double[n];
        double[] vxs    = new double[n];
        double[] vys    = new double[n];

        for (int k = 0; k < n; k++) {
            PhysicsEngine.Body b = bodies.get(k);

            names[k]  = b.name;
            masses[k] = b.massKg;
            xs[k]     = b.x;
            ys[k]     = b.y;
            vxs[k]    = b.vx;
            vys[k]    = b.vy;
        }

        i.putExtra(EXTRA_NAMES, names);
        i.putExtra(EXTRA_MASSES, masses);
        i.putExtra(EXTRA_X, xs);
        i.putExtra(EXTRA_Y, ys);
        i.putExtra(EXTRA_VX, vxs);
        i.putExtra(EXTRA_VY, vys);

        ctx.startForegroundService(i);
    }

    static String stack(Throwable t) {
        try {
            java.io.StringWriter sw = new java.io.StringWriter();
            t.printStackTrace(new java.io.PrintWriter(sw));
            String s = sw.toString();
            return s.length() > 1500 ? s.substring(0, 1500) + "…" : s;
        } catch (Throwable ignore) {
            return String.valueOf(t);
        }
    }
}
