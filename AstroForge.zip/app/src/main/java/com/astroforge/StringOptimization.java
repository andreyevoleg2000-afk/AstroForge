package com.astroforge;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Небольшой набор безопасных приёмов для горячих строковых путей.
 */
public final class StringOptimization {
    private static final int INITIAL_CAPACITY = 128;
    private static final int MAX_POOL_SIZE = 4096;

    private static final ConcurrentHashMap<String, String> POOL =
            new ConcurrentHashMap<>(512);

    private StringOptimization() {
    }

    /**
     * Пример быстрого форматирования без серии промежуточных concat-объектов.
     * Подберите capacity под реальную среднюю длину строки.
     */
    public static String buildStatusLine(String name, double distanceKm, double speedMs) {
        String safeName = name == null ? "" : name;
        StringBuilder sb = new StringBuilder(INITIAL_CAPACITY);
        sb.append("Объект: ")
          .append(safeName)
          .append(" | расстояние: ")
          .append(distanceKm)
          .append(" км | скорость: ")
          .append(speedMs)
          .append(" м/с");
        return sb.toString();
    }

    /**
     * Канонизация повторяющихся небольших строк без глобального String.intern().
     * Пул ограничен, чтобы не получить бесконечно растущую таблицу.
     */
    public static String canonicalize(String value) {
        if (value == null || value.isEmpty()) {
            return value;
        }

        String existing = POOL.putIfAbsent(value, value);
        if (existing != null) {
            return existing;
        }

        if (POOL.size() > MAX_POOL_SIZE) {
            // Грубая защита от бесконечного роста. Полную эвакуацию делать не нужно:
            // приложение продолжит работать, просто новые значения перестанут копиться.
            POOL.clear();
        }
        return value;
    }

    /**
     * Используйте intern() только для маленького, действительно ограниченного
     * набора повторяющихся констант. Не применять к данным пользователя/URL/JSON.
     */
    public static String canonicalizeConstant(String value) {
        return value == null ? null : value.intern();
    }
}
