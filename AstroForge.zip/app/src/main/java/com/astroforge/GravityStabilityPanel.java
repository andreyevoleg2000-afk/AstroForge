package com.astroforge;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.Collections;

import com.astroforge.BodySpec;
import com.astroforge.DoubleDoubleEngine;
import com.astroforge.EngineConfig;
import com.astroforge.EngineListener;

/**
 * Окно "Стабильность гравитации".
 *
 * Это UI-макет в стиле VelocityPanel:
 * - тот же фон окна с блюром;
 * - те же цвета полей и пилюль;
 * - те же выезжающие списки единиц;
 * - кнопка добавления орбитальных тел;
 * - кнопка "Рассчитать" пока является заглушкой.
 *
 * Логика парсинга чисел и автозамены нереалистичных значений
 * намеренно не подключена: поля хранятся, но ничего не считают.
 *
 * AIDE-safe: без лямбд, без androidx, diamond с явным типом,
 * все захваченные в анонимный класс локальные переменные - final.
 */
final class GravityStabilityPanel {

    private static final int ACCENT_COLOR        = 0xFFD9946B;
    private static final int ACCENT_BORDER_COLOR = Color.parseColor("#CCD9946B");
    private static final int FIELD_BG_COLOR      = Color.parseColor("#F21C1C1E");
    private static final int FIELD_BORDER_COLOR  = Color.parseColor("#B3E3E3E3");
    private static final int PILL_BG_COLOR       = Color.BLACK;
    private static final int DROPDOWN_BG_COLOR   = Color.parseColor("#FF1C1C1E");

    private static final long OPEN_ANIM_DURATION_MS  = 360L;
    private static final long CLOSE_ANIM_DURATION_MS = 220L;

    private static final int CLOSE_DIRECTION_CENTER = 0;
    private static final int CLOSE_DIRECTION_LEFT   = -1;
    private static final int CLOSE_DIRECTION_RIGHT  = 1;

    private static final String[] MASS_UNIT_LABELS = new String[] {
        "кг",
        "г",
        "M⊕",
        "M♃",
        "M☉"
    };

    private static final String[] RADIUS_UNIT_LABELS = new String[] {
        "м",
        "км",
        "R⊕",
        "R♃",
        "R☉"
    };

    private static final String[] TEMPERATURE_UNIT_LABELS = new String[] {
        "K",
        "°C",
        "°F"
    };

    private static final String[] DENSITY_UNIT_LABELS = new String[] {
        "кг/м³",
        "г/см³"
    };

    private static final String[] DISTANCE_UNIT_LABELS = new String[] {
        "м",
        "км",
        "а.е.",
        "R⊕",
        "R☉"
    };

    private static final String[] SPEED_UNIT_LABELS = new String[] {
        "м/с",
        "км/с"
    };

    private static final String[] TIME_UNIT_LABELS = new String[] {
        "с",
        "мин",
        "ч",
        "дн.",
        "лет"
    };

    private final Context context;
    private final FrameLayout rootContainer;
    private final Typeface typefaceRegular;
    private final Typeface typefaceSemiBold;

    private FrameLayout overlayRoot;
    private FrameLayout windowFrame;
    private FrameLayout dropdownLayer;
    private PixelFillOverlay pixelFillOverlay;

    private ValueAnimator openAnimator;
    private ValueAnimator closeAnimator;

    private boolean isClosing = false;

    private boolean swipeClosing = false;
    private boolean swipeFromLeftEdge = false;
    private float swipeStartX = 0f;
    private float swipeStartY = 0f;
    private float swipeLastDx = 0f;
    private float swipeLastDy = 0f;

    private LinearLayout orbitalBodiesContainer;

    private EditText parentMassInput;
    private UnitPillState parentMassUnit;

    private EditText parentRadiusInput;
    private UnitPillState parentRadiusUnit;

    private EditText parentTemperatureInput;
    private UnitPillState parentTemperatureUnit;

    private EditText parentDensityInput;
    private UnitPillState parentDensityUnit;

    private EditText simulationDurationInput;
    private UnitPillState simulationDurationUnit;

    private TextView calculateButtonView;
    private TextView resultSummaryView;
    private TextView resultChronologyView;
    private LinearLayout resultTreeContainer;
    private CalculationProgressOverlay calculationOverlay;

    private final List<OrbitalBodyRow> orbitalBodyRows =
	new ArrayList<OrbitalBodyRow>();

    private GravityStabilityPanel(
        Context context,
        FrameLayout rootContainer,
        Typeface typefaceRegular,
        Typeface typefaceSemiBold
    ) {
        this.context = context;
        this.rootContainer = rootContainer;
        this.typefaceRegular = typefaceRegular;
        this.typefaceSemiBold = typefaceSemiBold;
    }

    static void show(
        Context context,
        FrameLayout rootContainer,
        Typeface typefaceRegular,
        Typeface typefaceSemiBold
    ) {
        new GravityStabilityPanel(
            context,
            rootContainer,
            typefaceRegular,
            typefaceSemiBold
        ).build();
    }

    private int dp(float value) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            context.getResources().getDisplayMetrics()
        );
    }

    // =========================================================
    //  Построение окна
    // =========================================================

    private void build() {
        overlayRoot = new FrameLayout(context);
        overlayRoot.setBackgroundColor(Color.parseColor("#CC0F0F10"));
        overlayRoot.setClickable(true);
        overlayRoot.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					close();
				}
			});

        overlayRoot.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					return handleEdgeSwipe(event);
				}
			});

        windowFrame = new FrameLayout(context);
        windowFrame.setClickable(true);
        windowFrame.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					/* поглощаем клик */
				}
			});

        GradientDrawable frameBg = new GradientDrawable();
        frameBg.setShape(GradientDrawable.RECTANGLE);
        frameBg.setCornerRadius(dp(28));
        frameBg.setColor(0xF21E1E20);
        frameBg.setStroke(dp(2), ACCENT_COLOR);

        windowFrame.setBackground(frameBg);
        windowFrame.setClipToOutline(true);
        windowFrame.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);

        android.widget.ImageView blurBg = new android.widget.ImageView(context);
        blurBg.setImageResource(R.drawable.background);
        blurBg.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        blurBg.setRenderEffect(
            RenderEffect.createBlurEffect(
                dp(44),
                dp(44),
                Shader.TileMode.CLAMP
            )
        );
        blurBg.setAlpha(0.88f);
        windowFrame.addView(blurBg, matchParentFrameLp());

        View tint = new View(context);
        tint.setBackgroundColor(Color.parseColor("#CC232326"));
        windowFrame.addView(tint, matchParentFrameLp());
        AstroUiEffects.applyPaperEffect(windowFrame, context);

        ScrollView scrollView = new ScrollView(context);
        scrollView.setClipToPadding(false);

        LinearLayout content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);

        int pad = dp(20);
        content.setPadding(pad, pad, pad, pad);

        content.addView(buildTitle());
        content.addView(spacer(dp(18)));

        content.addView(buildLabel("Масса родительского тела"));
        content.addView(spacer(dp(6)));

        ValueUnitRow parentMassRow =
            buildValueUnitRow(MASS_UNIT_LABELS, "Введите массу");
        parentMassInput = parentMassRow.input;
        parentMassUnit = parentMassRow.unitState;
        content.addView(parentMassRow.row);

        content.addView(spacer(dp(14)));

        content.addView(buildLabel("Радиус родительского тела"));
        content.addView(spacer(dp(6)));

        ValueUnitRow parentRadiusRow =
            buildValueUnitRow(RADIUS_UNIT_LABELS, "Введите радиус");
        parentRadiusInput = parentRadiusRow.input;
        parentRadiusUnit = parentRadiusRow.unitState;
        content.addView(parentRadiusRow.row);

        content.addView(spacer(dp(14)));

        content.addView(buildLabel("Температура родительского тела"));
        content.addView(spacer(dp(6)));

        ValueUnitRow parentTemperatureRow =
            buildValueUnitRow(TEMPERATURE_UNIT_LABELS, "Введите температуру");
        parentTemperatureInput = parentTemperatureRow.input;
        parentTemperatureUnit = parentTemperatureRow.unitState;
        content.addView(parentTemperatureRow.row);

        content.addView(spacer(dp(14)));

        content.addView(buildLabel("Плотность родительского тела (необязательно)"));
        content.addView(spacer(dp(6)));

        ValueUnitRow parentDensityRow =
            buildValueUnitRow(DENSITY_UNIT_LABELS, "Необязательно");
        parentDensityInput = parentDensityRow.input;
        parentDensityUnit = parentDensityRow.unitState;
        content.addView(parentDensityRow.row);

        content.addView(spacer(dp(18)));

        content.addView(buildLabel("Время моделирования"));
        content.addView(spacer(dp(6)));

        ValueUnitRow simulationDurationRow =
            buildValueUnitRow(TIME_UNIT_LABELS, "Например, 30");
        simulationDurationInput = simulationDurationRow.input;
        simulationDurationUnit = simulationDurationRow.unitState;
        content.addView(simulationDurationRow.row);

        content.addView(spacer(dp(18)));

        content.addView(buildLabel("Орбитальные тела"));
        content.addView(spacer(dp(6)));

        orbitalBodiesContainer = new LinearLayout(context);
        orbitalBodiesContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(orbitalBodiesContainer);

        content.addView(spacer(dp(8)));

        content.addView(buildAddOrbitalBodyButton());

        content.addView(spacer(dp(18)));

        content.addView(buildCalculateButton());

        content.addView(spacer(dp(14)));

        content.addView(buildResultsSection());

        content.addView(spacer(dp(20)));

        scrollView.addView(
            content,
            new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT
            )
        );

        windowFrame.addView(scrollView, matchParentFrameLp());

        attachPixelFillOverlay();

        FrameLayout.LayoutParams windowLp = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        );

        int screenMargin = dp(18);
        windowLp.setMargins(
            screenMargin,
            screenMargin + dp(30),
            screenMargin,
            screenMargin + dp(30)
        );

        overlayRoot.addView(windowFrame, windowLp);
        rootContainer.addView(overlayRoot, matchParentFrameLp());

        windowFrame.post(new Runnable() {
				@Override
				public void run() {
					if (overlayRoot != null && overlayRoot.getParent() == rootContainer) {
						startOpenAnimation();
					}
				}
			});

        dropdownLayer = new FrameLayout(context);
        dropdownLayer.setClipChildren(false);
        dropdownLayer.setClipToPadding(false);
        dropdownLayer.setElevation(dp(1000));
        overlayRoot.addView(dropdownLayer, matchParentFrameLp());
        dropdownLayer.bringToFront();
    }

    private void close() {
        beginClose(CLOSE_DIRECTION_CENTER);
    }

    private void beginClose(int direction) {
        if (isClosing) {
            return;
        }

        if (overlayRoot == null || overlayRoot.getParent() != rootContainer) {
            return;
        }

        isClosing = true;
        swipeClosing = false;
        startCloseAnimation(direction);
    }

    private void startOpenAnimation() {
        if (windowFrame == null) {
            return;
        }

        if (openAnimator != null) {
            openAnimator.cancel();
            openAnimator = null;
        }

        if (closeAnimator != null) {
            closeAnimator.cancel();
            closeAnimator = null;
        }

        swipeClosing = false;
        swipeFromLeftEdge = false;

        windowFrame.setPivotX(windowFrame.getWidth() * 0.5f);
        windowFrame.setPivotY(windowFrame.getHeight() * 0.5f);
        windowFrame.setScaleX(0.965f);
        windowFrame.setScaleY(0.965f);
        windowFrame.setTranslationX(0f);
        windowFrame.setTranslationY(dp(10));

        if (pixelFillOverlay != null) {
            pixelFillOverlay.setVisibility(View.VISIBLE);
            pixelFillOverlay.setProgress(0f);
            pixelFillOverlay.setAlpha(1f);
        }

        openAnimator = ValueAnimator.ofFloat(0f, 1f);
        openAnimator.setDuration(OPEN_ANIM_DURATION_MS);
        openAnimator.setInterpolator(new DecelerateInterpolator(1.8f));
        openAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
				@Override
				public void onAnimationUpdate(ValueAnimator animation) {
					float p = ((Float) animation.getAnimatedValue()).floatValue();

					if (windowFrame != null) {
						windowFrame.setScaleX(0.965f + (0.035f * p));
						windowFrame.setScaleY(0.965f + (0.035f * p));
						windowFrame.setTranslationX(0f);
						windowFrame.setTranslationY(dp(10) * (1f - p));
					}

					if (pixelFillOverlay != null) {
						pixelFillOverlay.setProgress(p);

						if (p >= 1f) {
							pixelFillOverlay.setVisibility(View.GONE);
						}
					}
				}
			});

        openAnimator.start();
    }

    private void startCloseAnimation(final int direction) {
        if (windowFrame == null || overlayRoot == null) {
            performImmediateClose();
            return;
        }

        if (openAnimator != null) {
            openAnimator.cancel();
            openAnimator = null;
        }

        if (closeAnimator != null) {
            closeAnimator.cancel();
            closeAnimator = null;
        }

        final float endScale = 0.72f;

        final float endOffsetX;
        if (direction == CLOSE_DIRECTION_LEFT) {
            endOffsetX = -Math.max(dp(96), windowFrame.getWidth() * 0.22f);
        } else if (direction == CLOSE_DIRECTION_RIGHT) {
            endOffsetX = Math.max(dp(96), windowFrame.getWidth() * 0.22f);
        } else {
            endOffsetX = 0f;
        }

        final float endOffsetY =
            Math.max(dp(90), windowFrame.getHeight() * 0.18f);

        if (direction == CLOSE_DIRECTION_LEFT) {
            windowFrame.setPivotX(0f);
            windowFrame.setPivotY(windowFrame.getHeight());
        } else if (direction == CLOSE_DIRECTION_RIGHT) {
            windowFrame.setPivotX(windowFrame.getWidth());
            windowFrame.setPivotY(windowFrame.getHeight());
        } else {
            windowFrame.setPivotX(windowFrame.getWidth() * 0.5f);
            windowFrame.setPivotY(windowFrame.getHeight() * 0.5f);
        }

        if (pixelFillOverlay != null) {
            pixelFillOverlay.setVisibility(View.VISIBLE);
            pixelFillOverlay.setProgress(1f);
            pixelFillOverlay.setAlpha(1f);
        }

        closeAnimator = ValueAnimator.ofFloat(1f, 0f);
        closeAnimator.setDuration(CLOSE_ANIM_DURATION_MS);
        closeAnimator.setInterpolator(new AccelerateInterpolator(1.6f));
        closeAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
				@Override
				public void onAnimationUpdate(ValueAnimator animation) {
					float p = ((Float) animation.getAnimatedValue()).floatValue();
					float fraction = 1f - p;

					if (windowFrame != null) {
						float scale = 1f - ((1f - endScale) * fraction);
						windowFrame.setScaleX(scale);
						windowFrame.setScaleY(scale);
						windowFrame.setTranslationX(endOffsetX * fraction);
						windowFrame.setTranslationY(endOffsetY * fraction);
					}

					if (pixelFillOverlay != null) {
						pixelFillOverlay.setProgress(p);
					}
				}
			});

        closeAnimator.addListener(new android.animation.Animator.AnimatorListener() {
				@Override
				public void onAnimationStart(android.animation.Animator animation) {
				}

				@Override
				public void onAnimationEnd(android.animation.Animator animation) {
					performImmediateClose();
				}

				@Override
				public void onAnimationCancel(android.animation.Animator animation) {
					performImmediateClose();
				}

				@Override
				public void onAnimationRepeat(android.animation.Animator animation) {
				}
			});

        closeAnimator.start();
    }

    private boolean handleEdgeSwipe(MotionEvent event) {
        if (
            overlayRoot == null
            || windowFrame == null
            || overlayRoot.getParent() != rootContainer
			) {
            return false;
        }

        int action = event.getActionMasked();
        int edge = dp(28);

        switch (action) {
            case MotionEvent.ACTION_DOWN: {
					float x = event.getX();
					float y = event.getY();

					int w = overlayRoot.getWidth();
					if (w <= 0) {
						return false;
					}

					boolean fromLeft = x <= edge;
					boolean fromRight = x >= (w - edge);

					if (!fromLeft && !fromRight) {
						return false;
					}

					swipeClosing = true;
					swipeFromLeftEdge = fromLeft;
					swipeStartX = x;
					swipeStartY = y;
					swipeLastDx = 0f;
					swipeLastDy = 0f;

					return true;
				}

            case MotionEvent.ACTION_MOVE: {
					if (!swipeClosing) {
						return false;
					}

					swipeLastDx = event.getX() - swipeStartX;
					swipeLastDy = event.getY() - swipeStartY;

					float drag = swipeFromLeftEdge ? swipeLastDx : -swipeLastDx;
					if (drag < 0f) {
						drag = 0f;
					}

					float progress = Math.min(1f, drag / (float) dp(220));
					float scale = 1f - (0.28f * progress);

					float tx =
						(swipeFromLeftEdge ? -1f : 1f)
						* Math.max(dp(24), windowFrame.getWidth() * 0.22f)
						* progress;

					float ty =
						Math.max(dp(18), windowFrame.getHeight() * 0.18f)
						* progress;

					if (swipeFromLeftEdge) {
						windowFrame.setPivotX(0f);
					} else {
						windowFrame.setPivotX(windowFrame.getWidth());
					}

					windowFrame.setPivotY(windowFrame.getHeight());
					windowFrame.setScaleX(scale);
					windowFrame.setScaleY(scale);
					windowFrame.setTranslationX(tx);
					windowFrame.setTranslationY(ty);

					return true;
				}

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
					if (!swipeClosing) {
						return false;
					}

					float drag = swipeFromLeftEdge ? swipeLastDx : -swipeLastDx;

					boolean shouldClose =
						drag >= dp(84) || Math.abs(swipeLastDx) >= dp(84);

					if (shouldClose) {
						beginClose(
							swipeFromLeftEdge
							? CLOSE_DIRECTION_LEFT
							: CLOSE_DIRECTION_RIGHT
						);
					} else {
						cancelSwipeGesture();
					}

					return true;
				}

            default:
                return swipeClosing;
        }
    }

    private void cancelSwipeGesture() {
        swipeClosing = false;

        if (windowFrame == null) {
            return;
        }

        windowFrame.setPivotX(windowFrame.getWidth() * 0.5f);
        windowFrame.setPivotY(windowFrame.getHeight() * 0.5f);

        windowFrame.animate()
            .scaleX(1f)
            .scaleY(1f)
            .translationX(0f)
            .translationY(0f)
            .setDuration(180L)
            .setInterpolator(new DecelerateInterpolator(1.6f))
            .start();
    }

    private void performImmediateClose() {
        if (overlayRoot != null && overlayRoot.getParent() == rootContainer) {
            rootContainer.removeView(overlayRoot);
        }

        if (openAnimator != null) {
            openAnimator.cancel();
            openAnimator = null;
        }

        if (closeAnimator != null) {
            closeAnimator.removeAllListeners();
            closeAnimator.cancel();
            closeAnimator = null;
        }

        if (pixelFillOverlay != null) {
            pixelFillOverlay.setProgress(1f);
            pixelFillOverlay.setVisibility(View.GONE);
        }

        overlayRoot = null;
        windowFrame = null;
        pixelFillOverlay = null;

        isClosing = false;
        swipeClosing = false;
        swipeFromLeftEdge = false;
        swipeStartX = 0f;
        swipeStartY = 0f;
        swipeLastDx = 0f;
        swipeLastDy = 0f;

        orbitalBodyRows.clear();
    }

    private void attachPixelFillOverlay() {
        if (windowFrame == null) {
            return;
        }

        pixelFillOverlay = new PixelFillOverlay(context);
        pixelFillOverlay.setVisibility(View.VISIBLE);
        windowFrame.addView(pixelFillOverlay, matchParentFrameLp());
        pixelFillOverlay.bringToFront();
    }

    private final class PixelFillOverlay extends View {

        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Rect rect = new Rect();

        private float progress = 0f;

        private int cachedW = -1;
        private int cachedH = -1;

        private int tilePx = 1;
        private int cols = 0;
        private int rows = 0;

        private float[] thresholds = new float[0];

        PixelFillOverlay(Context context) {
            super(context);

            paint.setStyle(Paint.Style.FILL);

            setWillNotDraw(false);
            setClickable(false);
            setFocusable(false);
            setBackgroundColor(Color.TRANSPARENT);
        }

        void setProgress(float p) {
            if (p < 0f) {
                p = 0f;
            }

            if (p > 1f) {
                p = 1f;
            }

            if (progress == p) {
                return;
            }

            progress = p;
            invalidate();
        }

        private void ensureGeometry(int w, int h) {
            if (w == cachedH && h == cachedH && thresholds.length == cols * rows) {
                return;
            }

            cachedW = w;
            cachedH = h;

            int base = Math.min(w, h) / 18;
            tilePx = Math.max(dp(20), base);

            if (tilePx <= 0) {
                tilePx = dp(20);
            }

            cols = Math.max(1, (int) Math.ceil((double) w / (double) tilePx));
            rows = Math.max(1, (int) Math.ceil((double) h / (double) tilePx));

            thresholds = new float[cols * rows];

            float cx = w * 0.5f;
            float cy = h * 0.5f;

            float maxDist = (float) Math.sqrt((cx * cx) + (cy * cy));
            if (maxDist <= 0f) {
                maxDist = 1f;
            }

            int index = 0;

            for (int row = 0; row < rows; row++) {
                float y = (row * tilePx) + (tilePx * 0.5f);

                for (int col = 0; col < cols; col++) {
                    float x = (col * tilePx) + (tilePx * 0.5f);

                    float dx = x - cx;
                    float dy = y - cy;

                    float norm =
                        (float) Math.sqrt((dx * dx) + (dy * dy)) / maxDist;

                    if (norm < 0f) {
                        norm = 0f;
                    }

                    if (norm > 1f) {
                        norm = 1f;
                    }

                    thresholds[index++] = norm;
                }
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth();
            int h = getHeight();

            if (w <= 0 || h <= 0) {
                return;
            }

            ensureGeometry(w, h);

            final int baseAlpha = 220;
            final int fillColor = 0xF21E1E20;
            final int accentColor = 0xFFD9946B;

            int fillR = Color.red(fillColor);
            int fillG = Color.green(fillColor);
            int fillB = Color.blue(fillColor);

            int accentR = Color.red(accentColor);
            int accentG = Color.green(accentColor);
            int accentB = Color.blue(accentColor);

            int index = 0;

            for (int row = 0; row < rows; row++) {
                int top = row * tilePx;
                int bottom = Math.min(h, top + tilePx);

                for (int col = 0; col < cols; col++) {
                    int left = col * tilePx;
                    int right = Math.min(w, left + tilePx);

                    float threshold = thresholds[index++];
                    float local = progress - threshold;

                    float alpha01;

                    if (local <= 0f) {
                        alpha01 = 1f;
                    } else if (local >= 0.16f) {
                        alpha01 = 0f;
                    } else {
                        float t = local / 0.16f;
                        alpha01 = 1f - (t * t * (3f - 2f * t));
                    }

                    if (alpha01 <= 0.01f) {
                        continue;
                    }

                    int alpha = (int) (baseAlpha * alpha01);

                    if (((row + col) & 7) == 0) {
                        paint.setColor(Color.argb(alpha, accentR, accentG, accentB));
                    } else if (((row + col) & 3) == 0) {
                        paint.setColor(Color.argb(alpha, 52, 46, 44));
                    } else {
                        paint.setColor(Color.argb(alpha, fillR, fillG, fillB));
                    }

                    rect.set(left, top, right, bottom);
                    canvas.drawRect(rect, paint);
                }
            }
        }
    }

    // =========================================================
    //  UI-хелперы
    // =========================================================

    private View buildTitle() {
        TextView tv = new DigitTextView(context);
        tv.setText("Стабильность гравитации");
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        tv.setGravity(Gravity.START | Gravity.TOP);
        return tv;
    }

    private TextView buildLabel(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#DDE3E1DE"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        return tv;
    }

    private View spacer(int heightPx) {
        View v = new View(context);
        v.setLayoutParams(
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                heightPx
            )
        );
        return v;
    }

    private View buildAddOrbitalBodyButton() {
        final TextView btn = new DigitTextView(context);
        btn.setText("+  Добавить орбитальное тело");
        btn.setTextColor(Color.parseColor("#DDE3E1DE"));
        btn.setTypeface(typefaceRegular);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(dp(16), dp(12), dp(16), dp(12));

        GradientDrawable dashed = new GradientDrawable();
        dashed.setShape(GradientDrawable.RECTANGLE);
        dashed.setCornerRadius(dp(16));
        dashed.setColor(Color.TRANSPARENT);
        dashed.setStroke(
            dp(1.5f),
            Color.parseColor("#AAE3E3E3"),
            dp(8),
            dp(5)
        );

        btn.setBackground(dashed);
        btn.setClickable(true);
        btn.setFocusable(true);
        btn.setLayoutParams(
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        );

        btn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					HapticUtils.perform(v);
					addOrbitalBodyRow(orbitalBodiesContainer);
				}
			});

        return btn;
    }

    private View buildCalculateButton() {
        TextView btn = new DigitTextView(context);
        calculateButtonView = btn;
        btn.setText("Рассчитать");
        btn.setTextColor(Color.WHITE);
        btn.setTypeface(typefaceSemiBold);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(0, dp(14), 0, dp(14));
        btn.setBackground(
            createRoundedRect(
                dp(18),
                ACCENT_COLOR,
                Color.parseColor("#33E3E1DE"),
                dp(1)
            )
        );
        AstroUiEffects.applyControlShadow(btn, context);
        btn.setClickable(true);
        btn.setFocusable(true);
        btn.setLayoutParams(
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        );

        btn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					HapticUtils.perform(v);
					onCalculatePressed();
				}
			});

        return btn;
    }

    /**
     * Запускает расчёт через движок DoubleDoubleEngine.
     * Старую игрушечную физику здесь больше не трогаем.
     */
    private void onCalculatePressed() {
        final PreparedSystem system = collectSystemInputs();
        if (system.error != null) {
            showResults("Ошибка ввода", system.error);
            return;
        }

        setCalculationInProgress(true);
        showResults(
            "Расчёт запущен",
            "Считаю через DoubleDoubleEngine...\n" + system.buildInputSummary()
        );

        calculationOverlay = new CalculationProgressOverlay(context, rootContainer);
        calculationOverlay.begin("Гравитационная стабильность", ACCENT_COLOR);

        PerformancePools.math().execute(new Runnable() {
				@Override
				public void run() {
					try {
						final DoubleDoubleEngine engine =
							new DoubleDoubleEngine(system.config, new EngineListener() {
								@Override
								public void onStatus(String message) {
									postStatusLine(message);
								}

								@Override
								public void onFinished(String message) {
									postStatusLine(message);
								}

								@Override
								public void onError(String message) {
									postStatusLine(message);
								}
							}, new DoubleDoubleEngine.ProgressListener() {
								@Override
								public void onProgress(double currentSeconds, double totalSeconds) {
									int percent = totalSeconds <= 0.0 ? 0 : (int) Math.max(0.0, Math.min(100.0, currentSeconds * 100.0 / totalSeconds));
									if (calculationOverlay != null) {
										calculationOverlay.update(percent, currentSeconds, "Виртуальное время симуляции");
									}
								}
							});

						for (int i = 0; i < system.bodies.size(); i++) {
							engine.addBody(system.bodies.get(i));
						}

						final DoubleDoubleEngine.SimulationReport report =
							engine.runBlocking();

						rootContainer.post(new Runnable() {
								@Override
								public void run() {
									setCalculationInProgress(false);
							if (calculationOverlay != null) {
								calculationOverlay.update(100, system.config.totalVirtualSeconds, "Расчёт завершён");
								calculationOverlay.finish();
								calculationOverlay = null;
							}
									if (report == null) {
										showResults(
											"Пустой результат",
											"Движок ничего не вернул. Так тоже бывает, когда входные данные сами себе противоречат."
										);
										return;
									}

									showResults(
										report.summary != null ? report.summary : "Готово",
										buildChronologyText(report)
									);
								}
							});
					} catch (final Throwable t) {
						rootContainer.post(new Runnable() {
								@Override
								public void run() {
									setCalculationInProgress(false);
							if (calculationOverlay != null) {
								calculationOverlay.fail("Ошибка движка");
								calculationOverlay = null;
							}
									showResults("Ошибка движка", t.toString());
								}
							});
					}
				}
			});
    }

    private void setCalculationInProgress(boolean inProgress) {
        if (calculateButtonView != null) {
            calculateButtonView.setEnabled(!inProgress);
            calculateButtonView.setAlpha(inProgress ? 0.65f : 1.0f);
            calculateButtonView.setText(inProgress ? "Считаю..." : "Рассчитать");
        }
    }

    private void postStatusLine(final String message) {
        if (message == null || message.length() == 0) {
            return;
        }

        if (resultSummaryView == null) {
            return;
        }

        rootContainer.post(new Runnable() {
				@Override
				public void run() {
					if (resultChronologyView != null) {
						String old = resultChronologyView.getText() == null ? "" : resultChronologyView.getText().toString();
						if (old.length() == 0) {
							resultChronologyView.setText(message);
						} else {
							resultChronologyView.setText(old + "\n" + message);
						}
					}
				}
			});
    }

    private void showResults(String summary, String details) {
        if (resultSummaryView != null) {
            resultSummaryView.setText(summary == null ? "" : summary);
        }

        if (resultChronologyView != null) {
            if (details == null || details.trim().length() == 0) {
                resultChronologyView.setText("Сегменты и объекты появятся после расчёта.");
            } else {
                resultChronologyView.setText("Нажми на сегмент времени, потом на объект.");
            }
        }

        renderStructuredDetails(details);
    }

    private String buildChronologyText(DoubleDoubleEngine.SimulationReport report) {
        StringBuilder sb = new StringBuilder();

        if (report.chronology != null && report.chronology.size() > 0) {
            sb.append("Хронология событий:\n");
            for (int i = 0; i < report.chronology.size(); i++) {
                sb.append(report.chronology.get(i));
                if (i + 1 < report.chronology.size()) {
                    sb.append('\n');
                }
            }
        } else {
            sb.append("Хронология пуста.");
        }

        if (report.finalBodies != null && report.finalBodies.size() > 0) {
            sb.append("\n\nФинальные тела:\n");
            for (int i = 0; i < report.finalBodies.size(); i++) {
                sb.append(report.finalBodies.get(i));
                if (i + 1 < report.finalBodies.size()) {
                    sb.append('\n');
                }
            }
        }

        return sb.toString();
    }


    private void renderStructuredDetails(String details) {
        if (resultTreeContainer == null) {
            return;
        }

        resultTreeContainer.removeAllViews();

        if (details == null || details.trim().length() == 0) {
            TextView empty = buildDetailNote("После расчёта здесь появятся сегменты времени и карточки объектов.");
            resultTreeContainer.addView(empty);
            return;
        }

        ArrayList<String> lines = splitLines(details);
        ArrayList<SegmentBucket> buckets = parseSegmentBuckets(lines);

        if (buckets.size() == 0) {
            TextView raw = buildDetailNote(localizeEngineText(details));
            raw.setTextIsSelectable(true);
            resultTreeContainer.addView(raw);
            return;
        }

        for (int i = 0; i < buckets.size(); i++) {
            resultTreeContainer.addView(buildSegmentCard(buckets.get(i)));
        }
    }

    private ArrayList<String> splitLines(String textValue) {
        ArrayList<String> out = new ArrayList<String>();
        if (textValue == null) {
            return out;
        }

        String[] split = textValue.split("\r?\n");
        for (int i = 0; i < split.length; i++) {
            String line = split[i];
            if (line != null) {
                out.add(line);
            }
        }
        return out;
    }

    private ArrayList<SegmentBucket> parseSegmentBuckets(ArrayList<String> lines) {
        ArrayList<SegmentBucket> buckets = new ArrayList<SegmentBucket>();
        LinkedHashMap<Long, SegmentBucket> map = new LinkedHashMap<Long, SegmentBucket>();

        boolean inChronology = false;
        boolean inFinalBodies = false;

        for (int i = 0; i < lines.size(); i++) {
            String rawLine = lines.get(i);
            String line = rawLine == null ? "" : rawLine.trim();

            if (line.length() == 0) {
                continue;
            }

            if (line.startsWith("Хронология событий:")) {
                inChronology = true;
                inFinalBodies = false;
                continue;
            }

            if (line.startsWith("Финальные тела:")) {
                inChronology = false;
                inFinalBodies = true;
                continue;
            }

            if (inFinalBodies) {
                SegmentBucket finalBucket = getOrCreateBucket(map, Long.MAX_VALUE - 1L, "Финальные тела");
                if (line.startsWith("•") || line.startsWith("-")) {
                    line = line.substring(1).trim();
                }
                finalBucket.addFinalLine(line);
                continue;
            }

            if (!inChronology) {
                SegmentBucket misc = getOrCreateBucket(map, Long.MIN_VALUE + 1L, "Прочее");
                misc.addNote(line);
                continue;
            }

            TimeLineEntry entry = parseTimeLine(line);
            if (entry == null) {
                SegmentBucket miscChronology = getOrCreateBucket(map, Long.MIN_VALUE + 2L, "Хронология");
                miscChronology.addNote(line);
                continue;
            }

            long bucketStart = ((long) Math.floor(entry.timeYears / 1000.0d)) * 1000L;
            String title = formatSegmentTitle(bucketStart, bucketStart + 1000L);

            SegmentBucket bucket = getOrCreateBucket(map, bucketStart, title);
            bucket.minYears = Math.min(bucket.minYears, entry.timeYears);
            bucket.maxYears = Math.max(bucket.maxYears, entry.timeYears);

            if (entry.bodyName != null && entry.bodyName.length() > 0) {
                bucket.addBodySnapshot(entry.bodyName, entry.fieldMap, entry.rawSuffix);
            } else if (entry.note != null && entry.note.length() > 0) {
                bucket.addNote(entry.note);
            }
        }

        buckets.addAll(map.values());

        ArrayList<SegmentBucket> filtered = new ArrayList<SegmentBucket>();
        for (int i = 0; i < buckets.size(); i++) {
            SegmentBucket b = buckets.get(i);
            if (b.isRenderable()) {
                filtered.add(b);
            }
        }

        return filtered;
    }

    private SegmentBucket getOrCreateBucket(LinkedHashMap<Long, SegmentBucket> map, long key, String title) {
        SegmentBucket bucket = map.get(Long.valueOf(key));
        if (bucket == null) {
            bucket = new SegmentBucket();
            bucket.key = key;
            bucket.title = title;
            map.put(Long.valueOf(key), bucket);
        }
        return bucket;
    }

    private TimeLineEntry parseTimeLine(String line) {
        if (line == null || line.length() == 0) {
            return null;
        }

        if (!line.startsWith("[")) {
            return null;
        }

        int close = line.indexOf(']');
        if (close <= 1) {
            return null;
        }

        String timeToken = line.substring(1, close).trim();
        String suffix = line.substring(close + 1).trim();

        TimeLineEntry out = new TimeLineEntry();
        out.timeYears = parseTimeTokenToYears(timeToken);
        out.rawSuffix = suffix;

        if (suffix.length() == 0) {
            out.note = line;
            return out;
        }

        BodyLine bodyLine = parseBodyLine(suffix);
        if (bodyLine != null) {
            out.bodyName = bodyLine.bodyName;
            out.fieldMap = bodyLine.fields;
            out.note = bodyLine.bodyName;
            return out;
        }

        out.note = suffix;
        return out;
    }

    private double parseTimeTokenToYears(String token) {
        if (token == null) {
            return Double.NaN;
        }

        String t = token.trim().toLowerCase(Locale.US);
        double value = parseLeadingDouble(t);
        if (Double.isNaN(value)) {
            return Double.NaN;
        }

        if (t.contains("лет") || t.contains("год")) {
            return value;
        }
        if (t.contains("дн")) {
            return value / 365.25d;
        }
        if (t.contains("ч")) {
            return value / 24.0d / 365.25d;
        }
        if (t.contains("мин")) {
            return value / 60.0d / 24.0d / 365.25d;
        }
        return value / 86400.0d / 365.25d;
    }

    private double parseLeadingDouble(String value) {
        if (value == null) {
            return Double.NaN;
        }

        StringBuilder sb = new StringBuilder();
        boolean started = false;

        for (int i = 0; i < value.length(); i++) {
            char ch = value.charAt(i);
            if ((ch >= '0' && ch <= '9') || ch == '.' || ch == '-' || ch == '+' || ch == 'e' || ch == 'E') {
                sb.append(ch);
                started = true;
            } else if (started) {
                break;
            }
        }

        if (sb.length() == 0) {
            return Double.NaN;
        }

        return parseDouble(sb.toString());
    }

    private BodyLine parseBodyLine(String suffix) {
        if (suffix == null) {
            return null;
        }

        String s = suffix.trim();
        if (s.length() == 0) {
            return null;
        }

        String bodyName = null;
        String tail = null;

        int colon = s.indexOf(':');
        if (colon > 0) {
            String left = s.substring(0, colon).trim();
            tail = s.substring(colon + 1).trim();

            bodyName = extractBodyName(left);
            if (bodyName == null || bodyName.length() == 0) {
                bodyName = extractBodyName(s);
            }
        } else {
            bodyName = extractBodyName(s);
            tail = "";
        }

        if (bodyName == null || bodyName.length() == 0) {
            return null;
        }

        LinkedHashMap<String, String> fields = parseFields(tail);

        BodyLine out = new BodyLine();
        out.bodyName = bodyName;
        out.fields = fields;
        return out;
    }

    private String extractBodyName(String textValue) {
        if (textValue == null) {
            return "";
        }

        String s = textValue.trim();
        if (s.length() == 0) {
            return "";
        }

        int pipe = s.indexOf('|');
        if (pipe > 0) {
            s = s.substring(0, pipe).trim();
        }

        s = s.replace("Тело", "").trim();
        s = s.replace("«", "").replace("»", "").trim();
        s = s.replace("«", "").replace("»", "").trim();
        s = s.replace(":", "").trim();

        if (s.startsWith("[")) {
            int close = s.indexOf(']');
            if (close >= 0) {
                s = s.substring(close + 1).trim();
            }
        }

        return s;
    }

    private LinkedHashMap<String, String> parseFields(String tail) {
        LinkedHashMap<String, String> fields = new LinkedHashMap<String, String>();
        if (tail == null || tail.trim().length() == 0) {
            return fields;
        }

        String[] parts = tail.split(",");
        for (int i = 0; i < parts.length; i++) {
            String part = parts[i];
            if (part == null) {
                continue;
            }

            String token = part.trim();
            if (token.length() == 0) {
                continue;
            }

            int eq = token.indexOf('=');
            if (eq <= 0) {
                continue;
            }

            String key = token.substring(0, eq).trim();
            String value = token.substring(eq + 1).trim();

            if (key.length() > 0 && value.length() > 0) {
                fields.put(key, value);
            }
        }

        return fields;
    }

    private View buildSegmentCard(final SegmentBucket bucket) {
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackground(
            createRoundedRect(
                dp(18),
                Color.parseColor("#F21D1D20"),
                Color.parseColor("#77E3E1DE"),
                dp(1.2f)
            )
        );
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.bottomMargin = dp(10);
        card.setLayoutParams(lp);

        final TextView header = new DigitTextView(context);
        header.setTextColor(Color.WHITE);
        header.setTypeface(typefaceSemiBold);
        header.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        header.setPadding(dp(8), dp(10), dp(8), dp(10));
        header.setBackground(
            createRoundedRect(
                dp(14),
                Color.parseColor("#FF222225"),
                Color.parseColor("#88E3E1DE"),
                dp(1)
            )
        );
        header.setClickable(true);
        header.setFocusable(true);
        header.setCompoundDrawablePadding(dp(8));
        setHeaderIcon(header, R.drawable.line_spacing);
        header.setText("▼  " + bucket.title);

        card.addView(header);

        final LinearLayout bodyContainer = new LinearLayout(context);
        bodyContainer.setOrientation(LinearLayout.VERTICAL);
        bodyContainer.setPadding(dp(6), dp(12), dp(6), dp(0));
        bodyContainer.setVisibility(View.GONE);
        card.addView(bodyContainer);

        if (bucket.notes.size() > 0) {
            TextView note = buildDetailNote(localizeEngineText(joinLines(bucket.notes)));
            note.setPadding(dp(4), dp(4), dp(4), dp(8));
            bodyContainer.addView(note);
        }

        if (bucket.finalLines.size() > 0) {
            TextView finalHeader = buildSubHeader("Финальные тела");
            bodyContainer.addView(finalHeader);
            for (int i = 0; i < bucket.finalLines.size(); i++) {
                bodyContainer.addView(buildFinalBodyCard(bucket.finalLines.get(i)));
            }
        }

        ArrayList<BodySeries> series = bucket.getBodies();
        for (int i = 0; i < series.size(); i++) {
            bodyContainer.addView(buildBodyCard(series.get(i)));
        }

        if (series.size() == 0 && bucket.finalLines.size() == 0 && bucket.notes.size() == 0) {
            bodyContainer.addView(buildDetailNote("Нет данных для этого сегмента."));
        }

        header.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					boolean show = bodyContainer.getVisibility() != View.VISIBLE;
					bodyContainer.setVisibility(show ? View.VISIBLE : View.GONE);
					header.setText((show ? "▼" : "▶") + "  " + bucket.title);
				}
			});

        return card;
    }

    private View buildBodyCard(final BodySeries series) {
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        card.setBackground(
            createRoundedRect(
                dp(16),
                Color.parseColor("#EE242427"),
                Color.parseColor("#66E3E1DE"),
                dp(1.0f)
            )
        );
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.bottomMargin = dp(8);
        card.setLayoutParams(lp);

        final TextView header = new DigitTextView(context);
        header.setTextColor(Color.WHITE);
        header.setTypeface(typefaceSemiBold);
        header.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        header.setPadding(dp(10), dp(8), dp(10), dp(8));
        header.setBackground(
            createRoundedRect(
                dp(12),
                Color.parseColor("#FF1D1D1F"),
                Color.parseColor("#55E3E1DE"),
                dp(1)
            )
        );
        header.setText("▼  " + series.name);
        header.setCompoundDrawablePadding(dp(8));
        setHeaderIcon(header, R.drawable.galaxy);
        header.setClickable(true);
        header.setFocusable(true);
        card.addView(header);

        final LinearLayout body = new LinearLayout(context);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(6), dp(10), dp(6), dp(0));
        body.setVisibility(View.GONE);
        card.addView(body);

        if (series.first != null && series.last != null) {
            addFieldRows(body, series.first, series.last);
        } else if (series.last != null) {
            addFieldRows(body, null, series.last);
        } else {
            body.addView(buildDetailNote("Нет характеристик."));
        }

        header.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					boolean show = body.getVisibility() != View.VISIBLE;
					body.setVisibility(show ? View.VISIBLE : View.GONE);
					header.setText((show ? "▼" : "▶") + "  " + series.name);
				}
			});

        return card;
    }

    private View buildFinalBodyCard(String line) {
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(10), dp(10), dp(10), dp(10));
        card.setBackground(
            createRoundedRect(
                dp(14),
                Color.parseColor("#D8222224"),
                Color.parseColor("#44E3E1DE"),
                dp(1)
            )
        );

        TextView tv = buildDetailNote(localizeEngineText(line));
        tv.setTextColor(Color.parseColor("#E8E3E1DE"));
        card.addView(tv);
        return card;
    }

    private void addFieldRows(LinearLayout container, ParsedState first, ParsedState last) {
        if (last == null || last.fields == null || last.fields.size() == 0) {
            container.addView(buildDetailNote("Нет данных по характеристикам."));
            return;
        }

        for (Map.Entry<String, String> entry : last.fields.entrySet()) {
            String key = entry.getKey();
            String current = entry.getValue();
            String delta = computeDeltaText(
                first == null ? null : first.fields.get(key),
                current
            );

            container.addView(buildCharacteristicRow(key, current, delta));
        }
    }

    private View buildCharacteristicRow(String key, String current, String delta) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(10), dp(8), dp(10), dp(8));
        row.setBackground(
            createRoundedRect(
                dp(12),
                Color.parseColor("#1D1D20"),
                Color.parseColor("#33FFFFFF"),
                dp(0.8f)
            )
        );
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.bottomMargin = dp(6);
        row.setLayoutParams(lp);

        TextView label = new DigitTextView(context);
        label.setTextColor(Color.parseColor("#FFF0EDE7"));
        label.setTypeface(typefaceSemiBold);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        label.setText(mapFieldLabel(key));
        row.addView(label);

        TextView value = new DigitTextView(context);
        value.setTextColor(Color.parseColor("#E8E3E1DE"));
        value.setTypeface(typefaceRegular);
        value.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        value.setLineSpacing(0f, 1.08f);
        value.setText(localizeValueText(current == null ? "" : current));
        row.addView(value);

        if (delta != null && delta.length() > 0) {
            TextView deltaView = new DigitTextView(context);
            deltaView.setTextColor(ACCENT_COLOR);
            deltaView.setTypeface(typefaceSemiBold);
            deltaView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            deltaView.setText(localizeValueText(delta));
            row.addView(deltaView);
        }

        return row;
    }


    private String mapFieldLabel(String key) {
        if (key == null) {
            return "Характеристика";
        }

        String k = key.trim();
        String lower = k.toLowerCase(Locale.US);

        if (lower.equals("m") || lower.equals("mass")) return "Масса";
        if (lower.equals("r") || lower.equals("radius")) return "Радиус";
        if (lower.equals("d") || lower.equals("dist") || lower.equals("distance")) return "Расстояние";
        if (lower.equals("v") || lower.equals("speed") || lower.equals("velocity") || lower.equals("vel")) return "Скорость";
        if (lower.equals("v0") || lower.equals("init_speed") || lower.equals("initial_speed")) return "Начальная скорость";
        if (lower.equals("e") || lower.equals("ecc") || lower.equals("eccentricity")) return "Эксцентриситет";
        if (lower.equals("a") || lower.equals("acc") || lower.equals("acceleration")) return "Ускорение";
        if (lower.equals("i") || lower.equals("inc") || lower.equals("inclination")) return "Наклон";
        if (lower.equals("t") || lower.equals("period")) return "Период";
        if (lower.equals("rho") || lower.equals("ρ") || lower.equals("density")) return "Плотность";
        if (lower.equals("temp") || lower.equals("temperature")) return "Температура";
        if (lower.equals("status")) return "Статус";
        if (lower.equals("energy")) return "Энергия";
        if (lower.equals("steps") || lower.equals("step")) return "Шаги";
        if (lower.equals("time")) return "Время";
        if (lower.equals("collisions") || lower.equals("collision")) return "Столкновения";
        if (lower.equals("escapes") || lower.equals("escape")) return "Побеги";
        if (lower.equals("survivors") || lower.equals("alive")) return "Оставшиеся тела";

        return k;
    }

    private String computeDeltaText(String firstValue, String lastValue) {
        if (lastValue == null || lastValue.length() == 0) {
            return "";
        }

        if (firstValue == null || firstValue.length() == 0) {
            return "Δ " + lastValue;
        }

        double firstNum = parseLeadingDouble(firstValue);
        double lastNum = parseLeadingDouble(lastValue);

        if (!Double.isNaN(firstNum) && !Double.isNaN(lastNum)) {
            double delta = lastNum - firstNum;
            String unit = extractUnitTail(lastValue);
            if (Math.abs(delta) < 1e-12) {
                return "Δ 0" + (unit.length() > 0 ? " " + unit : "");
            }
            return "Δ " + formatSignedNumber(delta) + (unit.length() > 0 ? " " + unit : "");
        }

        if (!firstValue.equals(lastValue)) {
            return "Δ " + firstValue + " → " + lastValue;
        }

        return "Δ без изменений";
    }


    private String localizeValueText(String value) {
        if (value == null) {
            return "";
        }

        String s = value.trim();
        if (s.length() == 0) {
            return s;
        }

        s = s.replace(" km/s", " км/с");
        s = s.replace(" m/s", " м/с");
        s = s.replace(" km", " км");
        s = s.replace(" m", " м");
        s = s.replace(" kg", " кг");
        s = s.replace(" AU", " а.е.");
        s = s.replace(" yr", " лет");
        s = s.replace(" day", " дн.");
        s = s.replace(" days", " дн.");
        s = s.replace(" h", " ч");
        s = s.replace(" min", " мин");
        s = s.replace(" deg", "°");
        s = s.replace(" rad", " рад");
        s = s.replace(" K", " K");

        s = s.replace("bound", "связана");
        s = s.replace("escaped", "выбыла");
        s = s.replace("collision", "столкновение");
        s = s.replace("collided", "столкновение");
        s = s.replace("survived", "сохранилась");

        s = s.replace("true", "да");
        s = s.replace("false", "нет");

        return s;
    }

    private String localizeEngineText(String textValue) {
        if (textValue == null) {
            return "";
        }

        String s = textValue;

        s = s.replace("dist=", "расстояние=");
        s = s.replace("distance=", "расстояние=");
        s = s.replace("radius=", "радиус=");
        s = s.replace("mass=", "масса=");
        s = s.replace("velocity=", "скорость=");
        s = s.replace("speed=", "скорость=");
        s = s.replace("vel=", "скорость=");
        s = s.replace("ecc=", "эксцентриситет=");
        s = s.replace("eccentricity=", "эксцентриситет=");
        s = s.replace("inc=", "наклон=");
        s = s.replace("inclination=", "наклон=");
        s = s.replace("period=", "период=");
        s = s.replace("density=", "плотность=");
        s = s.replace("temperature=", "температура=");
        s = s.replace("status=", "статус=");
        s = s.replace("energy=", "энергия=");
        s = s.replace("steps=", "шаги=");
        s = s.replace("collisions=", "столкновения=");
        s = s.replace("escapes=", "побеги=");
        s = s.replace("survivors=", "оставшиеся тела=");

        s = s.replace("bound", "связана");
        s = s.replace("escaped", "выбыла");
        s = s.replace("collision", "столкновение");
        s = s.replace("collided", "столкновение");
        s = s.replace("survived", "сохранилась");

        s = s.replace(" km/s", " км/с");
        s = s.replace(" m/s", " м/с");
        s = s.replace(" km", " км");
        s = s.replace(" m", " м");
        s = s.replace(" kg", " кг");
        s = s.replace(" AU", " а.е.");
        s = s.replace(" yr", " лет");
        s = s.replace(" day", " дн.");
        s = s.replace(" days", " дн.");
        s = s.replace(" h", " ч");
        s = s.replace(" min", " мин");

        return s;
    }

    private void setHeaderIcon(TextView header, int drawableResId) {
        if (header == null) {
            return;
        }

        Drawable icon = null;
        try {
            icon = context.getResources().getDrawable(drawableResId);
        } catch (Throwable t) {
            icon = null;
        }

        if (icon == null) {
            return;
        }

        int size = dp(20);
        icon.setBounds(0, 0, size, size);
        header.setCompoundDrawables(icon, null, null, null);
    }

    private String extractUnitTail(String value) {
        if (value == null) {
            return "";
        }

        String v = value.trim();
        int idx = -1;

        for (int i = 0; i < v.length(); i++) {
            char ch = v.charAt(i);
            if ((ch < '0' || ch > '9') && ch != '.' && ch != '-' && ch != '+' && ch != 'e' && ch != 'E') {
                idx = i;
                break;
            }
        }

        if (idx < 0 || idx >= v.length()) {
            return "";
        }

        return v.substring(idx).trim();
    }

    private String formatSignedNumber(double value) {
        if (Double.isNaN(value) || Double.isInfinite(value)) {
            return String.valueOf(value);
        }

        String s = String.format(Locale.US, "%.6g", Double.valueOf(value));
        if (!s.startsWith("-")) {
            s = "+" + s;
        }
        return s;
    }

    private TextView buildDetailNote(String textValue) {
        TextView tv = new DigitTextView(context);
        tv.setTextColor(Color.parseColor("#DDE3E1DE"));
        tv.setTypeface(typefaceRegular);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tv.setLineSpacing(0f, 1.16f);
        tv.setText(textValue == null ? "" : textValue);
        AstroUiEffects.applyExplanationTypeface(tv, context);
        return tv;
    }

    private TextView buildSubHeader(String textValue) {
        TextView tv = new DigitTextView(context);
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tv.setText(textValue == null ? "" : textValue);
        tv.setPadding(dp(4), dp(4), dp(4), dp(6));
        return tv;
    }

    private String joinLines(ArrayList<String> lines) {
        if (lines == null || lines.size() == 0) {
            return "";
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            sb.append(lines.get(i));
            if (i + 1 < lines.size()) {
                sb.append('\n');
            }
        }
        return sb.toString();
    }

    private String formatSegmentTitle(long startYears, long endYears) {
        if (startYears <= Long.MIN_VALUE / 4L) {
            return "Прочее";
        }
        if (startYears >= Long.MAX_VALUE / 4L) {
            return "Финальные тела";
        }
        if (startYears < 0L) {
            return "0 - 1000 лет";
        }
        return startYears + " - " + endYears + " лет";
    }

    private static final class TimeLineEntry {
        double timeYears;
        String rawSuffix;
        String bodyName;
        LinkedHashMap<String, String> fieldMap;
        String note;
    }

    private static final class BodyLine {
        String bodyName;
        LinkedHashMap<String, String> fields;
    }

    private static final class ParsedState {
        double timeYears;
        LinkedHashMap<String, String> fields = new LinkedHashMap<String, String>();
        String rawSuffix;
    }

    private static final class BodySeries {
        String name;
        ParsedState first;
        ParsedState last;
    }

    private static final class SegmentBucket {
        long key;
        String title;
        double minYears = Double.POSITIVE_INFINITY;
        double maxYears = Double.NEGATIVE_INFINITY;
        final LinkedHashMap<String, BodySeries> bodies = new LinkedHashMap<String, BodySeries>();
        final ArrayList<String> notes = new ArrayList<String>();
        final ArrayList<String> finalLines = new ArrayList<String>();

        void addNote(String text) {
            if (text != null && text.length() > 0) {
                notes.add(text);
            }
        }

        void addFinalLine(String text) {
            if (text != null && text.length() > 0) {
                finalLines.add(text);
            }
        }

        void addBodySnapshot(String bodyName, LinkedHashMap<String, String> fields, String rawSuffix) {
            BodySeries series = bodies.get(bodyName);
            if (series == null) {
                series = new BodySeries();
                series.name = bodyName;
                bodies.put(bodyName, series);
            }

            ParsedState state = new ParsedState();
            if (fields != null) {
                state.fields.putAll(fields);
            }
            state.rawSuffix = rawSuffix;

            if (series.first == null) {
                series.first = state;
            }
            series.last = state;
        }

        boolean isRenderable() {
            return !notes.isEmpty() || !finalLines.isEmpty() || !bodies.isEmpty();
        }

        ArrayList<BodySeries> getBodies() {
            return new ArrayList<BodySeries>(bodies.values());
        }
    }
    private PreparedSystem collectSystemInputs() {
        PreparedSystem out = new PreparedSystem();

        final StringBuilder error = new StringBuilder();
        final ArrayList<BodySpec> bodies = new ArrayList<BodySpec>();
        final ArrayList<String> summaryLines = new ArrayList<String>();

        double parentMassKg = parseMassToKg(parentMassInput, parentMassUnit, "масса родительского тела");
        double parentRadiusM = parseRadiusToMeters(parentRadiusInput, parentRadiusUnit, "радиус родительского тела");
        Double parentTempK = parseTemperatureToKelvinOptional(parentTemperatureInput, parentTemperatureUnit);
        Double parentDensity = parseDensityToKgM3Optional(parentDensityInput, parentDensityUnit);

        if ((Double.isNaN(parentMassKg) || parentMassKg <= 0.0)
			&& !Double.isNaN(parentRadiusM)
			&& parentRadiusM > 0.0
			&& parentDensity != null
			&& parentDensity.doubleValue() > 0.0) {
            parentMassKg = parentDensity.doubleValue() * ((4.0 / 3.0) * Math.PI * parentRadiusM * parentRadiusM * parentRadiusM);
        }

        if ((Double.isNaN(parentRadiusM) || parentRadiusM <= 0.0)
			&& !Double.isNaN(parentMassKg)
			&& parentMassKg > 0.0
			&& parentDensity != null
			&& parentDensity.doubleValue() > 0.0) {
            parentRadiusM = Math.cbrt((3.0 * parentMassKg) / (4.0 * Math.PI * parentDensity.doubleValue()));
        }

        if (parentDensity == null || parentDensity.doubleValue() <= 0.0) {
            if (!Double.isNaN(parentMassKg)
				&& parentMassKg > 0.0
				&& !Double.isNaN(parentRadiusM)
				&& parentRadiusM > 0.0) {
                parentDensity = Double.valueOf(parentMassKg / ((4.0 / 3.0) * Math.PI * parentRadiusM * parentRadiusM * parentRadiusM));
            }
        }

        if (Double.isNaN(parentMassKg) || parentMassKg <= 0.0) {
            error.append("Нужна корректная масса родительского тела.\n");
        }

        if (Double.isNaN(parentRadiusM) || parentRadiusM <= 0.0) {
            error.append("Нужен корректный радиус родительского тела.\n");
        }

        if (error.length() > 0) {
            out.error = error.toString().trim();
            return out;
        }

        if (parentDensity == null || parentDensity.doubleValue() <= 0.0) {
            parentDensity = Double.valueOf(parentMassKg / ((4.0 / 3.0) * Math.PI * parentRadiusM * parentRadiusM * parentRadiusM));
        }

        BodySpec central = new BodySpec("Центральное тело", parentMassKg, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
        bodies.add(central);

        summaryLines.add(
            "Центр: m=" + formatNumber(parentMassKg) + " кг, r=" + formatNumber(parentRadiusM) + " м, ρ=" + formatNumber(parentDensity.doubleValue()) + " кг/м³"
        );
        if (parentTempK != null) {
            summaryLines.add("Температура центра: " + formatNumber(parentTempK.doubleValue()) + " K");
        }

        double simTimeSeconds = parseTimeToSeconds(simulationDurationInput, simulationDurationUnit, "время моделирования");
        if (Double.isNaN(simTimeSeconds) || simTimeSeconds <= 0.0) {
            simTimeSeconds = deriveDefaultSimulationSeconds(parentMassKg, orbitalBodyRows, parentRadiusM);
        }

        if (simTimeSeconds <= 0.0) {
            simTimeSeconds = 365.25 * 86400.0 * 5.0;
        }

        EngineConfig config = new EngineConfig();
        config.mode = EngineConfig.MODE_SAFE;
        config.totalVirtualSeconds = simTimeSeconds;
        config.writeCheckpoints = false;
        config.writeFinal = false;
        config.outputDir = null;
        config.filePrefix = "gravity_stability";

        double minPeriod = Double.POSITIVE_INFINITY;
        double maxDistance = 0.0;

        final int bodyCount = orbitalBodyRows.size();
        for (int i = 0; i < bodyCount; i++) {
            OrbitalBodyRow row = orbitalBodyRows.get(i);
            String bodyName = trimText(row.nameInput);
            if (bodyName.length() == 0) {
                bodyName = "Тело " + (i + 1);
            }

            double massKg = parseMassOrDensityMassKg(row.massInput, row.massUnit, row.radiusInput, row.radiusUnit, row.densityInput, row.densityUnit, bodyName);
            double radiusM = parseRadiusOrMassRadiusM(row.radiusInput, row.radiusUnit, row.massInput, row.massUnit, row.densityInput, row.densityUnit, bodyName);
            double densityKgM3 = parseDensityToKgM3OrDerive(row.densityInput, row.densityUnit, massKg, radiusM);

            if (Double.isNaN(massKg) || massKg <= 0.0) {
                error.append("Нужна масса для тела ").append(bodyName).append(".\n");
                continue;
            }
            if (Double.isNaN(radiusM) || radiusM <= 0.0) {
                error.append("Нужен радиус для тела ").append(bodyName).append(".\n");
                continue;
            }

            double distanceM = parseDistanceToMeters(row.distanceInput, row.distanceUnit, bodyName);
            if (Double.isNaN(distanceM) || distanceM <= 0.0) {
                error.append("Нужна орбитальная дистанция для тела ").append(bodyName).append(".\n");
                continue;
            }

            double speedMs = parseSpeedToMsOptional(row.speedInput, row.speedUnit);
            if (Double.isNaN(speedMs) || speedMs <= 0.0) {
                speedMs = Math.sqrt(Math.max(0.0, DoubleDoubleEngine.G * parentMassKg / Math.max(distanceM, parentRadiusM * 1.1)));
            }

            double phase = (2.0 * Math.PI * i) / Math.max(1, bodyCount);
            double x = Math.cos(phase) * distanceM;
            double y = Math.sin(phase) * distanceM;
            double vx = -Math.sin(phase) * speedMs;
            double vy = Math.cos(phase) * speedMs;

            BodySpec spec = new BodySpec(bodyName, massKg, x, y, 0.0, vx, vy, 0.0);
            bodies.add(spec);

            double period = 2.0 * Math.PI * Math.sqrt((distanceM * distanceM * distanceM) / Math.max(1.0, DoubleDoubleEngine.G * parentMassKg));
            if (period > 0.0 && period < minPeriod) {
                minPeriod = period;
            }
            if (distanceM > maxDistance) {
                maxDistance = distanceM;
            }

            summaryLines.add(
                bodyName + ": m=" + formatNumber(massKg) + " кг, r=" + formatNumber(radiusM) + " м, ρ=" + formatNumber(densityKgM3) + " кг/м³, d=" + formatNumber(distanceM) + " м, v=" + formatNumber(speedMs) + " м/с"
            );
        }

        if (error.length() > 0) {
            out.error = error.toString().trim();
            return out;
        }

        if (Double.isInfinite(minPeriod) || minPeriod <= 0.0) {
            minPeriod = 365.25 * 86400.0;
        }

        double dt = Math.min(86400.0, Math.max(60.0, minPeriod / 500.0));
        if (bodyCount > 25) {
            dt = Math.max(300.0, dt);
        }

        config.dt = dt;
        config.softening = Math.max(1.0, parentRadiusM * 1e-6);
        config.threadCount = 0;
        config.enableGaussLegendre = false;
        config.enablePN = false;
        config.checkpointVirtualSeconds = Math.max(dt * 50.0, simTimeSeconds / 12.0);

        summaryLines.add("Время моделирования: " + formatTime(simTimeSeconds));
        summaryLines.add("Шаг интегрирования: " + formatNumber(dt) + " с");
        summaryLines.add("Тела в модели: " + bodies.size());

        out.config = config;
        out.bodies = bodies;
        out.summaryLines = summaryLines;
        out.error = null;
        return out;
    }

    private String trimText(EditText input) {
        if (input == null || input.getText() == null) {
            return "";
        }
        return input.getText().toString().trim();
    }

    private double parseMassToKg(EditText input, UnitPillState unit, String label) {
        String text = trimText(input);
        if (text.length() == 0) {
            return Double.NaN;
        }
        double value = parseDouble(text);
        if (Double.isNaN(value)) {
            return Double.NaN;
        }
        int idx = unit != null ? unit.selectedIndex : 0;
        switch (idx) {
            case 1: return value / 1000.0;
            case 2: return value * 5.9722e24;
            case 3: return value * 1.89813e27;
            case 4: return value * 1.98847e30;
            default: return value;
        }
    }

    private double parseRadiusToMeters(EditText input, UnitPillState unit, String label) {
        String text = trimText(input);
        if (text.length() == 0) {
            return Double.NaN;
        }
        double value = parseDouble(text);
        if (Double.isNaN(value)) {
            return Double.NaN;
        }
        int idx = unit != null ? unit.selectedIndex : 0;
        switch (idx) {
            case 1: return value * 1000.0;
            case 2: return value * 6.371e6;
            case 3: return value * 6.9911e7;
            case 4: return value * 6.957e8;
            default: return value;
        }
    }

    private double parseDistanceToMeters(EditText input, UnitPillState unit, String label) {
        String text = trimText(input);
        if (text.length() == 0) {
            return Double.NaN;
        }
        double value = parseDouble(text);
        if (Double.isNaN(value)) {
            return Double.NaN;
        }
        int idx = unit != null ? unit.selectedIndex : 0;
        switch (idx) {
            case 1: return value * 1000.0;
            case 2: return value * 1.495978707e11;
            case 3: return value * 6.371e6;
            case 4: return value * 6.957e8;
            default: return value;
        }
    }

    private double parseSpeedToMsOptional(EditText input, UnitPillState unit) {
        String text = trimText(input);
        if (text.length() == 0) {
            return Double.NaN;
        }
        double value = parseDouble(text);
        if (Double.isNaN(value)) {
            return Double.NaN;
        }
        int idx = unit != null ? unit.selectedIndex : 0;
        switch (idx) {
            case 1: return value * 1000.0;
            default: return value;
        }
    }

    private Double parseDensityToKgM3Optional(EditText input, UnitPillState unit) {
        String text = trimText(input);
        if (text.length() == 0) {
            return null;
        }
        double value = parseDouble(text);
        if (Double.isNaN(value)) {
            return null;
        }
        int idx = unit != null ? unit.selectedIndex : 0;
        if (idx == 1) {
            return Double.valueOf(value * 1000.0);
        }
        return Double.valueOf(value);
    }

    private Double parseTemperatureToKelvinOptional(EditText input, UnitPillState unit) {
        String text = trimText(input);
        if (text.length() == 0) {
            return null;
        }
        double value = parseDouble(text);
        if (Double.isNaN(value)) {
            return null;
        }
        int idx = unit != null ? unit.selectedIndex : 0;
        switch (idx) {
            case 1: return Double.valueOf(value + 273.15);
            case 2: return Double.valueOf(((value - 32.0) * 5.0 / 9.0) + 273.15);
            default: return Double.valueOf(value);
        }
    }

    private double parseTimeToSeconds(EditText input, UnitPillState unit, String label) {
        String text = trimText(input);
        if (text.length() == 0) {
            return Double.NaN;
        }
        double value = parseDouble(text);
        if (Double.isNaN(value)) {
            return Double.NaN;
        }
        int idx = unit != null ? unit.selectedIndex : 0;
        switch (idx) {
            case 1: return value * 60.0;
            case 2: return value * 3600.0;
            case 3: return value * 86400.0;
            case 4: return value * 3.15576e7;
            default: return value;
        }
    }

    private double parseMassOrDensityMassKg(EditText massInput, UnitPillState massUnit, EditText radiusInput, UnitPillState radiusUnit, EditText densityInput, UnitPillState densityUnit, String bodyName) {
        double mass = parseMassToKg(massInput, massUnit, bodyName);
        if (!Double.isNaN(mass) && mass > 0.0) {
            return mass;
        }

        double radius = parseRadiusToMeters(radiusInput, radiusUnit, bodyName);
        Double density = parseDensityToKgM3Optional(densityInput, densityUnit);
        if (!Double.isNaN(radius) && radius > 0.0 && density != null && density.doubleValue() > 0.0) {
            return density.doubleValue() * ((4.0 / 3.0) * Math.PI * radius * radius * radius);
        }

        return Double.NaN;
    }

    private double parseRadiusOrMassRadiusM(EditText radiusInput, UnitPillState radiusUnit, EditText massInput, UnitPillState massUnit, EditText densityInput, UnitPillState densityUnit, String bodyName) {
        double radius = parseRadiusToMeters(radiusInput, radiusUnit, bodyName);
        if (!Double.isNaN(radius) && radius > 0.0) {
            return radius;
        }

        double mass = parseMassToKg(massInput, massUnit, bodyName);
        Double density = parseDensityToKgM3Optional(densityInput, densityUnit);
        if (!Double.isNaN(mass) && mass > 0.0 && density != null && density.doubleValue() > 0.0) {
            return Math.cbrt((3.0 * mass) / (4.0 * Math.PI * density.doubleValue()));
        }

        return Double.NaN;
    }

    private double parseDensityToKgM3OrDerive(EditText densityInput, UnitPillState densityUnit, double massKg, double radiusM) {
        Double density = parseDensityToKgM3Optional(densityInput, densityUnit);
        if (density != null && density.doubleValue() > 0.0) {
            return density.doubleValue();
        }
        if (massKg > 0.0 && radiusM > 0.0) {
            return massKg / ((4.0 / 3.0) * Math.PI * radiusM * radiusM * radiusM);
        }
        return Double.NaN;
    }

    private double deriveDefaultSimulationSeconds(double parentMassKg, List<OrbitalBodyRow> rows, double parentRadiusM) {
        double maxPeriod = 365.25 * 86400.0 * 2.0;
        for (int i = 0; i < rows.size(); i++) {
            OrbitalBodyRow row = rows.get(i);
            double distanceM = parseDistanceToMeters(row.distanceInput, row.distanceUnit, "orb");
            if (Double.isNaN(distanceM) || distanceM <= 0.0) {
                continue;
            }
            double period = 2.0 * Math.PI * Math.sqrt((distanceM * distanceM * distanceM) / Math.max(1.0, DoubleDoubleEngine.G * parentMassKg));
            if (period > maxPeriod) {
                maxPeriod = period;
            }
        }
        return Math.max(365.25 * 86400.0 * 2.0, maxPeriod * 4.0);
    }

    private String formatNumber(double value) {
        return String.format(Locale.US, "%.6g", Double.valueOf(value));
    }

    private String formatTime(double seconds) {
        if (seconds >= 3.15576e7) {
            return formatNumber(seconds / 3.15576e7) + " лет";
        }
        if (seconds >= 86400.0) {
            return formatNumber(seconds / 86400.0) + " дн.";
        }
        if (seconds >= 3600.0) {
            return formatNumber(seconds / 3600.0) + " ч";
        }
        if (seconds >= 60.0) {
            return formatNumber(seconds / 60.0) + " мин";
        }
        return formatNumber(seconds) + " с";
    }

    private double parseDouble(String text) {
        try {
            return Double.parseDouble(text.replace(',', '.'));
        } catch (Throwable t) {
            return Double.NaN;
        }
    }

    private void setResultsSectionVisibility(boolean visible) {
        if (resultSummaryView != null) {
            resultSummaryView.setVisibility(visible ? View.VISIBLE : View.GONE);
        }
        if (resultChronologyView != null) {
            resultChronologyView.setVisibility(visible ? View.VISIBLE : View.GONE);
        }
    }

    private View buildResultsSection() {
        LinearLayout box = new LinearLayout(context);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(16));
        box.setBackground(
            createRoundedRect(
                dp(18),
                Color.parseColor("#F2242426"),
                Color.parseColor("#55D9946B"),
                dp(1.25f)
            )
        );

        TextView title = buildLabel("Результат расчёта");
        title.setTypeface(typefaceSemiBold);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        title.setTextColor(Color.WHITE);
        box.addView(title);

        box.addView(spacer(dp(8)));

        resultSummaryView = new DigitTextView(context);
        resultSummaryView.setTextColor(Color.parseColor("#E8E3E1DE"));
        resultSummaryView.setTypeface(typefaceRegular);
        resultSummaryView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        resultSummaryView.setLineSpacing(0f, 1.15f);
        resultSummaryView.setText("Здесь появится краткий итог расчёта.");
        box.addView(resultSummaryView);

        box.addView(spacer(dp(10)));

        TextView chronologyTitle = buildLabel("Сегменты и объекты");
        chronologyTitle.setTypeface(typefaceSemiBold);
        chronologyTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        chronologyTitle.setTextColor(Color.WHITE);
        box.addView(chronologyTitle);

        box.addView(spacer(dp(6)));

        resultChronologyView = new DigitTextView(context);
        resultChronologyView.setTextColor(Color.parseColor("#E8E3E1DE"));
        resultChronologyView.setTypeface(typefaceRegular);
        resultChronologyView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        resultChronologyView.setLineSpacing(0f, 1.18f);
        resultChronologyView.setText("Нажми на сегмент времени, потом на объект.");
        resultChronologyView.setPadding(dp(6), dp(2), dp(6), dp(2));
        box.addView(resultChronologyView);

        box.addView(spacer(dp(8)));

        resultTreeContainer = new LinearLayout(context);
        resultTreeContainer.setOrientation(LinearLayout.VERTICAL);
        resultTreeContainer.setClipToPadding(false);
        resultTreeContainer.setClipChildren(false);
        box.addView(
            resultTreeContainer,
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        );

        return box;
    }

    private static final class PreparedSystem {
        EngineConfig config;
        ArrayList<BodySpec> bodies;
        ArrayList<String> summaryLines;
        String error;

        String buildInputSummary() {
            StringBuilder sb = new StringBuilder();
            if (summaryLines != null) {
                for (int i = 0; i < summaryLines.size(); i++) {
                    sb.append(summaryLines.get(i));
                    if (i + 1 < summaryLines.size()) {
                        sb.append("\n");
                    }
                }
            }
            return sb.toString();
        }
    }

    // =========================================================
    //  Поля с единицами
    // =========================================================

    private static final class ValueUnitRow {
        View row;
        EditText input;
        UnitPillState unitState;
    }

    private static final class UnitPillState {
        TextView pillView;
        int selectedIndex = 0;
        String[] labels;
    }

    private static final class OrbitalBodyRow {
        EditText nameInput;

        EditText massInput;
        UnitPillState massUnit;

        EditText radiusInput;
        UnitPillState radiusUnit;

        EditText densityInput;
        UnitPillState densityUnit;

        EditText temperatureInput;
        UnitPillState temperatureUnit;

        EditText distanceInput;
        UnitPillState distanceUnit;

        EditText speedInput;
        UnitPillState speedUnit;

        View rowView;
    }

    private void addOrbitalBodyRow(LinearLayout parent) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.VERTICAL);

        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        rowLp.bottomMargin = dp(14);
        row.setLayoutParams(rowLp);

        EditText nameInput = buildPlainTextField("Название орбитального тела");
        row.addView(nameInput);
        row.addView(spacer(dp(6)));

        ValueUnitRow massRow =
            buildValueUnitRow(MASS_UNIT_LABELS, "Введите массу");
        row.addView(massRow.row);
        row.addView(spacer(dp(10)));

        ValueUnitRow radiusRow =
            buildValueUnitRow(RADIUS_UNIT_LABELS, "Введите радиус");
        row.addView(radiusRow.row);
        row.addView(spacer(dp(10)));

        ValueUnitRow densityRow =
            buildValueUnitRow(DENSITY_UNIT_LABELS, "Плотность (необязательно)");
        row.addView(densityRow.row);
        row.addView(spacer(dp(10)));

        ValueUnitRow temperatureRow =
            buildValueUnitRow(TEMPERATURE_UNIT_LABELS, "Введите температуру");
        row.addView(temperatureRow.row);
        row.addView(spacer(dp(10)));

        ValueUnitRow distanceRow =
            buildValueUnitRow(DISTANCE_UNIT_LABELS, "Орбитальная дистанция");
        row.addView(distanceRow.row);
        row.addView(spacer(dp(10)));

        ValueUnitRow speedRow =
            buildValueUnitRow(SPEED_UNIT_LABELS, "Скорость (необязательно)");
        row.addView(speedRow.row);

        parent.addView(row);

        OrbitalBodyRow body = new OrbitalBodyRow();
        body.nameInput = nameInput;

        body.massInput = massRow.input;
        body.massUnit = massRow.unitState;

        body.radiusInput = radiusRow.input;
        body.radiusUnit = radiusRow.unitState;

        body.densityInput = densityRow.input;
        body.densityUnit = densityRow.unitState;

        body.temperatureInput = temperatureRow.input;
        body.temperatureUnit = temperatureRow.unitState;

        body.distanceInput = distanceRow.input;
        body.distanceUnit = distanceRow.unitState;

        body.speedInput = speedRow.input;
        body.speedUnit = speedRow.unitState;

        body.rowView = row;

        orbitalBodyRows.add(body);
    }

    private ValueUnitRow buildValueUnitRow(
        final String[] unitLabels,
        String hint
    ) {
        FrameLayout field = new FrameLayout(context);
        field.setBackground(
            createRoundedRect(
                dp(16),
                FIELD_BG_COLOR,
                FIELD_BORDER_COLOR,
                dp(1.25f)
            )
        );
        AstroUiEffects.applyControlShadow(field, context);
        field.setClipToOutline(true);

        final EditText input = new DigitEditText(context);
        input.setHint(hint);
        input.setHintTextColor(Color.parseColor("#77FFFFFF"));
        input.setTextColor(Color.WHITE);
        input.setTypeface(typefaceRegular);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        input.setSingleLine(true);
        input.setBackground(null);
        AstroUiEffects.applyControlShadow(input, context);
        input.setInputType(
            InputType.TYPE_CLASS_NUMBER
            | InputType.TYPE_NUMBER_FLAG_DECIMAL
            | InputType.TYPE_NUMBER_FLAG_SIGNED
        );
        input.setPadding(dp(16), dp(12), dp(120), dp(12));

        field.addView(input, matchParentFrameLp());

        final UnitPillState state = new UnitPillState();
        state.labels = unitLabels;
        state.selectedIndex = 0;

        final TextView pill = new DigitTextView(context);
        pill.setText(unitLabels[0]);
        pill.setTextColor(Color.WHITE);
        pill.setTypeface(typefaceSemiBold);
        pill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        pill.setGravity(Gravity.CENTER);
        pill.setMaxLines(1);
        pill.setEllipsize(android.text.TextUtils.TruncateAt.END);
        pill.setBackground(
            createRoundedRect(
                dp(14),
                PILL_BG_COLOR,
                Color.parseColor("#33E3E1DE"),
                dp(1)
            )
        );
        pill.setPadding(dp(12), dp(8), dp(12), dp(8));
        pill.setClickable(true);
        pill.setFocusable(true);

        FrameLayout.LayoutParams pillLp = new FrameLayout.LayoutParams(
            dp(104),
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        pillLp.gravity = Gravity.CENTER_VERTICAL | Gravity.END;
        pillLp.rightMargin = dp(8);

        field.addView(pill, pillLp);
        pill.setTranslationZ(dp(3f));

        state.pillView = pill;

        pill.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					HapticUtils.perform(v);

					openDropdown(
						pill,
						unitLabels,
						state.selectedIndex,
						new OnUnitSelected() {
							@Override
							public void onSelected(int newIndex) {
								state.selectedIndex = newIndex;
								pill.setText(unitLabels[newIndex]);
							}
						}
					);
				}
			});

        field.setLayoutParams(
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(50)
            )
        );

        ValueUnitRow row = new ValueUnitRow();
        row.row = field;
        row.input = input;
        row.unitState = state;

        return row;
    }

    private EditText buildPlainTextField(String hint) {
        EditText input = new DigitEditText(context);
        input.setHint(hint);
        input.setHintTextColor(Color.parseColor("#77FFFFFF"));
        input.setTextColor(Color.WHITE);
        input.setTypeface(typefaceRegular);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        input.setSingleLine(true);
        input.setBackground(
            createRoundedRect(
                dp(16),
                FIELD_BG_COLOR,
                FIELD_BORDER_COLOR,
                dp(1.25f)
            )
        );
        AstroUiEffects.applyControlShadow(input, context);
        input.setPadding(dp(16), dp(12), dp(16), dp(12));
        input.setLayoutParams(
            new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(50)
            )
        );

        return input;
    }

    // =========================================================
    //  Dropdown
    // =========================================================

    private interface OnUnitSelected {
        void onSelected(int index);
    }

    private void openDropdown(
        final View anchor,
        final String[] labels,
        int selectedIndex,
        final OnUnitSelected callback
    ) {
        dropdownLayer.removeAllViews();
        dropdownLayer.bringToFront();

        int[] anchorLoc = new int[2];
        anchor.getLocationOnScreen(anchorLoc);

        int[] rootLoc = new int[2];
        dropdownLayer.getLocationOnScreen(rootLoc);

        int relativeX = anchorLoc[0] - rootLoc[0];
        int relativeY = anchorLoc[1] - rootLoc[1];
        int anchorBottom = relativeY + anchor.getHeight();

        Rect visibleFrame = new Rect();
        rootContainer.getWindowVisibleDisplayFrame(visibleFrame);

        int visibleTop = visibleFrame.top - rootLoc[1];
        int visibleBottom = visibleFrame.bottom - rootLoc[1];

        View scrim = new View(context);
        scrim.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					dropdownLayer.removeAllViews();
				}
			});

        dropdownLayer.addView(scrim, matchParentFrameLp());

        LinearLayout list = new LinearLayout(context);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setBackground(
            createRoundedRect(
                dp(14),
                DROPDOWN_BG_COLOR,
                ACCENT_BORDER_COLOR,
                dp(1.25f)
            )
        );
        list.setClipToOutline(true);
        list.setPadding(dp(6), dp(6), dp(6), dp(6));

        for (int i = 0; i < labels.length; i++) {
            final int idx = i;

            TextView item = new DigitTextView(context);
            item.setText(labels[i]);
            item.setTextColor(i == selectedIndex ? ACCENT_COLOR : Color.WHITE);
            item.setTypeface(
                i == selectedIndex ? typefaceSemiBold : typefaceRegular
            );
            AstroUiEffects.applyUnitTypeface(item, context);
            item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            item.setPadding(dp(14), dp(10), dp(14), dp(10));
            item.setClickable(true);
            item.setFocusable(true);

            item.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						HapticUtils.perform(v);
						callback.onSelected(idx);
						dropdownLayer.removeAllViews();
					}
				});

            list.addView(
                item,
                new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            );
        }

        int estimatedHeight = dp(12) + (labels.length * dp(40));

        int spaceBelow = visibleBottom - anchorBottom - dp(8);
        int spaceAbove = relativeY - visibleTop - dp(8);

        if (spaceBelow < 0) {
            spaceBelow = 0;
        }

        if (spaceAbove < 0) {
            spaceAbove = 0;
        }

        boolean showAbove =
            spaceBelow < estimatedHeight && spaceAbove > spaceBelow;

        final int maxHeight = Math.max(
            0,
            Math.min(
                estimatedHeight,
                showAbove ? spaceAbove : spaceBelow
            )
        );

        ScrollView listScroll = new ScrollView(context) {
            @Override
            protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                int hSpec = heightMeasureSpec;

                if (maxHeight > 0) {
                    int mode = View.MeasureSpec.getMode(hSpec);
                    int size = View.MeasureSpec.getSize(hSpec);

                    if (mode == View.MeasureSpec.UNSPECIFIED || size > maxHeight) {
                        hSpec = View.MeasureSpec.makeMeasureSpec(
                            maxHeight,
                            View.MeasureSpec.AT_MOST
                        );
                    }
                }

                super.onMeasure(widthMeasureSpec, hSpec);
            }
        };

        listScroll.addView(
            list,
            new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT
            )
        );

        listScroll.setBackground(list.getBackground());
        list.setBackground(null);

        listScroll.setVerticalScrollBarEnabled(false);
        listScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        FrameLayout.LayoutParams listLp = new FrameLayout.LayoutParams(
            dp(180),
            FrameLayout.LayoutParams.WRAP_CONTENT
        );

        listLp.leftMargin = Math.max(
            dp(8),
            relativeX + anchor.getWidth() - dp(180)
        );

        if (showAbove) {
            listLp.topMargin = Math.max(
                visibleTop + dp(8),
                relativeY - maxHeight - dp(4)
            );
        } else {
            listLp.topMargin = anchorBottom + dp(4);
        }

        dropdownLayer.addView(listScroll, listLp);
        listScroll.bringToFront();
    }

    // =========================================================
    //  Утилиты
    // =========================================================

    private GradientDrawable createRoundedRect(
        float radius,
        int fillColor,
        int strokeColor,
        float strokeWidth
    ) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(radius);
        gd.setColor(fillColor);
        gd.setStroke((int) strokeWidth, strokeColor);
        return gd;
    }

    private FrameLayout.LayoutParams matchParentFrameLp() {
        return new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        );
    }
}


