package com.astroforge;

/**
 * Very small double-double helper.
 * Good enough for stable accumulations without dragging in BigDecimal.
 */
public final class DoubleDouble implements Comparable<DoubleDouble> {

    private static final double SPLIT = 134217729.0; // 2^27 + 1

    private double hi;
    private double lo;

    public DoubleDouble() {
        this.hi = 0.0;
        this.lo = 0.0;
    }

    public DoubleDouble(double value) {
        this.hi = value;
        this.lo = 0.0;
    }

    public static DoubleDouble of(double value) {
        return new DoubleDouble(value);
    }

    public double doubleValue() {
        return hi + lo;
    }

    public void set(double value) {
        this.hi = value;
        this.lo = 0.0;
    }

    public void set(DoubleDouble other) {
        if (other == null) {
            this.hi = 0.0;
            this.lo = 0.0;
            return;
        }
        this.hi = other.hi;
        this.lo = other.lo;
    }

    private static double[] twoSum(double a, double b) {
        double s = a + b;
        double bb = s - a;
        double err = (a - (s - bb)) + (b - bb);
        return new double[] { s, err };
    }

    private static double[] quickTwoSum(double a, double b) {
        double s = a + b;
        double err = b - (s - a);
        return new double[] { s, err };
    }

    private static double[] twoProd(double a, double b) {
        double p = a * b;
        double aSplit = SPLIT * a;
        double aHi = aSplit - (aSplit - a);
        double aLo = a - aHi;
        double bSplit = SPLIT * b;
        double bHi = bSplit - (bSplit - b);
        double bLo = b - bHi;
        double err = ((aHi * bHi - p) + aHi * bLo + aLo * bHi) + aLo * bLo;
        return new double[] { p, err };
    }

    private void normalize() {
        double[] t = quickTwoSum(hi, lo);
        hi = t[0];
        lo = t[1];
    }

    public void add(double value) {
        double[] s = twoSum(hi, value);
        double e = lo + s[1];
        double[] t = quickTwoSum(s[0], e);
        hi = t[0];
        lo = t[1];
    }

    public void add(DoubleDouble other) {
        if (other == null) {
            return;
        }
        add(other.hi);
        add(other.lo);
    }

    public void subtract(double value) {
        add(-value);
    }

    public void subtract(DoubleDouble other) {
        if (other == null) {
            return;
        }
        add(-other.hi);
        add(-other.lo);
    }

    public void multiply(double value) {
        double[] p = twoProd(hi, value);
        double e = p[1] + lo * value;
        double[] t = quickTwoSum(p[0], e);
        hi = t[0];
        lo = t[1];
    }

    public void multiply(DoubleDouble other) {
        if (other == null) {
            set(0.0);
            return;
        }
        double[] p = twoProd(hi, other.hi);
        double e = p[1] + (hi * other.lo) + (lo * other.hi) + (lo * other.lo);
        double[] t = quickTwoSum(p[0], e);
        hi = t[0];
        lo = t[1];
    }

    public void divide(double value) {
        if (value == 0.0) {
            hi = Double.NaN;
            lo = 0.0;
            return;
        }
        set(doubleValue() / value);
    }

    public void divide(DoubleDouble other) {
        if (other == null || other.doubleValue() == 0.0) {
            hi = Double.NaN;
            lo = 0.0;
            return;
        }
        set(doubleValue() / other.doubleValue());
    }

    public static DoubleDouble sqrt(DoubleDouble value) {
        if (value == null) {
            return new DoubleDouble(0.0);
        }
        double v = value.doubleValue();
        if (v <= 0.0) {
            return new DoubleDouble(0.0);
        }
        return new DoubleDouble(Math.sqrt(v));
    }

    @Override
    public int compareTo(DoubleDouble other) {
        double a = doubleValue();
        double b = other == null ? 0.0 : other.doubleValue();
        return Double.compare(a, b);
    }

    @Override
    public String toString() {
        return Double.toString(doubleValue());
    }
}
