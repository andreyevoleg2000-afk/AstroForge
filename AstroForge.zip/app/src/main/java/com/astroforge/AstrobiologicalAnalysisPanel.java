package com.astroforge;

import android.content.Context;
import android.graphics.Color;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Astrobiological environment simulation panel.
 *
 * UI intentionally follows the visual construction of VelocityPanel/HabitableZonePanel:
 * same rounded window, blurred background, dark field treatment and unit dropdowns.
 *
 * The surface simulation uses exactly 2000 fixed surface points. One integration circle
 * advances physical time by 1/150 s. Worker threads use all available CPU cores except
 * the Android main/UI thread. Scalar/input conversions and final aggregates use
 * MathContext.DECIMAL128 (34 decimal digits). Android's standard Java runtime has no
 * native IEEE-754 binary128 primitive, therefore no fake "128-bit double" is claimed.
 */
final class AstrobiologicalAnalysisPanel {

    private static final int ACCENT_COLOR = 0xFFD9946B;
    private static final int ACCENT_BORDER_COLOR = Color.parseColor("#CCD9946B");
    private static final int FIELD_BG = Color.parseColor("#FF1D1D1F");
    private static final int FIELD_BORDER = Color.parseColor("#BDBABABA");
    private static final int PILL_BG = Color.BLACK;
    private static final int DROPDOWN_BG = Color.parseColor("#FF1C1C1E");
    private static final MathContext DECIMAL128 = MathContext.DECIMAL128;

    private static final int SURFACE_POINTS = 2000;
    private static final int CIRCLES_PER_SECOND = 150;
    private static final double DT_SECONDS = 1.0 / 150.0;

    private final Context context;
    private final FrameLayout rootContainer;
    private final Typeface typefaceRegular;
    private final Typeface typefaceSemiBold;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private FrameLayout overlayRoot;
    private FrameLayout dropdownLayer;
    private LinearLayout compositionContainer;
    private LinearLayout resultContainer;
    private volatile CalculationProgressOverlay calculationOverlay;

    private EditText massInput;
    private UnitState massUnit;
    private EditText radiusInput;
    private UnitState radiusUnit;
    private EditText densityInput;
    private UnitState densityUnit;
    private EditText pressureInput;
    private UnitState pressureUnit;
    private EditText surfaceTempInput;
    private UnitState surfaceTempUnit;
    private EditText airTempInput;
    private UnitState airTempUnit;
    private EditText magneticInput;
    private UnitState magneticUnit;
    private EditText waterInput;
    private EditText starClassInput;
    private EditText starNumberInput;
    private EditText simulationTimeInput;
    private UnitState simulationTimeUnit;

    private EditText[] gasInputs;
    private static final String[] GAS_NAMES = new String[] {
        "Кислород", "Водород", "Аргон", "Водяной пар", "Пары серной кислоты",
        "Аммиак", "Углекислый газ", "Угарный газ", "Метан", "Пары ртути", "Пары галлия"
    };

    private AstrobiologicalAnalysisPanel(Context context, FrameLayout rootContainer,
                                         Typeface typefaceRegular, Typeface typefaceSemiBold) {
        this.context = context;
        this.rootContainer = rootContainer;
        this.typefaceRegular = typefaceRegular;
        this.typefaceSemiBold = typefaceSemiBold;
    }

    static void show(Context context, FrameLayout rootContainer,
                     Typeface typefaceRegular, Typeface typefaceSemiBold) {
        new AstrobiologicalAnalysisPanel(context, rootContainer, typefaceRegular, typefaceSemiBold).build();
    }

    private int dp(float value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value,
                context.getResources().getDisplayMetrics());
    }

    private void build() {
        overlayRoot = new FrameLayout(context);
        overlayRoot.setBackgroundColor(Color.parseColor("#CC0F0F10"));
        overlayRoot.setClickable(true);
        overlayRoot.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { close(); }
        });

        final FrameLayout windowFrame = new FrameLayout(context);
        windowFrame.setClickable(true);
        windowFrame.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { }
        });

        GradientDrawable frame = new GradientDrawable();
        frame.setShape(GradientDrawable.RECTANGLE);
        frame.setCornerRadius(dp(28));
        frame.setColor(0xF21E1E20);
        frame.setStroke(dp(2), ACCENT_COLOR);
        windowFrame.setBackground(frame);
        windowFrame.setClipToOutline(true);
        windowFrame.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);

        ImageView blur = new ImageView(context);
        blur.setImageResource(R.drawable.background);
        blur.setScaleType(ImageView.ScaleType.CENTER_CROP);
        blur.setRenderEffect(RenderEffect.createBlurEffect(dp(44), dp(44), Shader.TileMode.CLAMP));
        blur.setAlpha(0.88f);
        windowFrame.addView(blur, matchParentFrameLp());

        View tint = new View(context);
        tint.setBackgroundColor(Color.parseColor("#CC232326"));
        windowFrame.addView(tint, matchParentFrameLp());
        AstroUiEffects.applyPaperEffect(windowFrame, context);

        ScrollView scroll = new ScrollView(context);
        scroll.setClipToPadding(false);
        LinearLayout content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        content.setPadding(pad, pad, pad, pad);

        content.addView(title("Астробиологический анализ"));
        content.addView(spacer(dp(18)));

        content.addView(label("Масса планеты"));
        content.addView(spacer(dp(6)));
        ValueUnitRow mass = buildUnitField(new String[] {"кг", "Земли", "Юпитера"}, "Например, 5.972e24");
        massInput = mass.input; massUnit = mass.state; content.addView(mass.row);

        content.addView(spacer(dp(14)));
        content.addView(label("Радиус планеты"));
        content.addView(spacer(dp(6)));
        ValueUnitRow radius = buildUnitField(new String[] {"м", "км", "Радиуса Земли"}, "Например, 6371");
        radiusInput = radius.input; radiusUnit = radius.state; content.addView(radius.row);

        content.addView(spacer(dp(14)));
        content.addView(label("Плотность планеты (расчётная)"));
        content.addView(spacer(dp(6)));
        ValueUnitRow density = buildUnitField(new String[] {"г/см³", "кг/м³"}, "Рассчитывается автоматически");
        densityInput = density.input; densityUnit = density.state; content.addView(density.row);
        densityInput.addTextChangedListener(new TextWatcher() {
            private boolean internal;
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) { }
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) { }
            @Override public void afterTextChanged(Editable e) {
                if (!internal) {
                    internal = true;
                    updateDensity();
                    internal = false;
                }
            }
        });

        content.addView(spacer(dp(14)));
        content.addView(label("Атмосферное давление"));
        content.addView(spacer(dp(6)));
        ValueUnitRow pressure = buildUnitField(new String[] {"Па", "бар", "атм"}, "Например, 101325");
        pressureInput = pressure.input; pressureUnit = pressure.state; content.addView(pressure.row);

        content.addView(spacer(dp(14)));
        content.addView(buildCompositionButton());
        content.addView(spacer(dp(8)));
        compositionContainer = new LinearLayout(context);
        compositionContainer.setOrientation(LinearLayout.VERTICAL);
        compositionContainer.setVisibility(View.GONE);
        gasInputs = new EditText[GAS_NAMES.length];
        for (int i = 0; i < GAS_NAMES.length; i++) {
            compositionContainer.addView(label(GAS_NAMES[i] + " (%)"));
            compositionContainer.addView(spacer(dp(5)));
            gasInputs[i] = buildPlainField("0");
            compositionContainer.addView(gasInputs[i]);
            if (i + 1 < GAS_NAMES.length) compositionContainer.addView(spacer(dp(10)));
        }
        content.addView(compositionContainer);

        content.addView(spacer(dp(14)));
        content.addView(label("Температура поверхности"));
        content.addView(spacer(dp(6)));
        ValueUnitRow st = buildUnitField(new String[] {"К", "°C", "°F"}, "Например, 288");
        surfaceTempInput = st.input; surfaceTempUnit = st.state; content.addView(st.row);

        content.addView(spacer(dp(14)));
        content.addView(label("Температура воздуха"));
        content.addView(spacer(dp(6)));
        ValueUnitRow at = buildUnitField(new String[] {"К", "°C", "°F"}, "Например, 288");
        airTempInput = at.input; airTempUnit = at.state; content.addView(at.row);

        content.addView(spacer(dp(14)));
        content.addView(label("Сила магнитного поля"));
        content.addView(spacer(dp(6)));
        ValueUnitRow mf = buildUnitField(new String[] {"мкТл", "нТл", "Гс"}, "Например, 50");
        magneticInput = mf.input; magneticUnit = mf.state; content.addView(mf.row);

        content.addView(spacer(dp(14)));
        content.addView(label("Процент суши, занятой водой"));
        content.addView(spacer(dp(6)));
        waterInput = buildPlainField("Например, 71"); content.addView(waterInput);

        content.addView(spacer(dp(14)));
        content.addView(label("Класс звезды"));
        content.addView(spacer(dp(6)));
        starClassInput = buildTextField("Например, G"); content.addView(starClassInput);

        content.addView(spacer(dp(14)));
        content.addView(label("Номер класса звезды (0–9)"));
        content.addView(spacer(dp(6)));
        starNumberInput = buildPlainField("Например, 2"); content.addView(starNumberInput);

        content.addView(spacer(dp(14)));
        content.addView(label("Время симуляции"));
        content.addView(spacer(dp(6)));
        ValueUnitRow sim = buildUnitField(new String[] {"с", "мин", "ч", "сутки"}, "Например, 1");
        simulationTimeInput = sim.input; simulationTimeUnit = sim.state; content.addView(sim.row);

        content.addView(spacer(dp(18)));
        content.addView(buildCalculateButton());
        content.addView(spacer(dp(12)));
        content.addView(buildHint("2000 точек поверхности • dt = 1/150 с • каждый круг один раз обновляет все параметры • рабочие потоки используют все CPU-ядра, кроме главного."));
        content.addView(spacer(dp(12)));

        resultContainer = new LinearLayout(context);
        resultContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(resultContainer);
        content.addView(spacer(dp(20)));

        scroll.addView(content, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        windowFrame.addView(scroll, matchParentFrameLp());

        FrameLayout.LayoutParams windowLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        windowLp.setMargins(dp(18), dp(48), dp(18), dp(48));
        overlayRoot.addView(windowFrame, windowLp);
        rootContainer.addView(overlayRoot, matchParentFrameLp());

        windowFrame.post(new Runnable() {
            @Override public void run() {
                if (overlayRoot != null && overlayRoot.getParent() == rootContainer) {
                    WindowOpenAnimation.start(windowFrame, context.getResources().getDisplayMetrics().density);
                }
            }
        });

        dropdownLayer = new FrameLayout(context);
        overlayRoot.addView(dropdownLayer, matchParentFrameLp());

        massInput.setText("5.972e24");
        massUnit.selectedIndex = 0;
        radiusInput.setText("6371");
        radiusUnit.selectedIndex = 1;
        pressureInput.setText("101325");
        surfaceTempInput.setText("288");
        airTempInput.setText("288");
        magneticInput.setText("50");
        waterInput.setText("71");
        starClassInput.setText("G");
        starNumberInput.setText("2");
        simulationTimeInput.setText("1");
        updateDensity();
    }

    private TextView title(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text); tv.setTextColor(Color.WHITE); tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24); return tv;
    }

    private TextView label(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text); tv.setTextColor(Color.parseColor("#DDE3E1DE"));
        tv.setTypeface(typefaceRegular); tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13); return tv;
    }

    private TextView buildHint(String text) {
        TextView tv = new DigitTextView(context);
        tv.setText(text); tv.setTextColor(Color.parseColor("#99FFFFFF"));
        tv.setTypeface(typefaceRegular);
        AstroUiEffects.applyExplanationTypeface(tv, context); tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        tv.setLineSpacing(dp(2), 1.08f); return tv;
    }

    private View spacer(int h) {
        View v = new View(context); v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)); return v;
    }

    private static final class ValueUnitRow {
        View row; EditText input; UnitState state;
    }

    private static final class UnitState {
        TextView pill; String[] labels; int selectedIndex;
    }

    private ValueUnitRow buildUnitField(final String[] labels, String hint) {
        FrameLayout field = new FrameLayout(context);
        field.setBackground(round(dp(16), FIELD_BG, FIELD_BORDER, dp(1.25f)));
        AstroUiEffects.applyControlShadow(field, context);
        field.setClipToOutline(true);
        final EditText input = new DigitEditText(context);
        input.setHint(hint); input.setHintTextColor(Color.parseColor("#88FFFFFF")); input.setTextColor(Color.WHITE);
        input.setTypeface(typefaceRegular); input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15); input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setBackground(round(dp(16), FIELD_BG, FIELD_BORDER, dp(1.25f)));
        AstroUiEffects.applyControlShadow(input, context);
        input.setPadding(dp(16), dp(12), dp(140), dp(12));
        field.addView(input, matchParentFrameLp());

        final UnitState state = new UnitState(); state.labels = labels; state.selectedIndex = 0;
        final TextView pill = new DigitTextView(context);
        pill.setText(labels[0]); pill.setTextColor(Color.WHITE); pill.setTypeface(typefaceSemiBold); pill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        pill.setGravity(Gravity.CENTER); pill.setMaxLines(1); pill.setBackground(round(dp(14), PILL_BG, FIELD_BORDER, dp(1)));
        pill.setPadding(dp(12), dp(8), dp(12), dp(8));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(118), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.CENTER_VERTICAL | Gravity.END; lp.rightMargin = dp(8); field.addView(pill, lp);
        pill.setTranslationZ(dp(3f));
        state.pill = pill;
        pill.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                HapticUtils.perform(v); openDropdown(pill, labels, state, new Runnable() { @Override public void run() { } });
            }
        });
        field.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));
        ValueUnitRow row = new ValueUnitRow(); row.row = field; row.input = input; row.state = state; return row;
    }

    private EditText buildPlainField(String hint) {
        EditText input = new DigitEditText(context);
        input.setHint(hint); input.setHintTextColor(Color.parseColor("#88FFFFFF")); input.setTextColor(Color.WHITE);
        input.setTypeface(typefaceRegular); input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15); input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setBackground(round(dp(16), FIELD_BG, FIELD_BORDER, dp(1.25f))); input.setPadding(dp(16), dp(12), dp(16), dp(12));
        AstroUiEffects.applyControlShadow(input, context);
        input.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50))); return input;
    }

    private EditText buildTextField(String hint) {
        EditText input = buildPlainField(hint);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        return input;
    }

    private View buildCompositionButton() {
        final TextView btn = new DigitTextView(context);
        btn.setText("Состав атмосферы  ▼"); btn.setTextColor(Color.WHITE); btn.setTypeface(typefaceSemiBold);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15); btn.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        btn.setPadding(dp(16), 0, dp(16), 0); btn.setBackground(round(dp(16), FIELD_BG, FIELD_BORDER, dp(1.25f)));
        btn.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));
        btn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                HapticUtils.perform(v);
                boolean open = compositionContainer.getVisibility() != View.VISIBLE;
                compositionContainer.setVisibility(open ? View.VISIBLE : View.GONE);
                btn.setText(open ? "Состав атмосферы  ▲" : "Состав атмосферы  ▼");
            }
        });
        return btn;
    }

    private View buildCalculateButton() {
        TextView btn = new DigitTextView(context);
        btn.setText("Рассчитать"); btn.setTextColor(Color.WHITE); btn.setTypeface(typefaceSemiBold);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18); btn.setGravity(Gravity.CENTER); btn.setPadding(0, dp(18), 0, dp(18));
        btn.setBackground(round(dp(22), ACCENT_COLOR, Color.parseColor("#33E3E1DE"), dp(1)));
        AstroUiEffects.applyControlShadow(btn, context);
        btn.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        btn.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { HapticUtils.perform(v); calculate(); } });
        return btn;
    }

    private void updateDensity() {
        try {
            double m = massKg(parse(massInput));
            double r = radiusM(parse(radiusInput));
            if (!(m > 0.0) || !(r > 0.0)) return;
            BigDecimal bm = new BigDecimal(Double.toString(m), DECIMAL128);
            BigDecimal br = new BigDecimal(Double.toString(r), DECIMAL128);
            BigDecimal pi = new BigDecimal("3.141592653589793238462643383279502884", DECIMAL128);
            BigDecimal volume = br.pow(3, DECIMAL128).multiply(new BigDecimal("4", DECIMAL128), DECIMAL128)
                    .multiply(pi, DECIMAL128).divide(new BigDecimal("3", DECIMAL128), DECIMAL128);
            BigDecimal kgm3 = bm.divide(volume, DECIMAL128);
            BigDecimal value = densityUnit.selectedIndex == 0
                    ? kgm3.divide(new BigDecimal("1000", DECIMAL128), DECIMAL128)
                    : kgm3;
            String out = value.round(new MathContext(12, RoundingMode.HALF_UP)).stripTrailingZeros().toPlainString();
            densityInput.setText(out);
        } catch (Throwable ignored) { }
    }

    private void calculate() {
        resultContainer.removeAllViews();
        try {
            double mass = massKg(parse(massInput));
            double radius = radiusM(parse(radiusInput));
            double pressure = pressurePa(parse(pressureInput));
            double surfaceK = tempK(parse(surfaceTempInput), surfaceTempUnit.selectedIndex);
            double airK = tempK(parse(airTempInput), airTempUnit.selectedIndex);
            double magnetic = magneticTesla(parse(magneticInput), magneticUnit.selectedIndex);
            double waterPct = clamp(parseOrZero(waterInput), 0.0, 100.0);
            double simSeconds = simulationSeconds(parse(simulationTimeInput), simulationTimeUnit.selectedIndex);
            if (!(mass > 0.0) || !(radius > 0.0)) { error("Масса и радиус планеты должны быть положительными."); return; }
            if (!(pressure >= 0.0) || !(surfaceK > 0.0) || !(airK > 0.0) || !(magnetic >= 0.0)) { error("Проверьте давление, температуры и магнитное поле."); return; }
            if (!(simSeconds > 0.0)) simSeconds = 1.0;

            final Input in = new Input();
            in.massKg = mass; in.radiusM = radius; in.pressurePa = pressure; in.surfaceK = surfaceK; in.airK = airK;
            in.magneticT = magnetic; in.waterFraction = waterPct / 100.0; in.starClass = safeText(starClassInput); in.starNumber = (int) clamp(parseOrZero(starNumberInput), 0, 9);
            in.simSeconds = simSeconds; in.gas = normalizeGases();

            final int circles = safeCircleCount(simSeconds);
            resultContainer.addView(buildHint("Расчёт: " + SURFACE_POINTS + " точек × " + circles + " кругов, dt = 1/150 с. Обработка идёт вне главного потока UI."));
            resultContainer.addView(spacer(dp(10)));
            TextView progress = new DigitTextView(context);
            progress.setText("Выполняется…"); progress.setTextColor(Color.WHITE); progress.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14); resultContainer.addView(progress);

            calculationOverlay = new CalculationProgressOverlay(context, rootContainer);
            calculationOverlay.begin("Астробиологический анализ", ACCENT_COLOR);

            final TextView progressView = progress;
            new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        final Result result = runSimulation(in, circles);
                        mainHandler.post(new Runnable() {
                            @Override public void run() {
                                if (calculationOverlay != null) {
                                    calculationOverlay.update(100, in.simSeconds, "Расчёт завершён");
                                    calculationOverlay.finish();
                                    calculationOverlay = null;
                                }
                                showResult(result, progressView);
                            }
                        });
                    } catch (final Throwable t) {
                        mainHandler.post(new Runnable() {
                            @Override public void run() {
                                if (calculationOverlay != null) {
                                    calculationOverlay.fail("Ошибка расчёта: " + t.getMessage());
                                    calculationOverlay = null;
                                }
                                error("Ошибка расчёта: " + t.getMessage());
                            }
                        });
                    }
                }
            }, "astroforge-astrobio-launcher").start();
        } catch (Throwable t) {
            error("Не удалось подготовить расчёт: " + t.getMessage());
        }
    }

    private Result runSimulation(final Input in, final int circles) {
        final Result out = new Result();
        final double[] temperature = new double[SURFACE_POINTS];
        final double[] pressure = new double[SURFACE_POINTS];
        final double[] wind = new double[SURFACE_POINTS];
        final double[] radiation = new double[SURFACE_POINTS];
        final double[] water = new double[SURFACE_POINTS];
        final int workers = Math.max(1, Runtime.getRuntime().availableProcessors() - 1);
        final ExecutorService pool = Executors.newFixedThreadPool(workers, new NamedFactory());
        try {
            for (int i = 0; i < SURFACE_POINTS; i++) {
                double latitude = -Math.PI / 2.0 + Math.PI * (i + 0.5) / SURFACE_POINTS;
                temperature[i] = in.surfaceK + 10.0 * Math.cos(latitude);
                pressure[i] = in.pressurePa;
                water[i] = in.waterFraction;
            }
            final int progressStep = Math.max(1, circles / 100);
            for (int c = 0; c < circles; c++) {
                runSurfaceCircle(pool, workers, in, temperature, pressure, wind, radiation, water);
                if (c == 0 || ((c + 1) % progressStep == 0) || c + 1 == circles) {
                    int percent = (int) (((long) (c + 1) * 100L) / circles);
                    double simulationSeconds = (c + 1) * DT_SECONDS;
                    if (calculationOverlay != null) {
                        calculationOverlay.update(percent, simulationSeconds, "Круг " + (c + 1) + " из " + circles);
                    }
                }
            }

            BigDecimal sumT = BigDecimal.ZERO;
            BigDecimal sumP = BigDecimal.ZERO;
            BigDecimal sumW = BigDecimal.ZERO;
            double maxWind = 0.0;
            double maxRad = 0.0;
            double minT = Double.POSITIVE_INFINITY;
            double maxT = Double.NEGATIVE_INFINITY;
            for (int i = 0; i < SURFACE_POINTS; i++) {
                sumT = sumT.add(new BigDecimal(Double.toString(temperature[i]), DECIMAL128), DECIMAL128);
                sumP = sumP.add(new BigDecimal(Double.toString(pressure[i]), DECIMAL128), DECIMAL128);
                sumW = sumW.add(new BigDecimal(Double.toString(water[i]), DECIMAL128), DECIMAL128);
                if (wind[i] > maxWind) maxWind = wind[i];
                if (radiation[i] > maxRad) maxRad = radiation[i];
                if (temperature[i] < minT) minT = temperature[i];
                if (temperature[i] > maxT) maxT = temperature[i];
            }
            BigDecimal n = new BigDecimal(Integer.toString(SURFACE_POINTS), DECIMAL128);
            out.averageTemperatureK = sumT.divide(n, DECIMAL128).doubleValue();
            out.averagePressurePa = sumP.divide(n, DECIMAL128).doubleValue();
            out.waterFraction = sumW.divide(n, DECIMAL128).doubleValue();
            out.maxWindMs = maxWind; out.maxRadiation = maxRad; out.minTemperatureK = minT; out.maxTemperatureK = maxT;

            double gravity = 6.67430e-11 * in.massKg / (in.radiusM * in.radiusM);
            double escape = Math.sqrt(2.0 * 6.67430e-11 * in.massKg / in.radiusM);
            double density = in.massKg / ((4.0 / 3.0) * Math.PI * in.radiusM * in.radiusM * in.radiusM);
            out.gravity = gravity; out.escapeVelocity = escape; out.densityKgM3 = density;
            double gravityScore = clamp(gravity / 9.80665, 0.0, 2.0);
            double pressureScore = pressureCompatibility(in.pressurePa);
            double tempScore = temperatureCompatibility(out.averageTemperatureK);
            double waterScore = 1.0 - Math.abs(out.waterFraction - 0.70);
            double magneticScore = clamp(in.magneticT / 50e-6, 0.0, 1.0);
            out.environmentIndex = 100.0 * clamp(0.25 * gravityScore + 0.25 * pressureScore + 0.25 * tempScore + 0.15 * waterScore + 0.10 * magneticScore, 0.0, 1.0);
            return out;
        } finally {
            pool.shutdownNow();
        }
    }

    private void runSurfaceCircle(ExecutorService pool, int workers, final Input in,
                                  final double[] temperature, final double[] pressure,
                                  final double[] wind, final double[] radiation, final double[] water) {
        final CountDownLatch latch = new CountDownLatch(workers);
        int base = SURFACE_POINTS / workers;
        int rem = SURFACE_POINTS % workers;
        int start = 0;
        for (int w = 0; w < workers; w++) {
            final int from = start;
            final int to = from + base + (w < rem ? 1 : 0);
            start = to;
            pool.execute(new Runnable() {
                @Override public void run() {
                    try {
                        for (int i = from; i < to; i++) {
                            double latitude = -Math.PI / 2.0 + Math.PI * (i + 0.5) / SURFACE_POINTS;
                            double solar = starFlux(in.starClass, in.starNumber, latitude);
                            double localWater = water[i];
                            double evaporation = evaporationRate(temperature[i], in.pressurePa, localWater);
                            double condensation = condensationRate(temperature[i], in.airK, localWater);
                            localWater = clamp(localWater + (condensation - evaporation) * DT_SECONDS, 0.0, 1.0);
                            water[i] = localWater;
                            double gasPressure = in.pressurePa * gasPressureFactor(in.gas, temperature[i]);
                            pressure[i] += (gasPressure - pressure[i]) * 0.002;
                            double deltaT = in.surfaceK - temperature[i];
                            double heat = solar * 5.0 + deltaT * 0.08 + localWater * 0.5;
                            temperature[i] += heat * DT_SECONDS;
                            wind[i] = Math.abs(deltaT) * 0.35 + solar * 0.6 + pressureGradient(pressure[i], in.pressurePa);
                            radiation[i] = solar * 1.0e-3;
                        }
                    } finally { latch.countDown(); }
                }
            });
        }
        try { latch.await(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    private double[] normalizeGases() {
        double[] g = new double[GAS_NAMES.length];
        double total = 0.0;
        for (int i = 0; i < g.length; i++) { g[i] = Math.max(0.0, parseOrZero(gasInputs[i])); total += g[i]; }
        if (total <= 0.0) { g[0] = 21.0; g[1] = 0.0; g[2] = 0.93; g[6] = 0.04; total = 22.97; }
        for (int i = 0; i < g.length; i++) g[i] /= total;
        return g;
    }

    private double gasPressureFactor(double[] g, double tempK) {
        double reactive = g[0] * 0.02 + g[4] * 0.16 + g[5] * 0.04 + g[6] * 0.06 + g[7] * 0.01 + g[8] * 0.03 + g[9] * 0.18 + g[10] * 0.14;
        double thermal = clamp((tempK - 200.0) / 150.0, 0.2, 4.0);
        return 1.0 + reactive * thermal;
    }

    private double evaporationRate(double tempK, double pressurePa, double waterFraction) {
        double thermal = 1.0 / (1.0 + Math.exp(-(tempK - 273.15) / 12.0));
        double pressureSuppression = 1.0 / (1.0 + Math.max(0.0, pressurePa) / 5.0e6);
        return waterFraction * thermal * pressureSuppression * 0.02;
    }

    private double condensationRate(double tempK, double airK, double waterFraction) {
        double cold = clamp((airK - tempK) / 60.0, -1.0, 1.0);
        return waterFraction * Math.max(0.0, cold) * 0.015;
    }

    private double starFlux(String cls, int number, double latitude) {
        String c = cls == null ? "G" : cls.toUpperCase(Locale.US);
        double base;
        if (c.startsWith("O")) base = 3.0;
        else if (c.startsWith("B")) base = 2.5;
        else if (c.startsWith("A")) base = 1.8;
        else if (c.startsWith("F")) base = 1.3;
        else if (c.startsWith("K")) base = 0.75;
        else if (c.startsWith("M")) base = 0.25;
        else if (c.startsWith("L")) base = 0.10;
        else if (c.startsWith("T")) base = 0.04;
        else if (c.startsWith("Y")) base = 0.01;
        else base = 1.0;
        double subtype = 1.0 - (number * 0.025);
        return base * Math.max(0.6, subtype) * Math.max(0.05, Math.cos(latitude));
    }

    private double pressureGradient(double p, double baseline) { return Math.abs(p - baseline) / Math.max(1.0, baseline) * 20.0; }
    private double pressureCompatibility(double p) { return 1.0 / (1.0 + Math.abs(Math.log(Math.max(1.0, p) / 101325.0))); }
    private double temperatureCompatibility(double k) { return Math.exp(-Math.abs(k - 288.15) / 60.0); }

    private void showResult(Result r, TextView progress) {
        if (progress != null) progress.setText("Расчёт завершён");
        resultContainer.addView(spacer(dp(10)));
        resultContainer.addView(resultTitle("Результаты симуляции"));
        resultContainer.addView(resultLine("Гравитация поверхности", format(r.gravity) + " м/с²"));
        resultContainer.addView(resultLine("Скорость убегания", format(r.escapeVelocity) + " м/с"));
        resultContainer.addView(resultLine("Плотность", format(r.densityKgM3 / 1000.0) + " г/см³"));
        resultContainer.addView(resultLine("Средняя температура", format(r.averageTemperatureK) + " K"));
        resultContainer.addView(resultLine("Диапазон температуры", format(r.minTemperatureK) + "…" + format(r.maxTemperatureK) + " K"));
        resultContainer.addView(resultLine("Среднее давление", format(r.averagePressurePa) + " Па"));
        resultContainer.addView(resultLine("Максимальная скорость ветра", format(r.maxWindMs) + " м/с"));
        resultContainer.addView(resultLine("Максимальная радиационная нагрузка (отн.)", format(r.maxRadiation)));
        resultContainer.addView(resultLine("Средняя доля воды", format(r.waterFraction * 100.0) + " %"));
        resultContainer.addView(resultLine("Индекс совместимости среды", format(r.environmentIndex) + " / 100"));
        resultContainer.addView(spacer(dp(8)));
        resultContainer.addView(buildHint("Индекс — диагностическая оценка условий среды, а не вероятность существования жизни."));
    }

    private TextView resultTitle(String text) {
        TextView tv = new DigitTextView(context); tv.setText(text); tv.setTextColor(Color.WHITE); tv.setTypeface(typefaceSemiBold);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16); return tv;
    }

    private View resultLine(String label, String value) {
        LinearLayout row = new LinearLayout(context); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView a = new DigitTextView(context); a.setText(label + ": "); a.setTextColor(Color.parseColor("#BBFFFFFF")); a.setTypeface(typefaceRegular); a.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        TextView b = new DigitTextView(context); b.setText(value); b.setTextColor(ACCENT_COLOR); b.setTypeface(typefaceSemiBold); b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        row.addView(a); row.addView(b); return row;
    }

    private void error(String message) {
        TextView tv = new DigitTextView(context); tv.setText(message); tv.setTextColor(Color.parseColor("#FFFFB0A0")); tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13); resultContainer.addView(tv);
    }

    private void openDropdown(final View anchor, final String[] labels, final UnitState state, final Runnable ignored) {
        dropdownLayer.removeAllViews();
        int[] a = new int[2]; anchor.getLocationOnScreen(a); int[] r = new int[2]; dropdownLayer.getLocationOnScreen(r);
        int x = a[0] - r[0]; int y = a[1] - r[1] + anchor.getHeight();
        View scrim = new View(context); scrim.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { dropdownLayer.removeAllViews(); } }); dropdownLayer.addView(scrim, matchParentFrameLp());
        LinearLayout list = new LinearLayout(context); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(6), dp(6), dp(6), dp(6)); list.setBackground(round(dp(14), DROPDOWN_BG, ACCENT_BORDER_COLOR, dp(1.25f)));
        for (int i = 0; i < labels.length; i++) {
            final int index = i; TextView item = new DigitTextView(context); item.setText(labels[i]); item.setTextColor(i == state.selectedIndex ? ACCENT_COLOR : Color.WHITE); item.setTypeface(i == state.selectedIndex ? typefaceSemiBold : typefaceRegular);
            AstroUiEffects.applyUnitTypeface(item, context); item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14); item.setPadding(dp(14), dp(10), dp(14), dp(10));
            item.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { HapticUtils.perform(v); state.selectedIndex = index; state.pill.setText(state.labels[index]); dropdownLayer.removeAllViews(); updateDensity(); } }); list.addView(item, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        ScrollView sv = new ScrollView(context); sv.addView(list, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(190), ViewGroup.LayoutParams.WRAP_CONTENT); lp.leftMargin = Math.max(dp(8), x + anchor.getWidth() - dp(190)); lp.topMargin = y + dp(4); dropdownLayer.addView(sv, lp);
    }

    private GradientDrawable round(float radius, int fill, int stroke, int width) { GradientDrawable gd = new GradientDrawable(); gd.setShape(GradientDrawable.RECTANGLE); gd.setCornerRadius(radius); gd.setColor(fill); gd.setStroke(width, stroke); return gd; }
    private FrameLayout.LayoutParams matchParentFrameLp() { return new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT); }

    private void close() { if (overlayRoot != null && overlayRoot.getParent() == rootContainer) rootContainer.removeView(overlayRoot); }

    private Double parse(EditText e) { try { String s = e == null ? "" : e.getText().toString().trim().replace(',', '.'); if (s.length() == 0) return null; return Double.valueOf(s); } catch (Throwable t) { return null; } }
    private double parseOrZero(EditText e) { Double d = parse(e); return d == null || d.isNaN() || d.isInfinite() ? 0.0 : d.doubleValue(); }
    private double massKg(Double x) { if (x == null) return 0.0; if (massUnit.selectedIndex == 1) return x * 5.9722e24; if (massUnit.selectedIndex == 2) return x * 1.89813e27; return x; }
    private double radiusM(Double x) { if (x == null) return 0.0; if (radiusUnit.selectedIndex == 1) return x * 1000.0; if (radiusUnit.selectedIndex == 2) return x * 6.371e6; return x; }
    private double pressurePa(Double x) { if (x == null) return -1.0; if (pressureUnit.selectedIndex == 1) return x * 1.0e5; if (pressureUnit.selectedIndex == 2) return x * 101325.0; return x; }
    private double tempK(Double x, int unit) { if (x == null) return 0.0; if (unit == 1) return x + 273.15; if (unit == 2) return (x - 32.0) * 5.0 / 9.0 + 273.15; return x; }
    private double magneticTesla(Double x, int unit) { if (x == null) return 0.0; if (unit == 1) return x * 1.0e-9; if (unit == 2) return x * 1.0e-4; return x * 1.0e-6; }
    private double simulationSeconds(Double x, int unit) { if (x == null) return 1.0; if (unit == 1) return x * 60.0; if (unit == 2) return x * 3600.0; if (unit == 3) return x * 86400.0; return x; }
    private int safeCircleCount(double seconds) { double raw = seconds * CIRCLES_PER_SECOND; if (raw > 500000.0) return 500000; if (raw < 1.0) return 1; return (int)Math.round(raw); }
    private String safeText(EditText e) { String s = e == null ? "" : e.getText().toString().trim(); return s.length() == 0 ? "G" : s; }
    private double clamp(double x, double min, double max) { return Math.max(min, Math.min(max, x)); }
    private String format(double x) { if (Double.isNaN(x) || Double.isInfinite(x)) return "—"; return String.format(Locale.US, "%.6g", x); }

    private static final class Input {
        double massKg, radiusM, pressurePa, surfaceK, airK, magneticT, waterFraction, simSeconds; int starNumber; String starClass; double[] gas;
    }
    private static final class Result {
        double gravity, escapeVelocity, densityKgM3, averageTemperatureK, minTemperatureK, maxTemperatureK, averagePressurePa, maxWindMs, maxRadiation, waterFraction, environmentIndex;
    }
    private static final class NamedFactory implements ThreadFactory {
        private final AtomicInteger n = new AtomicInteger();
        @Override public Thread newThread(Runnable r) { Thread t = new Thread(r, "astroforge-astrobio-" + n.getAndIncrement()); t.setDaemon(true); return t; }
    }
}
