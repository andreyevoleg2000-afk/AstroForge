package com.astroforge;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Locale;

/**
 * Full-screen locked calculation overlay shared by long-running windows.
 * It captures the current UI, blurs the snapshot, and puts a themed progress card
 * above it. Touches never reach the underlying window until finish().
 */
final class CalculationProgressOverlay {

    private static final int DEFAULT_ACCENT = 0xFFD9946B;
    private static final int CARD_FILL = Color.parseColor("#E51E1E20");
    private static final int TEXT_PRIMARY = Color.WHITE;
    private static final int TEXT_SECONDARY = Color.parseColor("#B8FFFFFF");

    private final Context context;
    private final FrameLayout rootContainer;
    private final HandlerBridge handlerBridge;

    private FrameLayout overlay;
    private TextView percentText;
    private TextView simulationText;
    private TextView statusText;
    private ProgressBar progressBar;
    private ProgressDrawable progressDrawable;
    private String title = "Расчёт";
    private int accent = DEFAULT_ACCENT;
    private boolean active;
    private boolean keepAliveService;

    CalculationProgressOverlay(Context context, FrameLayout rootContainer) {
        this.context = context;
        this.rootContainer = rootContainer;
        this.handlerBridge = new HandlerBridge();
    }

    void begin(final String title, final int accentColor) {
        begin(title, accentColor, true);
    }

    void begin(final String title, final int accentColor, boolean keepAliveService) {
        if (active) {
            return;
        }
        active = true;
        this.keepAliveService = keepAliveService;
        this.title = title == null ? "Расчёт" : title;
        this.accent = accentColor == 0 ? DEFAULT_ACCENT : accentColor;

        Bitmap snapshot = captureRoot();

        overlay = new FrameLayout(context);
        overlay.setClickable(true);
        overlay.setFocusable(true);
        overlay.setFocusableInTouchMode(true);
        overlay.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                // Intentionally consume every click while calculation is active.
            }
        });
        overlay.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, android.view.MotionEvent event) {
                return true;
            }
        });

        if (snapshot != null) {
            ImageView blurredSnapshot = new ImageView(context);
            blurredSnapshot.setScaleType(ImageView.ScaleType.FIT_XY);
            blurredSnapshot.setImageBitmap(BlurUtils.fastBlur(snapshot, 0.20f, 8));
            blurredSnapshot.setAlpha(0.96f);
            addMatchParent(overlay, blurredSnapshot);
        } else {
            overlay.setBackgroundColor(Color.parseColor("#CC101012"));
        }

        View tint = new View(context);
        tint.setBackgroundColor(Color.parseColor("#880F0F10"));
        addMatchParent(overlay, tint);

        LinearLayout card = buildCard();
        FrameLayout.LayoutParams cardLp = new FrameLayout.LayoutParams(
                dp(316), ViewGroup.LayoutParams.WRAP_CONTENT
        );
        cardLp.gravity = Gravity.CENTER;
        overlay.addView(card, cardLp);

        rootContainer.addView(overlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        overlay.bringToFront();
        overlay.requestFocus();

        if (keepAliveService) {
            CalculationKeepAliveService.start(context, this.title);
        }
        requestNotificationPermissionIfNeeded();
        update(0, 0.0, "Подготовка расчёта…");
    }

    void update(final int percent, final double simulationSeconds, final String status) {
        final int safePercent = Math.max(0, Math.min(100, percent));
        final String safeStatus = status == null ? "Выполняется расчёт…" : status;
        handlerBridge.post(new Runnable() {
            @Override public void run() {
                if (!active || overlay == null) {
                    return;
                }
                if (progressBar != null) {
                    progressBar.setProgress(safePercent);
                }
                if (progressDrawable != null) {
                    progressDrawable.setProgress(safePercent);
                }
                if (percentText != null) {
                    percentText.setText(safePercent + " %");
                }
                if (simulationText != null) {
                    simulationText.setText("Время симуляции: " + formatSimulationTime(simulationSeconds));
                }
                if (statusText != null) {
                    statusText.setText(safeStatus);
                }
                if (keepAliveService) {
                    CalculationKeepAliveService.update(
                            context,
                            safePercent,
                            safePercent + " % • " + formatSimulationTime(simulationSeconds)
                    );
                }
            }
        });
    }

    void finish() {
        handlerBridge.post(new Runnable() {
            @Override public void run() {
                active = false;
                if (overlay != null && overlay.getParent() == rootContainer) {
                    rootContainer.removeView(overlay);
                }
                overlay = null;
                if (keepAliveService) {
                    CalculationKeepAliveService.stop(context);
                }
            }
        });
    }

    void fail(final String message) {
        handlerBridge.post(new Runnable() {
            @Override public void run() {
                if (statusText != null) {
                    statusText.setText(message == null ? "Ошибка расчёта" : message);
                }
                if (keepAliveService) {
                    CalculationKeepAliveService.update(context, 0, "Ошибка расчёта");
                }
                active = false;
                if (overlay != null && overlay.getParent() == rootContainer) {
                    rootContainer.removeView(overlay);
                }
                overlay = null;
                if (keepAliveService) {
                    CalculationKeepAliveService.stop(context);
                }
            }
        });
    }

    private void requestNotificationPermissionIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT >= 33 && context instanceof Activity) {
            try {
                Activity activity = (Activity) context;
                if (activity.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                        != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    activity.requestPermissions(
                            new String[]{android.Manifest.permission.POST_NOTIFICATIONS},
                            1842
                    );
                }
            } catch (Throwable ignored) {
            }
        }
    }

    private LinearLayout buildCard() {
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(20), dp(20), dp(20));

        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(24));
        bg.setColor(CARD_FILL);
        bg.setStroke(dp(2), accent);
        card.setBackground(bg);

        TextView titleView = textView(title, TEXT_PRIMARY, 18, true);
        card.addView(titleView);

        TextView subtitle = textView("Длительный расчёт", TEXT_SECONDARY, 12, false);
        LinearLayout.LayoutParams subtitleLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        subtitleLp.topMargin = dp(3);
        card.addView(subtitle, subtitleLp);

        progressBar = new ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setIndeterminate(false);
        progressDrawable = new ProgressDrawable(accent);
        progressBar.setProgressDrawable(progressDrawable);
        LinearLayout.LayoutParams progressLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(14)
        );
        progressLp.topMargin = dp(20);
        card.addView(progressBar, progressLp);

        LinearLayout info = new LinearLayout(context);
        info.setOrientation(LinearLayout.HORIZONTAL);
        info.setGravity(Gravity.CENTER_VERTICAL);

        percentText = textView("0 %", TEXT_PRIMARY, 15, true);
        info.addView(percentText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        simulationText = textView("Время симуляции: 0 с", TEXT_SECONDARY, 12, false);
        simulationText.setGravity(Gravity.END);
        info.addView(simulationText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f));

        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        infoLp.topMargin = dp(10);
        card.addView(info, infoLp);

        statusText = textView("Подготовка расчёта…", TEXT_SECONDARY, 12, false);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        statusLp.topMargin = dp(10);
        card.addView(statusText, statusLp);

        return card;
    }

    private TextView textView(String text, int color, float size, boolean bold) {
        TextView view = new TextView(context);
        view.setText(text);
        view.setTextColor(color);
        view.setTextSize(size);
        view.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) {
            view.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        }
        return view;
    }

    private Bitmap captureRoot() {
        try {
            int width = rootContainer.getWidth();
            int height = rootContainer.getHeight();
            if (width <= 0 || height <= 0) {
                return null;
            }
            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            rootContainer.draw(canvas);
            return bitmap;
        } catch (Throwable t) {
            return null;
        }
    }

    private void addMatchParent(FrameLayout parent, View child) {
        parent.addView(child, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
    }

    private int dp(float value) {
        return (int) (value * context.getResources().getDisplayMetrics().density + 0.5f);
    }

    private String formatSimulationTime(double seconds) {
        if (Double.isNaN(seconds) || Double.isInfinite(seconds)) {
            return "—";
        }
        if (Math.abs(seconds) < 60.0) {
            return String.format(Locale.US, "%.2f с", seconds);
        }
        if (Math.abs(seconds) < 3600.0) {
            return String.format(Locale.US, "%.2f мин", seconds / 60.0);
        }
        if (Math.abs(seconds) < 86400.0) {
            return String.format(Locale.US, "%.2f ч", seconds / 3600.0);
        }
        return String.format(Locale.US, "%.2f сут", seconds / 86400.0);
    }

    private static final class HandlerBridge {
        private final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
        void post(Runnable runnable) { handler.post(runnable); }
    }

    private static final class ProgressDrawable extends android.graphics.drawable.Drawable {
        private final Paint background = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int progress;
        private final int accent;

        ProgressDrawable(int accent) {
            this.accent = accent;
            background.setColor(Color.parseColor("#403F3F42"));
            fill.setColor(accent);
        }

        @Override protected void onBoundsChange(android.graphics.Rect bounds) { }

        @Override public void draw(Canvas canvas) {
            android.graphics.Rect bounds = getBounds();
            float radius = bounds.height() / 2.0f;
            canvas.drawRoundRect(bounds.left, bounds.top, bounds.right, bounds.bottom, radius, radius, background);
            float right = bounds.left + bounds.width() * (progress / 100.0f);
            canvas.drawRoundRect(bounds.left, bounds.top, right, bounds.bottom, radius, radius, fill);
        }

        @Override public void setAlpha(int alpha) { background.setAlpha(alpha); fill.setAlpha(alpha); }
        @Override public void setColorFilter(android.graphics.ColorFilter colorFilter) { background.setColorFilter(colorFilter); fill.setColorFilter(colorFilter); }
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
        @Override public int getIntrinsicHeight() { return 14; }

        void setProgress(int value) {
            progress = Math.max(0, Math.min(100, value));
            invalidateSelf();
        }

        @Override
        protected boolean onLevelChange(int level) {
            setProgress(level);
            return true;
        }
    }

    private static final class BlurUtils {
        static Bitmap fastBlur(Bitmap source, float scale, int radius) {
            if (source == null) {
                return null;
            }
            int width = Math.max(1, Math.round(source.getWidth() * scale));
            int height = Math.max(1, Math.round(source.getHeight() * scale));
            Bitmap small = Bitmap.createScaledBitmap(source, width, height, true);
            source.recycle();

            if (radius <= 0) {
                return small;
            }

            int[] pixels = new int[width * height];
            small.getPixels(pixels, 0, width, 0, 0, width, height);

            int[] temp = new int[pixels.length];
            int diameter = radius * 2 + 1;

            for (int y = 0; y < height; y++) {
                int row = y * width;
                for (int x = 0; x < width; x++) {
                    int rs = 0, gs = 0, bs = 0, count = 0;
                    for (int k = -radius; k <= radius; k++) {
                        int xx = x + k;
                        if (xx < 0) xx = 0;
                        if (xx >= width) xx = width - 1;
                        int c = pixels[row + xx];
                        rs += (c >> 16) & 0xFF;
                        gs += (c >> 8) & 0xFF;
                        bs += c & 0xFF;
                        count++;
                    }
                    temp[row + x] = (0xFF << 24) | ((rs / count) << 16) | ((gs / count) << 8) | (bs / count);
                }
            }

            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    int rs = 0, gs = 0, bs = 0, count = 0;
                    for (int k = -radius; k <= radius; k++) {
                        int yy = y + k;
                        if (yy < 0) yy = 0;
                        if (yy >= height) yy = height - 1;
                        int c = temp[yy * width + x];
                        rs += (c >> 16) & 0xFF;
                        gs += (c >> 8) & 0xFF;
                        bs += c & 0xFF;
                        count++;
                    }
                    pixels[y * width + x] = (0xFF << 24) | ((rs / count) << 16) | ((gs / count) << 8) | (bs / count);
                }
            }

            Bitmap blurred = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            blurred.setPixels(pixels, 0, width, 0, 0, width, height);
            small.recycle();
            return blurred;
        }
    }
}
