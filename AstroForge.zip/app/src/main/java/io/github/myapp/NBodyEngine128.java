package io.github.myapp;

import java.util.LinkedHashSet;
import java.util.Set;

/*
 * SoA-сборка + ФИКС ПРОИЗВОДИТЕЛЬНОСТИ и ФИКС ВЫВОДА wob.
 *  - Порог PAR_THRESHOLD: при малом числе тел расчёт ОДНОПОТОЧНЫЙ, без пула и без барьеров,
 *    с симметрией Ньютона (x2 быстрее). Пул (и его барьеры) включаются только при N>порога,
 *    где работы хватает их окупить.
 *  - wob выводится как смещение родителя от ЦЕНТРА МАСС по осям (X,Y) км.
 *  - Дрейф энергии ~1e-16 доказывает корректность SoA-формул.
 * Без record / без Math.fma / без Math.cbrt / без List.of / без лямбд / без diamond.
 */

// =====================================================================================
//  SoA-контейнер состояния: плоские double[] вместо объектов. Ноль аллокаций в цикле.
// =====================================================================================
final class BodyArrays {
    final int n;
    final double[] pxH, pxL, pyH, pyL, pzH, pzL;
    final double[] vxH, vxL, vyH, vyL, vzH, vzL;
    final double[] axH, axL, ayH, ayL, azH, azL;

    BodyArrays(int n) {
        this.n = n;
        pxH = new double[n]; pxL = new double[n];
        pyH = new double[n]; pyL = new double[n];
        pzH = new double[n]; pzL = new double[n];
        vxH = new double[n]; vxL = new double[n];
        vyH = new double[n]; vyL = new double[n];
        vzH = new double[n]; vzL = new double[n];
        axH = new double[n]; axL = new double[n];
        ayH = new double[n]; ayL = new double[n];
        azH = new double[n]; azL = new double[n];
    }
}

// =====================================================================================
//  ПУЛ ПОТОКОВ (только для N>порога). Рабочие стартуют с myGen=0.
// =====================================================================================
final class WorkerPool {
    static final int PH_DRIFT = 0;
    static final int PH_ACC = 1;
    static final int PH_KICK = 2;

    private final Object lock = new Object();
    private final int workers;
    private final int n;
    private final int[] from;
    private final int[] to;
    private final Thread[] threads;
    private final double[][] scr;

    private int phase;
    private double subDt;
    private BodyArrays ba;
    private double[] masses;
    private double[] radii;
    private long[] ids;
    private Set<Long>[] collSlots;

    private long generation;
    private int finished;
    private boolean dead;

    @SuppressWarnings("unchecked")
    WorkerPool(int workers, int n) {
        this.workers = workers;
        this.n = n;
        this.from = new int[workers];
        this.to = new int[workers];
        int base = n / workers;
        int rem = n % workers;
        int cur = 0;
        for (int w = 0; w < workers; w++) {
            from[w] = cur;
            cur += base + (w < rem ? 1 : 0);
            to[w] = cur;
        }
        this.scr = new double[workers][NBodyEngine128.SCRATCH];
        this.collSlots = new Set[workers];
        for (int w = 0; w < workers; w++) collSlots[w] = new LinkedHashSet<Long>();

        this.threads = new Thread[workers];
        for (int w = 0; w < workers; w++) {
            final int wid = w;
            Thread t = new Thread(new Runnable() {
                @Override public void run() { workerLoop(wid); }
            }, "nbody-worker-" + w);
            t.setDaemon(true);
            threads[w] = t;
            t.start();
        }
    }

    private void workerLoop(final int wid) {
        long myGen = 0L;
        while (true) {
            int ph; double sub; int f; int t;
            BodyArrays b; double[] m; double[] rd; long[] id; Set<Long> cs; double[] w;
            synchronized (lock) {
                while (!dead && myGen == generation) {
                    try { lock.wait(); } catch (InterruptedException ie) { return; }
                }
                if (dead) return;
                myGen = generation;
                ph = phase; sub = subDt; f = from[wid]; t = to[wid];
                b = ba; m = masses; rd = radii; id = ids; cs = collSlots[wid]; w = scr[wid];
            }
            runChunk(ph, sub, f, t, wid, b, m, rd, id, cs, w);
            synchronized (lock) {
                finished++;
                if (finished == workers) lock.notifyAll();
            }
        }
    }

    private void runChunk(int ph, double sub, int f, int t, int wid,
                          BodyArrays b, double[] m, double[] rd, long[] id,
                          Set<Long> cs, double[] w) {
        if (ph == PH_DRIFT) {
            NBodyEngine128.driftRange(b, f, t, sub, w);
        } else if (ph == PH_KICK) {
            NBodyEngine128.kickRange(b, f, t, sub, w);
        } else {
            NBodyEngine128.accRange(b, m, rd, id, n, f, t, wid, cs, w);
        }
    }

    void runPhase(int ph, double sub, BodyArrays b, double[] m, double[] rd, long[] id) {
        synchronized (lock) {
            this.phase = ph; this.subDt = sub;
            this.ba = b; this.masses = m; this.radii = rd; this.ids = id;
            this.finished = 0;
            this.generation++;
            lock.notifyAll();
            while (finished < workers) {
                try { lock.wait(); } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
        }
    }

    void mergeCollisions(Set<Long> into) {
        for (int w = 0; w < workers; w++) {
            if (!collSlots[w].isEmpty()) {
                into.addAll(collSlots[w]);
                collSlots[w].clear();
            }
        }
    }

    void shutdown() {
        synchronized (lock) {
            dead = true;
            lock.notifyAll();
        }
    }
}

// =====================================================================================
//  ДВИЖОК SoA: все DD-операции — static, без объектов. Плюс однопоточный шаг с симметрией.
// =====================================================================================
public final class NBodyEngine128 {
    public static final double G = 6.67430e-11;
    public static final double SECONDS_PER_YEAR = 365.25 * 86400.0;
    private static final double SPLIT = 134217729.0;

    private static final double CBRT2 = 1.2599210498948732;
    private static final double YOSHIDA_W1 = 1.0 / (2.0 - CBRT2);
    private static final double YOSHIDA_W0 = 1.0 - 2.0 * YOSHIDA_W1;
    private static final double C1 = YOSHIDA_W1 / 2.0;
    private static final double C4 = C1;
    private static final double C2 = (YOSHIDA_W0 + YOSHIDA_W1) / 2.0;
    private static final double C3 = C2;
    private static final double D1 = YOSHIDA_W1;
    private static final double D3 = D1;
    private static final double D2 = YOSHIDA_W0;

    static final int O_DX = 0, O_DY = 2, O_DZ = 4;
    static final int O_DX2 = 6, O_DY2 = 8, O_DZ2 = 10, O_R2P = 12, O_R2 = 14;
    static final int O_R = 16, O_R3 = 18, O_INV = 20, O_FAC = 22;
    static final int O_TX = 24, O_TY = 26, O_TZ = 28, O_ACC = 30;
    static final int SCRATCH = 32;


    // =====================================================================================
    //  Compatibility layer for the existing UI code in this project.
    //  It keeps the current screen unchanged while routing the math through this engine.
    // =====================================================================================

    public static final class DD {
        private final double hi;
        private final double lo;

        public DD(double hi, double lo) {
            this.hi = hi;
            this.lo = lo;
        }

        public static DD of(double value) {
            return new DD(value, 0.0);
        }

        public double toDouble() {
            return hi + lo;
        }
    }

    public static final class Vector3D_128 {
        private final DD x;
        private final DD y;
        private final DD z;

        public Vector3D_128(DD x, DD y, DD z) {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        public static Vector3D_128 of(double x, double y, double z) {
            return new Vector3D_128(DD.of(x), DD.of(y), DD.of(z));
        }

        public static Vector3D_128 of(DD x, DD y, DD z) {
            return new Vector3D_128(x, y, z);
        }

        public DD x() { return x; }
        public DD y() { return y; }
        public DD z() { return z; }
    }

    public static final class Planet {
        private final long id;
        private final double massKg;
        private final double radiusM;
        private final Vector3D_128 position;
        private final Vector3D_128 velocity;

        public Planet(long id, double massKg, double radiusM,
                      Vector3D_128 position, Vector3D_128 velocity) {
            this.id = id;
            this.massKg = massKg;
            this.radiusM = radiusM;
            this.position = position;
            this.velocity = velocity;
        }

        public long id() { return id; }
        public double massKg() { return massKg; }
        public double radiusM() { return radiusM; }
        public Vector3D_128 position() { return position; }
        public Vector3D_128 velocity() { return velocity; }
    }

    public static final class EngineInput {
        private final java.util.List<Planet> planets;
        private final double dt;

        public EngineInput(java.util.List<Planet> planets, double dt) {
            this.planets = planets;
            this.dt = dt;
        }

        public java.util.List<Planet> planets() { return planets; }
        public double dt() { return dt; }
    }

    public static final class EngineOutput {
        private final java.util.List<Planet> planets;
        private final java.util.List<Long> collidedIds;

        public EngineOutput(java.util.List<Planet> planets, java.util.List<Long> collidedIds) {
            this.planets = planets;
            this.collidedIds = collidedIds;
        }

        public java.util.List<Planet> planets() { return planets; }
        public java.util.List<Long> collidedIds() { return collidedIds; }
    }

    private static BodyArrays buildArrays(java.util.List<Planet> planets,
                                          double[] masses,
                                          double[] radii,
                                          long[] ids) {
        final int n = planets.size();
        BodyArrays ba = new BodyArrays(n);
        for (int i = 0; i < n; i++) {
            Planet p = planets.get(i);
            ids[i] = p.id();
            masses[i] = p.massKg();
            radii[i] = p.radiusM();
            Vector3D_128 pos = p.position();
            Vector3D_128 vel = p.velocity();
            ba.pxH[i] = pos.x().toDouble();
            ba.pyH[i] = pos.y().toDouble();
            ba.pzH[i] = pos.z().toDouble();
            ba.vxH[i] = vel.x().toDouble();
            ba.vyH[i] = vel.y().toDouble();
            ba.vzH[i] = vel.z().toDouble();
            ba.pxL[i] = 0.0;
            ba.pyL[i] = 0.0;
            ba.pzL[i] = 0.0;
            ba.vxL[i] = 0.0;
            ba.vyL[i] = 0.0;
            ba.vzL[i] = 0.0;
            ba.axH[i] = 0.0;
            ba.ayH[i] = 0.0;
            ba.azH[i] = 0.0;
            ba.axL[i] = 0.0;
            ba.ayL[i] = 0.0;
            ba.azL[i] = 0.0;
        }
        return ba;
    }

    private static java.util.List<Planet> buildPlanets(BodyArrays ba,
                                                       java.util.List<Planet> src,
                                                       int n) {
        java.util.ArrayList<Planet> out = new java.util.ArrayList<Planet>(n);
        for (int i = 0; i < n; i++) {
            Planet p = src.get(i);
            out.add(new Planet(
                p.id(),
                p.massKg(),
                p.radiusM(),
                Vector3D_128.of(ba.pxH[i] + ba.pxL[i], ba.pyH[i] + ba.pyL[i], ba.pzH[i] + ba.pzL[i]),
                Vector3D_128.of(ba.vxH[i] + ba.vxL[i], ba.vyH[i] + ba.vyL[i], ba.vzH[i] + ba.vzL[i])
            ));
        }
        return out;
    }

    public static EngineOutput step(EngineInput input) {
        if (input == null || input.planets() == null || input.planets().isEmpty()) {
            return new EngineOutput(new java.util.ArrayList<Planet>(0), new java.util.ArrayList<Long>(0));
        }

        final java.util.List<Planet> src = input.planets();
        final int n = src.size();
        final double dt = input.dt();
        final double[] masses = new double[n];
        final double[] radii = new double[n];
        final long[] ids = new long[n];
        final BodyArrays ba = buildArrays(src, masses, radii, ids);
        final java.util.LinkedHashSet<Long> collided = new java.util.LinkedHashSet<Long>();
        final double[] scratch = new double[SCRATCH];

        if (n <= 128) {
            stepSingleThread(ba, masses, radii, ids, n, dt, collided, scratch);
        } else {
            int workers = Math.max(1, Runtime.getRuntime().availableProcessors() - 1);
            if (workers <= 1) {
                stepSingleThread(ba, masses, radii, ids, n, dt, collided, scratch);
            } else {
                WorkerPool pool = new WorkerPool(workers, n);
                try {
                    yoshidaStepSoA(pool, ba, masses, radii, ids, dt, collided);
                    pool.mergeCollisions(collided);
                } finally {
                    pool.shutdown();
                }
            }
        }

        return new EngineOutput(buildPlanets(ba, src, n), new java.util.ArrayList<Long>(collided));
    }

    public static double totalEnergy(java.util.List<Planet> planets) {
        if (planets == null || planets.isEmpty()) return 0.0;
        int n = planets.size();
        double kinetic = 0.0;
        for (int i = 0; i < n; i++) {
            Planet p = planets.get(i);
            double vx = p.velocity().x().toDouble();
            double vy = p.velocity().y().toDouble();
            double vz = p.velocity().z().toDouble();
            kinetic += 0.5 * p.massKg() * (vx * vx + vy * vy + vz * vz);
        }
        double potential = 0.0;
        for (int i = 0; i < n; i++) {
            Planet pi = planets.get(i);
            double pix = pi.position().x().toDouble();
            double piy = pi.position().y().toDouble();
            double piz = pi.position().z().toDouble();
            for (int j = i + 1; j < n; j++) {
                Planet pj = planets.get(j);
                double dx = pj.position().x().toDouble() - pix;
                double dy = pj.position().y().toDouble() - piy;
                double dz = pj.position().z().toDouble() - piz;
                double r = Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (r > 0.0) {
                    potential -= G * pi.massKg() * pj.massKg() / r;
                }
            }
        }
        return kinetic + potential;
    }

    private NBodyEngine128() {}

    public static double circularVelocity(double centralMass, double r) {
        return Math.sqrt(G * centralMass / r);
    }

    static void ddAdd(double aH, double aL, double bH, double bL, double[] o, int ko) {
        double s = aH + bH;
        double v = s - aH;
        double e = (aH - (s - v)) + (bH - v);
        e += aL + bL;
        double s2 = s + e;
        double e2 = e - (s2 - s);
        o[ko] = s2;
        o[ko + 1] = e2;
    }

    static void ddSub(double aH, double aL, double bH, double bL, double[] o, int ko) {
        double bHn = -bH, bLn = -bL;
        double s = aH + bHn;
        double v = s - aH;
        double e = (aH - (s - v)) + (bHn - v);
        e += aL + bLn;
        double s2 = s + e;
        double e2 = e - (s2 - s);
        o[ko] = s2;
        o[ko + 1] = e2;
    }

    static void ddMul(double aH, double aL, double bH, double bL, double[] o, int ko) {
        double p = aH * bH;
        double c = SPLIT * aH;
        double aHi = c - (c - aH);
        double aLo = aH - aHi;
        double d = SPLIT * bH;
        double bHi = d - (d - bH);
        double bLo = bH - bHi;
        double e = ((aHi * bHi - p) + aHi * bLo + aLo * bHi) + aLo * bLo;
        e += aH * bL + aL * bH;
        double s2 = p + e;
        double e2 = e - (s2 - p);
        o[ko] = s2;
        o[ko + 1] = e2;
    }

    static void ddMulS(double aH, double aL, double b, double[] o, int ko) {
        double p = aH * b;
        double c = SPLIT * aH;
        double aHi = c - (c - aH);
        double aLo = aH - aHi;
        double d = SPLIT * b;
        double bHi = d - (d - b);
        double bLo = b - bHi;
        double e = ((aHi * bHi - p) + aHi * bLo + aLo * bHi) + aLo * bLo;
        e += aL * b;
        double s2 = p + e;
        double e2 = e - (s2 - p);
        o[ko] = s2;
        o[ko + 1] = e2;
    }

    static void ddSqrt(double h, double l, double[] o, int ko) {
        if (h <= 0.0) {
            o[ko] = 0.0;
            o[ko + 1] = 0.0;
            return;
        }
        double x = 1.0 / Math.sqrt(h);
        double ax = h * x;
        double ax2 = ax * ax;
        double tHn = -ax2;
        double s = h + tHn;
        double v = s - h;
        double e = (h - (s - v)) + (tHn - v);
        e += l;
        double s2 = s + e;
        double e2 = e - (s2 - s);
        double corr = s2 * (x * 0.5);
        double s3 = ax + corr;
        double v3 = s3 - ax;
        double e3 = (ax - (s3 - v3)) + (corr - v3);
        double s32 = s3 + e3;
        double e32 = e3 - (s32 - s3);
        o[ko] = s32;
        o[ko + 1] = e32;
    }

    static void ddDiv(double aH, double aL, double bH, double bL, double[] o, int ko) {
        double q1 = aH / bH;
        double p = bH * q1;
        double c = SPLIT * bH;
        double bHi = c - (c - bH);
        double bLo = bH - bHi;
        double d = SPLIT * q1;
        double qHi = d - (d - q1);
        double qLo = q1 - qHi;
        double em = ((bHi * qHi - p) + bHi * qLo + bLo * qHi) + bLo * qLo;
        em += bL * q1;
        double tH = p + em;
        double tL = em - (tH - p);
        double tHn = -tH, tLn = -tL;
        double s = aH + tHn;
        double v = s - aH;
        double e = (aH - (s - v)) + (tHn - v);
        e += aL + tLn;
        double s2 = s + e;
        double e2 = e - (s2 - s);
        double rH = s2, rL = e2;

        double q2 = rH / bH;
        double p2 = bH * q2;
        double c2 = SPLIT * bH;
        double bHi2 = c2 - (c2 - bH);
        double bLo2 = bH - bHi2;
        double d2 = SPLIT * q2;
        double qHi2 = d2 - (d2 - q2);
        double qLo2 = q2 - qHi2;
        double em2 = ((bHi2 * qHi2 - p2) + bHi2 * qLo2 + bLo2 * qHi2) + bLo2 * qLo2;
        em2 += bL * q2;
        double tH2 = p2 + em2;
        double tL2 = em2 - (tH2 - p2);
        double tHn2 = -tH2, tLn2 = -tL2;
        double s3 = rH + tHn2;
        double v3 = s3 - rH;
        double e3 = (rH - (s3 - v3)) + (tHn2 - v3);
        e3 += rL + tLn2;
        double s32 = s3 + e3;
        double e32 = e3 - (s32 - s3);
        double r2H = s32, r2L = e32;

        double q3 = r2H / bH;
        double ss = q1 + q2;
        double vv = ss - q1;
        double ee = (q1 - (ss - vv)) + (q2 - vv);
        double ss2 = ss + ee;
        double ee2 = ee - (ss2 - ss);
        double s4 = ss2 + q3;
        double v4 = s4 - ss2;
        double e4 = (ss2 - (s4 - v4)) + (q3 - v4);
        e4 += ee2;
        double s42 = s4 + e4;
        double e42 = e4 - (s42 - s4);

        o[ko] = s42;
        o[ko + 1] = e42;
    }

    static void driftRange(BodyArrays b, int f, int t, double sub, double[] w) {
        for (int i = f; i < t; i++) {
            ddMulS(b.vxH[i], b.vxL[i], sub, w, O_TX);
            ddAdd(b.pxH[i], b.pxL[i], w[O_TX], w[O_TX + 1], w, O_ACC);
            b.pxH[i] = w[O_ACC]; b.pxL[i] = w[O_ACC + 1];

            ddMulS(b.vyH[i], b.vyL[i], sub, w, O_TY);
            ddAdd(b.pyH[i], b.pyL[i], w[O_TY], w[O_TY + 1], w, O_ACC);
            b.pyH[i] = w[O_ACC]; b.pyL[i] = w[O_ACC + 1];

            ddMulS(b.vzH[i], b.vzL[i], sub, w, O_TZ);
            ddAdd(b.pzH[i], b.pzL[i], w[O_TZ], w[O_TZ + 1], w, O_ACC);
            b.pzH[i] = w[O_ACC]; b.pzL[i] = w[O_ACC + 1];
        }
    }

    static void kickRange(BodyArrays b, int f, int t, double sub, double[] w) {
        for (int i = f; i < t; i++) {
            ddMulS(b.axH[i], b.axL[i], sub, w, O_TX);
            ddAdd(b.vxH[i], b.vxL[i], w[O_TX], w[O_TX + 1], w, O_ACC);
            b.vxH[i] = w[O_ACC]; b.vxL[i] = w[O_ACC + 1];

            ddMulS(b.ayH[i], b.ayL[i], sub, w, O_TY);
            ddAdd(b.vyH[i], b.vyL[i], w[O_TY], w[O_TY + 1], w, O_ACC);
            b.vyH[i] = w[O_ACC]; b.vyL[i] = w[O_ACC + 1];

            ddMulS(b.azH[i], b.azL[i], sub, w, O_TZ);
            ddAdd(b.vzH[i], b.vzL[i], w[O_TZ], w[O_TZ + 1], w, O_ACC);
            b.vzH[i] = w[O_ACC]; b.vzL[i] = w[O_ACC + 1];
        }
    }

    static void accRange(BodyArrays b, double[] m, double[] rd, long[] id, int n,
                         int f, int t, int wid, Set<Long> cs, double[] w) {
        for (int i = f; i < t; i++) {
            double aiXH = 0, aiXL = 0, aiYH = 0, aiYL = 0, aiZH = 0, aiZL = 0;
            double pixH = b.pxH[i], pixL = b.pxL[i];
            double piyH = b.pyH[i], piyL = b.pyL[i];
            double pizH = b.pzH[i], pizL = b.pzL[i];
            for (int j = 0; j < n; j++) {
                if (j == i) continue;
                ddSub(b.pxH[j], b.pxL[j], pixH, pixL, w, O_DX);
                ddSub(b.pyH[j], b.pyL[j], piyH, piyL, w, O_DY);
                ddSub(b.pzH[j], b.pzL[j], pizH, pizL, w, O_DZ);
                ddMul(w[O_DX], w[O_DX + 1], w[O_DX], w[O_DX + 1], w, O_DX2);
                ddMul(w[O_DY], w[O_DY + 1], w[O_DY], w[O_DY + 1], w, O_DY2);
                ddMul(w[O_DZ], w[O_DZ + 1], w[O_DZ], w[O_DZ + 1], w, O_DZ2);
                ddAdd(w[O_DX2], w[O_DX2 + 1], w[O_DY2], w[O_DY2 + 1], w, O_R2P);
                ddAdd(w[O_R2P], w[O_R2P + 1], w[O_DZ2], w[O_DZ2 + 1], w, O_R2);
                if (w[O_R2] == 0.0 && w[O_R2 + 1] == 0.0) continue;
                ddSqrt(w[O_R2], w[O_R2 + 1], w, O_R);
                ddMul(w[O_R2], w[O_R2 + 1], w[O_R], w[O_R + 1], w, O_R3);
                ddDiv(1.0, 0.0, w[O_R3], w[O_R3 + 1], w, O_INV);
                ddMulS(w[O_INV], w[O_INV + 1], G * m[j], w, O_FAC);

                double rdbl = w[O_R] + w[O_R + 1];
                if (rdbl <= rd[i] + rd[j]) {
                    cs.add(Long.valueOf(id[i]));
                    cs.add(Long.valueOf(id[j]));
                }

                ddMul(w[O_DX], w[O_DX + 1], w[O_FAC], w[O_FAC + 1], w, O_TX);
                ddAdd(aiXH, aiXL, w[O_TX], w[O_TX + 1], w, O_ACC);
                aiXH = w[O_ACC]; aiXL = w[O_ACC + 1];

                ddMul(w[O_DY], w[O_DY + 1], w[O_FAC], w[O_FAC + 1], w, O_TY);
                ddAdd(aiYH, aiYL, w[O_TY], w[O_TY + 1], w, O_ACC);
                aiYH = w[O_ACC]; aiYL = w[O_ACC + 1];

                ddMul(w[O_DZ], w[O_DZ + 1], w[O_FAC], w[O_FAC + 1], w, O_TZ);
                ddAdd(aiZH, aiZL, w[O_TZ], w[O_TZ + 1], w, O_ACC);
                aiZH = w[O_ACC]; aiZL = w[O_ACC + 1];
            }
            b.axH[i] = aiXH; b.axL[i] = aiXL;
            b.ayH[i] = aiYH; b.ayL[i] = aiYL;
            b.azH[i] = aiZH; b.azL[i] = aiZL;
        }
    }

    private static void accSingle(BodyArrays b, double[] m, double[] rd, long[] id, int n,
                                  Set<Long> cs, double[] w) {
        for (int i = 0; i < n; i++) {
            b.axH[i] = 0; b.axL[i] = 0;
            b.ayH[i] = 0; b.ayL[i] = 0;
            b.azH[i] = 0; b.azL[i] = 0;
        }
        for (int i = 0; i < n; i++) {
            double pixH = b.pxH[i], pixL = b.pxL[i];
            double piyH = b.pyH[i], piyL = b.pyL[i];
            double pizH = b.pzH[i], pizL = b.pzL[i];
            for (int j = i + 1; j < n; j++) {
                ddSub(b.pxH[j], b.pxL[j], pixH, pixL, w, O_DX);
                ddSub(b.pyH[j], b.pyL[j], piyH, piyL, w, O_DY);
                ddSub(b.pzH[j], b.pzL[j], pizH, pizL, w, O_DZ);
                ddMul(w[O_DX], w[O_DX + 1], w[O_DX], w[O_DX + 1], w, O_DX2);
                ddMul(w[O_DY], w[O_DY + 1], w[O_DY], w[O_DY + 1], w, O_DY2);
                ddMul(w[O_DZ], w[O_DZ + 1], w[O_DZ], w[O_DZ + 1], w, O_DZ2);
                ddAdd(w[O_DX2], w[O_DX2 + 1], w[O_DY2], w[O_DY2 + 1], w, O_R2P);
                ddAdd(w[O_R2P], w[O_R2P + 1], w[O_DZ2], w[O_DZ2 + 1], w, O_R2);
                if (w[O_R2] == 0.0 && w[O_R2 + 1] == 0.0) continue;
                ddSqrt(w[O_R2], w[O_R2 + 1], w, O_R);
                ddMul(w[O_R2], w[O_R2 + 1], w[O_R], w[O_R + 1], w, O_R3);
                ddDiv(1.0, 0.0, w[O_R3], w[O_R3 + 1], w, O_INV);

                double rdbl = w[O_R] + w[O_R + 1];
                if (rdbl <= rd[i] + rd[j]) {
                    cs.add(Long.valueOf(id[i]));
                    cs.add(Long.valueOf(id[j]));
                }

                ddMulS(w[O_INV], w[O_INV + 1], G * m[j], w, O_FAC);
                ddMul(w[O_DX], w[O_DX + 1], w[O_FAC], w[O_FAC + 1], w, O_TX);
                ddAdd(b.axH[i], b.axL[i], w[O_TX], w[O_TX + 1], w, O_ACC);
                b.axH[i] = w[O_ACC]; b.axL[i] = w[O_ACC + 1];

                ddMul(w[O_DY], w[O_DY + 1], w[O_FAC], w[O_FAC + 1], w, O_TY);
                ddAdd(b.ayH[i], b.ayL[i], w[O_TY], w[O_TY + 1], w, O_ACC);
                b.ayH[i] = w[O_ACC]; b.ayL[i] = w[O_ACC + 1];

                ddMul(w[O_DZ], w[O_DZ + 1], w[O_FAC], w[O_FAC + 1], w, O_TZ);
                ddAdd(b.azH[i], b.azL[i], w[O_TZ], w[O_TZ + 1], w, O_ACC);
                b.azH[i] = w[O_ACC]; b.azL[i] = w[O_ACC + 1];

                ddMulS(w[O_INV], w[O_INV + 1], G * m[i], w, O_FAC);
                ddMul(w[O_DX], w[O_DX + 1], w[O_FAC], w[O_FAC + 1], w, O_TX);
                ddSub(b.axH[j], b.axL[j], w[O_TX], w[O_TX + 1], w, O_ACC);
                b.axH[j] = w[O_ACC]; b.axL[j] = w[O_ACC + 1];

                ddMul(w[O_DY], w[O_DY + 1], w[O_FAC], w[O_FAC + 1], w, O_TY);
                ddSub(b.ayH[j], b.ayL[j], w[O_TY], w[O_TY + 1], w, O_ACC);
                b.ayH[j] = w[O_ACC]; b.ayL[j] = w[O_ACC + 1];

                ddMul(w[O_DZ], w[O_DZ + 1], w[O_FAC], w[O_FAC + 1], w, O_TZ);
                ddSub(b.azH[j], b.azL[j], w[O_TZ], w[O_TZ + 1], w, O_ACC);
                b.azH[j] = w[O_ACC]; b.azL[j] = w[O_ACC + 1];
            }
        }
    }

    private static void driftAll(BodyArrays b, int n, double sub, double[] w) {
        driftRange(b, 0, n, sub, w);
    }

    private static void kickAll(BodyArrays b, int n, double sub, double[] w) {
        kickRange(b, 0, n, sub, w);
    }

    public static void stepSingleThread(BodyArrays ba, double[] masses, double[] radii, long[] ids, int n,
                                        double dt, Set<Long> collided, double[] w) {
        driftAll(ba, n, C1 * dt, w);
        accSingle(ba, masses, radii, ids, n, collided, w);
        kickAll(ba, n, D1 * dt, w);

        driftAll(ba, n, C2 * dt, w);
        accSingle(ba, masses, radii, ids, n, collided, w);
        kickAll(ba, n, D2 * dt, w);

        driftAll(ba, n, C3 * dt, w);
        accSingle(ba, masses, radii, ids, n, collided, w);
        kickAll(ba, n, D3 * dt, w);

        driftAll(ba, n, C4 * dt, w);
    }

    public static void yoshidaStepSoA(WorkerPool pool, BodyArrays ba, double[] masses, double[] radii,
                                      long[] ids, double dt, Set<Long> collidedAll) {
        pool.runPhase(WorkerPool.PH_DRIFT, C1 * dt, ba, masses, radii, ids);
        pool.runPhase(WorkerPool.PH_ACC, 0.0, ba, masses, radii, ids);
        pool.mergeCollisions(collidedAll);

        pool.runPhase(WorkerPool.PH_KICK, D1 * dt, ba, masses, radii, ids);
        pool.runPhase(WorkerPool.PH_DRIFT, C2 * dt, ba, masses, radii, ids);
        pool.runPhase(WorkerPool.PH_ACC, 0.0, ba, masses, radii, ids);
        pool.mergeCollisions(collidedAll);

        pool.runPhase(WorkerPool.PH_KICK, D2 * dt, ba, masses, radii, ids);
        pool.runPhase(WorkerPool.PH_DRIFT, C3 * dt, ba, masses, radii, ids);
        pool.runPhase(WorkerPool.PH_ACC, 0.0, ba, masses, radii, ids);
        pool.mergeCollisions(collidedAll);

        pool.runPhase(WorkerPool.PH_KICK, D3 * dt, ba, masses, radii, ids);
        pool.runPhase(WorkerPool.PH_DRIFT, C4 * dt, ba, masses, radii, ids);
    }

    public static double totalEnergySoA(BodyArrays b, double[] masses, int n) {
        double kinetic = 0.0;
        for (int i = 0; i < n; i++) {
            double vx = b.vxH[i] + b.vxL[i];
            double vy = b.vyH[i] + b.vyL[i];
            double vz = b.vzH[i] + b.vzL[i];
            kinetic += 0.5 * masses[i] * (vx * vx + vy * vy + vz * vz);
        }

        double potential = 0.0;
        for (int i = 0; i < n; i++) {
            double pix = b.pxH[i] + b.pxL[i];
            double piy = b.pyH[i] + b.pyL[i];
            double piz = b.pzH[i] + b.pzL[i];
            for (int j = i + 1; j < n; j++) {
                double dx = (b.pxH[j] + b.pxL[j]) - pix;
                double dy = (b.pyH[j] + b.pyL[j]) - piy;
                double dz = (b.pzH[j] + b.pzL[j]) - piz;
                double r = Math.sqrt(dx * dx + dy * dy + dz * dz);
                potential -= G * masses[i] * masses[j] / r;
            }
        }
        return kinetic + potential;
    }
}
