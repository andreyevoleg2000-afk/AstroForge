#include <jni.h>
#include <cmath>
#include <vector>
#include <random>
#include <algorithm>
#include <limits>
#include <cstdint>

namespace {

constexpr int DIRECT_SIZE = 7;
constexpr int SIM_STRIDE = 7;

constexpr long double PI = 3.141592653589793238462643383279502884L;
constexpr long double MU0 = 4.0e-7L * PI;

struct PlanetInput {
    long double radiusM;
    long double coreRadiusM;
    long double densityKgM3;
    long double heatFluxWm2;
    long double dipoleFraction;
    long double calibrationFactor;
};

struct SimConfigInput {
    long double years;
    long long steps;
    std::uint64_t seed;
    long double minHeatFluxWm2;
    long double coolingTimeYears;
    long double eventRatePerYear;
    long double gamma;
    long double dtMinYears;
    long double dtMaxYears;
    bool includeEvents;
};

struct FieldValues {
    long double coreFieldTesla;
    long double surfaceFieldTesla;
    long double dipoleMomentAm2;
    long double dipoleFractionUsed;
    long double energyFluxUsedWm2;
    long double magneticEnergyDensityJm3;
    long double magneticPressurePa;
};

inline long double clampLongDouble(long double value, long double low, long double high) {
    if (value < low) return low;
    if (value > high) return high;
    return value;
}

inline bool isValidPositive(long double value) {
    return std::isfinite(value) && value > 0.0L;
}

jdoubleArray createDoubleArray(JNIEnv* env, const std::vector<jdouble>& data) {
    if (env == nullptr) {
        return nullptr;
    }

    if (data.size() > static_cast<size_t>(std::numeric_limits<jsize>::max())) {
        return nullptr;
    }

    jdoubleArray result = env->NewDoubleArray(static_cast<jsize>(data.size()));
    if (result == nullptr) {
        return nullptr;
    }

    env->SetDoubleArrayRegion(
            result,
            0,
            static_cast<jsize>(data.size()),
            data.data()
    );

    return result;
}

long double coreFieldFromFlux(
        long double densityKgM3,
        long double heatFluxWm2,
        long double calibrationFactor
) {
    if (!isValidPositive(densityKgM3) || !isValidPositive(calibrationFactor)) {
        return 0.0L;
    }

    if (!std::isfinite(heatFluxWm2) || heatFluxWm2 <= 0.0L) {
        return 0.0L;
    }

    // Christensen dynamo scaling:
    // B_core ~ calibration * sqrt(rho * mu0) * F^(1/3)
    return calibrationFactor * std::sqrt(densityKgM3 * MU0) * std::cbrt(heatFluxWm2);
}

long double dipoleMomentFromSurfaceField(
        long double surfaceEquatorialFieldTesla,
        long double radiusM
) {
    if (!isValidPositive(radiusM)) {
        return 0.0L;
    }

    if (!std::isfinite(surfaceEquatorialFieldTesla) || surfaceEquatorialFieldTesla <= 0.0L) {
        return 0.0L;
    }

    // B_eq = mu0 / (4*pi) * M / r^3  =>  M = 4*pi/mu0 * B_eq * r^3
    return (4.0L * PI / MU0) *
           surfaceEquatorialFieldTesla *
           radiusM *
           radiusM *
           radiusM;
}

FieldValues computeFieldValues(const PlanetInput& planet, long double heatFluxWm2) {
    FieldValues result{};

    result.dipoleFractionUsed = clampLongDouble(planet.dipoleFraction, 0.0L, 1.0L);
    result.energyFluxUsedWm2 =
            std::isfinite(heatFluxWm2) && heatFluxWm2 >= 0.0L ? heatFluxWm2 : 0.0L;

    if (!isValidPositive(planet.radiusM) ||
        !isValidPositive(planet.coreRadiusM) ||
        planet.coreRadiusM >= planet.radiusM ||
        !isValidPositive(planet.densityKgM3)) {
        return result;
    }

    result.coreFieldTesla = coreFieldFromFlux(
            planet.densityKgM3,
            result.energyFluxUsedWm2,
            planet.calibrationFactor
    );

    long double ratio = planet.coreRadiusM / planet.radiusM;
    long double geometricFactor = ratio * ratio * ratio;

    result.surfaceFieldTesla =
            result.dipoleFractionUsed *
            result.coreFieldTesla *
            geometricFactor;

    result.dipoleMomentAm2 = dipoleMomentFromSurfaceField(
            result.surfaceFieldTesla,
            planet.radiusM
    );

    // u = B^2 / (2*mu0)
    result.magneticEnergyDensityJm3 =
            result.coreFieldTesla * result.coreFieldTesla / (2.0L * MU0);

    result.magneticPressurePa = result.magneticEnergyDensityJm3;

    return result;
}

std::vector<jdouble> directResultVector(const PlanetInput& planet) {
    std::vector<jdouble> output(DIRECT_SIZE, static_cast<jdouble>(0.0));

    FieldValues values = computeFieldValues(planet, planet.heatFluxWm2);

    output[0] = static_cast<jdouble>(values.coreFieldTesla);
    output[1] = static_cast<jdouble>(values.surfaceFieldTesla);
    output[2] = static_cast<jdouble>(values.dipoleMomentAm2);
    output[3] = static_cast<jdouble>(values.dipoleFractionUsed);
    output[4] = static_cast<jdouble>(values.energyFluxUsedWm2);
    output[5] = static_cast<jdouble>(values.magneticEnergyDensityJm3);
    output[6] = static_cast<jdouble>(values.magneticPressurePa);

    return output;
}

long double heatFluxAtTime(
        long double timeYears,
        long double initialHeatFluxWm2,
        long double minHeatFluxWm2,
        long double coolingTimeYears
) {
    long double floor =
            std::isfinite(minHeatFluxWm2) && minHeatFluxWm2 >= 0.0L ? minHeatFluxWm2 : 0.0L;

    if (!std::isfinite(initialHeatFluxWm2) || initialHeatFluxWm2 < 0.0L) {
        return floor;
    }

    if (!std::isfinite(coolingTimeYears) || coolingTimeYears <= 0.0L) {
        return std::max(initialHeatFluxWm2, floor);
    }

    long double decayed =
            floor + (initialHeatFluxWm2 - floor) * std::exp(-timeYears / coolingTimeYears);

    if (!std::isfinite(decayed)) {
        return std::max(initialHeatFluxWm2, floor);
    }

    return std::max(decayed, floor);
}

long double sampleTruncatedPowerLaw(
        long double dtMinYears,
        long double dtMaxYears,
        long double gamma,
        double uniform01
) {
    if (dtMaxYears <= dtMinYears) {
        return dtMinYears;
    }

    long double u = clampLongDouble(static_cast<long double>(uniform01), 0.0L, 1.0L);

    // gamma == 1: pdf ~ t^-1, inverse CDF is logarithmic.
    if (std::fabs(gamma - 1.0L) < 1.0e-10L) {
        long double logMin = std::log(dtMinYears);
        long double logMax = std::log(dtMaxYears);
        long double sampled = std::exp(logMin + (logMax - logMin) * u);
        return clampLongDouble(sampled, dtMinYears, dtMaxYears);
    }

    long double exponent = 1.0L - gamma;

    long double minTerm = std::pow(dtMinYears, exponent);
    long double maxTerm = std::pow(dtMaxYears, exponent);

    long double base = (maxTerm - minTerm) * u + minTerm;

    if (!std::isfinite(base) || base <= 0.0L) {
        return dtMinYears;
    }

    long double sampled = std::pow(base, 1.0L / exponent);
    return clampLongDouble(sampled, dtMinYears, dtMaxYears);
}

std::vector<long double> generateEventTimes(
        long double totalYears,
        const SimConfigInput& config
) {
    std::vector<long double> events;

    if (!config.includeEvents) {
        return events;
    }

    if (!std::isfinite(config.eventRatePerYear) || config.eventRatePerYear <= 0.0L) {
        return events;
    }

    if (!std::isfinite(totalYears) || totalYears <= config.dtMinYears) {
        return events;
    }

    std::mt19937_64 generator(config.seed);
    std::uniform_real_distribution<double> uniform01(0.0, 1.0);

    const long double meanWaitingYears = 1.0L / config.eventRatePerYear;

    long double currentTime = 0.0L;
    int rejectionCounter = 0;
    constexpr int MAX_REJECTIONS = 50000;

    while (true) {
        long double remaining = totalYears - currentTime;

        if (remaining < config.dtMinYears) {
            break;
        }

        long double upperBound = std::min(config.dtMaxYears, remaining);

        if (upperBound < config.dtMinYears) {
            break;
        }

        long double candidateWait = sampleTruncatedPowerLaw(
                config.dtMinYears,
                upperBound,
                config.gamma,
                uniform01(generator)
        );

        long double acceptance = 1.0L;

        if (std::isfinite(meanWaitingYears) && meanWaitingYears > 0.0L) {
            acceptance = std::exp(-candidateWait / meanWaitingYears);

            if (!std::isfinite(acceptance)) {
                acceptance = 0.0L;
            }
        }

        if (acceptance <= 0.0L) {
            ++rejectionCounter;
            if (rejectionCounter > MAX_REJECTIONS) {
                break;
            }
            continue;
        }

        double acceptanceRoll = uniform01(generator);

        if (static_cast<long double>(acceptanceRoll) < acceptance) {
            currentTime += candidateWait;

            if (currentTime > totalYears) {
                break;
            }

            events.push_back(currentTime);
            rejectionCounter = 0;
        } else {
            ++rejectionCounter;
            if (rejectionCounter > MAX_REJECTIONS) {
                break;
            }
        }
    }

    return events;
}

std::vector<jdouble> simulateResultVector(
        const PlanetInput& planet,
        const SimConfigInput& config
) {
    std::vector<jdouble> output;

    if (config.steps <= 0) {
        return output;
    }

    size_t totalSize = static_cast<size_t>(config.steps) * SIM_STRIDE;

    if (totalSize > static_cast<size_t>(std::numeric_limits<jsize>::max())) {
        return output;
    }

    output.reserve(totalSize);

    std::vector<long double> events = generateEventTimes(config.years, config);

    long double timeStep = 0.0L;
    if (config.steps > 1) {
        timeStep = config.years / static_cast<long double>(config.steps - 1);
    }

    long double polarity = 1.0L;
    size_t eventIndex = 0;
    long long cumulativeEvents = 0;

    for (long long i = 0; i < config.steps; ++i) {
        long double timeYears = 0.0L;

        if (config.steps > 1) {
            timeYears = static_cast<long double>(i) * timeStep;
        }

        if (timeYears > config.years) {
            timeYears = config.years;
        }

        while (eventIndex < events.size() && events[eventIndex] <= timeYears) {
            polarity = -polarity;
            ++cumulativeEvents;
            ++eventIndex;
        }

        long double currentHeatFlux = heatFluxAtTime(
                timeYears,
                planet.heatFluxWm2,
                config.minHeatFluxWm2,
                config.coolingTimeYears
        );

        FieldValues values = computeFieldValues(planet, currentHeatFlux);

        output.push_back(static_cast<jdouble>(timeYears));
        output.push_back(static_cast<jdouble>(values.energyFluxUsedWm2));
        output.push_back(static_cast<jdouble>(values.coreFieldTesla));
        output.push_back(static_cast<jdouble>(values.surfaceFieldTesla));
        output.push_back(static_cast<jdouble>(values.dipoleMomentAm2));
        output.push_back(static_cast<jdouble>(polarity));
        output.push_back(static_cast<jdouble>(cumulativeEvents));
    }

    return output;
}

} // namespace

extern "C" {

JNIEXPORT jdoubleArray JNICALL
Java_com_astroforge_MagneticEngine_nativeDirect(
        JNIEnv* env,
        jclass,
        jdouble massKg,
        jdouble radiusM,
        jdouble coreRadiusM,
        jdouble densityKgM3,
        jdouble heatFluxWm2,
        jdouble rotationPeriodHours,
        jdouble dipoleFraction,
        jdouble calibrationFactor
) {
    (void) massKg;
    (void) rotationPeriodHours;

    try {
        PlanetInput planet{};
        planet.radiusM = static_cast<long double>(radiusM);
        planet.coreRadiusM = static_cast<long double>(coreRadiusM);
        planet.densityKgM3 = static_cast<long double>(densityKgM3);
        planet.heatFluxWm2 = static_cast<long double>(heatFluxWm2);
        planet.dipoleFraction = static_cast<long double>(dipoleFraction);
        planet.calibrationFactor = static_cast<long double>(calibrationFactor);

        std::vector<jdouble> result = directResultVector(planet);
        return createDoubleArray(env, result);
    } catch (...) {
        std::vector<jdouble> empty(DIRECT_SIZE, static_cast<jdouble>(0.0));
        return createDoubleArray(env, empty);
    }
}

JNIEXPORT jdoubleArray JNICALL
Java_com_astroforge_MagneticEngine_nativeSimulate(
        JNIEnv* env,
        jclass,
        jdouble massKg,
        jdouble radiusM,
        jdouble coreRadiusM,
        jdouble densityKgM3,
        jdouble heatFluxWm2,
        jdouble rotationPeriodHours,
        jdouble dipoleFraction,
        jdouble calibrationFactor,
        jdouble years,
        jint steps,
        jlong seed,
        jdouble minHeatFluxWm2,
        jdouble coolingTimeYears,
        jdouble eventRatePerYear,
        jdouble gamma,
        jdouble dtMinYears,
        jdouble dtMaxYears,
        jboolean includeEvents
) {
    (void) massKg;
    (void) rotationPeriodHours;

    try {
        PlanetInput planet{};
        planet.radiusM = static_cast<long double>(radiusM);
        planet.coreRadiusM = static_cast<long double>(coreRadiusM);
        planet.densityKgM3 = static_cast<long double>(densityKgM3);
        planet.heatFluxWm2 = static_cast<long double>(heatFluxWm2);
        planet.dipoleFraction = static_cast<long double>(dipoleFraction);
        planet.calibrationFactor = static_cast<long double>(calibrationFactor);

        SimConfigInput config{};
        config.years = static_cast<long double>(years);
        config.steps = static_cast<long long>(steps);
        config.seed = static_cast<std::uint64_t>(seed);
        config.minHeatFluxWm2 = static_cast<long double>(minHeatFluxWm2);
        config.coolingTimeYears = static_cast<long double>(coolingTimeYears);
        config.eventRatePerYear = static_cast<long double>(eventRatePerYear);
        config.gamma = static_cast<long double>(gamma);
        config.dtMinYears = static_cast<long double>(dtMinYears);
        config.dtMaxYears = static_cast<long double>(dtMaxYears);
        config.includeEvents = includeEvents == JNI_TRUE;

        if (!std::isfinite(config.years) || config.years <= 0.0L || config.steps <= 0) {
            return env->NewDoubleArray(0);
        }

        std::vector<jdouble> result = simulateResultVector(planet, config);
        return createDoubleArray(env, result);
    } catch (...) {
        return env->NewDoubleArray(0);
    }
}

} // extern "C"
