cmake_minimum_required(VERSION 3.22.1)

project("AstroForgeNative")

add_library(
    magneto_core
    SHARED
    magneto_core.cpp
)

target_compile_features(magneto_core PRIVATE cxx_std_17)

target_compile_options(
    magneto_core
    PRIVATE
    -fexceptions
    -frtti
)
