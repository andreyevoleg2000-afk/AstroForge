import { AU, DAY } from './physics.js';

export const UNIT_FACTORS = {
  mass: {
    kg: 1,
    earth: 5.9722e24,
    jupiter: 1.89813e27,
    sun: 1.98847e30
  },
  radius: {
    km: 1,
    m: 0.001,
    earth: 6371,
    sun: 695700,
    au: AU / 1000
  },
  density: {
    kgm3: 1,
    gcm3: 1000
  },
  speed: {
    kms: 1,
    ms: 0.001,
    auday: (AU / 1000) / DAY,
    c: 299792.458
  },
  time: {
    second: 1 / DAY,
    minute: 1 / 1440,
    hour: 1 / 24,
    day: 1,
    year: 365.25
  }
};

/* Factors are expressed as base units per selected display unit. */
export function convertUnitValue(value, factors, fromUnit, toUnit) {
  if (!Number.isFinite(value) || !factors || !(factors[toUnit] > 0) || !(factors[fromUnit] > 0)) return NaN;
  return value * factors[fromUnit] / factors[toUnit];
}

export function valueToBaseUnits(value, factors, unit) {
  if (!Number.isFinite(value) || !factors || !(factors[unit] > 0)) return NaN;
  return value * factors[unit];
}

export function valueFromBaseUnits(value, factors, unit) {
  if (!Number.isFinite(value) || !factors || !(factors[unit] > 0)) return NaN;
  return value / factors[unit];
}
