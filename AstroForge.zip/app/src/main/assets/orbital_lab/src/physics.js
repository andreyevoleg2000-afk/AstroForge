export const G = 6.67430e-11;
export const AU = 149597870700;
export const DAY = 86400;
export const WORLD_SCALE = 1e9;

/* Pairwise Newtonian acceleration. No PN terms and no gravitational softening. */
export function updateAccelerations(bodies) {
  let i;
  let j;
  for (i = 0; i < bodies.length; i += 1) {
    bodies[i].a[0] = 0;
    bodies[i].a[1] = 0;
    bodies[i].a[2] = 0;
  }

  for (i = 0; i < bodies.length; i += 1) {
    const bi = bodies[i];
    for (j = i + 1; j < bodies.length; j += 1) {
      const bj = bodies[j];
      const dx = bj.p[0] - bi.p[0];
      const dy = bj.p[1] - bi.p[1];
      const dz = bj.p[2] - bi.p[2];
      const r2 = dx * dx + dy * dy + dz * dz;
      if (r2 <= 1e-12) {
        continue;
      }
      const invR3 = 1 / (r2 * Math.sqrt(r2));
      const factorI = G * bj.mass * invR3;
      const factorJ = G * bi.mass * invR3;
      bi.a[0] += dx * factorI;
      bi.a[1] += dy * factorI;
      bi.a[2] += dz * factorI;
      bj.a[0] -= dx * factorJ;
      bj.a[1] -= dy * factorJ;
      bj.a[2] -= dz * factorJ;
    }
  }
}

/* Velocity Verlet in KDK form: half kick, drift, new force, half kick. */
export function velocityVerletStep(bodies, dtSeconds) {
  let i;
  for (i = 0; i < bodies.length; i += 1) {
    const b = bodies[i];
    b.h[0] = b.v[0] + 0.5 * b.a[0] * dtSeconds;
    b.h[1] = b.v[1] + 0.5 * b.a[1] * dtSeconds;
    b.h[2] = b.v[2] + 0.5 * b.a[2] * dtSeconds;
    b.p[0] += b.h[0] * dtSeconds;
    b.p[1] += b.h[1] * dtSeconds;
    b.p[2] += b.h[2] * dtSeconds;
  }

  updateAccelerations(bodies);

  for (i = 0; i < bodies.length; i += 1) {
    const b = bodies[i];
    b.v[0] = b.h[0] + 0.5 * b.a[0] * dtSeconds;
    b.v[1] = b.h[1] + 0.5 * b.a[1] * dtSeconds;
    b.v[2] = b.h[2] + 0.5 * b.a[2] * dtSeconds;
  }
}

/*
 * Swept-sphere collision detection. previousPositions[i] contains the
 * coordinates immediately before the last Verlet step. This detects a
 * contact even when the bodies cross between two integration endpoints.
 * Two temporary debris fragments are allowed to pass through each other.
 */
export function findSweptCollision(bodies, previousPositions) {
  let earliest = null;
  let i;
  let j;

  for (i = 0; i < bodies.length; i += 1) {
    const a = bodies[i];
    const oldA = previousPositions[i];
    if (!oldA || !(a.radiusM > 0)) continue;

    for (j = i + 1; j < bodies.length; j += 1) {
      const b = bodies[j];
      const oldB = previousPositions[j];
      if (!oldB || !(b.radiusM > 0)) continue;
      if (a.isDebris && b.isDebris) continue;

      const radiusA = Number.isFinite(a.contactRadiusM) && a.contactRadiusM > 0 ? a.contactRadiusM : a.radiusM;
      const radiusB = Number.isFinite(b.contactRadiusM) && b.contactRadiusM > 0 ? b.contactRadiusM : b.radiusM;
      const radiusSum = radiusA + radiusB;
      const rx = oldA[0] - oldB[0];
      const ry = oldA[1] - oldB[1];
      const rz = oldA[2] - oldB[2];
      const moveX = (a.p[0] - oldA[0]) - (b.p[0] - oldB[0]);
      const moveY = (a.p[1] - oldA[1]) - (b.p[1] - oldB[1]);
      const moveZ = (a.p[2] - oldA[2]) - (b.p[2] - oldB[2]);

      const c = rx * rx + ry * ry + rz * rz - radiusSum * radiusSum;
      let hitTime = null;

      if (c <= 0) {
        hitTime = 0;
      } else {
        const quadraticA = moveX * moveX + moveY * moveY + moveZ * moveZ;
        if (quadraticA > 0) {
          const quadraticB = 2 * (rx * moveX + ry * moveY + rz * moveZ);
          const discriminant = quadraticB * quadraticB - 4 * quadraticA * c;
          const discriminantTolerance = 1e-12 * (Math.abs(quadraticB * quadraticB) + Math.abs(4 * quadraticA * c) + 1);
          if (discriminant >= -discriminantTolerance) {
            const root = Math.sqrt(Math.max(0, discriminant));
            const q = -0.5 * (quadraticB + (quadraticB >= 0 ? root : -root));
            let firstRoot;
            let secondRoot;
            if (Math.abs(q) > 0) {
              firstRoot = q / quadraticA;
              secondRoot = c / q;
            } else {
              firstRoot = (-quadraticB - root) / (2 * quadraticA);
              secondRoot = (-quadraticB + root) / (2 * quadraticA);
            }
            const entryTime = Math.min(firstRoot, secondRoot);
            if (entryTime >= 0 && entryTime <= 1) hitTime = entryTime;
          }
        }
      }

      if (hitTime !== null && (!earliest || hitTime < earliest.time)) {
        earliest = { a: a, b: b, time: hitTime };
      }
    }
  }

  return earliest;
}

export function estimatePredictionDays(bodies, previewIndex) {
  const preview = bodies[previewIndex];
  let primary = null;
  let primaryDistance = Infinity;
  let i;
  for (i = 0; i < bodies.length; i += 1) {
    if (i === previewIndex) continue;
    const candidate = bodies[i];
    const dx = candidate.p[0] - preview.p[0];
    const dy = candidate.p[1] - preview.p[1];
    const dz = candidate.p[2] - preview.p[2];
    const distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (distance > 0 && candidate.mass > 0 && (candidate.mass > (primary ? primary.mass : 0) || distance < primaryDistance)) {
      primary = candidate;
      primaryDistance = distance;
    }
  }
  if (!primary) return 365;
  const dx = primary.p[0] - preview.p[0];
  const dy = primary.p[1] - preview.p[1];
  const dz = primary.p[2] - preview.p[2];
  const radius = Math.sqrt(dx * dx + dy * dy + dz * dz);
  const periodSeconds = 2 * Math.PI * Math.sqrt((radius * radius * radius) / (G * primary.mass));
  const days = periodSeconds / DAY;
  if (!Number.isFinite(days)) return 365;
  return Math.max(5, Math.min(3650, days * 1.08));
}

export function predictTrajectory(sourceBodies, previewIndex, sampleCount) {
  const bodies = sourceBodies.map(function (body) {
    return {
      mass: body.mass,
      p: [body.p[0], body.p[1], body.p[2]],
      v: [body.v[0], body.v[1], body.v[2]],
      a: [0, 0, 0],
      h: [0, 0, 0]
    };
  });
  updateAccelerations(bodies);
  const horizonDays = estimatePredictionDays(bodies, previewIndex);
  const steps = Math.max(80, sampleCount || 480);
  const stepSeconds = horizonDays * DAY / steps;
  const points = [];
  points.push([bodies[previewIndex].p[0], bodies[previewIndex].p[1], bodies[previewIndex].p[2]]);
  let i;
  for (i = 0; i < steps; i += 1) {
    velocityVerletStep(bodies, stepSeconds);
    const p = bodies[previewIndex].p;
    points.push([p[0], p[1], p[2]]);
  }
  return { points: points, horizonDays: horizonDays };
}

export function makeBody(id, name, mass, radiusKm, density, position, velocity, bodyType, temperatureK) {
  const isStar = bodyType === 'star';
  return {
    id: id,
    name: name,
    type: isStar ? 'star' : 'planet',
    isStar: isStar,
    temperatureK: isStar && Number.isFinite(temperatureK) ? temperatureK : 0,
    mass: mass,
    radiusKm: radiusKm,
    radiusM: radiusKm * 1000,
    contactRadiusM: radiusKm * 1000,
    density: density,
    p: [position[0], position[1], position[2]],
    v: [velocity[0], velocity[1], velocity[2]],
    a: [0, 0, 0],
    h: [0, 0, 0],
    history: [],
    nextTrailTime: 0,
    mesh: null,
    trail: null,
    label: null,
    isDebris: false,
    debrisExpiresAtSimSeconds: 0,
    debrisTargetId: null
  };
}
