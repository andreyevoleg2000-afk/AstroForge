import { AU } from './physics.js';

export const SOLAR_RADIUS_M = 6.957e8;
export const SOLAR_TEMPERATURE_K = 5772;
export const KOPPARAPU_MIN_TEMP = 2600;
export const KOPPARAPU_MAX_TEMP = 7200;

const KOPPARAPU_REFERENCE_TEMP = 5780;
const KOPPARAPU_COEFFICIENTS = {
  inner: [1.107, 1.332e-4, 1.580e-8, -8.308e-12, -1.931e-15],
  outer: [0.356, 6.171e-5, 1.698e-9, -3.198e-12, -5.575e-16]
};

export function stellarLuminosityRatio(radiusM, temperatureK) {
  if (!(radiusM > 0) || !(temperatureK > 0) || !Number.isFinite(radiusM) || !Number.isFinite(temperatureK)) return 0;
  const radiusRatio = radiusM / SOLAR_RADIUS_M;
  const temperatureRatio = temperatureK / SOLAR_TEMPERATURE_K;
  return radiusRatio * radiusRatio * Math.pow(temperatureRatio, 4);
}

export function getKopparapuBoundaries(radiusM, temperatureK) {
  if (!Number.isFinite(temperatureK) || temperatureK < KOPPARAPU_MIN_TEMP || temperatureK > KOPPARAPU_MAX_TEMP) return null;
  const temperatureOffset = temperatureK - KOPPARAPU_REFERENCE_TEMP;
  function effectiveFlux(coefficients) {
    return coefficients[0] + coefficients[1] * temperatureOffset + coefficients[2] * temperatureOffset * temperatureOffset + coefficients[3] * Math.pow(temperatureOffset, 3) + coefficients[4] * Math.pow(temperatureOffset, 4);
  }
  const luminosity = stellarLuminosityRatio(radiusM, temperatureK);
  const innerFlux = effectiveFlux(KOPPARAPU_COEFFICIENTS.inner);
  const outerFlux = effectiveFlux(KOPPARAPU_COEFFICIENTS.outer);
  if (!(luminosity > 0) || !(innerFlux > 0) || !(outerFlux > 0)) return null;
  return {
    innerM: Math.sqrt(luminosity / innerFlux) * AU,
    outerM: Math.sqrt(luminosity / outerFlux) * AU,
    innerFlux: innerFlux,
    outerFlux: outerFlux,
    luminositySolar: luminosity
  };
}

export function estimateEquilibriumTemperature(planetPosition, stars, bondAlbedo) {
  if (!planetPosition || !Array.isArray(stars) || stars.length === 0) return null;
  const albedo = Number.isFinite(bondAlbedo) ? Math.max(0, Math.min(1, bondAlbedo)) : 0.30;
  let fourthPowerSum = 0;
  let dominantStar = null;
  let dominantContribution = 0;
  let i;
  for (i = 0; i < stars.length; i += 1) {
    const star = stars[i];
    if (!star || !star.isStar || !(star.temperatureK > 0) || !(star.radiusM > 0)) continue;
    const dx = planetPosition[0] - star.p[0];
    const dy = planetPosition[1] - star.p[1];
    const dz = planetPosition[2] - star.p[2];
    const distanceSquared = Math.max(dx * dx + dy * dy + dz * dz, star.radiusM * star.radiusM);
    const contribution = Math.pow(star.temperatureK, 4) * star.radiusM * star.radiusM / distanceSquared;
    fourthPowerSum += contribution;
    if (contribution > dominantContribution) {
      dominantContribution = contribution;
      dominantStar = star;
    }
  }
  if (!(fourthPowerSum > 0)) return null;
  return {
    temperatureK: Math.pow((1 - albedo) * fourthPowerSum / 4, 0.25),
    dominantStar: dominantStar
  };
}
