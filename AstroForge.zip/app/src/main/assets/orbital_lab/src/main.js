import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { SOLAR_RADIUS_M, SOLAR_TEMPERATURE_K, KOPPARAPU_MIN_TEMP, KOPPARAPU_MAX_TEMP, stellarLuminosityRatio as calculateStellarLuminosity, getKopparapuBoundaries as calculateKopparapuBoundaries, estimateEquilibriumTemperature } from './stellar.js';
import { UNIT_FACTORS, convertUnitValue, valueToBaseUnits, valueFromBaseUnits } from './units.js';
import {
  G,
  AU,
  DAY,
  WORLD_SCALE,
  makeBody,
  updateAccelerations,
  velocityVerletStep,
  findSweptCollision,
  predictTrajectory
} from './physics.js';

const viewport = document.getElementById('viewport');
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.8));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.0;
renderer.domElement.style.position = 'absolute';
renderer.domElement.style.inset = '0';
renderer.domElement.style.zIndex = '0';
renderer.domElement.style.touchAction = 'none';
viewport.insertBefore(renderer.domElement, viewport.firstChild);

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(51, window.innerWidth / window.innerHeight, 0.000001, 50000);
const composer = new EffectComposer(renderer);
composer.addPass(new RenderPass(scene, camera));
const bloomPass = new UnrealBloomPass(new THREE.Vector2(window.innerWidth, window.innerHeight), 0.62, 0.38, 1.05);
composer.addPass(bloomPass);
composer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.4));
const cameraState = {
  target: new THREE.Vector3(0, 0, 0),
  yaw: 0.82,
  pitch: 0.68,
  roll: 0,
  distance: 420,
  followBodyId: null
};
let surfaceMode = null;
const surfaceKeys = { forward: false, backward: false, left: false, right: false, ascend: false, descend: false };

/* A small environmental floor keeps unlit objects visible without washing out stellar lighting. */
scene.add(new THREE.AmbientLight(0x9fb6d7, 0.045));

const textureLoader = new THREE.TextureLoader();
let planetTexture = null;
textureLoader.load('./assets/planet-texture.jpg', function (texture) {
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  planetTexture = texture;
  bodies.forEach(function (body) {
    if (body.mesh && !body.isStar && !body.isDebris) {
      body.mesh.material.map = planetTexture;
      body.mesh.material.needsUpdate = true;
    }
  });
  if (previewMesh && previewState && previewState.draft.bodyType !== 'star') {
    previewMesh.material.map = planetTexture;
    previewMesh.material.needsUpdate = true;
  }
});
textureLoader.load('./assets/space-background.jpg', function (texture) {
  texture.colorSpace = THREE.SRGBColorSpace;
  scene.background = texture;
});

const sphereGeometry = new THREE.SphereGeometry(1, 40, 28);
const bodies = [];
let nextBodyId = 1;
let selectedBody = null;
let detailsEditingBodyId = null;
let detailLastChanged = 'radius';
let running = true;
let simulationSeconds = 0;
let accumulator = 0;
let dtDays = 0.020;
let rateDaysPerSecond = 1.0;
let previewState = null;
let previewMesh = null;
let previewArrow = null;
let previewLine = null;
let selectedRing = null;
let previewNeedsPrediction = false;
let lastPredictionTime = 0;
let lastTrailUpdate = 0;
let lastFrameTime = performance.now();
let toastTimer = null;

const raycaster = new THREE.Raycaster();
const pointerNdc = new THREE.Vector2();
const groundPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
const planeHit = new THREE.Vector3();
const pointerMap = new Map();
let multiGesture = null;
let placementGesture = null;
let lastTouchTime = 0;

const $ = function (id) { return document.getElementById(id); };
const simTime = $('simTime');
const timeValue = $('timeValue');
const liveDot = $('liveDot');
const objectPanel = $('objectPanel');
const objectList = $('objectList');
const bodyCount = $('bodyCount');
const createModal = $('createModal');
const validationBox = $('validationBox');
const correctionBox = $('correctionBox');
const correctionOptions = $('correctionOptions');
const placementBanner = $('placementBanner');
const placementTitle = $('placementTitle');
const placementInstructions = $('placementInstructions');
const selectionTag = $('selectionTag');
const selectionName = $('selectionName');
const sceneHint = $('sceneHint');
const dtInput = $('dtInput');
const rateInput = $('rateInput');
const autoOrbitInput = $('autoOrbitInput');
const orbitTargetSelect = $('orbitTargetSelect');
const orbitHelp = $('orbitHelp');
const speedInput = $('speedInput');
const bodyTypeSelect = $('bodyTypeSelect');
const starOptions = $('starOptions');
const starTempInput = $('starTempInput');
const starTempUnitSelect = $('starTempUnitSelect');
const massUnitSelect = $('massUnitSelect');
const radiusUnitSelect = $('radiusUnitSelect');
const densityUnitSelect = $('densityUnitSelect');
const speedUnitSelect = $('speedUnitSelect');
const dtUnitSelect = $('dtUnitSelect');
const rateUnitSelect = $('rateUnitSelect');
const hzToggleInput = $('hzToggleInput');
const hzLegend = $('hzLegend');
const bodyDetailsPanel = $('bodyDetailsPanel');
const surfaceOverlay = $('surfaceOverlay');
const surfaceAltitudeReadout = $('surfaceAltitudeReadout');
const gridDistanceLabels = [];

const EARTH_MASS_KG = 5.9722e24;
const JUPITER_MASS_KG = 1.89813e27;
const SOLAR_MASS_KG = 1.98847e30;
const EARTH_RADIUS_KM = 6371;
const SOLAR_RADIUS_KM = 695700;
const BOND_ALBEDO = 0.30;
let lastClimateUpdate = 0;

const FRAGMENT_COUNT = 6;
const FRAGMENT_MASS_FRACTION = 0.18;
const FRAGMENT_LIFETIME_DAYS = 12;

function makeGrid() {
  const fine = [];
  const major = [];
  const extent = 2400;
  const spacing = 12;
  let value;
  for (value = -extent; value <= extent; value += spacing) {
    const target = Math.abs(value % 60) < 0.001 ? major : fine;
    target.push(-extent, -0.15, value, extent, -0.15, value);
    target.push(value, -0.15, -extent, value, -0.15, extent);
  }
  for (value = -extent; value <= extent; value += 60) {
    if (value === 0) continue;
    const alongX = document.createElement('div');
    alongX.className = 'grid-distance-label';
    alongX.textContent = formatGridDistance(value);
    viewport.appendChild(alongX);
    gridDistanceLabels.push({ element: alongX, position: new THREE.Vector3(value, -0.08, 0) });
    const alongZ = document.createElement('div');
    alongZ.className = 'grid-distance-label';
    alongZ.textContent = formatGridDistance(value);
    viewport.appendChild(alongZ);
    gridDistanceLabels.push({ element: alongZ, position: new THREE.Vector3(0, -0.08, value) });
  }
  const fineGeometry = new THREE.BufferGeometry();
  fineGeometry.setAttribute('position', new THREE.Float32BufferAttribute(fine, 3));
  const fineLines = new THREE.LineSegments(fineGeometry, new THREE.LineBasicMaterial({ color: 0x55738f, transparent: true, opacity: 0.15, depthWrite: false }));
  fineLines.frustumCulled = false;
  scene.add(fineLines);
  const majorGeometry = new THREE.BufferGeometry();
  majorGeometry.setAttribute('position', new THREE.Float32BufferAttribute(major, 3));
  const majorLines = new THREE.LineSegments(majorGeometry, new THREE.LineBasicMaterial({ color: 0x78a6be, transparent: true, opacity: 0.27, depthWrite: false }));
  majorLines.frustumCulled = false;
  scene.add(majorLines);
  const axisPoints = [
    new THREE.Vector3(-extent, -0.12, 0), new THREE.Vector3(extent, -0.12, 0),
    new THREE.Vector3(0, -0.12, -extent), new THREE.Vector3(0, -0.12, extent)
  ];
  const axisGeometry = new THREE.BufferGeometry().setFromPoints(axisPoints);
  const axisLines = new THREE.LineSegments(axisGeometry, new THREE.LineBasicMaterial({ color: 0x75ddd4, transparent: true, opacity: 0.18, depthWrite: false }));
  axisLines.frustumCulled = false;
  scene.add(axisLines);
}
makeGrid();

function updateCamera() {
  if (surfaceMode) {
    updateSurfaceCamera();
    return;
  }
  const cp = Math.cos(cameraState.pitch);
  const direction = new THREE.Vector3(
    Math.sin(cameraState.yaw) * cp,
    Math.sin(cameraState.pitch),
    Math.cos(cameraState.yaw) * cp
  ).normalize();
  camera.position.copy(cameraState.target).addScaledVector(direction, cameraState.distance);
  camera.up.set(0, 1, 0);
  camera.up.applyAxisAngle(direction, cameraState.roll);
  camera.lookAt(cameraState.target);
  camera.near = Math.max(0.00000001, Math.min(0.001, cameraState.distance * 0.0005));
  let farDistance = Math.max(10, cameraState.distance * 4);
  bodies.forEach(function (body) {
    const bodyDistance = camera.position.distanceTo(scenePosition(body)) + body.visualRadius;
    if (bodyDistance > farDistance) farDistance = bodyDistance;
  });
  camera.far = Math.max(camera.near * 1000, farDistance * 1.25);
  camera.updateProjectionMatrix();
  camera.updateMatrixWorld();
}

function getSurfaceBasis(normal) {
  const worldUp = new THREE.Vector3(0, 1, 0);
  let east = new THREE.Vector3().crossVectors(worldUp, normal);
  if (east.lengthSq() < 1e-8) east.set(1, 0, 0).cross(normal);
  east.normalize();
  const north = new THREE.Vector3().crossVectors(normal, east).normalize();
  return { east: east, north: north };
}

function updateSurfaceCamera() {
  if (!surfaceMode) return;
  const body = bodies.find(function (item) { return item.id === surfaceMode.bodyId; });
  if (!body) {
    exitSurfaceMode();
    return;
  }
  const normal = surfaceMode.normal.clone().normalize();
  const basis = getSurfaceBasis(normal);
  const tangentForward = basis.north.multiplyScalar(Math.cos(surfaceMode.heading))
    .add(basis.east.multiplyScalar(Math.sin(surfaceMode.heading))).normalize();
  const lookDirection = tangentForward.clone().multiplyScalar(Math.cos(surfaceMode.lookPitch))
    .add(normal.clone().multiplyScalar(Math.sin(surfaceMode.lookPitch))).normalize();
  const cameraUp = normal.clone().multiplyScalar(Math.cos(surfaceMode.lookPitch))
    .addScaledVector(tangentForward, -Math.sin(surfaceMode.lookPitch)).normalize();
  const center = scenePosition(body);
  const altitudeScene = surfaceMode.altitudeM / WORLD_SCALE;
  camera.position.copy(center).addScaledVector(normal, body.visualRadius + altitudeScene);
  camera.up.copy(cameraUp);
  camera.lookAt(camera.position.clone().add(lookDirection));
  camera.near = Math.max(0.000000001, body.visualRadius * 0.00001);
  camera.far = Math.max(0.05, body.visualRadius * 60);
  camera.updateProjectionMatrix();
  camera.updateMatrixWorld();
}

function updateSurfaceModeMotion(elapsed) {
  if (!surfaceMode) return;
  const body = bodies.find(function (item) { return item.id === surfaceMode.bodyId; });
  if (!body) {
    exitSurfaceMode();
    return;
  }
  const forwardAmount = (surfaceKeys.forward ? 1 : 0) - (surfaceKeys.backward ? 1 : 0);
  const sideAmount = (surfaceKeys.right ? 1 : 0) - (surfaceKeys.left ? 1 : 0);
  const verticalAmount = (surfaceKeys.ascend ? 1 : 0) - (surfaceKeys.descend ? 1 : 0);
  const basis = getSurfaceBasis(surfaceMode.normal);
  if (forwardAmount !== 0 || sideAmount !== 0) {
    const direction = basis.north.multiplyScalar(forwardAmount).add(basis.east.multiplyScalar(sideAmount));
    direction.normalize();
    const angularDistance = Math.min(0.15, surfaceMode.speedMps * elapsed / Math.max(body.radiusM, 1));
    surfaceMode.normal.addScaledVector(direction, angularDistance).normalize();
  }
  if (verticalAmount !== 0) {
    surfaceMode.altitudeM += verticalAmount * surfaceMode.speedMps * elapsed * 4;
    surfaceMode.altitudeM = Math.max(2, Math.min(body.radiusM * 2, surfaceMode.altitudeM));
  }
  const altitudeKm = surfaceMode.altitudeM / 1000;
  surfaceAltitudeReadout.textContent = altitudeKm >= 1
    ? 'Высота ' + formatCompact(altitudeKm) + ' км'
    : 'Высота ' + formatCompact(surfaceMode.altitudeM) + ' м';
}

function enterSurfaceMode(mode, body) {
  if (!body || body.isStar || body.isDebris) {
    showToast('Посадка и полёт доступны только для планет.');
    return;
  }
  selectBody(body, true);
  const cp = Math.cos(cameraState.pitch);
  const normal = new THREE.Vector3(
    Math.sin(cameraState.yaw) * cp,
    Math.sin(cameraState.pitch),
    Math.cos(cameraState.yaw) * cp
  ).normalize();
  const altitude = mode === 'landing'
    ? Math.max(5, Math.min(1000, body.radiusM * 0.0002))
    : Math.max(1000, Math.min(500000, body.radiusM * 0.02));
  surfaceMode = {
    bodyId: body.id,
    type: mode,
    normal: normal,
    heading: 0,
    lookPitch: -0.055,
    altitudeM: altitude,
    speedMps: mode === 'landing' ? 45 : 250
  };
  cameraState.followBodyId = null;
  bodyDetailsPanel.hidden = true;
  $('surfaceModeTitle').textContent = (mode === 'landing' ? 'ПОСАДКА · ' : 'ПОЛЁТ · ') + body.name.toUpperCase();
  surfaceOverlay.hidden = false;
  Object.keys(surfaceKeys).forEach(function (key) { surfaceKeys[key] = false; });
  updateSurfaceCamera();
  showToast(mode === 'landing' ? 'Режим посадки: управляйте камерой и снижением.' : 'Режим полёта: WASD или экранные кнопки.');
}

function exitSurfaceMode() {
  if (!surfaceMode) return;
  const body = bodies.find(function (item) { return item.id === surfaceMode.bodyId; });
  surfaceMode = null;
  surfaceOverlay.hidden = true;
  Object.keys(surfaceKeys).forEach(function (key) { surfaceKeys[key] = false; });
  camera.near = 0.000001;
  camera.far = 50000;
  camera.updateProjectionMatrix();
  if (body) {
    cameraState.target.copy(scenePosition(body));
    cameraState.distance = Math.max(body.visualRadius * 12, 0.025);
    cameraState.followBodyId = body.id;
  } else {
    cameraState.followBodyId = null;
  }
}

updateCamera();

function scenePosition(body) {
  return new THREE.Vector3(
    body.p[0] / WORLD_SCALE,
    body.p[1] / WORLD_SCALE,
    body.p[2] / WORLD_SCALE
  );
}

function visualRadius(body) {
  return Math.max(0, body.radiusM / WORLD_SCALE);
}

function contactRadiusFromPhysicalRadius(radiusM) {
  return radiusM;
}

function formatGridDistance(sceneDistance) {
  const distanceKm = Math.abs(sceneDistance) * WORLD_SCALE / 1000;
  if (distanceKm <= 150000000) {
    return Math.round(distanceKm / 1000000) + ' млн км';
  }
  return (distanceKm / (AU / 1000)).toLocaleString('ru-RU', { maximumFractionDigits: 2 }) + ' а.е.';
}

function updateGridDistanceLabels() {
  const width = window.innerWidth;
  const height = window.innerHeight;
  gridDistanceLabels.forEach(function (item) {
    const projected = item.position.clone().project(camera);
    if (projected.z < -1 || projected.z > 1 || Math.abs(projected.x) > 1.08 || Math.abs(projected.y) > 1.08) {
      item.element.style.display = 'none';
    } else {
      item.element.style.display = 'block';
      item.element.style.left = ((projected.x * 0.5 + 0.5) * width) + 'px';
      item.element.style.top = ((-projected.y * 0.5 + 0.5) * height) + 'px';
      item.element.style.transform = 'translate(-50%, -50%)';
    }
  });
}

function blackbodyColorHex(temperatureK) {
  const temperature = Math.max(1000, Math.min(40000, temperatureK)) / 100;
  let red;
  let green;
  let blue;
  if (temperature <= 66) red = 255;
  else red = 329.698727446 * Math.pow(temperature - 60, -0.1332047592);
  if (temperature <= 66) green = 99.4708025861 * Math.log(temperature) - 161.1195681661;
  else green = 288.1221695283 * Math.pow(temperature - 60, -0.0755148492);
  if (temperature >= 66) blue = 255;
  else if (temperature <= 19) blue = 0;
  else blue = 138.5177312231 * Math.log(temperature - 10) - 305.0447927307;
  red = Math.max(0, Math.min(255, red));
  green = Math.max(0, Math.min(255, green));
  blue = Math.max(0, Math.min(255, blue));
  return new THREE.Color(red / 255, green / 255, blue / 255);
}

function stellarLuminosityRatio(star) {
  if (!star) return 0;
  return calculateStellarLuminosity(star.radiusM, star.temperatureK);
}

function getKopparapuBoundaries(star) {
  if (!star) return null;
  return calculateKopparapuBoundaries(star.radiusM, star.temperatureK);
}

function createHabitableZoneVisuals(star) {
  if (!star.isStar || star.hzGroup) return;
  const boundaries = getKopparapuBoundaries(star);
  if (!boundaries) return;
  const inner = boundaries.innerM / WORLD_SCALE;
  const outer = boundaries.outerM / WORLD_SCALE;
  const starSurface = Math.max(star.visualRadius * 1.06, 0.000001);
  const group = new THREE.Group();
  group.renderOrder = 0;
  const materials = [
    new THREE.MeshBasicMaterial({ color: 0xff554e, transparent: true, opacity: 0.105, side: THREE.DoubleSide, depthWrite: false }),
    new THREE.MeshBasicMaterial({ color: 0x4ee58b, transparent: true, opacity: 0.155, side: THREE.DoubleSide, depthWrite: false }),
    new THREE.MeshBasicMaterial({ color: 0x559cff, transparent: true, opacity: 0.085, side: THREE.DoubleSide, depthWrite: false })
  ];
  const rings = [];
  if (inner > starSurface) {
    rings.push(new THREE.Mesh(new THREE.RingGeometry(starSurface, inner, 160), materials[0]));
  } else {
    materials[0].dispose();
  }
  rings.push(new THREE.Mesh(new THREE.RingGeometry(inner, outer, 160), materials[1]));
  rings.push(new THREE.Mesh(new THREE.RingGeometry(outer, outer * 1.42, 160), materials[2]));
  rings.forEach(function (ring) {
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = -0.12;
    ring.frustumCulled = false;
    group.add(ring);
  });
  scene.add(group);
  star.hzGroup = group;
  star.hzBoundaries = boundaries;
  group.visible = hzToggleInput.checked;
}

function makeBodyMaterial(body, transparent) {
  if (body.isStar) {
    const color = blackbodyColorHex(body.temperatureK || SOLAR_TEMPERATURE_K);
    return new THREE.MeshStandardMaterial({
      color: color,
      emissive: color,
      emissiveIntensity: 3.4,
      roughness: 1,
      metalness: 0,
      transparent: Boolean(transparent),
      opacity: transparent ? 0.62 : 1,
      depthWrite: !transparent,
      toneMapped: false
    });
  }
  return new THREE.MeshStandardMaterial({
    map: body.isDebris ? null : planetTexture,
    color: body.isDebris ? 0x9fd9e2 : 0xffffff,
    roughness: body.isDebris ? 0.72 : 0.92,
    metalness: body.isDebris ? 0.08 : 0.015,
    emissive: body.isDebris ? 0x163f50 : 0x000000,
    emissiveIntensity: body.isDebris ? 0.42 : 0,
    transparent: Boolean(transparent),
    opacity: transparent ? 0.56 : 1,
    depthWrite: !transparent
  });
}

function updateStarLight(star) {
  if (!star.isStar || !star.starLight) return;
  const luminosity = stellarLuminosityRatio(star);
  const color = blackbodyColorHex(star.temperatureK || SOLAR_TEMPERATURE_K);
  star.starLight.color.copy(color);
  star.starLight.intensity = Math.min(2.0e8, Math.max(0, 2.0e4 * luminosity));
  star.starLight.distance = 0;
  star.starLight.decay = 2;
}

function setHabitableZonesVisible(visible) {
  bodies.forEach(function (body) {
    if (body.isStar && body.hzGroup) body.hzGroup.visible = visible;
  });
  hzLegend.hidden = !visible;
}

function addBodyVisual(body) {
  const material = makeBodyMaterial(body, false);
  const mesh = new THREE.Mesh(sphereGeometry, material);
  body.visualRadius = visualRadius(body);
  body.contactRadiusM = body.radiusM;
  mesh.scale.setScalar(body.visualRadius);
  mesh.position.copy(scenePosition(body));
  mesh.userData.bodyId = body.id;
  scene.add(mesh);
  body.mesh = mesh;

  if (body.isStar) {
    body.starLight = new THREE.PointLight(blackbodyColorHex(body.temperatureK || SOLAR_TEMPERATURE_K), 1, 9000, 2);
    body.starLight.position.copy(mesh.position);
    scene.add(body.starLight);
    updateStarLight(body);
    createHabitableZoneVisuals(body);
  }

  const lineMaterial = new THREE.LineBasicMaterial({ color: body.isStar ? 0xffc879 : 0x5ecbc4, transparent: true, opacity: 0.36, depthWrite: false });
  const trail = new THREE.Line(new THREE.BufferGeometry(), lineMaterial);
  trail.frustumCulled = false;
  scene.add(trail);
  body.trail = trail;

  if (!body.isDebris) {
    const label = document.createElement('div');
    label.className = body.isStar ? 'body-label star-label' : 'body-label';
    label.textContent = body.name;
    viewport.appendChild(label);
    body.label = label;
  }

  body.history = [[body.p[0], body.p[1], body.p[2]]];
  body.nextTrailTime = simulationSeconds + DAY * 0.35;
  updateTrailGeometry(body);
}
function updateTrailGeometry(body) {
  if (!body.trail) return;
  const points = body.history.map(function (p) {
    return new THREE.Vector3(p[0] / WORLD_SCALE, p[1] / WORLD_SCALE, p[2] / WORLD_SCALE);
  });
  body.trail.geometry.dispose();
  body.trail.geometry = new THREE.BufferGeometry().setFromPoints(points);
}

function removeBodyVisual(body) {
  if (body.mesh) {
    scene.remove(body.mesh);
    body.mesh.material.dispose();
    body.mesh = null;
  }
  if (body.trail) {
    scene.remove(body.trail);
    body.trail.geometry.dispose();
    body.trail.material.dispose();
    body.trail = null;
  }
  if (body.label && body.label.parentNode) body.label.parentNode.removeChild(body.label);
  body.label = null;
  if (body.starLight) {
    scene.remove(body.starLight);
    body.starLight = null;
  }
  if (body.hzGroup) {
    scene.remove(body.hzGroup);
    body.hzGroup.traverse(function (object) {
      if (object.geometry) object.geometry.dispose();
      if (object.material) object.material.dispose();
    });
    body.hzGroup = null;
  }
}

function addBody(body) {
  bodies.push(body);
  updateAccelerations(bodies);
  addBodyVisual(body);
  refreshObjectList();
}

function removeBodyFromSimulation(body) {
  const index = bodies.indexOf(body);
  if (index < 0) return false;
  removeBodyVisual(body);
  bodies.splice(index, 1);
  if (selectedBody && selectedBody.id === body.id) {
    selectedBody = null;
    clearSelectionRing();
    selectionTag.hidden = true;
  }
  if (cameraState.followBodyId === body.id) cameraState.followBodyId = null;
  if (detailsEditingBodyId === body.id) {
    detailsEditingBodyId = null;
    bodyDetailsPanel.hidden = true;
  }
  if (surfaceMode && surfaceMode.bodyId === body.id) exitSurfaceMode();
  return true;
}

function removeBodyById(id) {
  const body = bodies.find(function (item) { return item.id === id; });
  if (!body) return;
  if (!body.isDebris) {
    bodies.forEach(function (candidate) {
      if (candidate.isDebris && candidate.debrisTargetId === body.id) candidate.debrisTargetId = null;
    });
  }
  removeBodyFromSimulation(body);
  updateAccelerations(bodies);
  refreshObjectList();
  showToast('Объект удалён');
}

function updatePhysicalRadius(body) {
  if (!(body.mass > 0) || !(body.density > 0)) return;
  body.radiusM = Math.cbrt((3 * body.mass) / (4 * Math.PI * body.density));
  body.radiusKm = body.radiusM / 1000;
  body.visualRadius = visualRadius(body);
  body.contactRadiusM = body.radiusM;
  if (body.mesh) body.mesh.scale.setScalar(body.visualRadius);
  if (body.isStar) {
    updateStarLight(body);
    if (body.hzGroup) {
      scene.remove(body.hzGroup);
      body.hzGroup.traverse(function (object) {
        if (object.geometry) object.geometry.dispose();
        if (object.material) object.material.dispose();
      });
      body.hzGroup = null;
    }
    createHabitableZoneVisuals(body);
  }
  if (selectedBody && selectedBody.id === body.id) selectBody(body, false);
}

function mergeDebrisIntoBody(debris, target) {
  if (!debris || !target || debris === target || !debris.isDebris) return false;
  const oldMass = target.mass;
  const totalMass = oldMass + debris.mass;
  if (!(totalMass > 0)) return false;

  let axis;
  for (axis = 0; axis < 3; axis += 1) {
    target.p[axis] = (target.p[axis] * oldMass + debris.p[axis] * debris.mass) / totalMass;
    target.v[axis] = (target.v[axis] * oldMass + debris.v[axis] * debris.mass) / totalMass;
  }
  target.mass = totalMass;
  updatePhysicalRadius(target);
  removeBodyFromSimulation(debris);
  return true;
}

function processDebrisLifecycle() {
  let changed = false;
  const expired = bodies.filter(function (body) {
    return body.isDebris && simulationSeconds >= body.debrisExpiresAtSimSeconds;
  });
  expired.forEach(function (debris) {
    const target = bodies.find(function (body) { return body.id === debris.debrisTargetId && !body.isDebris; });
    if (target) mergeDebrisIntoBody(debris, target);
    else removeBodyFromSimulation(debris);
    changed = true;
  });
  if (changed) {
    updateAccelerations(bodies);
    refreshObjectList();
  }
}

function interpolateVector(start, end, t) {
  return [
    start[0] + (end[0] - start[0]) * t,
    start[1] + (end[1] - start[1]) * t,
    start[2] + (end[2] - start[2]) * t
  ];
}

function applyCollision(collision, previousPositions, previousVelocities) {
  const bodyA = collision.a;
  const bodyB = collision.b;
  if (bodies.indexOf(bodyA) < 0 || bodies.indexOf(bodyB) < 0) return;

  if (bodyA.isDebris || bodyB.isDebris) {
    const debris = bodyA.isDebris ? bodyA : bodyB;
    const target = bodyA.isDebris ? bodyB : bodyA;
    if (!target.isDebris) {
      mergeDebrisIntoBody(debris, target);
      updateAccelerations(bodies);
      refreshObjectList();
      showToast('Осколок поглощён объектом «' + target.name + '»');
    }
    return;
  }

  let survivor = bodyA;
  let impactor = bodyB;
  if (bodyB.mass > bodyA.mass || (bodyB.mass === bodyA.mass && bodyB.id < bodyA.id)) {
    survivor = bodyB;
    impactor = bodyA;
  }

  const indexA = bodies.indexOf(bodyA);
  const indexB = bodies.indexOf(bodyB);
  const t = collision.time;
  const positionA = interpolateVector(previousPositions[indexA], bodyA.p, t);
  const positionB = interpolateVector(previousPositions[indexB], bodyB.p, t);
  const velocityA = interpolateVector(previousVelocities[indexA], bodyA.v, t);
  const velocityB = interpolateVector(previousVelocities[indexB], bodyB.v, t);
  const totalMass = bodyA.mass + bodyB.mass;
  const center = [0, 0, 0];
  const centerVelocity = [0, 0, 0];
  let axis;
  for (axis = 0; axis < 3; axis += 1) {
    center[axis] = (positionA[axis] * bodyA.mass + positionB[axis] * bodyB.mass) / totalMass;
    centerVelocity[axis] = (velocityA[axis] * bodyA.mass + velocityB[axis] * bodyB.mass) / totalMass;
  }

  const relativeSpeed = Math.sqrt(
    Math.pow(velocityA[0] - velocityB[0], 2) +
    Math.pow(velocityA[1] - velocityB[1], 2) +
    Math.pow(velocityA[2] - velocityB[2], 2)
  );
  const debrisMass = impactor.mass * FRAGMENT_MASS_FRACTION;
  const accretedMass = impactor.mass - debrisMass;
  survivor.mass += accretedMass;
  survivor.p = center.slice();
  survivor.v = centerVelocity.slice();
  updatePhysicalRadius(survivor);

  bodies.forEach(function (candidate) {
    if (candidate.isDebris && candidate.debrisTargetId === impactor.id) {
      candidate.debrisTargetId = survivor.id;
    }
  });
  const wasFollowingImpactor = cameraState.followBodyId === impactor.id;
  removeBodyFromSimulation(impactor);
  if (wasFollowingImpactor) cameraState.followBodyId = survivor.id;

  const fragmentMass = debrisMass / FRAGMENT_COUNT;
  const fragmentRadiusM = Math.cbrt((3 * fragmentMass) / (4 * Math.PI * impactor.density));
  const kickSpeed = Math.max(5, relativeSpeed * 0.08);
  const fragmentContactRadius = contactRadiusFromPhysicalRadius(fragmentRadiusM);
  const survivorContactRadius = survivor.contactRadiusM || survivor.radiusM;
  const impactorContactRadius = impactor.contactRadiusM || impactor.radiusM;
  const baseOffset = survivorContactRadius + fragmentContactRadius * 1.6 + Math.max(10, impactorContactRadius * 0.12);
  const rotation = (survivor.id * 0.731 + impactor.id * 0.417) % (Math.PI * 2);
  const c = Math.cos(rotation);
  const s = Math.sin(rotation);
  const axes = [
    [1, 0, 0], [-1, 0, 0],
    [0, 1, 0], [0, -1, 0],
    [0, 0, 1], [0, 0, -1]
  ];
  let fragmentIndex;
  for (fragmentIndex = 0; fragmentIndex < FRAGMENT_COUNT; fragmentIndex += 1) {
    const sourceAxis = axes[fragmentIndex];
    const direction = [
      sourceAxis[0] * c - sourceAxis[2] * s,
      sourceAxis[1],
      sourceAxis[0] * s + sourceAxis[2] * c
    ];
    const fragmentPosition = [
      center[0] + direction[0] * baseOffset,
      center[1] + direction[1] * baseOffset,
      center[2] + direction[2] * baseOffset
    ];
    const fragmentVelocity = [
      centerVelocity[0] + direction[0] * kickSpeed,
      centerVelocity[1] + direction[1] * kickSpeed,
      centerVelocity[2] + direction[2] * kickSpeed
    ];
    const fragment = makeBody(
      nextBodyId,
      'Осколок ' + (fragmentIndex + 1) + ' · ' + impactor.name,
      fragmentMass,
      fragmentRadiusM / 1000,
      impactor.density,
      fragmentPosition,
      fragmentVelocity
    );
    nextBodyId += 1;
    fragment.isDebris = true;
    fragment.debrisTargetId = survivor.id;
    fragment.debrisExpiresAtSimSeconds = simulationSeconds + FRAGMENT_LIFETIME_DAYS * DAY;
    bodies.push(fragment);
    addBodyVisual(fragment);
  }

  if (selectedBody === null || selectedBody.id === impactor.id) selectBody(survivor, false);
  updateAccelerations(bodies);
  refreshObjectList();
  showToast('Столкновение: «' + impactor.name + '» разрушено · создано ' + FRAGMENT_COUNT + ' осколков');
  if (!createModal.hidden) populateOrbitTargets();
}

function clearSelectionRing() {
  if (selectedRing) {
    scene.remove(selectedRing);
    selectedRing.geometry.dispose();
    selectedRing.material.dispose();
    selectedRing = null;
  }
}

function selectBody(body, focus) {
  if (surfaceMode && (!body || surfaceMode.bodyId !== body.id)) exitSurfaceMode();
  selectedBody = body;
  clearSelectionRing();
  if (body) {
    selectedRing = new THREE.Mesh(
      new THREE.TorusGeometry(body.visualRadius * 1.42, Math.max(0.00001, body.visualRadius * 0.035), 8, 80),
      new THREE.MeshBasicMaterial({ color: 0x75e8df, transparent: true, opacity: 0.8, depthWrite: false })
    );
    selectedRing.rotation.x = Math.PI / 2;
    selectedRing.position.copy(scenePosition(body));
    scene.add(selectedRing);
    selectionName.textContent = body.name;
    selectionTag.hidden = false;
    if (focus) {
      cameraState.followBodyId = body.id;
      cameraState.distance = Math.max(visualRadius(body) * 12, 0.025);
    }
  } else {
    selectionTag.hidden = true;
    cameraState.followBodyId = null;
  }
  refreshObjectList();
}

function focusSystem() {
  if (surfaceMode) exitSurfaceMode();
  if (selectedBody && bodies.indexOf(selectedBody) >= 0) {
    cameraState.followBodyId = selectedBody.id;
    cameraState.distance = Math.max(cameraState.distance, selectedBody.visualRadius * 14, 0.025);
    return;
  }
  cameraState.followBodyId = null;
  if (bodies.length === 0) {
    cameraState.target.set(0, 0, 0);
    return;
  }
  let totalMass = 0;
  let x = 0;
  let y = 0;
  let z = 0;
  let i;
  for (i = 0; i < bodies.length; i += 1) {
    totalMass += bodies[i].mass;
    x += bodies[i].p[0] * bodies[i].mass;
    y += bodies[i].p[1] * bodies[i].mass;
    z += bodies[i].p[2] * bodies[i].mass;
  }
  if (totalMass > 0) cameraState.target.set(x / totalMass / WORLD_SCALE, y / totalMass / WORLD_SCALE, z / totalMass / WORLD_SCALE);
  cameraState.distance = Math.max(cameraState.distance, 240);
}

function calculatePlanetEquilibriumTemperature(planet) {
  if (!planet || planet.isStar || planet.isDebris) return null;
  const stars = bodies.filter(function (body) { return body.isStar; });
  return estimateEquilibriumTemperature(planet.p, stars, BOND_ALBEDO);
}

function getPlanetClimateDescription(planet) {
  const climate = calculatePlanetEquilibriumTemperature(planet);
  if (!climate) return 'T_eq —';
  let description = 'T_eq ' + Math.round(climate.temperatureK) + ' K';
  const star = climate.dominantStar;
  const boundaries = getKopparapuBoundaries(star);
  if (boundaries) {
    const dx = planet.p[0] - star.p[0];
    const dy = planet.p[1] - star.p[1];
    const dz = planet.p[2] - star.p[2];
    const distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
    let zoneName = 'холодная зона';
    if (distance < boundaries.innerM) zoneName = 'горячая зона';
    else if (distance <= boundaries.outerM) zoneName = 'обитаемая зона';
    description += ' · ' + zoneName;
  }
  return description;
}

function detailBaseValue(inputId, kind, unitId) {
  const value = parseNumericInput(inputId);
  const unit = $(unitId).value;
  return valueToBaseUnits(value, UNIT_FACTORS[kind], unit);
}

function setDetailBaseValue(inputId, kind, unitId, baseValue) {
  const unit = $(unitId).value;
  $(inputId).value = formatInputNumber(valueFromBaseUnits(baseValue, UNIT_FACTORS[kind], unit));
}

function syncBodyDetailsDerived(changedField) {
  const mass = detailBaseValue('bodyEditMass', 'mass', 'bodyEditMassUnit');
  const radiusKm = detailBaseValue('bodyEditRadius', 'radius', 'bodyEditRadiusUnit');
  const density = detailBaseValue('bodyEditDensity', 'density', 'bodyEditDensityUnit');
  if (!(mass > 0) || !Number.isFinite(mass)) return;
  if (changedField === 'density') {
    if (!(density > 0) || !Number.isFinite(density)) return;
    const nextRadiusKm = calculateRadiusKm(mass, density);
    setDetailBaseValue('bodyEditRadius', 'radius', 'bodyEditRadiusUnit', nextRadiusKm);
  } else {
    if (!(radiusKm > 0) || !Number.isFinite(radiusKm)) return;
    setDetailBaseValue('bodyEditDensity', 'density', 'bodyEditDensityUnit', calculateDensity(mass, radiusKm));
  }
}

function openBodyDetails(body) {
  if (!body || body.isDebris) return;
  if (surfaceMode) exitSurfaceMode();
  detailsEditingBodyId = body.id;
  detailLastChanged = 'radius';
  $('bodyDetailsTitle').textContent = (body.isStar ? 'Звезда · ' : 'Планета · ') + body.name;
  $('bodyEditName').value = body.name;
  setDetailBaseValue('bodyEditMass', 'mass', 'bodyEditMassUnit', body.mass);
  setDetailBaseValue('bodyEditRadius', 'radius', 'bodyEditRadiusUnit', body.radiusKm);
  setDetailBaseValue('bodyEditDensity', 'density', 'bodyEditDensityUnit', body.density);
  $('bodyEditStarOptions').hidden = !body.isStar;
  const currentTemperature = body.temperatureK || SOLAR_TEMPERATURE_K;
  const temperatureUnit = $('bodyEditTemperatureUnit').value;
  $('bodyEditTemperature').value = formatInputNumber(temperatureUnit === 'C' ? currentTemperature - 273.15 : currentTemperature);
  $('bodyEditTemperatureUnit').dataset.previousUnit = temperatureUnit;
  $('bodyLanding').disabled = body.isStar;
  $('bodyFlight').disabled = body.isStar;
  $('bodyEditClimate').textContent = body.isStar
    ? 'Светимость: ' + formatCompact(stellarLuminosityRatio(body)) + ' L☉'
    : getPlanetClimateDescription(body);
  bodyDetailsPanel.hidden = false;
}

function saveBodyDetails() {
  const body = bodies.find(function (item) { return item.id === detailsEditingBodyId; });
  if (!body || body.isDebris) return;
  syncBodyDetailsDerived(detailLastChanged);
  const name = $('bodyEditName').value.trim();
  const mass = detailBaseValue('bodyEditMass', 'mass', 'bodyEditMassUnit');
  const radiusKm = detailBaseValue('bodyEditRadius', 'radius', 'bodyEditRadiusUnit');
  const density = detailBaseValue('bodyEditDensity', 'density', 'bodyEditDensityUnit');
  if (!name || !(mass > 0) || mass > 1e36 || !(radiusKm > 0) || radiusKm > 1e10 || !(density > 0) || density > 1e15 || !Number.isFinite(mass + radiusKm + density)) {
    showToast('Проверьте название, массу, радиус и плотность. Все значения должны быть положительными.');
    return;
  }
  let temperatureK = body.temperatureK;
  if (body.isStar) {
    const rawTemperature = parseNumericInput('bodyEditTemperature');
    temperatureK = $('bodyEditTemperatureUnit').value === 'C' ? rawTemperature + 273.15 : rawTemperature;
    if (!Number.isFinite(temperatureK) || temperatureK < 1000 || temperatureK > 50000) {
      showToast('Температура звезды должна быть в диапазоне 1000–50000 K.');
      return;
    }
  }
  body.name = name;
  body.mass = mass;
  body.density = density;
  body.radiusM = radiusKm * 1000;
  body.radiusKm = radiusKm;
  if (body.isStar) body.temperatureK = temperatureK;
  updatePhysicalRadius(body);
  updateAccelerations(bodies);
  selectionName.textContent = body.name;
  $('surfaceModeTitle').textContent = surfaceMode
    ? (surfaceMode.type === 'landing' ? 'ПОСАДКА · ' : 'ПОЛЁТ · ') + body.name.toUpperCase()
    : $('surfaceModeTitle').textContent;
  $('bodyEditClimate').textContent = body.isStar
    ? 'Светимость: ' + formatCompact(stellarLuminosityRatio(body)) + ' L☉'
    : getPlanetClimateDescription(body);
  refreshObjectList();
  showToast('Характеристики «' + body.name + '» обновлены.');
}

function refreshObjectList() {
  bodyCount.textContent = String(bodies.length);
  objectList.innerHTML = '';
  if (bodies.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'empty-list';
    empty.textContent = 'В системе пока нет тел. Создайте объект или загрузите пример, чтобы запустить N-body расчёт.';
    objectList.appendChild(empty);
    return;
  }
  bodies.forEach(function (body) {
    const row = document.createElement('div');
    row.className = body.isDebris ? 'object-row debris-row' : (body.isStar ? 'object-row star-row' : 'object-row');
    const orb = document.createElement('div');
    orb.className = 'object-orb';
    const meta = document.createElement('div');
    meta.className = 'object-meta';
    const strong = document.createElement('strong');
    strong.textContent = body.name + (body.isStar ? ' · Звезда' : '');
    const small = document.createElement('small');
    small.textContent = formatMass(body.mass) + ' кг  ·  r ' + formatCompact(body.radiusKm) + ' км' + (body.isDebris ? ' · ' + Math.max(0, (body.debrisExpiresAtSimSeconds - simulationSeconds) / DAY).toFixed(1) + ' д' : '');
    body.listMeta = small;
    if (body.isStar) {
      small.textContent += ' · T_eff ' + Math.round(body.temperatureK) + ' K · L ' + formatCompact(stellarLuminosityRatio(body)) + ' L☉';
    } else if (!body.isDebris) {
      small.textContent += ' · ' + getPlanetClimateDescription(body);
    }
    meta.appendChild(strong);
    meta.appendChild(small);
    if (!body.isDebris) {
      const edit = document.createElement('button');
      edit.type = 'button';
      edit.className = 'object-menu-button';
      edit.title = 'Открыть характеристики';
      edit.setAttribute('aria-label', 'Характеристики: ' + body.name);
      edit.innerHTML = '<svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/></svg>';
      edit.addEventListener('click', function (event) {
        event.stopPropagation();
        selectBody(body, true);
        openBodyDetails(body);
      });
      row.appendChild(orb);
      row.appendChild(meta);
      row.appendChild(edit);
    } else {
      row.appendChild(orb);
      row.appendChild(meta);
    }
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'object-delete-button';
    remove.textContent = '×';
    remove.title = 'Удалить объект';
    remove.addEventListener('click', function (event) {
      event.stopPropagation();
      removeBodyById(body.id);
    });
    row.appendChild(remove);
    row.addEventListener('click', function () {
      selectBody(body, true);
      if (!bodyDetailsPanel.hidden && !body.isDebris) openBodyDetails(body);
    });
    if (selectedBody && selectedBody.id === body.id) row.style.background = 'rgba(113,229,220,.07)';
    objectList.appendChild(row);
  });
}
function formatCompact(value) {
  if (!Number.isFinite(value)) return '—';
  if (Math.abs(value) >= 1e6 || (Math.abs(value) > 0 && Math.abs(value) < 0.01)) return value.toExponential(2);
  return value.toLocaleString('ru-RU', { maximumFractionDigits: 2 });
}

function formatMass(value) {
  return Number(value).toExponential(2).replace('e+', 'e');
}

function showToast(message) {
  const toast = $('toast');
  toast.textContent = message;
  toast.classList.add('show');
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(function () { toast.classList.remove('show'); }, 2300);
}

function getGroundPoint(clientX, clientY, target) {
  const rect = renderer.domElement.getBoundingClientRect();
  pointerNdc.x = ((clientX - rect.left) / rect.width) * 2 - 1;
  pointerNdc.y = -((clientY - rect.top) / rect.height) * 2 + 1;
  raycaster.setFromCamera(pointerNdc, camera);
  return raycaster.ray.intersectPlane(groundPlane, target);
}

function screenDragDirection(deltaX, deltaY) {
  const right = new THREE.Vector3(1, 0, 0).applyQuaternion(camera.quaternion).normalize();
  const up = new THREE.Vector3(0, 1, 0).applyQuaternion(camera.quaternion).normalize();
  const direction = right.multiplyScalar(deltaX).addScaledVector(up, -deltaY);
  if (direction.lengthSq() < 1e-8) return null;
  return direction.normalize();
}

function makeDefaultDirection(position) {
  let primary = null;
  let maxMass = 0;
  let i;
  for (i = 0; i < bodies.length; i += 1) {
    if (bodies[i].mass > maxMass) {
      maxMass = bodies[i].mass;
      primary = bodies[i];
    }
  }
  if (!primary) return new THREE.Vector3(1, 0, 0);
  const dx = position.x - primary.p[0] / WORLD_SCALE;
  const dz = position.z - primary.p[2] / WORLD_SCALE;
  const tangent = new THREE.Vector3(-dz, 0, dx);
  if (tangent.lengthSq() < 1e-7) return new THREE.Vector3(1, 0, 0);
  return tangent.normalize();
}

function updatePreviewVelocity() {
  if (!previewState || !previewState.position) return;
  const body = previewState.body;
  body.p[0] = previewState.position.x * WORLD_SCALE;
  body.p[1] = previewState.position.y * WORLD_SCALE;
  body.p[2] = previewState.position.z * WORLD_SCALE;

  let direction;
  let speed;
  let baseVelocity = [0, 0, 0];
  if (previewState.draft.autoOrbit) {
    const primary = bodies.find(function (candidate) {
      return candidate.id === previewState.draft.orbitTargetId && !candidate.isDebris;
    });
    if (!primary) {
      previewState.invalidOrbit = true;
      if (orbitHelp) orbitHelp.textContent = 'Выбранное центральное тело исчезло. Отмените размещение и выберите другое.';
      return;
    }

    const dx = body.p[0] - primary.p[0];
    const dy = body.p[1] - primary.p[1];
    const dz = body.p[2] - primary.p[2];
    const orbitalRadius = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (!(orbitalRadius > primary.radiusM + body.radiusM)) {
      previewState.invalidOrbit = true;
      if (orbitHelp) orbitHelp.textContent = 'Точка должна находиться за пределами поверхности выбранного тела.';
      return;
    }
    previewState.invalidOrbit = false;
    direction = new THREE.Vector3(-dz, 0, dx);
    if (direction.lengthSq() < 1e-10) direction.set(1, 0, 0);
    direction.normalize();
    speed = Math.sqrt(G * (primary.mass + body.mass) / orbitalRadius);
    baseVelocity = primary.v;
    body.v[0] = baseVelocity[0] + direction.x * speed;
    body.v[1] = baseVelocity[1] + direction.y * speed;
    body.v[2] = baseVelocity[2] + direction.z * speed;
    previewState.draft.speedKms = speed / 1000;
    speedInput.value = formatInputNumber(previewState.draft.speedKms / getLinearUnitFactor('speed')); 
    if (orbitHelp) orbitHelp.textContent = 'Круговая скорость: ' + formatCompact(previewState.draft.speedKms) + ' км/с · радиус: ' + formatCompact(orbitalRadius / 1000) + ' км';
  } else {
    direction = previewState.direction;
    if (!direction || direction.lengthSq() < 1e-8) direction = makeDefaultDirection(previewState.position);
    direction = direction.clone().normalize();
    speed = previewState.draft.speedKms * 1000;
    body.v[0] = direction.x * speed;
    body.v[1] = direction.y * speed;
    body.v[2] = direction.z * speed;
  }

  if (previewArrow) {
    previewArrow.position.copy(previewState.position);
    previewArrow.setDirection(direction);
    const speedKms = speed / 1000;
    const length = Math.max(4.5, Math.min(36, 5 + speedKms * 0.42));
    previewArrow.setLength(length, Math.min(3.5, length * 0.28), Math.min(1.8, length * 0.13));
  }
  previewNeedsPrediction = true;
}

function createPreviewObjects(draft) {
  const body = makeBody(-999, draft.name, draft.mass, draft.radiusKm, draft.density, [0, 0, 0], [0, 0, 0], draft.bodyType, draft.temperatureK);
  const material = makeBodyMaterial(body, true);
  previewMesh = new THREE.Mesh(sphereGeometry, material);
  previewMesh.scale.setScalar(visualRadius(body));
  previewMesh.renderOrder = 4;
  previewMesh.visible = false;
  scene.add(previewMesh);
  previewArrow = new THREE.ArrowHelper(new THREE.Vector3(1, 0, 0), new THREE.Vector3(0, 0, 0), 8, 0x72e8dd, 2, 1.2);
  previewArrow.line.material.transparent = true;
  previewArrow.line.material.opacity = 0.9;
  previewArrow.cone.material.transparent = true;
  previewArrow.cone.material.opacity = 0.95;
  previewArrow.visible = false;
  scene.add(previewArrow);
  previewLine = new THREE.Line(new THREE.BufferGeometry(), new THREE.LineDashedMaterial({ color: 0x78e8dd, dashSize: 1.8, gapSize: 1.05, transparent: true, opacity: 0.75, depthWrite: false }));
  previewLine.frustumCulled = false;
  previewLine.visible = false;
  scene.add(previewLine);
  previewState = { draft: draft, body: body, position: null, direction: null, active: true, invalidOrbit: false, placedCount: 0 };
  previewNeedsPrediction = true;
}

function destroyPreviewObjects() {
  if (previewMesh) {
    scene.remove(previewMesh);
    previewMesh.material.dispose();
    previewMesh = null;
  }
  if (previewArrow) {
    scene.remove(previewArrow);
    previewArrow.line.geometry.dispose();
    previewArrow.line.material.dispose();
    previewArrow.cone.geometry.dispose();
    previewArrow.cone.material.dispose();
    previewArrow = null;
  }
  if (previewLine) {
    scene.remove(previewLine);
    previewLine.geometry.dispose();
    previewLine.material.dispose();
    previewLine = null;
  }
  previewState = null;
  previewNeedsPrediction = false;
  placementGesture = null;
  placementBanner.hidden = true;
}

function updatePreviewPrediction(force) {
  if (!previewState || !previewState.position) return;
  const now = performance.now();
  if (!force && now - lastPredictionTime < 95) return;
  lastPredictionTime = now;
  previewNeedsPrediction = false;
  updatePreviewVelocity();
  previewNeedsPrediction = false;
  if (previewState.invalidOrbit) {
    previewLine.geometry.dispose();
    previewLine.geometry = new THREE.BufferGeometry();
    return;
  }
  const sources = bodies.slice();
  sources.push(previewState.body);
  const result = predictTrajectory(sources, sources.length - 1, 420);
  const points = result.points.map(function (p) {
    return new THREE.Vector3(p[0] / WORLD_SCALE, p[1] / WORLD_SCALE, p[2] / WORLD_SCALE);
  });
  previewLine.geometry.dispose();
  previewLine.geometry = new THREE.BufferGeometry().setFromPoints(points);
  previewLine.computeLineDistances();
}

function beginPlacement(draft) {
  createModal.hidden = true;
  objectPanel.hidden = true;
  sceneHint.style.opacity = '0';
  createPreviewObjects(draft);
  if (draft.multiCreate) {
    placementTitle.textContent = 'МНОЖЕСТВЕННОЕ СОЗДАНИЕ';
    placementInstructions.textContent = draft.autoOrbit ? 'Каждое отпускание устанавливает тело на новой круговой орбите выбранного центра.' : 'Каждое отпускание устанавливает копию с теми же параметрами. Для завершения нажмите «Отмена».';
  } else if (draft.autoOrbit) {
    const primary = bodies.find(function (body) { return body.id === draft.orbitTargetId; });
    placementTitle.textContent = 'АВТО-ОРБИТА';
    placementInstructions.textContent = primary ? 'Выберите радиус орбиты вокруг «' + primary.name + '». Скорость и направление задаются автоматически.' : 'Не найдено центральное тело для орбиты.';
  } else {
    placementTitle.textContent = 'РАЗМЕЩЕНИЕ ОБЪЕКТА';
    placementInstructions.textContent = 'Потяните: направление и наклон скорости · отпустите: установить';
  }
  placementBanner.hidden = false;
  showToast(draft.autoOrbit ? 'Выберите расстояние до центрального тела' : 'Коснитесь плоскости, задайте направление и отпустите');
}

function cancelPlacement() {
  if (!previewState) return;
  destroyPreviewObjects();
  sceneHint.style.opacity = '1';
  showToast('Размещение отменено');
}

function setPreviewPosition(point) {
  if (!previewState || !point) return;
  previewState.position = point.clone();
  previewMesh.position.copy(point);
  previewMesh.visible = true;
  previewArrow.visible = true;
  previewLine.visible = true;
  updatePreviewVelocity();
}

function resetPreviewForNextPlacement() {
  if (!previewState) return;
  previewState.position = null;
  previewState.direction = null;
  previewState.invalidOrbit = false;
  previewState.body.p[0] = 0;
  previewState.body.p[1] = 0;
  previewState.body.p[2] = 0;
  previewState.body.v[0] = 0;
  previewState.body.v[1] = 0;
  previewState.body.v[2] = 0;
  previewMesh.visible = false;
  previewArrow.visible = false;
  previewLine.visible = false;
  previewLine.geometry.dispose();
  previewLine.geometry = new THREE.BufferGeometry();
  previewNeedsPrediction = false;
  placementGesture = null;
}

function commitPreview() {
  if (!previewState || !previewState.position) {
    showToast('Сначала выберите точку на плоскости');
    return;
  }
  updatePreviewVelocity();
  if (previewState.invalidOrbit) {
    placementGesture = null;
    showToast('Орбита должна находиться выше поверхности выбранного тела');
    return;
  }
  const data = previewState.draft;
  const p = previewState.body.p.slice();
  const v = previewState.body.v.slice();
  const placementNumber = previewState.placedCount + 1;
  const objectName = placementNumber === 1 ? data.name : data.name + ' ' + placementNumber;
  const body = makeBody(nextBodyId, objectName, data.mass, data.radiusKm, data.density, p, v, data.bodyType, data.temperatureK);
  nextBodyId += 1;
  addBody(body);
  selectBody(body, false);
  cameraState.followBodyId = data.multiCreate ? null : body.id;
  sceneHint.style.opacity = '0';

  if (data.multiCreate) {
    previewState.placedCount = placementNumber;
    resetPreviewForNextPlacement();
    placementTitle.textContent = 'МНОЖЕСТВЕННОЕ СОЗДАНИЕ · ' + placementNumber;
    placementInstructions.textContent = 'Установлено: ' + placementNumber + '. Выберите следующую точку; параметры сохраняются. Нажмите «Отмена», чтобы закончить.';
    showToast('Установлено тел: ' + placementNumber + ' · выберите следующую позицию');
  } else {
    destroyPreviewObjects();
    showToast('Объект добавлен · прогнозная траектория рассчитана');
  }
}

function pickBody(clientX, clientY) {
  const rect = renderer.domElement.getBoundingClientRect();
  pointerNdc.x = ((clientX - rect.left) / rect.width) * 2 - 1;
  pointerNdc.y = -((clientY - rect.top) / rect.height) * 2 + 1;
  raycaster.setFromCamera(pointerNdc, camera);
  const meshes = bodies.map(function (body) { return body.mesh; }).filter(Boolean);
  const hits = raycaster.intersectObjects(meshes, false);
  if (hits.length > 0) {
    const id = hits[0].object.userData.bodyId;
    const body = bodies.find(function (item) { return item.id === id; });
    if (body) selectBody(body, false);
  }
}

function panCamera(deltaX, deltaY) {
  const viewDirection = new THREE.Vector3().subVectors(cameraState.target, camera.position).normalize();
  const right = new THREE.Vector3().crossVectors(viewDirection, camera.up).normalize();
  const up = camera.up.clone().normalize();
  const factor = cameraState.distance / Math.max(400, window.innerHeight) * 1.6;
  cameraState.target.addScaledVector(right, -deltaX * factor);
  cameraState.target.addScaledVector(up, deltaY * factor);
}

function getPinchMetrics() {
  const entries = Array.from(pointerMap.values());
  if (entries.length < 2) return null;
  const a = entries[0];
  const b = entries[1];
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  return {
    distance: Math.sqrt(dx * dx + dy * dy),
    angle: Math.atan2(dy, dx),
    centerX: (a.x + b.x) * 0.5,
    centerY: (a.y + b.y) * 0.5
  };
}

renderer.domElement.addEventListener('contextmenu', function (event) { event.preventDefault(); });
renderer.domElement.addEventListener('pointerdown', function (event) {
  event.preventDefault();
  renderer.domElement.setPointerCapture(event.pointerId);
  pointerMap.set(event.pointerId, { x: event.clientX, y: event.clientY, lastX: event.clientX, lastY: event.clientY, startX: event.clientX, startY: event.clientY, moved: false, mode: event.button === 2 ? 'pan' : 'rotate' });

  if (previewState) {
    if (placementGesture) return;
    const point = getGroundPoint(event.clientX, event.clientY, new THREE.Vector3());
    if (point) {
      placementGesture = { pointerId: event.pointerId, anchor: point.clone(), startX: event.clientX, startY: event.clientY };
      setPreviewPosition(point);
      if (!previewState.draft.autoOrbit) previewState.direction = null;
      previewNeedsPrediction = true;
    }
    return;
  }

  if (pointerMap.size >= 2) {
    multiGesture = getPinchMetrics();
  }
}, { passive: false });

renderer.domElement.addEventListener('pointermove', function (event) {
  if (pointerMap.has(event.pointerId)) {
    const pointer = pointerMap.get(event.pointerId);
    pointer.lastX = pointer.x;
    pointer.lastY = pointer.y;
    pointer.x = event.clientX;
    pointer.y = event.clientY;
    if (Math.abs(pointer.x - pointer.startX) + Math.abs(pointer.y - pointer.startY) > 5) pointer.moved = true;
  }

  if (previewState) {
    if (placementGesture && placementGesture.pointerId === event.pointerId) {
      const deltaX = event.clientX - placementGesture.startX;
      const deltaY = event.clientY - placementGesture.startY;
      const dir = screenDragDirection(deltaX, deltaY);
      if (!previewState.draft.autoOrbit && dir && Math.sqrt(deltaX * deltaX + deltaY * deltaY) > 8) previewState.direction = dir;
      setPreviewPosition(placementGesture.anchor);
      previewNeedsPrediction = true;
    } else if (!placementGesture) {
      const point = getGroundPoint(event.clientX, event.clientY, new THREE.Vector3());
      if (point) setPreviewPosition(point);
    }
    return;
  }

  if (pointerMap.size >= 2) {
    const metrics = getPinchMetrics();
    if (metrics && multiGesture) {
      if (metrics.distance > 1 && multiGesture.distance > 1) {
        if (surfaceMode) {
          surfaceMode.altitudeM *= multiGesture.distance / metrics.distance;
          const activeBody = bodies.find(function (item) { return item.id === surfaceMode.bodyId; });
          if (activeBody) surfaceMode.altitudeM = Math.max(2, Math.min(activeBody.radiusM * 2, surfaceMode.altitudeM));
        } else {
          cameraState.distance *= multiGesture.distance / metrics.distance;
          cameraState.distance = Math.max(0.00001, Math.min(12000, cameraState.distance));
        }
      }
      let angleDelta = metrics.angle - multiGesture.angle;
      while (angleDelta > Math.PI) angleDelta -= Math.PI * 2;
      while (angleDelta < -Math.PI) angleDelta += Math.PI * 2;
      if (surfaceMode) surfaceMode.heading += angleDelta;
      else {
        cameraState.roll += angleDelta;
        panCamera(metrics.centerX - multiGesture.centerX, metrics.centerY - multiGesture.centerY);
      }
    }
    multiGesture = metrics;
  } else if (pointerMap.has(event.pointerId)) {
    const pointer = pointerMap.get(event.pointerId);
    const dx = event.clientX - pointer.lastX;
    const dy = event.clientY - pointer.lastY;
    if (surfaceMode) {
      surfaceMode.heading -= dx * 0.006;
      surfaceMode.lookPitch = Math.max(-1.2, Math.min(0.72, surfaceMode.lookPitch + dy * 0.005));
    } else if (pointer.mode === 'pan') {
      panCamera(dx, dy);
    } else if (event.shiftKey || event.altKey) {
      cameraState.roll += dx * 0.006;
    } else {
      cameraState.yaw -= dx * 0.006;
      cameraState.pitch += dy * 0.006;
      cameraState.pitch = Math.max(-1.48, Math.min(1.48, cameraState.pitch));
    }
  }
}, { passive: false });

renderer.domElement.addEventListener('pointerup', function (event) {
  const pointer = pointerMap.get(event.pointerId);
  if (previewState && placementGesture && placementGesture.pointerId === event.pointerId) {
    const deltaX = event.clientX - placementGesture.startX;
    const deltaY = event.clientY - placementGesture.startY;
    const direction = screenDragDirection(deltaX, deltaY);
    if (!previewState.draft.autoOrbit && direction && Math.sqrt(deltaX * deltaX + deltaY * deltaY) > 8) previewState.direction = direction;
    commitPreview();
  } else if (pointer && !pointer.moved && !previewState && !surfaceMode) {
    pickBody(event.clientX, event.clientY);
  }
  pointerMap.delete(event.pointerId);
  multiGesture = getPinchMetrics();
}, { passive: false });

renderer.domElement.addEventListener('pointercancel', function (event) {
  pointerMap.delete(event.pointerId);
  if (placementGesture && placementGesture.pointerId === event.pointerId) placementGesture = null;
  multiGesture = getPinchMetrics();
});

renderer.domElement.addEventListener('wheel', function (event) {
  event.preventDefault();
  if (surfaceMode) {
    const body = bodies.find(function (item) { return item.id === surfaceMode.bodyId; });
    surfaceMode.altitudeM *= Math.exp(event.deltaY * 0.0011);
    if (body) surfaceMode.altitudeM = Math.max(2, Math.min(body.radiusM * 2, surfaceMode.altitudeM));
  } else {
    cameraState.distance *= Math.exp(event.deltaY * 0.0011);
    cameraState.distance = Math.max(0.00001, Math.min(12000, cameraState.distance));
  }
}, { passive: false });

function parseNumericInput(id) {
  const raw = $(id).value.trim().replace(',', '.').replace(/\s+/g, '');
  if (!raw) return NaN;
  return Number(raw);
}

function getLinearUnitFactor(kind) {
  if (kind === 'mass') return UNIT_FACTORS.mass[massUnitSelect.value];
  if (kind === 'radius') return UNIT_FACTORS.radius[radiusUnitSelect.value];
  if (kind === 'density') return UNIT_FACTORS.density[densityUnitSelect.value];
  if (kind === 'speed') return UNIT_FACTORS.speed[speedUnitSelect.value];
  return 1;
}

function getUnitSelector(kind) {
  if (kind === 'mass') return massUnitSelect;
  if (kind === 'radius') return radiusUnitSelect;
  if (kind === 'density') return densityUnitSelect;
  if (kind === 'speed') return speedUnitSelect;
  return null;
}

function parseInputInBase(id, kind) {
  const value = parseNumericInput(id);
  const selector = getUnitSelector(kind);
  const factors = UNIT_FACTORS[kind];
  if (!selector || !Number.isFinite(value) || !factors) return NaN;
  return valueToBaseUnits(value, factors, selector.value);
}

function bindLinearUnitSelector(inputId, select, factors) {
  let previousUnit = select.value;
  select.addEventListener('change', function () {
    const currentValue = parseNumericInput(inputId);
    const nextUnit = select.value;
    if (Number.isFinite(currentValue) && Number.isFinite(factors[previousUnit]) && Number.isFinite(factors[nextUnit]) && factors[nextUnit] > 0) {
      $(inputId).value = formatInputNumber(convertUnitValue(currentValue, factors, previousUnit, nextUnit));
    }
    previousUnit = nextUnit;
  });
}

function bindTemperatureUnitSelector() {
  let previousUnit = starTempUnitSelect.value;
  starTempUnitSelect.addEventListener('change', function () {
    const value = parseNumericInput('starTempInput');
    const nextUnit = starTempUnitSelect.value;
    if (Number.isFinite(value)) {
      const kelvin = previousUnit === 'C' ? value + 273.15 : value;
      starTempInput.value = formatInputNumber(nextUnit === 'C' ? kelvin - 273.15 : kelvin);
    }
    previousUnit = nextUnit;
  });
}

function parseTemperatureKelvin() {
  const value = parseNumericInput('starTempInput');
  if (!Number.isFinite(value)) return NaN;
  return starTempUnitSelect.value === 'C' ? value + 273.15 : value;
}

function formatBaseValueInInput(value, kind) {
  const selector = getUnitSelector(kind);
  if (!selector) return '';
  return formatInputNumber(valueFromBaseUnits(value, UNIT_FACTORS[kind], selector.value));
}

bindLinearUnitSelector('massInput', massUnitSelect, UNIT_FACTORS.mass);
bindLinearUnitSelector('radiusInput', radiusUnitSelect, UNIT_FACTORS.radius);
bindLinearUnitSelector('densityInput', densityUnitSelect, UNIT_FACTORS.density);
bindLinearUnitSelector('speedInput', speedUnitSelect, UNIT_FACTORS.speed);
bindLinearUnitSelector('dtInput', dtUnitSelect, UNIT_FACTORS.time);
bindLinearUnitSelector('rateInput', rateUnitSelect, UNIT_FACTORS.time);
bindTemperatureUnitSelector();

function bindDetailUnitSelector(inputId, selectId, factors) {
  const select = $(selectId);
  let previousUnit = select.value;
  select.addEventListener('change', function () {
    const value = parseNumericInput(inputId);
    const nextUnit = select.value;
    if (Number.isFinite(value) && factors[previousUnit] > 0 && factors[nextUnit] > 0) {
      $(inputId).value = formatInputNumber(convertUnitValue(value, factors, previousUnit, nextUnit));
    }
    previousUnit = nextUnit;
  });
}

bindDetailUnitSelector('bodyEditMass', 'bodyEditMassUnit', UNIT_FACTORS.mass);
bindDetailUnitSelector('bodyEditRadius', 'bodyEditRadiusUnit', UNIT_FACTORS.radius);
bindDetailUnitSelector('bodyEditDensity', 'bodyEditDensityUnit', UNIT_FACTORS.density);
$('bodyEditTemperatureUnit').addEventListener('change', function () {
  const value = parseNumericInput('bodyEditTemperature');
  if (!Number.isFinite(value)) return;
  const wasCelsius = $('bodyEditTemperatureUnit').dataset.previousUnit === 'C';
  const isCelsius = $('bodyEditTemperatureUnit').value === 'C';
  const kelvin = wasCelsius ? value + 273.15 : value;
  $('bodyEditTemperature').value = formatInputNumber(isCelsius ? kelvin - 273.15 : kelvin);
  $('bodyEditTemperatureUnit').dataset.previousUnit = $('bodyEditTemperatureUnit').value;
});
$('bodyEditTemperatureUnit').dataset.previousUnit = 'K';
$('bodyEditMass').addEventListener('change', function () { detailLastChanged = 'mass'; syncBodyDetailsDerived('mass'); });
$('bodyEditRadius').addEventListener('change', function () { detailLastChanged = 'radius'; syncBodyDetailsDerived('radius'); });
$('bodyEditDensity').addEventListener('change', function () { detailLastChanged = 'density'; syncBodyDetailsDerived('density'); });

function calculateDensity(mass, radiusKm) {
  const radiusM = radiusKm * 1000;
  const volume = (4 / 3) * Math.PI * radiusM * radiusM * radiusM;
  return mass / volume;
}

function calculateMass(radiusKm, density) {
  const radiusM = radiusKm * 1000;
  const volume = (4 / 3) * Math.PI * radiusM * radiusM * radiusM;
  return density * volume;
}

function calculateRadiusKm(mass, density) {
  return Math.cbrt((3 * mass) / (4 * Math.PI * density)) / 1000;
}

function formatInputNumber(value) {
  if (!Number.isFinite(value)) return '';
  return Number(value.toPrecision(8)).toString();
}

function setValidation(message) {
  validationBox.textContent = message;
  validationBox.hidden = !message;
}

function hideCorrection() {
  correctionBox.hidden = true;
  correctionOptions.innerHTML = '';
}

function startFromForm(values) {
  const name = $('bodyName').value.trim() || ('Объект ' + nextBodyId);
  const draft = {
    name: name,
    mass: values.mass,
    radiusKm: values.radiusKm,
    density: values.density,
    speedKms: values.speedKms,
    autoOrbit: values.autoOrbit,
    orbitTargetId: values.orbitTargetId,
    multiCreate: values.multiCreate,
    bodyType: values.bodyType,
    temperatureK: values.temperatureK
  };
  setValidation('');
  hideCorrection();
  beginPlacement(draft);
}

function correctionButton(target, values) {
  let newValue;
  let label;
  let symbol;
  if (target === 'mass') {
    newValue = calculateMass(values.radiusKm, values.density);
    label = 'Пересчитать массу';
    symbol = 'm ← ρ, r';
  } else if (target === 'radiusKm') {
    newValue = calculateRadiusKm(values.mass, values.density);
    label = 'Пересчитать радиус';
    symbol = 'r ← m, ρ';
  } else {
    newValue = calculateDensity(values.mass, values.radiusKm);
    label = 'Пересчитать плотность';
    symbol = 'ρ ← m, r';
  }
  const maxValue = target === 'mass' ? 1e36 : (target === 'radiusKm' ? 1e10 : 1e15);
  if (!Number.isFinite(newValue) || newValue <= 0 || newValue > maxValue) {
    setValidation('Автоматически вычисленное значение выходит за допустимый диапазон. Измените исходные параметры.');
    return;
  }
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'correction-option';
  const labelSpan = document.createElement('span');
  labelSpan.textContent = label;
  const formulaSpan = document.createElement('span');
  formulaSpan.textContent = symbol;
  button.appendChild(labelSpan);
  button.appendChild(formulaSpan);
  button.addEventListener('click', function () {
    values[target] = newValue;
    const inputId = target === 'radiusKm' ? 'radiusInput' : (target === 'mass' ? 'massInput' : 'densityInput');
    const unitKind = target === 'radiusKm' ? 'radius' : target;
    $(inputId).value = formatBaseValueInInput(newValue, unitKind);
    startFromForm(values);
  });
  correctionOptions.appendChild(button);
}

function validateAndCreate() {
  hideCorrection();
  setValidation('');
  const bodyType = bodyTypeSelect.value;
  const values = {
    mass: parseInputInBase('massInput', 'mass'),
    radiusKm: parseInputInBase('radiusInput', 'radius'),
    density: parseInputInBase('densityInput', 'density'),
    speedKms: parseInputInBase('speedInput', 'speed'),
    bodyType: bodyType,
    temperatureK: bodyType === 'star' ? parseTemperatureKelvin() : 0,
    autoOrbit: autoOrbitInput.checked,
    orbitTargetId: Number(orbitTargetSelect.value),
    multiCreate: $('multiCreateInput').checked
  };
  const validMass = Number.isFinite(values.mass) && values.mass > 0 && values.mass <= 1e36;
  const validRadius = Number.isFinite(values.radiusKm) && values.radiusKm > 0 && values.radiusKm <= 1e10;
  const validDensity = Number.isFinite(values.density) && values.density > 0 && values.density <= 1e15;
  const validSpeed = values.autoOrbit || (Number.isFinite(values.speedKms) && values.speedKms >= 0 && values.speedKms <= 1e6);
  if (!validSpeed) {
    setValidation('Скорость должна быть неотрицательным конечным числом в выбранных единицах.');
    return;
  }
  if (bodyType === 'star' && (!Number.isFinite(values.temperatureK) || values.temperatureK < 1000 || values.temperatureK > 50000)) {
    setValidation('Эффективная температура звезды должна находиться в диапазоне 1000–50 000 K. Для зон Коппарапу поддерживается 2600–7200 K.');
    return;
  }
  if (values.autoOrbit && !bodies.some(function (body) { return body.id === values.orbitTargetId && !body.isDebris; })) {
    setValidation('Выберите существующее тело, вокруг которого будет рассчитана орбита.');
    return;
  }
  if (values.autoOrbit && !Number.isFinite(values.speedKms)) values.speedKms = 0;
  const invalidCount = (validMass ? 0 : 1) + (validRadius ? 0 : 1) + (validDensity ? 0 : 1);
  if (invalidCount > 1) {
    setValidation('Некорректны два или три физических параметра. Для автоматического пересчёта оставьте корректными любые два из трёх.');
    return;
  }
  if (invalidCount === 1) {
    correctionBox.hidden = false;
    const title = correctionBox.querySelector('.correction-title');
    title.textContent = 'Одно значение некорректно. Пересчитать его по двум остальным?';
    if (!validMass) correctionButton('mass', values);
    if (!validRadius) correctionButton('radiusKm', values);
    if (!validDensity) correctionButton('density', values);
    return;
  }

  const expectedDensity = calculateDensity(values.mass, values.radiusKm);
  const relativeError = Math.abs(values.density - expectedDensity) / Math.max(values.density, expectedDensity);
  if (relativeError > 0.02) {
    correctionBox.hidden = false;
    correctionBox.querySelector('.correction-title').textContent = 'Параметры не согласованы (' + (relativeError * 100).toFixed(1) + '%). Что сохранить, а что пересчитать?';
    correctionButton('mass', values);
    correctionButton('radiusKm', values);
    correctionButton('density', values);
    return;
  }
  startFromForm(values);
}

function updateBodyTypeControls(resetValues) {
  const isStar = bodyTypeSelect.value === 'star';
  starOptions.hidden = !isStar;
  if (!resetValues) return;
  if (isStar) {
    $('bodyName').value = 'Новая звезда';
    $('massInput').value = formatBaseValueInInput(SOLAR_MASS_KG, 'mass');
    $('radiusInput').value = formatBaseValueInInput(SOLAR_RADIUS_KM, 'radius');
    $('densityInput').value = formatBaseValueInInput(1408, 'density');
    $('speedInput').value = formatBaseValueInInput(0, 'speed');
    starTempInput.value = starTempUnitSelect.value === 'C' ? formatInputNumber(SOLAR_TEMPERATURE_K - 273.15) : String(SOLAR_TEMPERATURE_K);
  } else {
    $('bodyName').value = 'Новая планета';
    $('massInput').value = formatBaseValueInInput(EARTH_MASS_KG, 'mass');
    $('radiusInput').value = formatBaseValueInInput(EARTH_RADIUS_KM, 'radius');
    $('densityInput').value = formatBaseValueInInput(5514, 'density');
    $('speedInput').value = formatBaseValueInInput(29.78, 'speed');
  }
}

function populateOrbitTargets() {
  const previousValue = orbitTargetSelect.value;
  orbitTargetSelect.innerHTML = '';
  const candidates = bodies.filter(function (body) { return !body.isDebris; });
  if (candidates.length === 0) {
    const option = document.createElement('option');
    option.value = '';
    option.textContent = 'Сначала добавьте тело';
    orbitTargetSelect.appendChild(option);
  } else {
    candidates.forEach(function (body) {
      const option = document.createElement('option');
      option.value = String(body.id);
      option.textContent = body.name + ' · ' + formatMass(body.mass) + ' кг';
      orbitTargetSelect.appendChild(option);
    });
    const desired = selectedBody && !selectedBody.isDebris ? selectedBody.id : candidates.reduce(function (best, body) {
      return body.mass > best.mass ? body : best;
    }, candidates[0]).id;
    const previousExists = candidates.some(function (body) { return String(body.id) === previousValue; });
    orbitTargetSelect.value = previousExists ? previousValue : String(desired);
  }
  autoOrbitInput.disabled = candidates.length === 0;
  updateAutoOrbitControls();
}

function updateAutoOrbitControls() {
  const enabled = autoOrbitInput.checked && !autoOrbitInput.disabled;
  orbitTargetSelect.disabled = !enabled;
  speedInput.disabled = enabled;
  speedUnitSelect.disabled = enabled;
  orbitHelp.textContent = enabled ? 'При выборе точки рассчитается круговая скорость относительно центрального тела.' : 'Автоматически задаёт круговую скорость после выбора позиции на плоскости.';
}

function openCreateModal() {
  if (previewState) cancelPlacement();
  if (surfaceMode) exitSurfaceMode();
  bodyDetailsPanel.hidden = true;
  objectPanel.hidden = true;
  setValidation('');
  hideCorrection();
  populateOrbitTargets();
  createModal.hidden = false;
  setTimeout(function () { $('bodyName').focus(); }, 50);
}

$('addOpen').addEventListener('click', openCreateModal);
$('createClose').addEventListener('click', function () { createModal.hidden = true; });
$('createCancel').addEventListener('click', function () { createModal.hidden = true; });
$('createSubmit').addEventListener('click', validateAndCreate);
autoOrbitInput.addEventListener('change', updateAutoOrbitControls);
orbitTargetSelect.addEventListener('change', updateAutoOrbitControls);
bodyTypeSelect.addEventListener('change', function () { updateBodyTypeControls(true); });
hzToggleInput.addEventListener('change', function () {
  setHabitableZonesVisible(hzToggleInput.checked);
  const supportedStars = bodies.filter(function (body) { return body.isStar && getKopparapuBoundaries(body); }).length;
  if (hzToggleInput.checked && supportedStars === 0) showToast('Добавьте звезду с температурой 2600–7200 K, чтобы увидеть зоны Коппарапу.');
});
$('objectsToggle').addEventListener('click', function () { objectPanel.hidden = !objectPanel.hidden; });
$('objectsClose').addEventListener('click', function () { objectPanel.hidden = true; });
$('bodyDetailsClose').addEventListener('click', function () { bodyDetailsPanel.hidden = true; });
$('bodyEditSave').addEventListener('click', saveBodyDetails);
$('bodyLanding').addEventListener('click', function () {
  const body = bodies.find(function (item) { return item.id === detailsEditingBodyId; });
  enterSurfaceMode('landing', body);
});
$('bodyFlight').addEventListener('click', function () {
  const body = bodies.find(function (item) { return item.id === detailsEditingBodyId; });
  enterSurfaceMode('flight', body);
});
$('surfaceExit').addEventListener('click', exitSurfaceMode);
Array.prototype.forEach.call(surfaceOverlay.querySelectorAll('[data-surface-key]'), function (button) {
  const key = button.getAttribute('data-surface-key');
  button.addEventListener('pointerdown', function (event) {
    event.preventDefault();
    surfaceKeys[key] = true;
    if (button.setPointerCapture) button.setPointerCapture(event.pointerId);
  });
  function releaseKey(event) {
    event.preventDefault();
    surfaceKeys[key] = false;
  }
  button.addEventListener('pointerup', releaseKey);
  button.addEventListener('pointercancel', releaseKey);
  button.addEventListener('lostpointercapture', function () { surfaceKeys[key] = false; });
});
$('cancelPlacement').addEventListener('click', cancelPlacement);
$('focusSelected').addEventListener('click', focusSystem);
$('centerView').addEventListener('click', focusSystem);
$('resetCamera').addEventListener('click', function () {
  if (surfaceMode) exitSurfaceMode();
  cameraState.yaw = 0.82;
  cameraState.pitch = 0.68;
  cameraState.roll = 0;
  cameraState.distance = bodies.length > 0 ? 420 : 300;
  cameraState.followBodyId = null;
  if (bodies.length > 0) focusSystem();
  showToast('Камера сброшена');
});
$('clearSystem').addEventListener('click', function () {
  if (surfaceMode) exitSurfaceMode();
  bodyDetailsPanel.hidden = true;
  detailsEditingBodyId = null;
  bodies.slice().forEach(removeBodyVisual);
  bodies.length = 0;
  selectedBody = null;
  clearSelectionRing();
  cameraState.followBodyId = null;
  selectionTag.hidden = true;
  simulationSeconds = 0;
  accumulator = 0;
  updateAccelerations(bodies);
  refreshObjectList();
  showToast('Система очищена');
});

function loadDemoSystem() {
  if (surfaceMode) exitSurfaceMode();
  bodyDetailsPanel.hidden = true;
  detailsEditingBodyId = null;
  bodies.slice().forEach(removeBodyVisual);
  bodies.length = 0;
  selectedBody = null;
  clearSelectionRing();
  selectionTag.hidden = true;
  simulationSeconds = 0;
  accumulator = 0;
  const sunMass = 1.9885e30;
  const earthMass = 5.9722e24;
  const relativeSpeed = Math.sqrt(G * (sunMass + earthMass) / AU);
  const totalMass = sunMass + earthMass;
  const sunPosition = -earthMass / totalMass * AU;
  const earthPosition = sunMass / totalMass * AU;
  const sunVelocity = -earthMass / totalMass * relativeSpeed;
  const earthVelocity = sunMass / totalMass * relativeSpeed;
  const sun = makeBody(nextBodyId, 'Солнце', sunMass, 696340, 1408, [sunPosition, 0, 0], [0, 0, sunVelocity], 'star', 5778);
  nextBodyId += 1;
  const earth = makeBody(nextBodyId, 'Земля', earthMass, 6371, 5514, [earthPosition, 0, 0], [0, 0, earthVelocity]);
  nextBodyId += 1;
  bodies.push(sun, earth);
  updateAccelerations(bodies);
  addBodyVisual(sun);
  addBodyVisual(earth);
  cameraState.target.set(0, 0, 0);
  cameraState.distance = 420;
  cameraState.followBodyId = null;
  refreshObjectList();
  objectPanel.hidden = true;
  sceneHint.style.opacity = '0';
  showToast('Загружена демонстрационная система · 2 тела');
}
$('loadDemo').addEventListener('click', loadDemoSystem);
$('playToggle').addEventListener('click', function () {
  running = !running;
  $('playIcon').innerHTML = running ? '<path d="M8 5v14M16 5v14"/>' : '<path d="m8 5 11 7-11 7z"/>';
  $('playToggle').title = running ? 'Пауза' : 'Продолжить';
  liveDot.classList.toggle('paused', !running);
  showToast(running ? 'Симуляция запущена' : 'Симуляция на паузе');
});

dtInput.addEventListener('change', function () {
  const value = parseNumericInput('dtInput');
  const stepDays = value * UNIT_FACTORS.time[dtUnitSelect.value];
  const stepSeconds = stepDays * DAY;
  if (Number.isFinite(value) && value > 0 && Number.isFinite(stepSeconds) && stepSeconds > 0) {
    dtDays = stepDays;
    dtInput.value = formatInputNumber(value);
  } else {
    dtInput.value = formatInputNumber(dtDays / UNIT_FACTORS.time[dtUnitSelect.value]);
    showToast('Шаг dt должен быть положительным конечным числом.');
  }
});
rateInput.addEventListener('change', function () {
  const value = parseNumericInput('rateInput');
  const rateDays = value * UNIT_FACTORS.time[rateUnitSelect.value];
  const rateSeconds = rateDays * DAY;
  if (Number.isFinite(value) && value > 0 && Number.isFinite(rateSeconds) && rateSeconds > 0) {
    rateDaysPerSecond = rateDays;
    rateInput.value = formatInputNumber(value);
  } else {
    rateInput.value = formatInputNumber(rateDaysPerSecond / UNIT_FACTORS.time[rateUnitSelect.value]);
    showToast('Скорость должна быть положительным конечным числом.');
  }
});

document.addEventListener('keydown', function (event) {
  if (surfaceMode) {
    const keyMap = { KeyW: 'forward', ArrowUp: 'forward', KeyS: 'backward', ArrowDown: 'backward', KeyA: 'left', ArrowLeft: 'left', KeyD: 'right', ArrowRight: 'right', KeyE: 'ascend', PageUp: 'ascend', KeyQ: 'descend', PageDown: 'descend' };
    if (keyMap[event.code]) {
      event.preventDefault();
      surfaceKeys[keyMap[event.code]] = true;
    }
  }
  if (event.key === 'Escape') {
    if (surfaceMode) exitSurfaceMode();
    else if (!createModal.hidden) createModal.hidden = true;
    else if (previewState) cancelPlacement();
    else if (!bodyDetailsPanel.hidden) bodyDetailsPanel.hidden = true;
    else objectPanel.hidden = true;
  }
  if (event.code === 'Space' && createModal.hidden && !previewState) {
    event.preventDefault();
    $('playToggle').click();
  }
});
document.addEventListener('keyup', function (event) {
  const keyMap = { KeyW: 'forward', ArrowUp: 'forward', KeyS: 'backward', ArrowDown: 'backward', KeyA: 'left', ArrowLeft: 'left', KeyD: 'right', ArrowRight: 'right', KeyE: 'ascend', PageUp: 'ascend', KeyQ: 'descend', PageDown: 'descend' };
  if (keyMap[event.code]) surfaceKeys[keyMap[event.code]] = false;
});
window.addEventListener('blur', function () {
  Object.keys(surfaceKeys).forEach(function (key) { surfaceKeys[key] = false; });
});

function updateBodyLabels() {
  const width = window.innerWidth;
  const height = window.innerHeight;
  bodies.forEach(function (body) {
    if (!body.label || !body.mesh) return;
    const pos = body.mesh.position.clone();
    pos.y += body.visualRadius * 1.45;
    pos.project(camera);
    if (pos.z < -1 || pos.z > 1 || Math.abs(pos.x) > 1.15 || Math.abs(pos.y) > 1.15) {
      body.label.style.display = 'none';
    } else {
      body.label.style.display = 'block';
      body.label.style.left = ((pos.x * 0.5 + 0.5) * width) + 'px';
      body.label.style.top = ((-pos.y * 0.5 + 0.5) * height) + 'px';
      body.label.style.transform = 'translate(-50%, -50%)';
      body.label.classList.toggle('selected', Boolean(selectedBody && selectedBody.id === body.id));
    }
  });
}

function updateVisualPositions() {
  bodies.forEach(function (body) {
    const position = scenePosition(body);
    if (body.mesh) body.mesh.position.copy(position);
    if (body.starLight) body.starLight.position.copy(position);
    if (body.hzGroup) body.hzGroup.position.copy(position);
    if (body.label) body.label.textContent = body.name;
  });
  if (selectedRing && selectedBody) selectedRing.position.copy(scenePosition(selectedBody));
  if (previewState && previewMesh && previewState.position) previewMesh.position.copy(previewState.position);
}

function recordTrails() {
  bodies.forEach(function (body) {
    if (simulationSeconds >= body.nextTrailTime) {
      body.history.push([body.p[0], body.p[1], body.p[2]]);
      if (body.history.length > 650) body.history.shift();
      body.nextTrailTime += DAY * 0.35;
      updateTrailGeometry(body);
    }
  });
}

function updateClimateReadouts(now) {
  if (now - lastClimateUpdate < 350) return;
  lastClimateUpdate = now;
  bodies.forEach(function (body) {
    if (body.listMeta && !body.isStar && !body.isDebris) {
      const base = formatMass(body.mass) + ' кг  ·  r ' + formatCompact(body.radiusKm) + ' км';
      body.listMeta.textContent = base + ' · ' + getPlanetClimateDescription(body);
    }
  });
}

function updateTimeReadout() {
  const days = simulationSeconds / DAY;
  const formatted = days.toFixed(3);
  simTime.textContent = 'T + ' + formatted + ' d';
  timeValue.innerHTML = formatted + ' <small>дней</small>';
}

function animate(now) {
  requestAnimationFrame(animate);
  const elapsed = Math.max(0, (now - lastFrameTime) / 1000);
  lastFrameTime = now;
  if (running && bodies.length > 0) {
    const stepSeconds = dtDays * DAY;
    accumulator += elapsed * rateDaysPerSecond * DAY;
    let steps = 0;
    const processingDeadline = performance.now() + 8;
    while (accumulator >= stepSeconds && performance.now() < processingDeadline) {
      const previousPositions = bodies.map(function (body) { return body.p.slice(); });
      const previousVelocities = bodies.map(function (body) { return body.v.slice(); });
      velocityVerletStep(bodies, stepSeconds);
      simulationSeconds += stepSeconds;
      const collision = findSweptCollision(bodies, previousPositions);
      if (collision) applyCollision(collision, previousPositions, previousVelocities);
      processDebrisLifecycle();
      accumulator -= stepSeconds;
      steps += 1;
    }
    /* Never discard accumulated model time: if computation falls behind, it is retained. */
    if (steps > 0) recordTrails();
  }

  if (surfaceMode) updateSurfaceModeMotion(Math.min(elapsed, 0.08));
  if (!surfaceMode && cameraState.followBodyId !== null) {
    const following = bodies.find(function (body) { return body.id === cameraState.followBodyId; });
    if (following) cameraState.target.lerp(scenePosition(following), 0.24);
    else cameraState.followBodyId = null;
  }
  updateCamera();
  if (previewNeedsPrediction && previewState) updatePreviewPrediction(false);
  updateVisualPositions();
  updateBodyLabels();
  updateGridDistanceLabels();
  updateTimeReadout();
  updateClimateReadouts(now);
  composer.render();
}
requestAnimationFrame(animate);

window.addEventListener('resize', function () {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.8));
  composer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.4));
  renderer.setSize(window.innerWidth, window.innerHeight);
  composer.setSize(window.innerWidth, window.innerHeight);
});

refreshObjectList();
