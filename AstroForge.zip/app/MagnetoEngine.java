package com.astroforge;

import java.util.ArrayList;
import java.util.List;

/**
 * Java-обертка над C++ движком magneto_core.
 *
 * Пакет синхронизирован с проектом AstroForge: com.astroforge.
 *
 * Режимы:
 * 1. direct(...)    - мгновенный расчёт магнитного поля.
 * 2. simulate(...)  - эволюция поля по годам + события по scaling law.
 */
public final class MagnetoEngine {

    public static final String LIBRARY_NAME = "magneto_core";

    public static final int DIRECT_RESULT_SIZE = 7;
    public static final int SIM_POINT_STRIDE = 7;

    public static final class MagnetoException extends RuntimeException {
        public MagnetoException(String message) {
            super(message);
        }

        public MagnetoException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    /**
     * Физические параметры объекта.
     *
     * massKg              Масса объекта, кг.
     * radiusM             Радиус объекта, м.
     * coreRadiusM         Радиус ядра/динамо-области, м.
     * densityKgM3         Плотность проводящей среды, кг/м^3.
     * heatFluxWm2         Конвективный тепловой поток, Вт/м^2.
     * rotationPeriodHours Период вращения в часах. Может быть 0.
     * dipoleFraction      Доля дипольности, 0..1.
     * calibrationFactor   Калибровочный коэффициент закона Кристенсена.
     */
    public record PlanetParams(
		double massKg,
		double radiusM,
		double coreRadiusM,
		double densityKgM3,
		double heatFluxWm2,
		double rotationPeriodHours,
		double dipoleFraction,
		double calibrationFactor
    ) {
	public PlanetParams {
		if (!Double.isFinite(massKg) || massKg <= 0.0) {
			throw new MagnetoException("massKg должен быть положительным конечным числом.");
		}

		if (!Double.isFinite(radiusM) || radiusM <= 0.0) {
			throw new MagnetoException("radiusM должен быть положительным конечным числом.");
		}

		if (!Double.isFinite(coreRadiusM) || coreRadiusM <= 0.0) {
			throw new MagnetoException("coreRadiusM должен быть положительным конечным числом.");
		}

		if (coreRadiusM >= radiusM) {
			throw new MagnetoException("coreRadiusM должен быть меньше radiusM.");
		}

		if (!Double.isFinite(densityKgM3) || densityKgM3 <= 0.0) {
			throw new MagnetoException("densityKgM3 должен быть положительным конечным числом.");
		}

		if (!Double.isFinite(heatFluxWm2) || heatFluxWm2 < 0.0) {
			throw new MagnetoException("heatFluxWm2 должен быть неотрицательным конечным числом.");
		}

		if (!Double.isFinite(rotationPeriodHours) || rotationPeriodHours < 0.0) {
			throw new MagnetoException("rotationPeriodHours должен быть неотрицательным конечным числом.");
		}

		if (!Double.isFinite(dipoleFraction) || dipoleFraction < 0.0 || dipoleFraction > 1.0) {
			throw new MagnetoException("dipoleFraction должен быть в диапазоне [0..1].");
		}

		if (!Double.isFinite(calibrationFactor) || calibrationFactor <= 0.0) {
			throw new MagnetoException("calibrationFactor должен быть положительным конечным числом.");
		}
	}
    }

    /**
     * Настройки симуляции.
     *
     * years               Длительность симуляции в годах.
     * steps               Количество точек времени.
     * seed                Seed для детерминированной генерации событий.
     * minHeatFluxWm2      Минимальный тепловой поток, Вт/м^2.
     * coolingTimeYears    Характерное время охлаждения, лет. 0 = без затухания.
     * eventRatePerYear    Средняя частота событий в год.
     * gamma               Показатель степенного закона ожидания.
     * dtMinYears          Минимальное время ожидания между событиями.
     * dtMaxYears          Максимальное время ожидания между событиями.
     * includeEvents       Генерировать ли события инверсий/джerkers.
     */
    public record SimulationConfig(
		double years,
		int steps,
		long seed,
		double minHeatFluxWm2,
		double coolingTimeYears,
		double eventRatePerYear,
		double gamma,
		double dtMinYears,
		double dtMaxYears,
		boolean includeEvents
    ) {
	public SimulationConfig {
		if (!Double.isFinite(years) || years <= 0.0) {
			throw new MagnetoException("years должен быть положительным конечным числом.");
		}

		if (steps <= 0) {
			throw new MagnetoException("steps должен быть больше нуля.");
		}

		if (!Double.isFinite(minHeatFluxWm2) || minHeatFluxWm2 < 0.0) {
			throw new MagnetoException("minHeatFluxWm2 должен быть неотрицательным конечным числом.");
		}

		if (!Double.isFinite(coolingTimeYears) || coolingTimeYears < 0.0) {
			throw new MagnetoException("coolingTimeYears должен быть неотрицательным конечным числом.");
		}

		if (!Double.isFinite(eventRatePerYear) || eventRatePerYear < 0.0) {
			throw new MagnetoException("eventRatePerYear должен быть неотрицательным конечным числом.");
		}

		if (!Double.isFinite(gamma) || gamma <= 0.0) {
			throw new MagnetoException("gamma должен быть положительным конечным числом.");
		}

		if (!Double.isFinite(dtMinYears) || dtMinYears <= 0.0) {
			throw new MagnetoException("dtMinYears должен быть положительным конечным числом.");
		}

		if (!Double.isFinite(dtMaxYears) || dtMaxYears < dtMinYears) {
			throw new MagnetoException("dtMaxYears должен быть больше или равен dtMinYears.");
		}
	}
    }

    /**
     * Результат прямого расчёта.
     */
    public record DirectResult(
		double coreFieldTesla,
		double surfaceFieldTesla,
		double dipoleMomentAm2,
		double dipoleFractionUsed,
		double energyFluxUsedWm2,
		double magneticEnergyDensityJm3,
		double magneticPressurePa
    ) {
	public double surfaceFieldGauss() {
		return surfaceFieldTesla * 1.0e4;
	}

	public double surfaceFieldMicroTesla() {
		return surfaceFieldTesla * 1.0e6;
	}

	public double surfaceFieldNanoTesla() {
		return surfaceFieldTesla * 1.0e9;
	}
    }

    /**
     * Одна точка симуляции.
     */
    public record SimulationPoint(
		double timeYears,
		double heatFluxWm2,
		double coreFieldTesla,
		double surfaceFieldTesla,
		double dipoleMomentAm2,
		double polarity,
		int cumulativeEvents
    ) {
    }

    /**
     * Результат симуляции.
     */
    public record SimulationResult(
		PlanetParams params,
		SimulationConfig config,
		List<SimulationPoint> points
    ) {
	public SimulationResult {
		if (params == null) {
			throw new MagnetoException("PlanetParams не может быть null.");
		}

		if (config == null) {
			throw new MagnetoException("SimulationConfig не может быть null.");
		}

		if (points == null) {
			throw new MagnetoException("Список точек симуляции не может быть null.");
		}

		points = List.copyOf(points);

		if (points.size() != config.steps()) {
			throw new MagnetoException(
				"Количество точек симуляции не совпадает с config.steps(): " +
				points.size() + " != " + config.steps()
			);
		}
	}

	public int pointCount() {
		return points.size();
	}

	public SimulationPoint first() {
		return points.get(0);
	}

	public SimulationPoint last() {
		return points.get(points.size() - 1);
	}
    }

    private static final UnsatisfiedLinkError NATIVE_LOAD_ERROR = loadNativeLibrary();

    private MagnetoEngine() {
        // Utility class.
    }

    private static UnsatisfiedLinkError loadNativeLibrary() {
        try {
            System.loadLibrary(LIBRARY_NAME);
            return null;
        } catch (UnsatisfiedLinkError error) {
            return error;
        }
    }

    public static boolean isNativeLoaded() {
        return NATIVE_LOAD_ERROR == null;
    }

    private static void ensureNativeLoaded() {
        if (NATIVE_LOAD_ERROR != null) {
            throw new MagnetoException(
				"Не удалось загрузить нативную библиотеку " + LIBRARY_NAME +
				". Убедись, что C++ движок собран в libmagneto_core.so и доступен приложению.",
				NATIVE_LOAD_ERROR
            );
        }
    }

    /**
     * Быстрый прямой расчёт магнитного поля.
     */
    public static DirectResult direct(PlanetParams params) {
        if (params == null) {
            throw new MagnetoException("PlanetParams не может быть null.");
        }

        ensureNativeLoaded();

        double[] raw = nativeDirect(
			params.massKg(),
			params.radiusM(),
			params.coreRadiusM(),
			params.densityKgM3(),
			params.heatFluxWm2(),
			params.rotationPeriodHours(),
			params.dipoleFraction(),
			params.calibrationFactor()
        );

        if (raw == null || raw.length != DIRECT_RESULT_SIZE) {
            throw new MagnetoException("Нативный движок вернул некорректный прямой результат.");
        }

        return new DirectResult(
			raw[0],
			raw[1],
			raw[2],
			raw[3],
			raw[4],
			raw[5],
			raw[6]
        );
    }

    /**
     * Симуляция магнитного поля на протяжении заданного числа лет.
     */
    public static SimulationResult simulate(PlanetParams params, SimulationConfig config) {
        if (params == null) {
            throw new MagnetoException("PlanetParams не может быть null.");
        }

        if (config == null) {
            throw new MagnetoException("SimulationConfig не может быть null.");
        }

        ensureNativeLoaded();

        long expectedLong = (long) config.steps() * SIM_POINT_STRIDE;
        if (expectedLong > Integer.MAX_VALUE) {
            throw new MagnetoException("Слишком много шагов симуляции для текущего буфера.");
        }

        int expectedLength = (int) expectedLong;

        double[] raw = nativeSimulate(
			params.massKg(),
			params.radiusM(),
			params.coreRadiusM(),
			params.densityKgM3(),
			params.heatFluxWm2(),
			params.rotationPeriodHours(),
			params.dipoleFraction(),
			params.calibrationFactor(),
			config.years(),
			config.steps(),
			config.seed(),
			config.minHeatFluxWm2(),
			config.coolingTimeYears(),
			config.eventRatePerYear(),
			config.gamma(),
			config.dtMinYears(),
			config.dtMaxYears(),
			config.includeEvents()
        );

        if (raw == null || raw.length != expectedLength) {
            throw new MagnetoException(
				"Нативный движок вернул некорректный массив симуляции: " +
				(raw == null ? "null" : raw.length) +
				", ожидалось: " + expectedLength
            );
        }

        ArrayList<SimulationPoint> points = new ArrayList<SimulationPoint>(config.steps());

        for (int i = 0; i < config.steps(); i++) {
            int offset = i * SIM_POINT_STRIDE;

            double timeYears = raw[offset];
            double heatFlux = raw[offset + 1];
            double coreField = raw[offset + 2];
            double surfaceField = raw[offset + 3];
            double dipoleMoment = raw[offset + 4];
            double polarity = raw[offset + 5];
            int cumulativeEvents = (int) Math.round(raw[offset + 6]);

            points.add(
				new SimulationPoint(
					timeYears,
					heatFlux,
					coreField,
					surfaceField,
					dipoleMoment,
					polarity,
					cumulativeEvents
				)
            );
        }

        return new SimulationResult(params, config, points);
    }

    private static native double[] nativeDirect(
		double massKg,
		double radiusM,
		double coreRadiusM,
		double densityKgM3,
		double heatFluxWm2,
		double rotationPeriodHours,
		double dipoleFraction,
		double calibrationFactor
    );

    private static native double[] nativeSimulate(
		double massKg,
		double radiusM,
		double coreRadiusM,
		double densityKgM3,
		double heatFluxWm2,
		double rotationPeriodHours,
		double dipoleFraction,
		double calibrationFactor,
		double years,
		int steps,
		long seed,
		double minHeatFluxWm2,
		double coolingTimeYears,
		double eventRatePerYear,
		double gamma,
		double dtMinYears,
		double dtMaxYears,
		boolean includeEvents
    );
}
